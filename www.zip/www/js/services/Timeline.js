angular
.module('app.services')
.service('Timeline', Timeline);

Timeline.$inject = ['$cordovaSQLite','$q','$timeout','$ionicPlatform'];

function Timeline($cordovaSQLite,$q,$timeout,$ionicPlatform){
    var canvasData=[];
   var monthlyTimline = [];
   var months= ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  
   var latest_slide_index = 0;
   var timeline_param = "";
     this.setTimelineParams = function(params){
       timeline_param = params;
     }
     this.getTimelineParams = function(){
       return timeline_param;
     }
    this.setCurrentSlideIndex = function(current_slide_index){
        latest_slide_index = current_slide_index;
    }
    this.getCurrentSlideIndex = function(){
        return latest_slide_index;
    }
    this.getMonthYear = function(){
		var query = " SELECT distinct month_year  FROM tbl_master order by date asc";
        var bufferArray = [];
 		var q = $q.defer();
		$cordovaSQLite.execute(db, query).then(function(res) {
			
            if(res.rows.length > 0) { 
				for(var i=0;i<res.rows.length;i++){	        	 
					bufferArray.push(res.rows.item(i).month_year);
				}
                 q.resolve(bufferArray);
                return bufferArray; 
            } else {
                console.log("No results found");
                q.reject("No results found"); 
                return false;
            }
        }, function (err) {
            q.reject(err);
            console.error(err);
        });
        return q.promise;   
    }

     this.hasMasterData = function(){
    var query = " SELECT  date  FROM tbl_master limit 1";
        var bufferArray = [];
    var q = $q.defer();
    $cordovaSQLite.execute(db, query).then(function(res) {
      
            if(res.rows.length > 0) { 
                 q.resolve(res);
            } else {
                console.log("No results found");
                q.reject("No results found"); 
                return false;
            }
        }, function (err) {
            q.reject(err);
            console.error(err);
        });
        return q.promise;   
    }

    this.getDataForDate = function(date){
       var query = " SELECT *  FROM tbl_master where date = ?";
 		var q = $q.defer();
        var bufferArray = [];
		$cordovaSQLite.execute(db, query,[date]).then(function(res) {
            
            if(res.rows.length > 0) {  
                for(var i=0;i<res.rows.length;i++){				 
					bufferArray.push(res.rows.item(i));
				}
			   q.resolve(bufferArray);
                return bufferArray; 
            } else {
                
                q.reject("No results found"); 
                return false;
            }
        }, function (err) {
            q.reject(err);
            console.error(err);
        });
        return q.promise;   
    }

    this.setDataToDate = function(bufferArray){
        
                                var obj1 = JSON.parse(bufferArray.grade_first);
                                var obj2 = (bufferArray.grade_second != "undefined")? JSON.parse(bufferArray.grade_second) : null;
                                var obj3 = (bufferArray.grade_third  != "undefined")?JSON.parse(bufferArray.grade_third): null;
                                var medication_value = JSON.parse(bufferArray.medication).length;
                                switch (bufferArray.stress) {
                                    case '1.0':
                                       bufferArray.stress_value="LOW";//data to be saved
                                        break;
                                    case '2.0':
                                       bufferArray.stress_value="MED";//data to be saved
                                        break;
                                    case '3.0':
                                       bufferArray.stress_value="HIGH";//data to be saved
                                        break;
                                    default:
                                        bufferArray.stress_value=0;
                                 }
				
                                bufferArray.medication_value=medication_value;
                                bufferArray.grade_obj1 = obj1;
                                bufferArray.grade_obj2 = obj2;
                                bufferArray.grade_obj3 = obj3;
                                bufferArray.today = this.checkToday(bufferArray.date);
                                if(obj2 == null){
                                    bufferArray.avg_grade =  obj1.grade;
                                }
                                else if(obj3 == null){
                                     bufferArray.avg_grade =  ((obj1.grade+obj2.grade)/2);
                                     if(bufferArray.avg_grade % 1 != 0){
                                         bufferArray.avg_grade = (bufferArray.avg_grade).toFixed(2);
                                     }
                                }
                                else{
                                     bufferArray.avg_grade =  ((obj1.grade+obj2.grade+obj3.grade)/3);
                                     if(bufferArray.avg_grade % 1 != 0){
                                         bufferArray.avg_grade = (bufferArray.avg_grade).toFixed(2);
                                     }
                                }
                    return bufferArray;
    }

	this.getRecordsByMonth = function(month_year){
		var query = " SELECT *  FROM tbl_master where month_year = ? order by date asc";
 		var q = $q.defer();
        var bufferArray = [];
		$cordovaSQLite.execute(db, query,[month_year]).then(function(res) {
            
            if(res.rows.length > 0) {  
                for(var i=0;i<res.rows.length;i++){				 
					bufferArray.push(res.rows.item(i));
				}
                
			   q.resolve(bufferArray);
                return bufferArray; 
            } else {
                console.log("No results found");
                q.reject("No results found"); 
                return false;
            }
        }, function (err) {
            q.reject(err);
            console.error(err);
        });
        return q.promise;   
    }

  this.getAllMonthsTillNow = function(fisrtMonthYear){
      firstMonth = months.indexOf(fisrtMonthYear.split("_")[0]);
      firstYear = fisrtMonthYear.split("_")[1];
      nowNormalized = moment().startOf("month")+1, /* the first of current month */
      startDate = moment([firstYear, firstMonth,1]);
      startDateNormalized = startDate.clone().startOf("month").add("M", 0), /* the first of startDate + 1 Month - as it was asked for the months in between startDate and now */
      monthTillNow = [];
    /* .isBefore() as it was asked for the months in between startDate and now */
      while (startDateNormalized.isBefore(nowNormalized)) {
            var temp = {id:startDateNormalized.format("MMMM")+"_"+startDateNormalized.format("YYYY")}
            monthTillNow.push(temp);
            startDateNormalized.add("M", 1);
        }
    return monthTillNow;
  }

  this.checkToday = function(checkDate){
     return moment(checkDate).isSame(moment().format('YYYY-MM-DD'));
  }
   
  this.isSameMonth = function(checkDate){
      return moment(checkDate).isSame(moment(),'month');
  } 

  this.setAllDataEntry = function(all_data_month,month_year,monthlyTimeline,current_slide_index){
      console.log("6");
      if(monthlyTimeline[current_slide_index].loaded == true)
      {
           console.log("7");
          return monthlyTimeline;
      }
    
        var first_date = month_year.split("_")[1]+"-"+moment().month(month_year.split("_")[0]).format("MM")+"-01";//setting first late
        var last_date = "";
        
        if(current_slide_index == monthlyTimeline.length-1){
             last_date = moment();
        }
        else{
            last_date = moment(first_date).endOf('month');
        }
        if(current_slide_index == 0){
          console.log(all_data_month[0]);
            first_date = all_data_month[0].date;
        }
        
        for (var m = moment(first_date); m.diff(last_date, 'days') <=0; m.add(1, 'days')) { //loop to first date till today
            
           if(m<last_date){
               
                    var temp_count = 0;
                    for(var i=0;i<all_data_month.length;i++){
                            if(m.isSame(all_data_month[i].date)) //if data found,setting obj to monthly timelime
                            {
                                
                                var obj1 = JSON.parse(all_data_month[i].grade_first);
                                var obj2 = (all_data_month[i].grade_second != "undefined")? JSON.parse(all_data_month[i].grade_second) : null;
                                var obj3 = (all_data_month[i].grade_third  != "undefined")?JSON.parse(all_data_month[i].grade_third): null;
                                var medication_value = JSON.parse(all_data_month[i].medication).length;
                                if(all_data_month[i].stress == ""){
                                    all_data_month[i].stress_value=0;
                                }
                                else if(all_data_month[i].stress == 0.0){
                                    all_data_month[i].stress_value="LOW";
                                }
                                else if(all_data_month[i].stress == 1.0){
                                    all_data_month[i].stress_value="MED";
                                }
                                else{
                                    all_data_month[i].stress_value="HIGH";
                                }
                                 if(all_data_month[i].exercise==60){
                                    all_data_month[i].exercise="60+";
                                }
                                all_data_month[i].medication_value=medication_value;
                                all_data_month[i].grade_obj1 = obj1;
                                all_data_month[i].grade_obj2 = obj2;
                                all_data_month[i].grade_obj3 = obj3;
                                all_data_month[i].today = this.checkToday(all_data_month[i].date);
                                if(obj2 == null){
                                    all_data_month[i].avg_grade =  obj1.grade;
                                }
                                else if(obj3 == null){
                                     all_data_month[i].avg_grade =  ((obj1.grade+obj2.grade)/2);
                                     if(all_data_month[i].avg_grade % 1 != 0){
                                         all_data_month[i].avg_grade = (all_data_month[i].avg_grade).toFixed(2);
                                     }
                                }
                                else{
                                     all_data_month[i].avg_grade =  ((obj1.grade+obj2.grade+obj3.grade)/3);
                                     if(all_data_month[i].avg_grade % 1 != 0){
                                         all_data_month[i].avg_grade = (all_data_month[i].avg_grade).toFixed(2);
                                     }
                                }

                                monthlyTimeline[current_slide_index].data.push(all_data_month[i]);
                                 monthlyTimeline[current_slide_index].loaded=true;
                                temp_count = 1;
                                break;
                            }


                    }
                    if(temp_count==0){ // no data found then setting no data to object
                            var no_data = {};
                            no_data.today = this.checkToday(m);
                            no_data.date = m.format("YYYY-MM-DD");
                            no_data.grade_obj1 = null;
                            no_data.grade_obj2 = null;
                            no_data.grade_obj3 = null;
                            no_data.avg_grade = 0;

                            monthlyTimeline[current_slide_index].data.push(no_data);
                            
                            monthlyTimeline[current_slide_index].loaded=true;
                    }
           }
         
      }
      console.log("11");
console.log(monthlyTimeline);
        return monthlyTimeline;
  }

  this.addNewDay = function(monthlyTimeline,$scope){
     
      var lastMonth = monthlyTimeline[monthlyTimeline.length-1];
      
    //  if(!this.checkToday(lastMonth.data[lastMonth.data.length-1].date)){
    //      console.log(this.isSameMonth(lastMonth.data[lastMonth.data.length-1].date));
    //      if(this.isSameMonth(lastMonth.data[lastMonth.data.length-1].date))
    //      {
    //         var no_data = {};
    //         no_data.today = true;
    //         no_data.date = moment().format("YYYY-MM-DD");
    //         no_data.grade_obj1 = null;
    //         no_data.grade_obj2 = null;
    //         no_data.grade_obj3 = null;
    //         no_data.avg_grade = 0;
    //         monthlyTimeline[monthlyTimeline.length-1].data[monthlyTimeline[monthlyTimeline.length-1].data.length-1].today=false;
    //        //creating variable panelData and using timeout to give time to DOM to replicate result of ng-class 
    //         var panelData = monthlyTimeline[monthlyTimeline.length-1].data;
    //         panelData.push(no_data); 
    //         monthlyTimeline[monthlyTimeline.length-1].data=[];
    //         $timeout(function(){
    //            monthlyTimeline[monthlyTimeline.length-1].data = panelData; 
    //         },1);
    //         monthlyTimeline[monthlyTimeline.length-1].loaded=true;
    //        }
    //        else{
    //            monthlyTimeline.push ={};
    //        }
    //   }
      return monthlyTimeline;
      
  }
  this.getRecordsByDate = function(date){
		var query = " SELECT *  FROM tbl_master where date = ?";
        var bufferArray = [];
 		var q = $q.defer();
		$cordovaSQLite.execute(db, query, [date]).then(function(res) {
            if(res.rows.length > 0) { 

                for(var i=0;i<res.rows.length;i++){				 
					bufferArray.push(res.rows.item(i));
				}  
			   q.resolve(bufferArray);
			  // console.log(res.rows)
                 
            } else {
                console.log("No results found");
                q.reject("No results found"); 
                return false;
            }
        }, function (err) {
            q.reject(err);
            console.error(err);
        });
		//console.log(q.promise);
        return q.promise;   
    }
   
     this.getLastSevenData = function(){
    var query = " SELECT * FROM tbl_master order by date desc limit 7";
        var bufferArray = [];
    var q = $q.defer();
    $cordovaSQLite.execute(db, query).then(function(res) {
            if(res.rows.length > 0) { 

                for(var i=0;i<res.rows.length;i++){        
          bufferArray.push(res.rows.item(i));
        }  
              q.resolve(bufferArray);
              return bufferArray;   
            } else {
                console.log("No results found");
                q.reject("No results found"); 
                return false;
            }
        }, function (err) {
            q.reject(err);
            console.error(err);
        });
    //console.log(q.promise);
        return q.promise;   
    }

    this.setDataToPdf = function(pdfData){
       for(var i=0;i<pdfData.length;i++){
            // var obj1 = JSON.parse(pdfData[i].grade_first);
            // obj1.is_wakeup = (obj1.is_wakeup == 0)? 'No' : (obj1.is_wakeup == 1)? 'Yes': ' ' ;
            //  obj1.last_long_level = (obj1.last_long_level  == '')? ' ' : obj1.last_long_level + ' mins' ;
            // var obj2 = (pdfData[i].grade_second != "undefined")? JSON.parse(pdfData[i].grade_second) : null;
           
            // var obj3 = (pdfData[i].grade_third  != "undefined")?JSON.parse(pdfData[i].grade_third): null;
            
            // var medication_value = JSON.parse(pdfData[i].medication);
           
            
             var obj1 = JSON.parse(pdfData[i].grade_first);
            obj1.is_wakeup = (obj1.is_wakeup == 0)? 'No' : (obj1.is_wakeup == 1)? 'Yes': ' ' ;
             obj1.last_long_level = (obj1.last_long_level  == '')? ' ' : obj1.last_long_level + ' mins' ;
            var obj2 = (pdfData[i].grade_second != "undefined")? JSON.parse(pdfData[i].grade_second) : null;
            if(obj2 != null){
               obj2.is_wakeup = (obj2.is_wakeup == 0)? 'No' : (obj2.is_wakeup == 1)? 'Yes': ' ' ;
             obj2.last_long_level = (obj2.last_long_level  == '')? ' ' : obj2.last_long_level + ' mins' ;
            }
            var obj3 = (pdfData[i].grade_third  != "undefined")?JSON.parse(pdfData[i].grade_third): null;
             if(obj3 != null){
               obj3.is_wakeup = (obj3.is_wakeup == 0)? 'No' : (obj3.is_wakeup == 1)? 'Yes': ' ' ;
             obj3.last_long_level = (obj3.last_long_level  == '')? ' ' : obj3.last_long_level + ' mins' ;
            }
            var allMedName = JSON.parse(pdfData[i].medication);
            var medication_value = ' ';
            console.log(allMedName.length);
             for(var j=0;j<allMedName.length;j++){
                medication_value = medication_value +' '+ allMedName[j];
             }


            if(pdfData[i].stress == ""){
                pdfData[i].stress_value="";
            }
            else if(pdfData[i].stress == 0.0){
                pdfData[i].stress_value="LOW";
            }
            else if(pdfData[i].stress == 1.0){
                pdfData[i].stress_value="MED";
            }
            else{
                pdfData[i].stress_value="HIGH";
            }
            if(pdfData[i].exercise==60){
                pdfData[i].exercise="60+";
            }
            pdfData[i].medication_value=medication_value;
            pdfData[i].grade_obj1 = obj1;
            pdfData[i].grade_obj2 = obj2;
            pdfData[i].grade_obj3 = obj3;
            pdfData[i].displayDate = moment(pdfData[i].date).format("dddd, M/D");
       }
        return pdfData;
    }

    this.storeItemsInService = function(item,headerData){
         var graph = [];
         graph.graphHeader = headerData;
         graph.canvasImage = item;
         canvasData.push(graph);
    }
    this.getItemsFromService = function(){
       return canvasData;     
     }
     this.flushServiceData = function(){
        canvasData = [];
     }
    

}