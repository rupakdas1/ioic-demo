angular
.module('app.services')
.factory('InvoiceService', InvoiceService);

InvoiceService.$inject = ['$q','$timeout','$ionicPlatform','Timeline'];

function InvoiceService($q,$timeout,$ionicPlatform,Timeline){
   // console.log(Timeline.getLastSevenData().then);
    // var pdfData = [];
    //    Timeline.getLastSevenData().then(
    //         function(result){ 
    //              pdfData = Timeline.setDataToPdf(result);
    //              console.log(pdfData)
    //         },
    //         function(err){  
               
    //          });


 


function createPdf(invoice,canvasData) {
        return $q(function(resolve, reject) {
            var dd = createDocumentDefinition(invoice,canvasData);
            var pdf = pdfMake.createPdf(dd);

            pdf.getBase64(function (output) {
                resolve(base64ToUint8Array(output));
                dd = null;
                pdf = null;
            });
        });
    }

    return {
       
        createPdf: createPdf
    };    
}
function base64ToUint8Array(base64) {  
    var raw = atob(base64);
    var uint8Array = new Uint8Array(raw.length);
    for (var i = 0; i < raw.length; i++) {
    uint8Array[i] = raw.charCodeAt(i);
    }
    return uint8Array;
}

function createDocumentDefinition(invoice,canvasData) {
    console.log(invoice);
     console.log("canvasData",canvasData);

function buildTableBody(data, columns) {
    var body = [];

    body.push(columns);

    data.forEach(function(row) {
        var dataRow = [];

        columns.forEach(function(column) {
            dataRow.push(row[column].toString());
        })

        body.push(dataRow);
    });
     console.log(body);
    return body;
}
function gradeTableBody(data) {
       console.log(data);
        var grade1=data.grade_obj1;
       var grade2=data.grade_obj2;
       var grade3=data.grade_obj3;
         var grade= {
                         grade:'-',
                         record_time:'-' ,
                         is_wakeup:'-' ,
                         last_long_level:'-',
                         luckyData:'-'
                         }
       if(data.grade_obj2==null){
              grade2=grade;
              grade3=grade;
       }
       else if(data.grade_obj3==null){
                 grade3=grade;
       }
     //  data.grade_obj1.is_wakeup
    var body = [
					[
                     {text: 'Grade', style: 'tableHeader1', border: [false, false, false, false]},
                     {text: 'Time of Erection', style: 'tableHeader1', border: [false, false, false, false]}, 
                     {text: 'Upon Waking?', style: 'tableHeader1', border: [false, false, false, false]},
                     {text: 'How Long?', style: 'tableHeader1', border: [false, false, false, false]},
                     {text: 'Partner', style: 'tableHeader1', border: [false, false, false, false]}
                     ],
					[
						{text: grade1.grade.toString()  ,style: 'tableContents', border: [false, false, false, false]},
                        {text: grade1.record_time.toString(),style: 'tableContents', border: [false, false, false, false]},
                        {text: grade1.is_wakeup.toString(),style: 'tableContents', border: [false, false, false, false]},
                        {text: grade1.last_long_level.toString(),style: 'tableContents', border: [false, false, false, false]},
                        {text: grade1.luckyData.toString(),style: 'tableContents', border: [false, false, false, false]},
					],
                   [
						{text: grade2.grade.toString()  ,style: 'tableContents'},
                        {text: grade2.record_time.toString(),style: 'tableContents'},
                        {text: grade2.is_wakeup.toString(),style: 'tableContents'},
                        {text: grade2.last_long_level.toString(),style: 'tableContents'},
                        {text: grade2.luckyData.toString(),style: 'tableContents'},
					],
                   [
						{text: grade3.grade.toString()  ,style: 'tableContents'},
                        {text: grade3.record_time.toString(),style: 'tableContents'},
                        {text: grade3.is_wakeup.toString(),style: 'tableContents'},
                        {text: grade3.last_long_level.toString(),style: 'tableContents'},
                        {text: grade3.luckyData.toString(),style: 'tableContents'},
					]
				]
    return body;
}
function exerciseTableBody(data) {
    var exerciseData=data;
     console.log(data);
    var body = [
                          [      
                                    {text: 'Exercise', style: 'tableHeader2', border: [false, false, false, false]},
                                    {text: 'Smokes', style: 'tableHeader2' ,border: [false, false, false, false]}, 
                                    {text: 'Drinks', style: 'tableHeader2' ,border: [false, false, false, false]},
                                    {text: 'Meds', style: 'tableHeader2' ,border: [false, false, false, false]},
                                    {text: 'Weight (kgs)', style: 'tableHeader2', border: [false, false, false, false]},
                                    {text: 'Stress', style: 'tableHeader2' ,border: [false, false, false, false]}
                            ],
					        [
                                    {text: exerciseData.exercise.toString(),style: 'tableContents' ,border: [false, false, false, false]},
                                    {text: exerciseData.smoke.toString(),style: 'tableContents' ,border: [false, false, false, false]},
                                    {text: exerciseData.drinks.toString(),style: 'tableContents', border: [false, false, false, false]},
                                    {text: exerciseData.medication_value,style: 'tableContentsMeds' ,border: [false, false, false, false]},
                                    {text: exerciseData.weight.toString(),style: 'tableContents' ,border: [false, false, false, false]},
                                    {text: exerciseData.stress_value.toString(),style: 'tableContents' ,border: [false, false, false, false]}
					        ]
				 ]
    return body;
}

function  gradeTable(data, columns) {
    return {
        style: 'tableContents',
        table: {
            widths: ['*','*','*','*','*'],
            body: gradeTableBody(data)

        },
          layout: 'lightHorizontalLines'
    };
}
function  exerciseTable(data, columns) {
    return {
        style: 'tableContents',
        table: {
            widths: ['*','*','*','*','*','*'],
            body: exerciseTableBody(data)
        },
          layout: 'lightHorizontalLines',
       
    };
}
horizontalLine = function(width_percent) {
        width_percent = width_percent === undefined ? 100 : width_percent;

        var length = 514 / 100 * width_percent;

        var return_obj = {
            "margin": [0, 15, 0,30],
            "canvas": [{
                "type": "line",
                "x1": 0,
                "y1": 0,
                "x2": length,
                "y2": 0,
                "lineWidth": 0.5,
                "lineColor": "#BDBDBD"
            }]
        };

        return return_obj;
    };

function hederTable(data) {
 
    return {
         style: 'dateTable',
        table: {
                    widths: ['*'],
                    body: [
                        [ 
                      { text:data.displayDate,alignment:'left',style: 'itemsTableHeader',border: [false, false, false, false]},
                        ]
                    ]
                }
    };
}

var at = {
    canvasHeder0: function(data) { 
     return {
             style:'canvasTable0',
             table: {
                widths: ['auto', '*'],
                body: [
                    [ 
                    {  margin:[25,10,0,10],
                        alignment: 'center',
                       image:'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADoAAAA4CAYAAACsc+sjAAACYElEQVRoQ+2bO4gUQRCGv19RRBATEzNBkDMUvdBEDAQVNDC+SBCOMzEWDEzFRIwUxVBEEEPxARqJGJ4XCJcuyoGIL/BR0s7sbc+6t9PTMws3UB3tLlX/zl/P7tpe0fEyMwEPgDPAlobwv4E7ks431KsVDw/V6TKz/cD7lqC7JX1uiVFRnwXRg8By+S0G/Ex84O2R3B5Ja4l6SWKzJvpc0rGUJzGzd8BcKetEU4w2ScY9mms5M4tz1EN33JCeo7mhNabnOZprSM/RGst5juaGludoR5bzHPUcLSzgxagwQuj3V4H5jAz7AVzrxYbBzI4DTzJIDlVW+kL0HHC/BdFBH4k+Aq4nkn5RyvWS6E1JiylEzSyMcsJyoikGmygziw2DmcU56h6dcJgfha6ZXQCWgG0N3RhAngKLkoaAoed1PkrpxKNm9hXY2ZBkLH5Y0tvhB5uZ6Lo3MskelfSqT0Q/AocSyd4CTpSyvSM6kLQ3haiZPQTOOtHRby+dzHW7KkajEuwerQa0h25xdty0fdRDd6MK7KHroVvfnacNx7y91I9QK6cXL0ZejHyv6xuG2rLrVbfoze2HY5XZp59e/PQSLOCjFMAnDBOGzRve7vRi5HvdwgKVjhK9+QCEMUjKugecTBh3vgROpwACr4EDpWzlYvJY6N4GLiVifirlBoqIJur+Jzat6uZiTiOag/mP6HdgR452qTMv6c1Q38z2Aast8ILqLklfIsxTwOMWmKuBaAiDi0B8eT8F8w/wDFiQFF6vLzO7Uf4dZGsKUCTzC7gr6fIYXnBEuMNwBGh6HeEbcOUvh52H5mruj38AAAAASUVORK5CYII=',                          
                       fit:[30,30]
                    }, 
                    {  
                        width: '*',
                        alignment: 'left',
                         margin:[15,8,0,0],
                        stack: [
                              { text:'Grade'},
                              { text:data}
                        ]
                    }
                    ]
                ]
            },
            layout: 'lightHorizontalLines'
    };
},
    canvasHeder1: function(data) {

    return {
             style:'canvasTable1',
             table: {
                widths: ['auto', '*'],
                body: [
                    [ 
                    {  margin:[25,10,0,10],
                        alignment: 'center',
                        image:'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADgAAABKCAYAAADubJfUAAAF70lEQVR4Xu2bd6hdRRCHv59dUROVSNSABawRlUSNgr0EYoxojIKKYkGwRQiKBY0NDJYIsYAisQUL2ENUrNjAElNEQQVFxV6xY4k68gvnhvde7rl3T3s3kTf/JOTunDPf2d3ZmdmJ6LFExNrAOcBkYGsggPeBh4HrJP1RxURVUa6qGxF7AHcC2+Y86z3gREmvl31XzwAjYjSwEFizi/F/AmMkvVMGsieAEbEa8BowNtHoBcCekv5OHL9sWK8AjwfmFDT2OEn3FtShV4D3AMcWNPZuSf4whaRXgC8DexWyFF6UtF9BnZ7N4FPA+ILGPilpQkGdngHOzM6+IvZeI+n8Igoe26slugtgz7hqosH/ZEfFW4nje+tF/faIuBo4L9HgqyRdmDi237CezGAG6AP+2QRn8xJwsKS/VirADNJL9Fzg8jYRjSOYS4CZkv4tA9ezPTjQ2IgYCUzMgm3/7GD7cUlflQVr6fVsiVY1PFV/UAEjYjPgMGArYHPAqZCD6DmSvkg1usi4QQGMiL2BqcARgAPtgbIEuBaYXmW/tQNvDDAi1sniTYPtlPjVHwGm1AlZO2BEePmdAZwMbJAI1nfYDEkXldBrq1ILYET4OY4tzwIOAVapYKCjlnGSnAxXlkqAETHMJQXgzD4uvrJRwCJgd0mGrSSlALNyg6Gcn61byYJ85WmSZlV9djJgRDjqsIu309i/6osT9H8FdpD0acLY3CFFAB0YO0AeTJkr6fAqLywC6Gh+RpWXldQ9StKDJXXT88GIKAL4MXAHsA9wYFnjMr1vgdGS/GdhqXMGHf0/CtzmNEhSRMS7wHaFrVpe4RV/qDJV7roAb3TKI+n7lm0RYe/6U8UzsS/qE8Axkn4u8sHqApwsyWHWMokIV81cPatTPgC8J99MfWiTgGcD16caUmCcM5Cpkman6DQJeBdwQooRfcY4q/gO2CRBz/vyCkkuQeZKk4BvAzsmGNp3yGJnE8AzWc6Yov4RcD9g0EWSvO+XSSOA2Z3fLwXKgi2DZks6NSI8g0+X+EC+W/wcsLObJ2l6U4C+93s15fMPGHO6pFv8bxHhVMue088qIw9JmtIUoAPxm0pY5QzijZZeRKwFXAC4ou2/F5FGAW8HTipiDWAHs54kBwz9JEuib8gqb6mPbRTQ59TOqZZk4xZLGtNJJyImZQH/9gnPbgYwW1Z2MO2KS53sWupgEgz3/twX8FjXUofn6DQGuBswP8XQPAeTqptdhdsJ+d7QR5Lv/V2aXN9xcVEns0aHhoHfW/fnEXEacHOqkX3G9XMwJfQH7tvVJS1J9qKpL4yIW7Plk6ricT6/hkny0q5VmgB0Nayjs8gh8Jl3ZJmUqNMXqRUwIryMPQv+s4y8AEyS5HpMLVI3oGeuaj3T/TMTJP1YB2HdgHbd3oNVxefo+LJlir4vrxvQ3tNeNE/cqZR6PrpP7SBJDp5LS92APv98DrYTh2Iu77uLMPXO4sMM0ilRKakNMDt07RzymuvmSxoXEb5pcr63caLFn7lwJem3xPH9htUJ6NizU61klqRpfntEuH3SDQijEo0eKenrxLHLA0bEZZlrd6qyoEy5PCJ8XeaSYZ4cLemB1o8RsQXwXGLmXhnQy8AxXEu+yRp13KzTgu7YEBARzv+cB+bJqIEOIyI2zWayW3ZQHjDrcPgyYfrtzQzcgl4oyQWipRIRzuDzsu9PJPlOfjmJiBFZecLdT3lSCdApx2MJgO2GuETfgr4UcP91O7lPUm77ZEQ45XHb8jY5+pUA3WzjRpwmxXXMjiWMiJgHHNoE4Nzs3q9JwLGSfGubK00CDnQwdYP6/Brerd+6ScAtgV2zBnE3iTtg3rBGyuclHdDteY0B5ni2OqGvlHTxCgVYM/RESU5mO8qgzmA3Y1q/R0S3mXYpYiNJP3R75goJ2GGmvZe9r0dIOqUbnH9faQBTYHI+TDPnYFmD6tYbmsEq6VLds1HmeUMzODSD7ddNbSWLMsuyr87QEh1aokNLtOouqqY/tAf/B3swt1O/yv+j+A8OwnBpWWrTwQAAAABJRU5ErkJggg==',
                       fit:[30,30]
                    }, 
                    {  
                        width: '*',
                        alignment: 'left',
                        margin:[15,8,0,0],
                        stack: [
                              { text:'Exercise'},
                              { text:data}
                        ]
                    }
                    ]
                ]
            },
            layout: 'lightHorizontalLines'
       };
     },
    canvasHeder2: function(data) {
     return {
             style:'canvasTable2',
             table: {
                widths: ['auto', '*'],
                body: [
                    [ 
                    { margin:[25,10,0,10],
                        alignment: 'center',
                        image:'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFIAAAAwCAYAAACCEC3KAAADh0lEQVRoQ+2bXYiUVRjHf//FUjQS/Gg1SMpAVi9avQhCQyIIurGMiiIQdhEv/EiRZf2CbgQ17QNiCQItCtGCgtrbIKgLscQLUVCUpYWFiKLL0ijdR57lzDD7Mu/MOzPvDPvOnAeGuZjnPOecH8/znnP+5x1RcDOzxcBJ4BXAgM+BI5KmOzk1dbKzvPsys3nAJWBDIvbHkvbk3V+teEUH+RIwnjLBIUlfdApm0UEOA5+lwLoDPCfJM7btVnSQK4EpwEu8mjnM7ZK+bDfJQoN0OGZ2FHinDqhz7iNpsl1AuwHkA8AF4Ok6kP4HHOhZ4Me8V/XCgwxZuQK4CDyeMeN+B34AfgpQJzK2S3XrCpAB5hPAd8BTTUD5rQTVvyXdajRG14AMMBcCnwJvNgoi4f8r8C3wlaTLWWJ1FcjShM1sP+CL0ENZINTx+Rn4QNI3XbshrzUxM1sGHAB2A56prZovaLskXa0WqCszsnKiZvYIsDeU+5Mt0vwXeFvSmWScrgeZgOpn8teBrcDaFqC6KHKisn1PgUxA9dLfCGwKH9+HPtgAXD8xlY+nPQsyCczM/DnqUF2Oew1YXgfqP8B6STN70AiyCq0gzw2Fo+eqGkDHJfljIoKss/IvCsfKl1P8XEgelHQtZmSd+jUzZ/Q18GqK64eSRiLIDKuLmfnz8jrgC1TSJiWtjiAzgHQXM3sfGElxfyyCzA7yBeD7FPctEWR2kPOBP4GHqzTZEUFmBBnK+6Nw3Ey2ej6CbAykq/Fjfg8U7ol8+zMmaV8E2QDIkquZLQFcAJmS9EfckDcBMa1JzMicYEaQEWROBJoME4SN6dK17kxGmtlbwOYG9bgmhzDnm90DrgCnJf1XbbRmdsqVcsB9j7nIKzM7Dhye89Pr/ADLElll12bmSpBf+1basw7yL2Bp58dZiB77JflppmwpiTfiIH1TGa06gXWSbiRAelmPJtwPRZC1U6hlkNvCa8S9lKnvAf6aYKW1DLJPUk+VvJl5CQ9EkC3WTgTZIsBS8wgygsyJQE5hYkbOcZC/5DS+IoUZBBbkvWoXCUA7x9rQPtIVjL52jqbAsQck3UwcEd8FDibmNOpHRJeMPK2jzSbwt4s5SSktSI7+N5NKe9FBPhNkof5IskzAX9kbluTv/MwyM/PqPQ+8EX74RNLOkrDr14xrorA7g8YfdROSbtdKLDN7FLhbktnuA8ZSbJkJch9BAAAAAElFTkSuQmCC',
                       fit:[30,30]
                    }, 
                    {  
                        width: '*',
                        alignment: 'left',
                       margin:[15,8,0,0],
                        stack: [
                              { text:'Smokes'},
                              { text:data}
                        ]
                    }
                    ]
                ]
            },
            layout: 'lightHorizontalLines'
    }
},
    canvasHeder3: function(data) { 
    return {
             style:'canvasTable3',
             table: {
                widths: ['auto', '*'],
                body: [
                    [ 
                    { margin:[25,10,0,10],
                        alignment: 'center',
                        image:'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAABOCAYAAAA3vqZVAAAGcUlEQVRoQ+1aachVVRRdS7NsNssmG0jKtIFQmjSLguYky9IyGiCL0jS1keaSBikqtTQxacAszWwerDSQkqR5INEymqW5rEzNcsV63fuxvb53373v+wJ/uP+I7+x91jl777On+xE1SFJPAA8C2LUWT43f/wHwKoD+JH+oJcsc4DcB7FsSNLKPInlFI8CvATioGcA3kLy+EWCDGrwR+t4mIvl7I8BWs9XdCC0h2S5PMM/G/QA8GoRfB3BbzmaTAWwc1tuT/KWRG18K4NYgOIbk8Bxn/BDAXmG9O8l3GwEeB2BwEBxOckwO8DMAeof1viSfaAT4WQDHBcETST6ZA3w3gAvC+giSoxsBLqU6SVnTjCY5ohHgJQA2C4Jbkvw558b9AUwL64+TPKkUsKTNAfwahJaS3CTveUg6EIA9P6W3SO5XFtjeaVWntIBk1zrAHQF8HXi+I7ltWeCjAbwQhF4meWQd4FYAVgBYL+ETgLYk/6omVzWASDoHwL1B4H6SZ+cBe03SlwB2DHy7kPy8DPB1AGKAv5HkNQWAbWPbOqVeJOeWAb4HwPlBYDBJ/5ZLkmYA6BuY+pF8rAywA0WfIJAbhVI+SdkgMpSkf1uDatk4q7KeJONTqXpzSTbHyLBY00S1gD/JlDzOrZ8WUPV5ACYEvgkkB5W58U8A2geB3BQXVJ1NpdNJOqIVVvXK8B4t1JrkqgI3PgLAS4FvJsljCgFLcgAwcEorSLatB+p1Sb2SCjNln0Py0KLA2wFYHJgXk3Q4rEuSHFbnB8b5JPcsCnwKgKmBeR7JHnVR/7vxpgCc1VKndY29PUkXf6vRGl4taR6AAwLXTSSvLgKcqDsrfzPJq3KBJR0P4KnA5BPvQfLjEsDZJ7UUQKfsrZtuLMnZ5T0AeweQySTPLAqa3Hh9AD7ozkFuLMlhcZ8IfBaABzK37UrSwaQUSToXwMQg5NTYheRn6W8VYEn+16eMDdokkt6gNCVP0t69WxCeSNJmqFAKnE38yyxE8pvSqImApGwUs607krTXNwHboexYKTV823SDxGdspk5h3wtJ3lUBlrRBUtjF6JTbBRTVQpWSdxZJh9UK8CEA5oTNFpLsUnTzPD5JOwD4KvD8CaAdyZUGzubQ1ZyguQeQ5HQa1V3J7QbO9jynk5ySBZTkLHMZgN8AuL15B4Cd8jAAfwC4uFrOluQn6qea0jCSYw38QSZodCPpQNJEiTlecXrM0YBfwD4kncuj7CWZ9vZOkhcZ2AOSrQJvB5I/+v+JZzpBOGnYXvVoJgB7blPQkXQqgEeC4FSSAwzs97VRWHARvkKSq0yXuTW7gZxTWIuuTOdKcsdp06T0NMk+BnZlkYZOkWwlKW8MMR1ABwDbAPgIwE4A9q9yCKvch/armR3WK12Jgd1qpLSKZGtJLtDGV9nMo4nTSDprVUiSi4QXAVRL+J0TE9k/UppN8vCiwB7CXElyVjX1SnLwORnAWABbBJ7SwHYGO0VK40gOqedZkhYA2D3wDQTgjFT3xla72xCfPtL7BUdPJ2ReiB3XUfHYeqqud6mWWK9q45bYuN4eaxewbRydqt7pi6z7mV1bz8aVd1xkt6I8kpxE6nr1OuCiGq3Jt07VzlTVkoRVFofjzVY1gK0BxB557QogLXHDenusXTd2yHQKu919cTi6S+BqFUn2dp5/xqLwYQCuv0YVCpmS/C3C3yRS8gD8DHcAtfQoyZ97nLddg6XkosClUbGQWaPm8nR+CMlYqrrm8pToFgBuvNtkDla69MmOJNL9bIozkuFbWmV6Cl/t24O142q0e5kbu3jzIPWoei5aY90HvJ7kyNIhM5kS+FOux8BDq6ixGqbbGPe/M0guMkNp4LirpMsznlkN9G8AB5P0uKmJmgvsTsPPyW2NbefOIO0WbUODDiI5KXuiZgE3eZbkYn05Sc9IKiTJTraMpNvXNahFgBtxtHXAMR8vB+DJT0ptSNpZWoQkORa4YU/pOZK93S1+kYmvnRsZI9Y6ZdLgx09H95EcaODnAcTxfe7n1zJqSOL4GwC6BTkPae4wcHbM6wmBpzvj47MpAxie2Z0ABmRkPapcZOANASzMfBM0rwOF7d8o+bNvdhA/jWSlRUqHqG4z7ACeNf9f5I+bPUh+2wScqMafaR9KUllLg7/tZj9+WV1NFUkV4erDEztPcuIzK3sY/w2I/9jIE4YpcWDjjf4F8AY7fIznRykAAAAASUVORK5CYII=',
                       fit:[30,30]
                    }, 
                    {  
                        width: '*',
                        alignment: 'left',
                        margin:[15,8,0,0],
                        stack: [
                              { text:'Drinks'},
                              { text:data}
                        ]
                    }
                    ]
                ]
            },
            layout: 'lightHorizontalLines'
    };
},
    canvasHeder6: function(data) {
     return {
             style:'canvasTable6',
             table: {
                widths: ['auto', '*'],
                body: [
                    [ 
                    {  margin:[25,10,0,10],
                        alignment: 'center',
                        image:'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAYAAABV7bNHAAALM0lEQVR4XtWcebh21RjG79tQmTKlQaWPMlMhCoUSmnVpTgmJZI5QpCKzZMoQIpkriZIxMymzzGOGkLHIGLfrd6z3XOfss/d+997v+37f6bmu7/r+OGs961n3ftaznmm91jKkJFtKupekLcq/tSRdVf79QdKFki6QdL7tn8xyC54l8z68k6wm6dGSniDpNh3nRtInJL1O0tm2/9NxXudhywKgJLtJepWkjTpLvnTgNyQdZvsLE/BYMnWVApTkOuXrHzSlTaFRr5X0FNv/ngbPVQZQkvUkfaDYmGnsZSGP8yXtaftPkzJeJQAl4Sh9StKKSTfQMv9Lku5r+5+TrLHSAUoCKIDTZm/+K+kcSedK+oqkX0i6hqQ1JW0uaWtJ+0hae8zmT7P9sKsNQEluKemTY8B5j6Sjbf+wbWNJriVpf0nPl7RBy9gn2eYCGEQrTYMKOGjOLRok5SiwmTf02UmS60k6VdIeDfMul7Sxbfyn3rRSAEpyq3KsNmyQ8K+SdrT9ud47kJSEfbxT0r4N80+w/bQhvGcOUJKNCzhNx+DKAs5nh2xgNKe4DJ+XdJcaPv+QtKHt3/ddY6YAJdmk2Jw2cHay/Zm+gteNT3JPSU2O4iNsv7XvOjMDKMmtCzjrNwj1N0k728YuTY2ScPPtVMPwLNsP6bvQTABKQiyFs9YGzi62udGmSkn2K/aoypejvKZtXIjONHWACjhs/OYNUvxdEuAA4NQpyU0k/a74TVX+69n+TZ9FpwpQktuWY0UYUUeAs6ttIvCZUZJfS1q3ZoEtbON4dqapAZTkduVYNYHDTbKb7Y91lm7gwCRfl7RZzXQ+Dh56Z5oKQAUcjlXdV0MYwHmw7Y92lmyCgUkulnTHGhbb99XeiQFKcvtyrNZp2BMeMuB8ZII995qaBK8ZW1SlzW2TN+pMEwGU5A7lWDWBgyB72H5fZ4kmHJiEUOaSBjbr2760zxKDAUqCCnMTjYuoP15sDwZ65pTksSVpVl3rUttNbkejXIMASnKnAs7NOu6YWwsDOVOQSkz2ZUl3rZHrVNsP7yjv/LDeACW5c0mUdwVntNjMQUpCRH9GAwgH2H7HTAFKsmkBhzLMEJoZSCWFi/bUOagEqRvZJrzpRZ01KAl+BfakCRxuK7J8ZPDaYp6pg1QiedwM6ml1dJTtF/ZCpgzuBFABh43dtGGRfwGK7XOTXFvSu1cWSAUckv/bN8hG4n6F7StmAlAScsBoThs4XOXzHurKAqkDOGCyl+0muzQWs1YNSkLyCXDqnC6YU3uivMIXXESzBqkjOCfZfvxYFFoGNAKUhKsScG7cMB9w+DpnN/GfNkjFvXiApHtIujdZwpa9IR9J/Q9OUvqpBSjJ3SQRVLaBs7ft94/7OpOClOSGkg6V9FBJuBh9iXw3x//lti/qO3kJQOUrkR++UQMzuiz26RM+DAEpyQ0kHS7pyS2y9N0vJ+LZtikqdqJFACVBY0CZRHsdAc6+ts/sxH3BoD4glePz5pYSUd/lF44no/jKAtRYv2geoCRULj8k6UEt4Oxv+/Sh0nUEiX4fykSzJgqThD/fb1toIUBY+1c3DKbvBnDeO6nUHUHquwx+GHvBB+tDf5S0u+3GktMcQEmuK+nHDQkvWkoAB+dvKjQhSNgPbAmbIrS43PZV5QQQZlDepjuNk7CNJErUbUQE8MCm0tMIoKdLenEDF4wa9e+p0gCQSLgd36f6mgTASH88sTQ+NO3hMtpwbNMksYhGAP28waf4sO0dp4rMAmYFJC6FuvzxaORPJR3UdgzGyVeA+tqY3BXauI1t0sPz5BKh16UhOVqkKL85ToChfy/OKA2Z12zgQQ4bZ3RQHFXMB0pAQ8QhHeQ8xfbBVYCOKi0k1fnn2N61A9NBQ0r7CuDU1dLhiSux3yStdCWB9vrSHNpFTpSCo/bV0WA0qKlUe4jtN3XhOmRMEtIitK3UEceO7rDBGcgCDt2vj+kp33m250vXAMTZJGKv0ia2udmmTkX4b0uiIlKl36JVtin+DaLC/6RioJt4EIJcv+GPW9umU0QARCm2riqxxiRBXtvOkvCF0Nw6Otj2KYOQKZOSAM5hLTywubQef7EhAzmvRQCEH0AT90K60nYTupPIPjc3ydskHVjDCG3GBvRqMFjIJ8lrJD2uRUgune3oOEvySEmENFXC8VzL9l8AiDpRXbl4JhpUOurxO4jSq3Sg7bcP/QJJiATa8j/fKuDMNVIV5/KXDfufq+e12SD6+qb+DiLJVkW1qzjQnrKObf7vTUkIQHEIm2gROKNBSU4sGYPqvLkrH4DIlexcw3Umt1iSppjvDNt79Ubm/5rwChpAW+ZSq+dY0RaziJIQlswZ5ApdYnsFANHc+NKaAVP3g5LgEJ4niaxglY60/aK+ALVowIgVt+W2deCUY7aGJLSWbMZCIkBfDYC4ar9TIxhOE9dtr2J/0wYLOPg9ZAbriKaqpputdkKSE0pSrWlZ9gU42LxGSvKjhhzYuqNYDH+nLgeDq7+DbcAaTB3AgTcfg76eTpTkZZKe2jL4uwUc/KpWSkJJa7uaQZuPAMJnwHeoo2NtHzdukQk0ZzR1s65xXxJMQlvfc2dwWDwJ6ZP71+xh+xFA+EFk1uoel6A9dMA3JdPaVJfnTvg8e3YAeFPb3DTjvvZLJB3RMuh7RXM69yImoUtl2xqeWyzMKB4g6bSWhbEfh1bTAS2ac3dJJzeEMXXTxtqgJBjxZ7TIyEe+X99GzSRoHC2EVdqgmrR/i6S2FhGcKq7Uk/Eyq9yK44WqEiBSn+9U2i58jrCNXamlJNTWn9kCzg8KOL1iuCSrl1usmnLh5KxeBYjBn25pAhjJR3iCb4FRJeLmiNJVj9ZQrhlC77JNoW8JJXmBpCPHgMNt1at7DH5JeDhcVy+7zPY6dXUxwg6sel2kPWTj1Tk/a7B1aOTa1SOc5HhJz2pZmOoEx6o3OAWgpmN7uu29myqr1OIpKfNwbZp0FulTSYBUV+9f1M+Y5HnUr1oEwH8BnF8NEbKkRZCl7onW3NuOtto81YDnSCLj2JQS7SoXKdPnSjqRSD0JlwGXQpUutD3X45OE8Ue3LIDvBjjYxUGUhNu1rs6H/VkXB3OsES2drBhI0q9jx1ckxYUnOj/G9rzDlmQXmgoadkUTFt2zx8wYHOwttxdloipdYJuXQ903XF7vcMPdRxLNDfg4dUSPMkaPOtqZtsncLaKi2gjH04UqtWX6GEuGAc1ZUqLpo0ZJjm35CBQT57pW+mrEnAwl4U6/Im21BHnw4Ta7uKs9SPIoSW/ssylJlIDIVU8Kzu6S6N2u2//8MR8MUM9N1Q4vNTGqB7QUdyHAQXOo4Q2mJPQW4Tnz1rWOFj1XGKRBg6VbetQwyLwQrKYaqktw0wBOUwd9J5GSoDm0AlNqryOarchVz9MqBagc13GBJ8NoEMVFGESlCYvUyKKiYIUZnviWtv+83ADChaBTjZutjch8Upvv3PxU+p1I4JNtbOvt5un4VrYJdBfRKtegokXYA0IcbsdxhN2iPZAUxUW22dwclTf0/KIDaVQAJ3PZdJxG08gc8o6N3qgltCwAKpuj5Y+rFTeiD7HB0bFoalVu4sc8ei0bH/ktG4AKSDhvPN1u+oGAPsCNG4vNQXO6dZiN47Yy/14KevzeRtNVPIk4tAdTXDxu4fFsYrisNGihkOUndEhz8Mx7WnJiZw4fpzUL5ZjWwpN80da5pdufgiDHjhJNX6IWxu968F6M0nYvWvYAjXaTBCO+A7/zUTrtSdDV9R+Si6ZURQ2en7ygS4725UF0tQGouruSKqWvGz8KoPj/iiE/YNKG3P8AAvT/Pw7DpBUAAAAASUVORK5CYII=',
                       fit:[30,30]
                    }, 
                    {  
                        width: '*',
                        alignment: 'left',
                        margin:[15,8,0,0],
                        stack: [
                              { text:'Medication'},
                              { text:data}
                        ]
                    }
                    ]
                ]
            },
            layout: 'lightHorizontalLines'
    };
     },
    canvasHeder4: function(data) { 
    return  {
             style:'canvasTable4',
             table: {
                widths: ['auto', '*'],
                body: [
                    [ 
                    {  margin:[25,10,0,10],
                        alignment: 'center',
                        image:'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD4AAABICAYAAACuukaYAAAHfElEQVR4Xu2cCYwlVRWGv98N1LjvSFxARDQqIkgUMEYFl0hEkE1FRSFRHBcIDhiVLSYiCEEjGJiJSkAgCoqKAm4jCopEcUHRGHdxiyJoxF1/80/fmtyuea+76vV7nRdSJ+n0TFXde89f95z/nHvrnharILa3A54LPBnYEXgAcB/gDsAtwB+BG4BvAp+X9J1Zq6VZDWB7S+DVwKuAnXqO80PgXOAsSX/p2bbT41MHbjt9vgZ4G7BVJy3GPxRrOBV4t6R/r7CvRc2nCtz2NsAHgaePUPJW4GvAdcAvgD8B/wPuC2wN7Aw8DXjgiLYx/VdM0wWmBtx2wF5afLfW/QrgbOAzkv5l+0HAQ4s13BH4TX4k/dp2/v+s4iL7A7V+/wBeJumSacz8VIDbfhFwIbBFpdQ3gDdJusb2LsABwD7Ao8YofhPwCeASSRtsPwE4vbyIpkksZI2k968U/IqB2949TFyBNnAycDwQNn8X8IKein4FeHNxiyNLf3cufaT/AyRd3LPP6fm47YcD1xc/Tcf/jZlKOtf2scA7gJjvpHIGcDSwJ/Ax4K6lo5j9bpIy9kQy8YwX9v5cyxQPAT4KrI8/tjSKL0f5+PwLgcPL/cuAAEycj8ts22p3JXBgIb+0vVO5/73kBeGNSZCPBG47CcYehYBqv63HiK8mbDVyqqS1ts8HXlpd/1sJSadIyr+xHeAhwkh89sxyPeZ8RHGTJDiNfBF4DvBa4L3V9YuAcMkoSfj7XSKJpF+1H1gE3Pb2xSf3LllV15f53ZKkxCzj37VcIel57Y5sJ6m5m6SrR9xbBxzWun6mpDW2M+t5CX1kA7BW0qaXtAm47TDuh6NMnx4zgSVuJ04n3iYNbctOkr5VX7T9SGBLST9oXX8wEIYfxQ0B/LOS3o6zxHHq/6dYV0LrQpy0vRsQc7pLq1USjaVSxr8D6yStt/2pir1vA34MPBGIeW8tKVnYRrEdsrq8gHtlyLC6Fx/OuMn6AjIAmwzw28WyMkmxrnssMUmZwCRUtVVnkvZPLiDbGej7wKNLJ4mVp8XkJd3cZfZt7wpcWz379mLymaHrJf22NauJzwlTkYslJVnZJLaTzSVMfrYQ24eq21G8Uyizfc/CQydV4TYLom0DPIN+pOr4iL4Jgu0aSIhke0mxhpFiOwT1+nLzUklh83HPZsbim81CZ7MXtdzk2A5nfbJ67qgAj5m9vFzMsnAXSTGJzmL7J8Ws0iYLiiQfY6UP8HRi+w3Ae0qHfwXuL+mfnRVc6CNRJNEksiHAvwo8tVw4TVJ8p7PYfljxyabNnpKSyU0TeKJNlqqN7J5UuLOSC8DfWPKFNLspwMOqjymdvE7SWT07zEvLy2vkrcCnl1pJ9Zlx28kXkvK+M1GgDHKgpNo9l1W5Ze63tYFP4t/7haBaIyel3E5SwtJm0hW47TDzL4H7tTo5UlKyvc5iOy8vkScyFeDJ0pKttWVnSeGMUcCPA04sN9ZLatLXRc/aTkxPqtvOMN8iqZ0oLfkSZgH8mcAXqlED9jJJJ4zTpISrpKl3L0lFZnWk2F5TyDd7dc0KbVHs7zLtswAefqizrx0k1UTURa/lZuteQHKKJpvbS1IWSJ1lFsCT7SUpaLKo3gS5nPYtYkqo3UpSFiCdZerAM7LtMGyTfV0tKSu7qYntC4CDS4fXSmrCb+cxZgX8JWWB0yiyF/CIEibPGLUsXEpj22Hxo4olfalkbs3i51hJ2dXpJbMCHnOPn2dREEm62uyWXCSpma1Oyto+pWw9tfvKCnCbesHTqcMFq5xuOGsGth1wMcm2jA1X45S2XYe7+rFjJOWl9JZZAk+szWrq2ZVWyasfO4Gph8WzYsw2dCPZ7NhVUpKj3jIz4NGkxOd8MKj3za5KHJY0NlbXKIp/nwPsW11P1Mji6ee9EZcGMwVewO9QZj5fRxrJSuoD+bAwLoe3nf2AfGfLnlu9wZANjL37LkraL2jmwAv4h5TNxKeMmKGkoNlJ+X3Zjk5a+jggW1Ft+VEBnd8rklUBXsBnJZW99Sxzk5r2kWwZ52vJ8ZL+3KfhuGdXDXijQFloHAO8uHwcXArHH4qlnCzpp9MAXOkxm3C2nJLlA0QOBiSraz4aJinZ+NEQ+DpwjaTs+U1dVn3Gp45gwg4H4AsvbuUbERNOwKo3G2Z8mPHFu6y9NxtX3WYnHHAw9cHUB1PfaAODj0/IIXPbbCC3gdwGchvIbcXnROeR4QZyG8htILeB3AZym0d2nlSngdUHVh9YfWD1gdUnZdB5bDew+sDqdgpoUs4YSaVOqndvd2L7oFIGGmy35Nh2Xc50oaQc1rvdie0cClxbgN0Y4CmcSbFKJMezHr+S00Xz+MZs37scH2uqmdYFeCoAciqxKV3MyYT9UtY8jyD66mQ7FYs5T//8qu0eTd1ZXRWU+zk6eV4pmJ3JnyroC2CC51PdkDPuOXFZ/+WCj0vatwGes6g5/z2q0n+CMee2yY2lCvnWusQyx7PeVw7ZTVxlPLeQF4p4D5UUa96s1iPHMp+UB4BnLFNNPMcYN6rWVBOnTOs8SV+uFf4/8hshZbVlqeAAAAAASUVORK5CYII=',
                       fit:[30,30]
                    }, 
                    {  
                        width: '*',
                        alignment: 'left',
                        margin:[15,8,0,0],
                        stack: [
                              { text:'Weight'},
                              { text:data}
                        ]
                    }
                    ]
                ]
            },
            layout: 'lightHorizontalLines'
    };
},
    canvasHeder5: function(data) { 
     
    return {
             style:'canvasTable5',
             table: {
                widths: ['auto', '*'],
                body: [
                    [ 
                    {  margin:[25,10,0,10],
                        alignment: 'center',
                        image:'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADQAAABOCAYAAABvwTVMAAAH00lEQVR4XtVbBYwlRRB9D/fD3S24u7trDrkQPEAgeIAEh+CWIEeA4BwhBCc4weG4w+VwCe7uDo+8Te/m72z3/Jn/e/buKiFctqu76013V1e/qk+MRZG0CIBLASwP4AUA+5F8tRuT2E3nbvpKmhPAcwBmaRnnYwALkvyr07HHCiBJkwF4HMCKEcNXJvnM+AboagC7JYxehORb4w0gSQcDOC9h8G8Apib533gBSNI6AB4AMFHC4NEkV+sUjPsN2hmSNE9wAjOWGHwRyf3HeUCSJgfwJIBl2xi7D8nLxgdA1wHYqYKhK5K0K+9YGt9ykg4HcHYFC/8BMBXJPyvoJlUaBSRpQwD3ApiwgpGvkFyqgl6pSmOAJM0P4FkA01c0cgTJ1N1UcYiGvJykKQGMBrBkZUuAQ0mm7qfKwzSyQpJuBLB9wooHAWwQaVuH5GOVLU8oZgck6WgApybmOwfApAAOLLQLwHQkfxynAEnaFMBdACaIGOaV2QTAowDWKLS/R3KBbsFkjRQkLQTAUfK0EcPeB7ACgO8BeBWmLujcQnK7cQaQJBv4FIDFIkb9CmA1kmMC6LcjOseSTG3TWji7PkOSPMatALZJzLwDyZvcJmkHADdE9DYneU8ty5tyCpJOAHBiYvzTSdpJ9Iik0wEcGdGdneTnYx2QpK0A3J6I2h0hbNH6tpF0P4CNCoZ/SXLWHGC6cgqB4HgawDQRY97185rkD61tkr4CMFNB/z6S9o5ZpKMzJGlI8GgLR6z4BYB5gdcLYOYA8ElEv9+27BZVbUCSfMfcAWDzyOS+IIeSvK3YJmkLAHdG+uxI0pFFFukE0CkAjknMfhJJO4kBIuk4ACdFmhYm+U4WNHWf4JKGArALjn0If/2tSXqVYoC8akXX/jOAIak+nYCsvEKSlggR9FSRid4M5+anlBGSPgBgXqFVRpJcsxPDU30qAZI0XXjbxOItg1ipjEsL/b+LGDGc5EGDCig4Ad8pxfvDdnh7bUXSAWlSJK0H4KGIwp4krxpsQGcBOCIx6XEk7SRKRdJhAPx0KMqyJF9q179Oe+mWkzQMwPWJAR2/bVflQEtKsT7nA/gjrLTZ0tR/3gll7aaOnzDJnwQkaZnApU0RAfQagFVI+hJtK5J8yS7aVrE7hRcBrBcFJMnspgmOeSNzOJxxWOPwpq2ETIOfELFHX9v+NRVOHABIknlnB5E+yEXxsjvUv6/qRIE1NQk/GDIiBuhcAIckZj+S5Jl1LZPkt062ALRk/qH9AEnaBcCIRIcbSe5YF4z1Jc0A4MIAyq9bz1vpDqwxnzmLjfoGleQ850gAzq4VZQyAVUlm3zrhxdsLsPh/n7vWvzmIja20uYolSX7aA0jSzCHVMVcEzLfBCZjoGGsiaQ8AVyYMGEay52lPSROHWzwVUzmRa2Kj3V1Qdk+47T0AV5D8ou5XkTQfgJcjbJGHupbkrr1jGlAZMVh37nb6n4at4S1SSULo5QTz6pEOH4Xx+oJiA/IfY1ut0oQdKB1C0hFCJSn54F71dUkabJ8YkAsdFq80eh6lyhycpOUC3+djUZQzSQ5gkAzI+89p9txuNAW/j6cr+z7hQn4+ETI5oDVvMaBAo9fLOSrYOlR12FX2usvYv8vaPF5vH1eI+DAXZTGSb7RbbEnDARwQ0XMwu3yRhOlzCu0G7rQ9QUD6i05J0unHpEjaOGT+YrvmIJIGG5XGtpmkm80AFWYdQ3LpNmAcVbwCYLaInmscNi57sjQJyG+UIm93Hcmd2wCKfQh38RPe0cBnZf0bARSeDH4rFZPFR5E8I2WQJOdY7aBiUsmZNAXIcWGs3mDLFP8gyW8vRwMxavkakrtXOc9NAUp96flIms7qJyEacH61mNmznvWXJpmkyFoHawqQCRETI62SJBUlHQXgtMgKOBpwMvmJKqtjnaYAxdImT5FcNbI6rv9xFiMWDdQm8psCZE9UdLuXk9y7FVBwHq41jREoJj0cDfxddXUaWaHwOv0mYsSAoFTSBZEUv7v+HqKBthFFcZ7sKxSK/B6JAFqf5MO9f5dkJtZkS8yGA0n6yV5bmgDkogp/+aLMQtIZPL+QXf/jaGD2iJ7P36ZVCMwY2iYAuQ6731kB8DVJP/N7RJJTMrG6BD/3HQ10nEBuAtAoEyqFr/cIyR6eLzxXrknsJWf/TDF3LFkBBQYnVilyAcmDQ92pGaRYNHAVyT07RhI65gbk8CXGDu1jgiTU+cTIGPdxNODLtyvJDWjLkFAuGuXS5bUAxALTfwGsTdJFtl1LbkApBmntUK89ScTiU0ke2zWShracc0nOKbWKXbUv2lhhkzkDM7K1ooEy8LlXqA6D5GhgOZJOOGeTbIAkeTv5URcLMmMG70/yomxIcm85SS6YtUuuIveS3KyKYl2dnCvkynnnUtuJz5Ojgdocd7uB3Z4TUKoWrmjHtiRdktaI5ATkWoVYQVOr4c4+7NUIkgbO0IcA5i4x1ukURwOVMuedgs6yQpIcm5XVXDsaWJOkq+0blVyAnLtxOjMlJ5M8vlEkObecpH0BXJww2PUOLnMu5bNzgc21Qn4ux35q5iSz63litdq5MPQbJxeguwHELkr/cviSRixPDJoLkH83V3THd5N0nemgSi5ArlR0rrPXbfs3EJuRNEcwqJIFkC0OP4JaNwSoo7r5PXc3X+B/ELq54UaFiScAAAAASUVORK5CYII=',
                       fit:[30,30]
                    }, 
                    {  
                        width: '*',
                        alignment: 'left',
                       margin:[15,8,0,0],
                        stack: [
                              { text:'Stress'},
                              { text:data}
                        ]
                    }
                    ]
                ]
            },
            layout: 'lightHorizontalLines'
    };
    },
    
};

function getCanvas(data){
   return{
     
            image: data,
            fit: [515, 400]
           
           
   }

}



function convertImgToDataURLviaCanvas() {
   var url='../../img/pdf_logo.png';
  var img = new Image();
  console.log("img",img);
//  var dataURL;
 // img.src=url;
  img.crossOrigin = 'Anonymous';
  img.onload = function() {
    console.log("in");
    var canvas = document.createElement('CANVAS');
    var ctx = canvas.getContext('2d');
    var dataURL;
    canvas.height = this.height;
    canvas.width = this.width;
    ctx.drawImage(this, 0, 0);
    dataURL = canvas.toDataURL("image/png");
    console.log('dataURL',dataURL);
    canvas = null;
  };
  img.src = url;
 // return dataURL.replace(/^data:image\/(png|jpg);base64,/, "");
 //return dataURL
}

    var dd = {
         content: [
        {    
            image:'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAZ8AAAB8CAYAAAC2Rb0MAAAgAElEQVR4Xu1dB5hVxdn+tt0td3vvLEsHaSogIl1Q6aJGTYxo7L/G2KLGrjEmtiS2WGLFEhMVlSogIIKooEiRKnV7773+z3vu3uXu3XPumTnlFph5njxq7pyZ+d45O++Zr/p1dnZ2kmgCAYGAQEAgIBBwIwJ+gnzciLbCVF/m1lNObavnF8KxgqxIC01LD+N44kTXlcfq6GiNe+QN9Pej6GB/irIESP+MCcY/bf8eHOCnaf3iIdcIvH+ghprbOwyDKT08iGZmWg0bT+tABypb6JvCBq2Pyz43OyuCksICDB3TVwYT5OMFO3XX5hL6Or/eC1bCvoSp6VZ6ckIi+wMOPb1F3ghLAI1OCKGxSSE0JimU+kYGaZJHPNQTgXM/zaGalnbDYAkN9KeV8zPJGujZj4U7NxfTpnxjyefVaSnSO3gqNkE+XrDr3nIY80BxMpCPs7wJoYESCYGMpmdYxc2I54Vw6Gs0+WDoe8+Mp4X9IjSuSP9jJY3tNH95LrV3GGulEOSjf2/ECDoQEOSjAzyTHo0NCaDfDo6mi/tHCBLixNgM8hkcG0yLZ6RyrsS47m/sraJXd1caN2DXSIJ8DIdUDMiDgCAfHrTc2zcuJICuHBItfXULGxEb9maQD2ZePDONBsdY2BZhYC/cdRYsz6PCeuPtlIJ8DNwoMRQ/AoJ8+DFz9xPxoYF084gYmp0V7u6pfW4+s8jnwn6R9Kcz49yOx3dFjXTrxiJT5hXkYwqsYlBWBAT5sCLl+X6XDYyi20bFkr9nbd+eB8LFCswiH2uQP62cl0mhbnY8uHdLCa3PNcchSJCPV7/KJ//iBPn41h6fnRJGfxmfSNYgwUByO2cW+WCu+8ck0Pxs990+y5vaae6yXGoz2NHAjpsgH9/62z/pVivIx/e2FHFOf5+YROnhgb63eJNXbCb5DIsLprfOdZ/jweL91fTizgrTEBPkYxq0YmAWBAT5sKDkfX2iggPojXNTKVMQUI/NMZN8MNH756XRgGj3OB5ctDKPck0MABfk431/16fUigT5+O524xB889xU4QnnsIVmk8/FAyLp7tPNdzz4saSJbtpQaOrLKcjHVHjF4GoICPJRQ8i7f1/QL4LuOzPeuxfpxtWZTT7hFn9aNS/TdMJ/4LtSWnO8zlTkBPmYCq8YXA0BreSDQMg+EZ5JCXN6YijdcFq0mmiyv2uVFxkIWNUtTe2dVNnUTpXN7VTT0kEdJufPfeysRDq/j+fzj2naEIMfMpt8sNyHxiXQHBPd3qtbOmj20hxqaTc2o4Ez1IJ8DH75xHB8CGg9jC/ICqdHxyXwTeYFvd0tLxyVShvbaVtxI31b1Ehbixuputm43GOAFPnH3pmZSlke+hjwgm3tXoI7yGdEfAi9Pj3FNLH/c7CG/vFTuWnj2wcW5GM6xL4/QUdHB5WUlFBlZSU1NTURKlEEBQVRVFQUJSYmUkiI9uSA7j6MPb0bnpYX37Lbipvold2V9HN5k2FwIEEkDpNTvbmDfIDxhxekU7ZJyWAvXZVPR2taTN9KbyQf/H20dnSSxeRgNpFYlOH1qq+vpyNHjlBLi/zL6OfnR6mpqZScnMwwWu8unj6MNS1ax0PeJO/XBQ308q5KOlxtzEHz1oxUGhYbrAMd33/UXeSDgN87RscaDtjOsma6bl2B4ePKDegp8qlv7aRtJY30U2kTlTXa1NN2NTVUjkigGhLo36sMSXakhcYmhdLgWAvpjXIT5KPyijU2NtKBAweovV1dTQMCSknh//L1psPYHX9x3iYv1PqPbyujFUdrdYs/LcNKfztbW6kJ3ZN7yQDuIh+4uq+Yl2H4F/qjW415F1i2w53ks6+yhb4tbCCkC/q5vFlX4CzKkZyZaCtFMjU9jJADkbd5Jfm0trZSTU2NdNPw9/eXVFqRkZGEG4a72969ewkExNKwviFDhlBoaChL9+4+3nYYcy1eQ2dvlfffe6ro3z/ry1zs7+dHn8xOpzTrqRt86i7ywatntKNHXWsHzVqaS01txhXDc/Un4g7y2VHWTC/vqpBuOWa04AB/urBfBC0aEsVFQl5FPm1tbZSXl0cVFRWSTcWxBQYGSrcK2Ffc1aqqqujw4cNc08XGxlLfvn25nvHWw5hLCI7O3izvR4dq6ekfyzik6d3VXXEouhZp4sPuJB94Xb4yVZu6Ww6Cjw/V0lM6958HWjPJZ39li2TX3GJw9VUl+XhJyGvIB7ecgwcPUnNzs8u9i4mJoezsbJ791dz3+PHjVFbGdxAFBATQqFGjuOb05sOYSxDGzt4u731bSgilzbU26MqXzc2gKIu/1iF8+jl3kg+A+nhWOmUa5GX4m9X59EuVMfY/lk00g3ygRn5mezl9cqiGZQmG94m0BNATZydKRRldNa8gH9xy9u3bx6zegmE/LS3NcNCcBwQZ1tby2wFGjhxJuKmxNm8/jFnlYO3n7fJC9fKb1QW66rc8PC7hlC2/4G7yuWJwFN06Ur/jwd6KFrpqbT7ra2xIP6PJB+/uvd+USOEEnmwB/n5S9vdLB0QqLsMryKe0tJRycnKYsYJtZdiwYRQcbK5XERwN6ur4I5wF+bjeSm8nH6x+e2kT3bhee2qVedkR9MCYUzPrgbvJJzo4QCq1EKjzovnED2X02WH+j03mg0umo5Hkk1/fRrd/XUzH3OAizirz/OwIuueMeNm98Qrywa2noaGBVR6pn1bPMp5Jjh07RuXlfIFmQu2mjrAvkA+kuHZdIe0q02akhRoI6iCzGgJnD1S10IHKZqpq7pCCZu2usanWQBqVEEIRQTpPY42Ldzf5YJlQ85yboT3DRENbJ81amkMNre5xNLBDaxT5HKttpevXFVKVwcHTGl+BHo/NzY6gB2U+xDxOPlC5bd++nVtGBHf279+f+znWB6qrqyVnA2fHB7Xn4+LiKCsrS61bj9995TDmEspFZ1+Rd11uPf1pS4lmsVfNz+Ty/mGZCDEYr/5cSV8cr6O6FuWDEtqB0+KC6abhMZJLrDubJ8gHLr8vTdHuePDZkVp6YhuffdcITI0gn+b2TrpqbYFhsWpGyOU8xkNjE2hO3551mDxOPnCr3rVrF7e8VquVBg8ezP0cywMgHgSVIqsBT8Mf/NChQ7mzHfjKYcyDhau+viIvbhcLVuRSUX2bJtH/enYiTdfxNe44KTx///tLNb2xt8ol6cgtdGJqGP1hVKxhRnk1MDxBPvjb+2RWuub6Sji891a4dnZSk1vL70aQD2LUlh5xr7qQV1bcypH9vX/UiVyUHicfHPA7duzgvmEg7mfAgAG8GKj2R3wRbjy8xIOBMzIyNLmC+8phrAoeYwdfkvfVn6vojT3aYn8uHRhFdxoQgX+kupXu2lxMeXWtjAj37hbo70c3DI+hRYOjNI/B+qBe8hkSG0wHq1qkKHuetmhINN08IobnEakv5rpiNb+jQf9oC+XVtemKCdJLPquO19HD35Vyy+yJB6CKfndmWncZdI+TD/KkwebDe9jj5jNo0CBDA0+1Eg8CYdPT0ykhQVuST186jI14aX1J3u+LG+n3XxVpEntwbDAtnqGv6iYOt+vXF1JZo7bbl/PCbx8dR5cPVPZA0iSo00N6yeejWen04s5K2pjP5+6OKPvl8zIpgDMW/akfy+ljTrfksCB/yckBNyY9Bn495FPS2E6XrMyjRoMDYvGhAicOo945x9fjlpGxdGXXB5BHyQfEA3dmqN60NNx+YPcxIvMBK/Eg24J9vRaLRcq8gMBX/LvW5kuHsVYZHZ/zJXnr2zpp+pLjmkoyoOTFF/MzNUOG7/6rGdRB1iB/qbQGHA8KG9pcahHgAgtCZC1NoWXxRpBPQX0b/WEjP+k/OSFJSvfC2mAvuWBpDrcq88J+kfSnM+PoV6vyPUY+z++soPf2V7OKqtgP5yfKU5yeGCK9F8jfBs9BuG0frm6lQ9UttOpYnWbnG8eJ40MD6fM5GQRfGI+Rj17isQsEx4N+/frpIiDE8hw6dEj19qXFmYDlzdB6GI9LDqXfDdVWU4dlXXJ98FU0PE6fi7tWeT1VQuKKNQV0sJLfHgCstlzC53ziiPmnh2vprz8oG8EnpVnplpExPco4oI7Rmpx6enFnhaLnk9FZAZzfEyPIByqaBcvzuGOtzkoOo+cnJzG/3suP1dFj3/OrrRbPTKPBMRaPkQ8Sg85ZlkP1Or3zgPMDYxNoVLzrv2l8CH14sIZe3l2pS82Ijbl/TALNzw73DPkYRTxGEJCniQcyaD2Mmf/CDOyI6/iaBdq/5vXI6yny+duP5bSEUy1jh/yri7IoLJBTD9T18G/XFEiu1HLtztPjXAbwwSvud18WUG6tvFZhyewMzcZ5tdfJCPLBTe6tfdVSTjKehtx6n85Jp5QwtiBvLe70sEm906VO9dTNZ/H+aukDQ0+blRUh3d6COfSUuXVtUvxbqQ41MPb2f7PS3U8+SJ+D4E2tqjYlsLXcgLyBePQcxnpePK3Pnorkoyfh6OdzM5gPQsc9ga1n4Ypc2W2amBZGz56j/nW/u7xZshfJGe5/PzKWfmuS84FR5FPe1E5zl+VyZ1+GNuDG4eqOB3DkuOyLPO4/hfvGxNOC7AjpOU+QD0w885bn6rLJ4Mbz/nlpXMRjB0pvCALGeX5ysnvJh5V4IiIiJOM9+kMfiaJtubm5hMSjrhoPASFzwS+//OIxVZujHOLmw/b376mbz39/qaFnt/MFG9slgnfPoBh+eyDqDN21qVgWGB4j9TXrCmm3TKAsIs/vNykDg1HkA+Hv+aaENuTxOR6g3PrSuRmqjgd//6mCPjzIZzOBfQ2OBqFdt1lPkM9X+Q1092b5d4PlLwm3Q7xDI1VUba7Guu3rYl0JS387ONp95MNDPHAigAeZY0NZAzgnqBFQdHS0lHjUlRMCiAc2HrUaPWbZeJw3VZAPy58MkafI54vj9fTQd9qCTV+akkJjVBIsykn/yaFaelImuzLe6w0L+zCr8p78UT7B5NkpYfTPSeq3J7ad6dnLSPLR6m34zMQkmpSq7HjQ0tFJs5fmcpdTtzsa2CX2BPloIU3HHVrYP5LuPSNOy9Z2PwP120UKN3OWgYfFBbuHfEA8IA6lSqD2xeLGI0c89t+NICBW4tFSGoEFdLk+gnzYkPMU+WwpbKTbvub3vIJUWtO+KBnC4eL71cI+bIARkVKc0uy+EfTwWHNyzxlJPhD0whV5lM8Z4zQhNYz+MVGZXFfn1NOD3/J/UDjfZD1BPq5sgSwvxnOTk2l8Ml/NMblxoRItbtAWAgBnHNO93ViJJzw8XAoadb7xOAuth4BQDhuqNrUbjzuJB/IJ8mH5k/HczQfFuK7XWFZZa3brH0ua6KYN8olN1yzoI5U3ZmlKaivHeAuWcXj6GE0+7+yvppc4jetQLUH1lhgqX2Hzxg1FtL2EL/Pz0Nhgetspbsvd5AP3Z+Db4VTvjHV/gMu6C/uQNUibE4zjPHduLqZN+Xw5OR2fN5V8jCYe3hsQsl5DTYcAVsTh4N+9jXgE+bD+2XiOfL4tatQUcwLJ1NQ/StIjZgeJLttkovwdDd6u0EOyTDgtVDT1LgH/90nJdE6K/q9fufmNJp+K5g6ao4CFK/mvOy2GrhvWOxQhp7aVLl6pz9HAPq+7yWdzYSPdofEWjjUjK8MH5xlTjkaPIw7WYhr5mEU8vATEfrQRufvGY1+buPmw7ZKn1G5aVTSQ6rXpqaoxFErSK91a+kRa6MPz01QN6s/+VEH/lTGow2Px09kZhnz9uoN8MIeWAn9JYTbHA+dv/Bd2VtK7+6vYXrquXs6OBp4inxd3VdLifXxrdxT0jMRQutSgDBc7S5vo/QN8Dhum33zMJh67ACjDADWamhMCy1vmKeIRNx+W3bH18RT56Cmt/OH56ZTtkEyRXVqibcVNdPNX8qq3K4dE0y0u8pjBZvT41jJZ9cy9Z8bTwn42V2EzmtE3H6xxW0kT3ayghnQlwz8mJdMEhxse3JQRnCl3G3Q1zkX9I+keGSO9u28+939bSmtz+GuMmbHPesc0/ObDSjzIzTZw4EBVG4+agEYQkCeJR5CP2g6f+N1T5KMl2NG+6pXzMyk+RN7uwCK50u0HXm+I9TkntafqDJHoL7n4Ooba5b2ZaeSvX+WvuHwzyAeTXbQyTzFoVmkxk9Os9PQ5id0/a41Ree+8NBoY3dtl3t3kc8vGItpaxGerYnnPPNHHUPKBNxsCSNW82kA8cC5A4TUjmh4C8jTxCPJhfwM8RT7/2FFB/9GoXth0cZamQD47KpXNHXTpqjzZVDlIU//cpCQanWCr14My0H//qVwxBxfyar04OVnzTYx1p8win/cOVNPzO/ii+uFVBdWb/QPg9xuL6HvOw3toXDC9fa58glh3k49eTzfWPXRHP8PIx1PEYwcpPz+fior43WF5S16bsSlabT7TMqz0x9P1+evzygNvmRhGTyulsbXK6ynyuWlDEf3I6RkF2YMD/GnTxexu0Up4IeD07s0lsio0uF4/Oi6BNuQ1ENLrKxU/TLUG0YtTkk1LqeO4drPIB04Ys5flUGs7X6kFZDtA1gMkK4XbNm+BSOQ+m+dUCM0ur7vJB5kNtNaX4v1bN7u/IeTDSjxhYWGSqs2oG48jOCj+VlnJX3dlyJAhhHV5svnaYawXK1+SF85mU5cc15S2HjeNlfMy9MIlPa8ny0LfSItEPAkKbseGLNBhELPIB1M88F0prTnOZ/MA8SLf26u7K+nNvXzG+nBkNJifSSEK+c/cTT6TP9H2Lhq9x0aMx00+KD1QVlZGiJmBoT8wMFD6klDL1WYm8QCIo0ePUkUF35Ucz6HyaGioOS6nrBvkS4cxq0yu+vmSvFoLjUH+EfEh9Pr0FCMgk8b4544K+oBD/QeV02UDo+j606IVD0/DFucm8tle2iQltuRtU9Ot9FNpk2Kmb6XxLu4fSXe7yAbgTvJBAusJHx3lFd1r+zOTD+JjcMCjxDRvM5t4sJ6CggIqLOR7KWG0hdrNjJsYD0a+dBjzyKXU15fkXXK4lv7moqyBKzyQv+r3I9UTXLJiikSY164vYKo9A+KDV5tj2WKleX4ubyb8z7llRAT18BRjXaeZNx+s4ZJV+XS8poV1Obr6Ifmmq9pH7iQfaBvH/+8UIx/cbOBIgNsOb3MH8WBNWNv+/fu5lod0PlADerr50mFsBFa+JK+eBIpaA0ydMUZUO2JTlh6tZSotffOIWFo0hL1c9ut7qui1n3urrKdnWOmvZ5/wFGPde7PJ54ODNfTPn7QlemWVAf1OiwuhN891fXN1J/lgTVAB663hw4OBmX2Zbj5ajflQZ+Fwh2rOHQ0xP1ALsjasDQTk6eZLh7ERWPmKvPn1KGvAb6C2Y8STBkcJV2QwRplnnpLGKN/9rynJBHsFS3tFwRYyIzOc/jKevzS82eSDWkWzl+ZQC6fjAQsWjn0eHJtAcxUcDez93E0+KLBXUK+t8jOv/Gb3VyUfpKbZuXOnaukB54W6m3gwPxwfcPtRsz+hL0pfZ2QYYwzWu0m+chjrldP+vK/I+9yOCs0R3CiY9dGsdM2QwcX66R/L6Mtcfm0DJh0eHyK5VdtT/7taiJKczhmcWYUxm3ywjoe/L5VKO5vVwi3+tGpepqqbvLvJ58q1BbS/gr+qrh2nOX0jaHKaZx2s7GtRJZ+qqio6fPgw9x576laBKqlYL/4p12DnSUpKorQ0Y/IbcQMj84CvHMZGyIoxfEFelKNGyv3alt550VhwmJsdQQ9qrJdT3NBO160vUHWphV1nb0WzYrE1lMtGHJBapUqlsgu/GRRFfxgVyyJujz7uIB89yV5ZBLpkQCRTGIO7yUdLnJKjvNcMi6EbTuud744FE6P7qJJPcXEx5eXxJ+HLysoi1MPxRIONCh558H5DFmzc3lCQLjIyUrrxeNq7zRkTXziMjdxHX5BXb80Ue516XtxQvRPVR5XKX2M8GMDhTDA8LphQa+iR70sVsxyflRxGz05MIlcauIe+K6UvZNyXrz8thq6VScypJpM7yAdruOyLfDpSbY7jwQfnpzM5a7ibfLS4mjvu15R0Kz01gd+Op7bnWn4/KclHCxCefMYXDmMj8fF2eVHA7NaNxdzBiHaMggL8aOmcDIrjTKsDW8YN6wsVD1QErV4zLFoqf+0YdqLmkTcpzUpPTkhUTER67bpC2awIt4+Oo8s1JKF0F/noiX1y9T5DZfkGo4u8u8nntZ+r6PU9/PGMdnnhwfiJDnWwkeeAKvkgcBMBnLxt0KBBhBo9oqkj4O2HsboEfD28WV4QwOVf5HMZ+J2l11qoDY4FHx+Sd5gJRSqdycmKGbLf3V9NL7ioeXNuhpUeH58om9Nt1tJcWXlxY5roohqo0q67i3xqW+F4kEtNyBZqYHtoXALNyWI7u9xNPq6SzbJAgAwlGy/qo6qKZRlLbx9V8kF8z65du7gcDuDdhvgZ0dgQ8ObDmE0Cvl7eKi+M/HdsKqI9MjEvPBIqJaF0NUZJYztduCJXNnUMcrihKucZibYcbkpNyWvN3l+OFEG2Mz49Ljvk53MzKCWM31PVXeSDRT+6tYxWHK3l2R6XfSMsAVJWCjU7mX0Qd5MPbJHTlhxXtPOxAPHOjDQaEts7SSrLs0b2USUfTAabD2w/rC09PV0y6ovGhoC3HsZsq+fv5Y3y5tS1SQXjeMs1O0sPI/8rU5O5QXlqezl9/Iv8refaYTFSlgKW9sz2cvqfwjh43tmDTSnLM9y013OU63ZcmzvJZ3d5M13zZQELNEx9fjUgku7iyJfobvKBENesK6TdZfIOVSxCanWhZxmbpw8T+cBgjyBTZI9Wa94SuKm2Tm/63RsPYzPx8TZ5kbgTtW+qmrV5tjlipTWwVClnl1T4bU4GWQPZayA8trWMlru4DSDlzh2jbV5sT/xQRp8d7n1zGJkQQv+epi01kDvJBzJcvjqfDlcZ43jAW3/JE+SDkhnv6CgoB8xemppCY1Ru0ixnAEqclzdq+7thIh8sAnncYPuprVW+4kZHR1Pfvn111+hhEfpk6uNth7HZ2HqLvMgT9q9dlYolCHhxSA8Pok9mp/eqnKk2TmljuxQ0KdfmZUfQA5wu20iG+qctJbQhTzlG6Kqh0bRocLSUJboBScOc2k0jYulqjiwJnrr5YN6PDtVKMVF6m5ZcfJ4gH62F9RzxQbLZDxiq4brCFB9td21i14g5j8VMPvYH4YBQXl5OdXV1BHsQ7DtwLIiPj6eoKPaUHnpflJPpeW85jN2FqSflPVbbKtVzQQmC7RrKJLjCyLlqJiuerpJlIs4G8Ta8DTb4OzcX07eFytqKYXHBivatJbMzNJdfcPfNB+mH4DSh1/Hg4XEJNJvR0cC+H54gH8z969X5dEjnbQ8fNijJwmrfcnwHUZ7ixg2FqrFoSu8t4i25yYf3j0D0V0dA62E8LjlUqlPiiQZ1UN/IIE1Tu0NeGGYrm9qpqqWDqpraCQZ91OQpbmjTtGa1hy4fFEW3awjIxLifHamlJ7bJf7k/Mi6BZnEeiPa1Nrd3EoISd5Ty2QeQnmfxDPniaWo44Hd3kw/m/PO2Mlp2RLvjQaQlgFZwOBp4mnwQ3/XQdyUs2+GyT2ZEEIF0ETPG2nDjefT7Ms0B2JhnaGywIB9WwM3sp/UwNnNNamMjRT1iR7Q0X5TXlZw4rN+cnkqBbKnUeg3linz0kBomqm/tpJu+KuRKyXLPGfF0UX/tOQ89QT57Kprp6rXaHQ8c7WA877Snbj5Ia4e8g4UG5HmD+zUcLVCscUiMvBccPEGR6mn18TpD1NT3nBkvyIfnRTOrry8exoJ8bG8DKom+OzONMsL5XZLt79OWwka67Wv5Krxa7BDO7yncqa9fV0hHGcoQICfdhxekKwaksvwNeIJ8sK4r1hTQwUptec8gc7aGm7ynyAfymhFkGxUcQCnWQIoNDqC2zk7JmaCsqZ2qDXDGsb87sI0i76FQu7H8NZncR5CPyQCbOPyjZyXQBX3YAhKVloE6PZd9IZ/CyhLgR8vmZuouXQ6nBqTtUXMlf+qcJJqiM/Gkp8jnk8O19KSG2kt6PPs8ST5Qq161toAOm5RiyKw/mz+PT6TzMq2CfMwCmGdcQT48aHlH3wB/P7prdJwu9ZSjJHOX5Srao85IDJXKYCtUcmYG5MODNfR3F3VwUPkUN4BMHbc4LMZT5FPf1kmzPs/hLnmu5wPCk+QDrHNqW2nR2gKfqfEzKiGEXuty4Rc3H+Y/XfM6CvIxD1szRrYG+dMTZyfS+GTjyq+rlcj+9aAouk2jQwNcr1/ezRYbkmwNpNenp1JiaIBm6DxFPliwUtySkjBwNFg5P4Ms/uxxVI5jeZp8sBalQGHNG2jSgynWIHp7Rmr3LV6Qj0lA8wwryIcHLc/2xeH8j4nJ1C9Km6ef0urxBYtgyVYXBdLGp4TRTcNjaLCCUdh5bAy14lidFJDoKku283N9Ii1SgGl0sDYPCk+Sz77KFlq0Jp/5JdHqaGCfwBvIB2vRm4WdGTCNHWEbxUeNY1l3QT4awTTyMUE+RqJp3lgoq4wMBrEaD2W1lanlZsPziI+Ylh5GSI2fGR5E6RGBFNFVLwGxPWVNbbSrrFmKZfq2qFFzgtRBMcH0ytQUsgbx3wg8ST7ACBkeShrZXOoR5wInC63NW8gHHxrP/qScokmrfEY8h9vlXyck9sqoIMjHCHR1jiHIRyeAJj+ONPTXDYuh8/pYubMX8CwNBuTr1vO5RWN8xFxBtVbDWfgOCUtdBWaOTgih5ycncwchepp8eDDX29dbyMcuB9z2kR29DS+EF7TsKAs9c06SbMCyIB8v2CBBPl6wCTJLSLUGSfVzEOSp19jPKmFNSwfdtKGQftEZva42H2r83Dcmnl77uZKWKJRxwBhnp9iK0fHIL8hHDf0Tv786LYVA8ka2nWXNdM83xVTRpC3nmlFrQRmPB8YmUJhCXqXKVXkAABQuSURBVEJBPkYhrWMcQT46wDP4Uai1oJde2D+S5veN0Bw4qmdZiMt5bGspbcpXT+TLOw+cJe4YHUdz+9rcw/F9jEqoq47VKQ6FLMiPj09gvvUJ8mHfFTPIB7OjIu5be6vo8yN11NxubL0jNemQtunWkbGqpCrIRw1JN/wuyMcNILuYIikskMYmhdLY5FAakxRqmk2HV8qVx+rouZ0VUpogvS0+NFCKYl/YL4IiLT0dCWAvuPebEtqYr5yI1LkUg6v1CPJh3y2zyMe+ApDQ4v3V9OnhWt2579SkQsqcKwZHEW48LE2QDwtKJvcR5GMewIhdgU0Enlv4Z0xwAEUF+0v/jA8JoNGJIZSlw+Bs3sptIyPh9NqcOvroUA13kTsURoNKBw4KMzPDXd7iMA8K6cFRQaldOSSabhkRoyqyIB9ViLo7mE0+9okqmjuk3HdbixslhxSjbkNw1jivTzjN7BPOHR8myIf9PRE9BQIeRQDquF1lTQSdfmF9m5TyBP8f0qCATPE/kCxsVah6OijGwqwq86hgYnK3IoAPDbxHP5Q00U+lTVTe2CYl4K1t6aCOTnlHBQRV4/0aEG2R3qtB0RZCTsM0q/a0UoJ83LrtYjKBgEBAIOCdCMBBrra1QyqqiDIVoYH+hIq2cOUP5ShmyCqdIB9WpEQ/gYBAQCAgEDAMAUE+hkEpBhIICAQEAgIBVgQE+bAiJfoJBAQCAgGBgGEICPIxDEoxkEBAICAQEAiwIiDIhxUp0U8gIBAQCAgEDENAkI9hUIqBBAICAYGAQIAVAUE+rEiJfgIBgYBAQCBgGAKCfAyDUgwkEBAICAQEAqwICPJhRUr0EwgIBAQCAgHDEBDkYxiUYiCBgEBAICAQYEVAkA8rUqKfQEAgIBAQCBiGgCAfw6AUAwkEBAICAYEAKwKCfFiREv0EAgIBgYBAwDAEBPkYBqUYSCAgEBAICARYERDkw4qU6CcQEAgIBAQChiEgyMcwKMVAAgGBgEBAIMCKgCAfVqREP4GAQEAgIBAwDAFBPoZBKQYSCAgEBAICAVYEBPmwIiX6CQQEAgIBgYBhCAjyMQxKfQNtzG+g5vZOxUH8/YiiLAEUHexPmRFBFBzgp2/CU+BpNUwBgSXAjzLDgyRMA/1PAVCEiAIBL0FAkI+XbMTspblU2tjGtJqgAD8aGR9Cs7LCaU5WONMzp2InHkwD/P2oX5SF/m94DJ2dEnoqwiVkFgi4FQFBPm6FW3kynoPScZSxyaH0wJh4Sg4LdKskTe2dtHBFnjRnWngg/XtailvnZ5lMK6aT0qz0yLh4Cg8SVyEWnF318YX3RK+M4nltCAjy0Yab4U85HpQ3j4yl2OCAHnM0tHXQkepWOlTdQoerW6ihtaP797Agf7p1ZCwt7Bdh+LqUBmxo66QpnxyTfu4TEUQfzUp329ysEzlievvoOIoL6Ykpxqlu6aDjNS30TWEj5de1dg99QVY4PTougXUq0U8BAV94T8TmeQYBQT6ewb3XrI4H5ZLZGZQernyTgWXogwPV9PLuSmpxsBP9c1Ky21RGvnCo8GAKLn9jTyW9ubeqe2+eOieJpqSFeckb4pvL8IX3xDeR9f1VC/Lxkj3kOSjtS8ZN6KHvS+lgZbP0f8Fo/uH56W4xnPvCoaIF0z9uLqGN+fUSnuNTwui5SUle8ob45jJ84T3xTWR9f9WCfLxkD7UclFh6SWM7Xbwyj5rabGo4qOwWDY5SlaqutYMOVrVQQV0blTW1U0JoAGWEB1FWZBBFWpRtHXgGramtk65dVyD9e7I1kJ4558QhHejnR9lRQYpr0Dq3qlBOHbRguqOsma7vkis+NJBWzstgmralo5MOVbXS/spm6ugkGhRjoQHRFgph8ErEAZ3XpfKDatBRPZhT20q7y5ulPYJ6c1hssLRXWhpud0eqW+iXqhZJ3Yj14X8xweq2LaU1YpxtxY1UUN9GuJFf0CecEkMDpHdL73uiRUbxjO8gIMjHS/ZKy0FpX/prP1fR63sqpf8MDfSnT+dkUKzCgQKyend/NS09UkuNXYTlCEFwgD9dPjCSFg2NJmtgb3fu8R8do3acri6a0qGtd27erdKCKYhx2pLj3VOtXtDH5eFc3tROj28ro++LGqnNCRd/Pz8amxRKD42Lp3gZe5N9km3FTXTzV4XSf153WgxdNyyaKps76MFvS2hrcWMvsVOsQfTA2HgakxjCBElFcwc9sa2MthQ29Fqj/ePhj6fH0cRUZRWj8xp/NzSaXthZQZ8cqqXm9hP2x5empNCYpBDS854wCSU6+TwCgny8ZAu1HJT2pds9isq6XLUfGZcguWE7t5y6NrppfSGTS3daeBC9f14ahTkRkNZDxYi5ebdKC6b1bZ00tcuRAvOtWdBHiq2Sa98VNdIj35dSRVO7y6VFBwcQ9kTJhdv5YP/VgEi6cUMhHe66PcgNDtdwuIX/VuWWu7mgkf68rZQqVdaIORb2j6TbR8XKxpA5rxE3tVXH6notTZAP71t66vYX5OMle6/loHRc+sPfl3YfBgv6RdB9Z8b3kAx+CQuW51Jxgy2WCOqWaRlWGh4XIqnayhvb6cfSRlq8r5qqmm2H6dy+EfTg2J7j7CxrltQrUPPdurFI6pcUFkh/Hp/YPR88lKEesjej5ubdKi2Y7qlopqvX2tSJcLVev7CP7LT7K1to0doC6uy03QJHJYQQSGNQTLD0/x2obKH3DlTTvgqbPS7Q30/yCEyz9nYkcTzYL+wXSVgD7HhnJIbSzEwrDYsLlgKQ91Y007Kjdd02Poz7wNgEmtdXPtZrb0ULXf3liTX2jbQQ3o3BMRaKCg6gg5Ut9H1xI604Wtst45y+EfSQ057jR8c1Do0NltaCNjnNSiPigwkfK/DAPDMpRHL71/Ke8O6v6O/bCAjy8ZL903JQOi799T1V9NrPNtXbaXEh9Oa5PeNuEO3/x83F0u8j4kPoX1OTyYK0CU7tWG0rXbmmoNuGtG5hH4qQiXfhMSQbPTfrlmnB9LGtZbS86zA+OyWM/qngcHDThiL6scSmErtqaDTdNDyGnNEE6f71hzJJxYk2IzOc/jK+t/u248Ful23RkGj6vxG9xwQJQc23+rjt1gF725JZGbJOJtetL6SdpU1SP3xoPDw2gUJlVKlf5tYT5MYHhZ+fHy2ekSrZrByb8xpxm3tyQiKNTnCt+uN5T1j3VfQ7ORAQ5OMl+6jloHRc+uqceslGgAavt4+d4m5gZM6ts9168OWbKvMFbh/vwe9Kuw+3V6elyB4wPIeK0XOzbhkPpri/fPRLDT2zvbx7+FempdDpMocrVFl3bLLd+kDk/56e0ot47INAJXrJyjzpxomD/Z0ZqRL+rg52V6SH50BqcDKxxyX98Yx4uqR/zxivdbn19KcttvchITSQPpuTQa5iZh3thqcnhtIrU5NdrpHVDZ3nPWHdV9Hv5EBAkI+X7CPPQSm35H0VUAPlSz/hq3TNgkzNkr2xt4pe3W27Rd17Zrxs8KpZhwrL3KyCOWJ65+lxskb/utZOyq1rlRwGDnS5rGP8mX3C6fGz5INMcajjcEd7YUoyjUtynY7nnX3V9NKuCqn/zSNiadGQnt6IzreKt2ak9lBbysn72ZFayYkADSq/15wyTNy7pYTWd60Rsl86INIlbDUtHTR/eS7VdwUvr5qf2cPrznGNULMum8vmBWjWe8L6Doh+3ouAIB8v2Ru95PNTaRPdsN7mMdUn0kIfXZCmWbLF+6vpxZ22w1Lp4DLrUGGZm1Uwrel1zs2wSjYsJS/p36zOl9yV4c0Gm5CzU4bz+rYUNtJtX9tuSnOzI+jBMT3taI4He6o1iD6bo54tAmRx7qc2rzw578Jfr86nQ10OC0vnZjClX7pjUzFtLmiQxnxteiqNij9ht3NcI+w8T59zwsbnaj/Mek9Y3wHRz3sREOTjJXujl3wcv4QnpoXRsw5xN84iQm1zvLZVivlAHEltSwfVtnZI/8SXL36zOyYYTT5GzM26ZbzkA0P6DcNjaHyy65vMpE+OS/YRuLUjDY9aq2luJ9hV0GAjgSrTsTke7HDNfnFKT5WX0vhwCYdrONrXF2f1iCmyrxFecd9cnEUy5r1ewz69vVxSPaI5OzI4rnFWVoSU+46lCfJhQenU7CPIx0v2XS/5vLCzkt7db0sNc8XgaLp1ZEwvyXAQ/OdgNb1/oJrqWk7EZriCwCjyMXJu1i1zxPQPo2IpVibW5oMDNd3qtvnZEXS/063EeS7EKs1ZmsO6hF79EsMCabmTysrxYJfzVFSazH4Dw+8fnJ9O/bsCex3XiJigzxluUhgD3nnP77DdeK8cEk23jDjxDgny0bzl4kEFBAT5eMmroZd87tpcQl93pYW5f0wCzc/u+UUONQ1cgx2TZ0J0GKNxKEdY/CWvNvwTNx+7l5QR5GP03KxbxoLp9tImurFLXQk12nvnpXUf4nLzIGDz/M9s6q6QQH9V24zzGHDfdlZZOR7ss/tG0MMyrs5ya/nVqnw6VmPLJAAHEziaoCFA9byuNfJkaXhrXzW93GWbunZYDF1/WnT3tIJ8WN860Y8VAUE+rEiZ3I/loFRaQl5dG136RR61diUZddbX47nbNxXTN136/OwoC904PEaKvpezV7DYXXjUKUbPzboVrJje9nWxFP2PdlZyGD0/2XU+N7u6C9nEv1KIA2JdI/o5HuxyzgNKY038+LiUXQCqtU0XZfVwt5726XHpdgsPu80XZ7n0dLOP/8QPZfTZYZtb+GNnJdL5fayCfHg2UvTlQkCQDxdc5nVmPSjlVnDPNyW0Ic9mUwCxIDOBo7Ec9pzpXSljwi3+9NEF6bLlBexjv7Srkt7ZZ1Ph6b35mDE36y6wYnqoupWuWJ1PHV0Bo89NTnZp98EN0h48qpaBnGWtjuSDvG7wNFNrpY3tNLtL/SfnpHDV2oLuQFAEtyIvnFq75aui7nQ+b89Io6GxJ1zCxc1HDT3xOy8Cgnx4ETOpP+tB6Tz91uImuqUrLxh+s6c3cey3raSJbt5g84QblxxKL0x2bdD+v6+K6IeunGIs5IPo9k9ny3tomTE36xbwYPro1rLuSP9+0RZ6f2aaopH+oe9K6YuuIM+7z4ini51ibFjXZ+/n7Gr99DlJNFmllIOjS7rcbc0x4wUCVm92sN/IrQ+JQRE7hPx0uC2tuzCzRzE9I8jH1XvCi5no7/sICPLxkj3kOSixZOSwfPdAtZTVwK5um5pulaLOnRuyIl/zpS1lDNK/vDszVVHqXWXNUl4xe5JMJfJBTtIJHx+TUsnA9vH1RfJpaMyYm3XLeDAtbmini1bmdtdHum9MPC3Ili/OB4zsGb1jQgKkDAPWoN7ZIuzr/PxIHX3VZY9Duhxkfu7xceCQWNS+R4tnpioGriL/3PxluVTTYkuDJEdWjrhDPfj5nAyKcpGt3FHlJldITyv5sL4nrHsq+p08CAjy8ZK9ZD0oCxva6HBVK729r4p2ldlSp6DBkP3B+Wmy8RxIyTJ1yXGJUGBUf2ZiEp2T0tudGLnA7v6mmEq68r9hXFcBinOXncgVpxTxbtbcLNvGiql9rOd3VtB7+6ul/4T6Cyo1uXQ0+N1R1TkmKZQeOytBVpW5/Fgd/XlrmUTSyO+2ZHZ6rz2SS6+DLAePj0/oVcq7qKGNUHPIHhAL9/C3Z8h/TNz/bSmtzbGl4ekfbaGnJiT1KlKIj5h/7a6kxV1qVnxIwHkBZRGUCJLH1RpjsLwnLPsp+pxcCAjy8ZL9dDwokbIlxCkHV0NrJx2taemOQHdcNtQucBFOClOu84J8YPYcYzgEZ2eFSyq4SEuA5N22o7RJikXBYTs9w0rLuvKRuSKfOzcX06Z8m6HeEuAnJSKFbSEowI8ucijpbcbcLNvGSz7wyrtwRR7Vdt0orhkWQzc4eHw5zolURXB1ttdRwg0IN5rBMcGScX9PRQvtKW+SEmzabUlXd+WAc167I/mAyKACg1ciMglMSA2TPOrsiUU3FTRQdVfiVzgaPD85WbG0Aj5ULluV3106A/a+SalWGhJroShLgERgP5Q09cjscP1pMXTtsBNebva1ar35SB8wjO8Jy56KPicPAoJ8vGQveQMipduOxZ9uGxWnmNXYUTQcXr/7skCKzFdqEZYAKZEmjNn3fmNLQuqKfI7WtEoHsHMdG2f3XjPmZtk2XvLBmI6efkq3APvcSMJ6/5YSl5ja+6L+DTwM5ZrzwX7pwEj6w8ai7uzics8ghdLj4xNpbJLrxJ4oZfHQdyW0t9yWhVqpQdY7Rscqqhr1kA/re8Kyp6LPyYOAIB8v2Us18sFXLiqMxgQHUHZkEI1NDqVJaVbFonFyYqHa5n8O1khlE+xf9+iHr/ZR8SF0zbBoGhhtofV5DUzkg2dRsRJ54JDexx5tj9ihFU4VQM2YW23rtJAPiBKGd3uGB6USA/a5IReSciItDW6QjoX2cMNENunfDIySbhtKTe5gR6Ao8sFtyGvovl3hecRkjYwPodtHxzKlzMEz8MB/a2+V5BEJInD8WMBeoWTDLSNjKTO8d7kH+5r1kA/Pe6K2p+L3kwcBQT4nz15ySQIDO1LrQFVnD07kGkCmMwzhUEOBIF2lczFjbr1rN+J5EBdulshkjazhUJsxVNHuEefjbE9pbOuU9qmiuV2qu5QSpkwQLDLAAeBITQtBxYiaTq6cEFjG09KH9T3RMrZ4xncQEOTjO3slVnqSIqD3VnGSwiLEOskREORzkm+wEM/7ERDk4/17JFZoPAKCfIzHVIwoEOBCQJAPF1yi80mCgCCfk2QjhRi+i4AgH9/dO7Fy7QgI8tGOnXhSIGAIAoJ8DIFRDOJjCAjy8bENE8s9+RCAK7TdTd3i76eYVeHkk1xIdCojIMjnVN59IbtAQCAgEPAQAv8PDmqbutyU/+gAAAAASUVORK5CYII=',     
            margin: [0,0,0,15],
            width:215
		},
        horizontalLine(),
        { 
            text: 'Hello,', 
        },
        {
            text: [
                 { text:'The below report is entries from the days '},
                 { text:invoice[invoice.length-1].displayDate+' to ' +invoice[0].displayDate, fontSize: 13, bold: true },
                ],
                margin: [0,0,0,30]
        }
        
           ],
           pageBreakBefore: function(currentNode, followingNodesOnPage, nodesOnNextPage, previousNodesOnPage) {
           return currentNode.startPosition.top >= 600;
            },
            styles: {
            tableHeader1:{
                fillColor:'#006490',
                color:'#fff',
                fontSize:12,
                bold: true,
                alignment:'center'
            },
              tableHeader2:{
                fillColor:'#35a8de',
                color:'#fff',
                fontSize:12,
                bold: true,
                alignment:'center'
            },
            dateTable: {
                margin: [0, 0, 0, 0],
            },
            
            canvasTable1: {
               fillColor:'#35a8de',
                color:'#fff',
                fontSize:15,
                bold: true,
                 margin:[0,0,0,0]
            },
            canvasTable0: {
                fillColor:'#006490',
                color:'#fff',
                fontSize:15,
                bold: true,
                 margin:[0,0,0,0]
            },
            tableContents:{
                color:'black',
                fontSize:12,
                bold: true,
                alignment:'center'
              
            },
            tableContentsMeds:{
                color:'black',
                fontSize:8,
                bold: true,
                alignment:'center'
              
            },
            itemsTableHeader: {
               fillColor:'#35a8de',
               color:'#fff',
               fontSize:20,
			   bold: true
            },

            canvasTable2: {
               fillColor:'#dd30df',
               color:'#fff',
               fontSize:15,
               bold: true,
                margin:[0,0,0,0]
            },
            canvasTable3: {
                fillColor:'#e3c743',
               color:'#fff',
               fontSize:15,
               bold: true
            },
            canvasTable4: {
               fillColor:'#2dbeb0',
               color:'#fff',
               fontSize:15,
               bold: true
            },
            canvasTable5: {
               fillColor:'#d04e74',
               color:'#fff',
               fontSize:15,
               bold: true
            },
            canvasTable6: {
                 fillColor:'#57d04e',
               color:'#fff',
               fontSize:15,
               bold: true,
               margin:[0,0,0,0]
            },
            canvasTable7: {
               fillColor:'#d04e74',
               color:'#fff',
               fontSize:15,
               bold: true
            },
            headerStyle:{
               
                color:'black',
                fontSize:15,
                 margin:[0,0,0,0]
            }
        }      
    }


  for(var i=invoice.length-1;i>=0;i--){
     dd.content.push(hederTable(invoice[i]));
     dd.content.push(gradeTable(invoice[i]));
    dd.content.push(exerciseTable(invoice[i]));
    dd.content.push(horizontalLine());
   // dd.content.push(getCanvas(i));
  }
  console.log(canvasData.length+"sfjkdnsjkfndsjkfnjkdsbfjkbdsjkfb");
   for(var j=0;j<canvasData.length;j++){
     if(canvasData[j].graphHeader != undefined){
       dd.content.push(at['canvasHeder' + j](canvasData[j].graphHeader));
        dd.content.push(getCanvas(canvasData[j].canvasImage));
     }
  }
    return dd;
}