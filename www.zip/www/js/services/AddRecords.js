angular
.module('app.services')
.service('AddRecords', AddRecords);

AddRecords.$inject = ['$cordovaSQLite','$q'];

function AddRecords($cordovaSQLite,$q){

    this.getRecords = function(){
        var query = "SELECT date FROM tbl_master";
		$cordovaSQLite.execute(db,query).then(function(result) {
			if(result.rows.length > 0) {			
			} else {
				console.log("NO ROWS EXIST");
			}
		}, function(error) {
			console.error(error);
		});
    } 
 /* =================Returm current time in 12 hour====================== */ 
	this.currentTime = function(date) {
		var hours = date.getHours();
		var minutes = date.getMinutes();
		var ampm = hours >= 12 ? 'PM' : 'AM';
		hours = hours % 12;
		hours = hours ? hours : 12; // the hour '0' should be '12'
		minutes = minutes < 10 ? '0'+minutes : minutes;
		var strTime = hours + ':' + minutes + ' ' + ampm;
		return strTime;
	}
	this.getGradeData = function(grade_date, grade_sl) {
        var grade_col = "";
		var x = '';
		var q = $q.defer();
		var query = "SELECT *  FROM tbl_master where date = ?";
		$cordovaSQLite.execute(db,query,[grade_date]).then(function(result) {
			if(result.rows.length > 0) {
				var bufferArray = [];
				 for(var i=0;i<result.rows.length;i++){	
					if(grade_sl == 0)			 
						bufferArray.push(result.rows.item(i).grade_first) ;
					if(grade_sl == 1)			 
						bufferArray.push( result.rows.item(i).grade_second) ;
					if(grade_sl == 2)			 
						bufferArray.push(result.rows.item(i).grade_third) ;
				}			
			   q.resolve(bufferArray);
			} else {				
				  return false; 
			}
		}, function(error) {
			 q.reject(error);			
			console.error(error);
		});
		 return q.promise;
	}
	/* =================Store record on tbl_master table===================== */ 
    this.setRecords = function(recordData, last_insert_id_value, gradeData){
		console.log(gradeData);
		var grade_first, grade_second, grade_third;
		var date = recordData.date;	
		if(gradeData != null){
			if(gradeData.length == 1){
				var gradeDataJson = {
					grade : gradeData[0].grade,
					record_time : gradeData[0].record_time,
					date : gradeData[0].date,
					is_wakeup: gradeData[0].is_wakeup,
					last_long_level : gradeData[0].last_long_level,
					luckyData: gradeData[0].luckyData
				}
				grade_first = JSON.stringify(gradeDataJson);
                if(recordData.gradeValueData.grade){					
					grade_second = JSON.stringify(recordData.gradeValueData);
					window.localStorage.setItem(date,2)
				}
			}
			else if(gradeData.length == 2){
				var gradeDataJson1 = {
					grade : gradeData[0].grade,
					record_time : gradeData[0].record_time,
					date : gradeData[0].date,
					is_wakeup: gradeData[0].is_wakeup,
					last_long_level : gradeData[0].last_long_level,
					luckyData: gradeData[0].luckyData
				}
				grade_first = JSON.stringify(gradeDataJson1);

				var gradeDataJson2 = {
					grade : gradeData[1].grade,
					record_time : gradeData[1].record_time,
					date : gradeData[1].date,
					is_wakeup: gradeData[1].is_wakeup,
					last_long_level : gradeData[1].last_long_level,
					luckyData: gradeData[1].luckyData
				}
				grade_second = JSON.stringify(gradeDataJson2);
				if(recordData.gradeValueData.grade){
					grade_third = JSON.stringify(recordData.gradeValueData);

					window.localStorage.setItem(date,3)
				}
			}
			else if(gradeData.length == 3){
				var gradeDataJson1 = {
					grade : gradeData[0].grade,
					record_time : gradeData[0].record_time,
					date : gradeData[0].date,
					is_wakeup: gradeData[0].is_wakeup,
					last_long_level : gradeData[0].last_long_level,
					luckyData: gradeData[0].luckyData
				}
				grade_first = JSON.stringify(gradeDataJson1);

				var gradeDataJson2 = {
					grade : gradeData[1].grade,
					record_time : gradeData[1].record_time,
					date : gradeData[1].date,
					is_wakeup: gradeData[1].is_wakeup,
					last_long_level : gradeData[1].last_long_level,
					luckyData: gradeData[1].luckyData
				}
				grade_second = JSON.stringify(gradeDataJson2);
				var gradeDataJson3 = {
					grade : gradeData[2].grade,
					record_time : gradeData[2].record_time,
					date : gradeData[2].date,
					is_wakeup: gradeData[2].is_wakeup,
					last_long_level : gradeData[2].last_long_level,
					luckyData: gradeData[2].luckyData
				}
				grade_third= JSON.stringify(gradeDataJson3);
			}		
			}
		else{
			grade_first = JSON.stringify(recordData.gradeValueData);
			window.localStorage.setItem(date,1)
		}
		var month_year = recordData.month_year;
		var exercise = recordData.exerciseData;
		var drinks = recordData.drinkData;
		var smoke = recordData.smokeData;
		var weight = recordData.weightData;
		var stress = recordData.stressData;
		var medication = JSON.stringify(recordData.medicationData);
		var last_insert_id = 0;
		 last_insert_id_value = 1;
			 if(window.localStorage.getItem(date) <= 3){
						console.log(last_insert_id);
						var query = "INSERT  OR REPLACE INTO tbl_master ( id, date,month_year,grade_first,grade_second,grade_third,exercise,drinks,smoke,weight,stress,medication) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
						$cordovaSQLite.execute(db,query,[last_insert_id_value,date,month_year,grade_first,grade_second,grade_third,exercise,drinks,smoke,weight,stress,medication]).then(function(result) {
							console.log("INSERT ID -> " + result.insertId);

						}, function(error) {
							console.error(error);
						});
				 }
    }
	/* =================Update record tbl_record table====================== */ 
	this.updateRecord = function(data, sl){
		var query;
		var q = $q.defer();
		switch(sl){
			case 0:
				query = "UPDATE tbl_master SET grade_first = '"+JSON.stringify(data)+"' WHERE date = ?";
				break;
			case 1:
				query = "UPDATE tbl_master SET grade_second = '"+JSON.stringify(data)+"' WHERE date = ?";
				break;
			case 2:
				query = "UPDATE tbl_master SET grade_third = '"+JSON.stringify(data)+"' WHERE date = ?";
				break;
		}	
		$cordovaSQLite.execute(db,query,[data.date]).then(function(result) {
			q.resolve(result.rowsAffected);
		}, function(error) {
			q.reject(error)
			console.error(error);
		});
		return q.promise;
	}
	/* ================= Delete a record===================== */ 
	this.deleteRecord = function(dateTodelete) {
		if(dateTodelete != '' || dateTodelete != undefined )
		var q = $q.defer();
		var query = "DELETE FROM tbl_master WHERE date = ?";
			$cordovaSQLite.execute(db,query,[dateTodelete]).then(function(result) {
			localStorage.removeItem(dateTodelete);
			q.resolve(result.rowsAffected);
		}, function(error) {
			q.reject(error)
			console.error(error);
		});
		return q.promise;
	}
}