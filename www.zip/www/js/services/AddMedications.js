angular
.module('app.services')
.service('AddMedications', AddMedications);

AddMedications.$inject = ['$cordovaSQLite','$q'];

function AddMedications($cordovaSQLite,$q){
    
    var que_list = [];
    var que_camefrom = "";

    this.storeItemsInService = function(items){
        que_list = items;
    }
    this.getItemsFromService = function(){
       return que_list;     
     }
     this.setCamefrom =  function(camefrom){
         que_camefrom = camefrom;
     }
     this.getCamefrom =  function(){
         return que_camefrom;
     }
    /* =================Get  Medications service====================== */ 
    this.getMedications = function(){
        
        var query = "SELECT * FROM tbl_medications";		
 		var q = $q.defer();
         var bufferArray = [];
		$cordovaSQLite.execute(db, query).then(function(result) {
            if(result.rows.length > 0) {
			  for(var i=0; i<result.rows.length; i++){				 
					bufferArray.push(result.rows.item(i));
				}
			   q.resolve(bufferArray);
               return bufferArray; 
            } else {
                console.log("No results found");
                q.reject("No results found"); 
                return false;
            }
        }, function (err) {
            q.reject(err);
            console.error(err);
        });
        return q.promise;   
    } 
     /* =================Set  Medications service====================== */ 
    this.setMedications = function(medicationData){ 
         var q = $q.defer(); 
		var medication_name = medicationData;		
        var query = "INSERT INTO tbl_medications (medication_name,recorded_date) VALUES (?,?)";
        var recorded_date = moment();
        $cordovaSQLite.execute(db,query,[medication_name,recorded_date]).then(function(result) {
              q.resolve(result.rows.length);
			
		}, function(error) {
			console.error(error);
			 q.reject(error); 
		});
		return q.promise;
    }
     /* =================Delete  Medications service====================== */ 
    this.deleteMedicine = function(medication_name){
        var q = $q.defer();
		var query = "DELETE FROM tbl_medications WHERE medication_name = ?";
			$cordovaSQLite.execute(db,query,[medication_name]).then(function(result) {
			q.resolve(result.rowsAffected);
            console.log(result.rowsAffected);
		}, function(error) {
			q.reject(error)
			console.error(error);
		});
		return q.promise;
    }
      /* =================update  Medications service====================== */ 
    this.updateMedications = function(new_med,old_med){ 
         var q = $q.defer(); 
        var query = "UPDATE tbl_medications SET medication_name =? ,recorded_date =? WHERE medication_name = ?";
        var recorded_date = moment();
        $cordovaSQLite.execute(db,query,[new_med,recorded_date,old_med]).then(function(result) {
            console.log(result);
            q.resolve(result);
		}, function(error) {
			console.error(error);
			 q.reject(error); 
		});
		return q.promise;
    }
     /* =================Set  Questions  service====================== */ 
    this.setQuestions = function(que,ans,graphIndex){ 
         if(ans == null){
            ans = "";
         }
         var q = $q.defer(); 
        var query = "INSERT INTO tbl_queforDoctor (question_text,recorded_date,faq_answer,graphIndex) VALUES (?,?,?,?)";
        var recorded_date = moment();
        $cordovaSQLite.execute(db,query,[que,recorded_date,ans,graphIndex]).then(function(result) {
              q.resolve(result.rows.length);
			
		}, function(error) {
			console.error(error);
			 q.reject(error); 
		});
		return q.promise;
    }

     this.getQuestions = function(){
        
        var query = "SELECT * FROM tbl_queforDoctor";		
 		var q = $q.defer();
         var bufferArray = [];
		$cordovaSQLite.execute(db, query).then(function(result) {
            if(result.rows.length > 0) {
			  for(var i=0;i<result.rows.length;i++){				 
					bufferArray.push(result.rows.item(i));
				}
			   q.resolve(bufferArray);
               return bufferArray; 
            } else {
                console.log("No results found");
                q.reject("No results found"); 
                return false;
            }
        }, function (err) {
            q.reject(err);
            console.error(err);
        });
        return q.promise;   
    } 
    /* =================Delete  Questions====================== */ 
    this.deleteQuestion = function(que,ans){
        var q = $q.defer();
		var query = "DELETE FROM tbl_queforDoctor WHERE question_text = ? and faq_answer = ?";
			$cordovaSQLite.execute(db,query,[que,ans]).then(function(result) {
			q.resolve(result.rowsAffected);
		}, function(error) {
			q.reject(error)
			console.error(error);
		});
		return q.promise;
    }
     /* =================Update  Questions====================== */ 
    this.updateQuestions = function(old_que,new_que,ans){ 
         var q = $q.defer(); 
         console.log(ans);
        var query = "UPDATE tbl_queforDoctor SET question_text =? ,recorded_date =? WHERE question_text = ? and faq_answer = ?";
        var recorded_date = moment();
        $cordovaSQLite.execute(db,query,[new_que,recorded_date,old_que,ans]).then(function(result) {
            console.log(result);
		}, function(error) {
			console.error(error);
			 q.reject(error); 
		});
		return q.promise;
    }
}