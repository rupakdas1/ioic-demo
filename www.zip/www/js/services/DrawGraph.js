/*     <canvas id="EHS_canvas" ></canvas>   // put this is html
*
*
*
*
*/


function LineGraph (ctx, graphData) {

	this.ctx  = ctx ;
	this.height = ctx.canvas.height;
	this.width = ctx.canvas.width;
	//alert(this.width);

	this.graphData = graphData;

	this.graphData.paddingPx=[];
	this.graphData.paddingPx[0] = Math.round(this.height*this.graphData.padding[0]/100);
	this.graphData.paddingPx[1] = Math.round(this.width*this.graphData.padding[1]/100);
	this.graphData.paddingPx[2] = Math.round(this.height*this.graphData.padding[2]/100);
	this.graphData.paddingPx[3] = Math.round(this.width*this.graphData.padding[3]/100);

}

LineGraph.prototype.setDimension = function(width,height){
	
  this.height = height;
  this.width = width;
}

LineGraph.prototype.setData = function(plotData){
	this.isGradeGraph = false;
	if(plotData=="")
	{
		//alert("No data");
		plotData=0;
		//this.graphData.labelX=[];
	}
	if(plotData != "" && plotData[0].grade!=undefined){
		this.isGradeGraph = true;
	}
	this.graphData.data = plotData;
}

LineGraph.prototype.draw = function() {

	this.ctx.clearRect(0,0,this.width,this.width);
	// Fill the background color
	this.ctx.fillStyle = this.graphData.backgroundColor || "#FFFFFF";
	this.ctx.fillRect(0, 0, this.width, this.height);
	
	//draw verticle grid
	var innerWidth = this.width - this.graphData.paddingPx[1] - this.graphData.paddingPx[3];
	var innerHeight = this.height - this.graphData.paddingPx[0] - this.graphData.paddingPx[2];  
	for(var i = 0; i<= this.graphData.verticalGrid; i++){
		this.ctx.beginPath();
		this.ctx.strokeStyle = this.graphData.gridColor;
		this.ctx.moveTo(Math.round(this.graphData.paddingPx[3]+i*innerWidth/this.graphData.verticalGrid ), Math.round(this.graphData.paddingPx[0]));
		this.ctx.lineTo(Math.round(this.graphData.paddingPx[3]+i*innerWidth/this.graphData.verticalGrid ), Math.round(this.height - this.graphData.paddingPx[2]));
		this.ctx.closePath();
		this.ctx.stroke()
	}

	//draw horizontal grid  
	for(var i = 0; i<= this.graphData.horizontalGrid; i++){
		this.ctx.beginPath();
		this.ctx.strokeStyle = this.graphData.gridColor;
		this.ctx.moveTo(Math.round(this.graphData.paddingPx[3]), Math.round(this.graphData.paddingPx[0]+i*innerHeight/this.graphData.horizontalGrid ));
		this.ctx.lineTo(Math.round(this.width - this.graphData.paddingPx[1]), Math.round(this.graphData.paddingPx[0]+i*innerHeight/this.graphData.horizontalGrid ));
		this.ctx.closePath();
		this.ctx.stroke()
	}

	//draw labelY
	for (var i = 0; i < this.graphData.labelY.length; i++) {
		this.ctx.fillStyle =  "#FFFFFF";
		this.ctx.textAlign = "end";
		this.ctx.textBaseline = "middle";
		this.ctx.font = 'bold ' +this.width*0.023 + "px sans-serif";
  		this.ctx.fillText(this.graphData.labelY[this.graphData.labelY.length-i-1], this.graphData.paddingPx[3]*0.85, Math.round(this.graphData.paddingPx[0]+i*innerHeight/this.graphData.horizontalGrid ));
	};

	//draw labelX
	for (var i = 0; i < this.graphData.data.length ; i++) {
		this.ctx.fillStyle =  "#FFFFFF";
		this.ctx.textAlign = "center";
		this.ctx.textBaseline = "middle";
		this.ctx.font = 'bold ' + this.width*0.023 + "px sans-serif";
		if(this.isGradeGraph){
  		  this.ctx.fillText(this.graphData.data[i].labelX, this.graphData.paddingPx[3]+innerWidth*(this.graphData.data[i].x)/(this.graphData.boundary.maxX-this.graphData.boundary.minX),innerHeight + this.graphData.paddingPx[2]-17);
	     }
	     else
	     	this.ctx.fillText(this.graphData.data[i].labelX, this.graphData.paddingPx[3]+innerWidth*(this.graphData.data[i].x)/(this.graphData.boundary.maxX-this.graphData.boundary.minX),innerHeight + this.graphData.paddingPx[2]);

	};

	if(this.isGradeGraph){
		 for (var i = 0; i < this.graphData.data.length ; i++) {
		this.ctx.fillStyle =  "#FFFFFF";
		this.ctx.textAlign = "center";
		this.ctx.textBaseline = "middle";
		this.ctx.font ='bold ' + this.width*0.022 + "px sans-serif";
  		this.ctx.fillText(this.graphData.data[i].record_time, this.graphData.paddingPx[3]+innerWidth*(this.graphData.data[i].x)/(this.graphData.boundary.maxX-this.graphData.boundary.minX),innerHeight + this.graphData.paddingPx[2]-3
  			);
	};

	}

	//plot data
	
	for(var i = 0; i<this.graphData.data.length;i++){
		if(i<this.graphData.data.length-1){
			this.ctx.beginPath();
			this.ctx.strokeStyle = this.graphData.plotColor;
			this.ctx.lineWidth = 3;
			this.ctx.moveTo(this.graphData.paddingPx[3]+innerWidth*(this.graphData.data[i].x)/(this.graphData.boundary.maxX-this.graphData.boundary.minX),
				this.height-this.graphData.paddingPx[2]-innerHeight*(this.graphData.data[i].y)/(this.graphData.boundary.maxY-this.graphData.boundary.minY));

			this.ctx.lineTo(this.graphData.paddingPx[3]+innerWidth*(this.graphData.data[i+1].x)/(this.graphData.boundary.maxX-this.graphData.boundary.minX),
				this.height-this.graphData.paddingPx[2]-innerHeight*(this.graphData.data[i+1].y)/(this.graphData.boundary.maxY-this.graphData.boundary.minY));
			this.ctx.closePath();
			this.ctx.stroke();
		}
		this.ctx.fillStyle =  this.graphData.pointColor || "white";
		this.ctx.beginPath();
		this.ctx.arc(this.graphData.paddingPx[3]+innerWidth*(this.graphData.data[i].x)/(this.graphData.boundary.maxX-this.graphData.boundary.minX),
			this.height-this.graphData.paddingPx[2]-innerHeight*(this.graphData.data[i].y)/(this.graphData.boundary.maxY-this.graphData.boundary.minY)

			, 9, 0, 2 * Math.PI, false);
		this.ctx.fill();

	}

};


LineGraph.prototype.refresh = function(){
	
	this.graphData.paddingPx[0] = Math.round(this.height*this.graphData.padding[0]/100);
	this.graphData.paddingPx[1] = Math.round(this.width*this.graphData.padding[1]/100);
	this.graphData.paddingPx[2] = Math.round(this.height*this.graphData.padding[2]/100);
	this.graphData.paddingPx[3] = Math.round(this.width*this.graphData.padding[3]/100);
}

