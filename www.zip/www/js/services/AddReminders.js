angular
.module('app.services')
.service('AddReminders', AddReminders);

AddReminders.$inject = ['$cordovaSQLite','$q','$cordovaCalendar'];

function AddReminders($cordovaSQLite,$q,$cordovaCalendar){
    
    var rem_list = [];
    var eve_list = [];
    var app_list = [];
      // var db = $cordovaSQLite.openDB({ name: "ehs.db", location: 1 });
    this.storeItemsInService = function(items){
        rem_list = items;
    }
    this.getItemsFromService = function(){
        console.log(rem_list);
       return rem_list;     
     }
       this.getEventsFromService = function(){
        console.log(eve_list);
       return eve_list;     
     }
       this.getAppointmentsFromService = function(){
        console.log(app_list);
       return app_list;     
     }
     this.storeEventsInService = function(items){
        eve_list = items;
    }
    this.storeAppointmentsInService = function(items){
        app_list = items;
    }
    this.getLengthOfRemindres = function() {
       var query = "SELECT reminder_name  FROM tbl_reminders limit 1";   
    var q = $q.defer();
         var bufferArray = [];
    $cordovaSQLite.execute(db, query).then(function(result) {
        
            if(result.rows.length > 0) {
               q.resolve(result.rows);
               return result.rows; 
            } else {
                console.log("No results found");
                q.reject("No results found"); 
                return false;
            }
        }, function (err) {
            q.reject(err);
            console.error(err);
        });
        return q.promise;   
    }
    this.getLengthOfEvents = function() {
       var query = "SELECT event_name  FROM tbl_events limit 1";   
    var q = $q.defer();
         var bufferArray = [];
    $cordovaSQLite.execute(db, query).then(function(result) {
            if(result.rows.length > 0) {
               q.resolve(result.rows);
               return result.rows; 
            } else {
                console.log("No results found");
                q.reject("No results found"); 
                return false;
            }
        }, function (err) {
            q.reject(err);
            console.error(err);
        });
        return q.promise;    
    }
    this.getLengthOfAppointments = function() {
       var query = "SELECT appointment_name FROM tbl_appointments limit 1";   
    var q = $q.defer();
         var bufferArray = [];
    $cordovaSQLite.execute(db, query).then(function(result) {
     
           if(result.rows.length > 0) {
               q.resolve(result.rows);
               return result.rows; 
            } else {
                console.log("No results found");
                q.reject("No results found"); 
                return false;
            }
        }, function (err) {
            q.reject(err);
            console.error(err);
        });
        return q.promise;   
    }
  this.getReminders = function(){
        console.log("sd");
        var query = "SELECT * FROM tbl_reminders";      
        var q = $q.defer();
         var bufferArray = [];
        $cordovaSQLite.execute(db, query).then(function(result) {
            console.log(result)
            if(result.rows.length > 0) {
              for(var i=0;i<result.rows.length;i++){                 
                    bufferArray.push(result.rows.item(i));
                }
               q.resolve(bufferArray);
               return bufferArray; 
            } else {
                console.log("No results found");
                q.reject("No results found"); 
                return false;
            }
        }, function (err) {
            q.reject(err);
            console.error(err);
        });
        return q.promise;   
    } 
     this.getEvents = function(){
        var query = "SELECT * FROM tbl_events";    
    var q = $q.defer();
         var bufferArray = [];
    $cordovaSQLite.execute(db, query).then(function(result) {
      console.log(result)
            if(result.rows.length > 0) {
        for(var i=0;i<result.rows.length;i++){         
          bufferArray.push(result.rows.item(i));
        }
         q.resolve(bufferArray);
               return bufferArray; 
            } else {
                console.log("No results found");
                q.reject("No results found"); 
                return false;
            }
        }, function (err) {
            q.reject(err);
            console.error(err);
        });
        return q.promise;   
    } 
     this.getAppointments = function(){
        var query = "SELECT * FROM tbl_appointments";    
    var q = $q.defer();
         var bufferArray = [];
    $cordovaSQLite.execute(db, query).then(function(result) {
      console.log(result)
            if(result.rows.length > 0) {
        for(var i=0;i<result.rows.length;i++){         
          bufferArray.push(result.rows.item(i));
        }
         q.resolve(bufferArray);
               return bufferArray; 
            } else {
                console.log("No results found");
                q.reject("No results found"); 
                return false;
            }
        }, function (err) {
            q.reject(err);
            console.error(err);
        });
        return q.promise;   
    } 

    this.setReminders = function(reminderData,reminderDate){ 
         var q = $q.defer(); 
         var setStartDate = new Date(reminderDate);
         var tempDate = setStartDate;
         var setEndDate = moment(tempDate).add(1, 'hours').toISOString();
         setEndDate = new Date(setEndDate);
         console.log(setStartDate);
         console.log(setEndDate);
            var reminder_name = reminderData;       
        var query = "INSERT INTO tbl_reminders (reminder_name,recorded_date) VALUES (?,?)";
        var recorded_date =reminderDate // moment().format("DD/MM/YYYY");

        window.plugins.calendar.hasReadWritePermission(
                  function(result) {

                    $cordovaCalendar.createEvent({
                                title: reminderData,
                                location: '',
                                notes: '',
                                startDate: setStartDate,
                                endDate: setEndDate,
                                firstReminderMinutes: 60                                                   
                              }).then(function (result) {
                                                console.log(result);
                                                // success
                                                $cordovaSQLite.execute(db,query,[reminder_name,recorded_date]).then(function(result) {
                                                q.resolve(result.rows.length);
                                                
                                                }, function(error) {
                                                                    $cordovaCalendar.deleteEvent({
                                                                    title: reminderData,
                                                                    location: '',
                                                                    notes: '',
                                                                    startDate: setStartDate,
                                                                    endDate: setEndDate                                                                    
                                                                  }).then(function (result) {
                                                                     // success
                                                                      }, function (err) {
                                                                        // error
                                                                      });
                                                    q.reject(error); 
                                                });

                                     }, function (err) {
                                     console.log("err",err);
                                    // error
                                    });
                    // if this is 'false' you probably want to call 'requestReadWritePermission' now
                    console.log(result);
                  },
                  function(err){
                    window.plugins.calendar.requestReadWritePermission();
                    console.log(err);
                  }
                );              

 
        
        return q.promise;
    }

    this.setAppointments = function(appointmentData,appointmentDate,appointmentLocation){ 
         var q = $q.defer(); 
         console.log("appointmentData:",appointmentData);
         console.log("appointmentDate:",appointmentDate);
            console.log("appointmentLocation:",appointmentLocation);
        var appointment_name = appointmentData;
        var location_text= appointmentLocation;  
        var query = "INSERT INTO tbl_appointments (appointment_name,recorded_date,location_text) VALUES (?,?,?)";
        var recorded_date =appointmentDate // moment().format("DD/MM/YYYY");
        $cordovaSQLite.execute(db,query,[appointment_name,recorded_date,location_text]).then(function(result) {
              q.resolve(result.rows.length);
      
    }, function(error) {
       q.reject(error); 
    });
    return q.promise;
    }
     this.setEvents = function(eventData,eventDate,eventLocation){ 
         var q = $q.defer(); 
         console.log("eventData:",eventData);
         console.log("eventDate:",eventDate);
          console.log("eventLocation:",eventLocation);
        var event_name = eventData;
        var location_text=eventLocation;   
        var query = "INSERT INTO tbl_events (event_name,recorded_date,location_text) VALUES (?,?,?)";
        var recorded_date =eventDate // moment().format("DD/MM/YYYY");
        $cordovaSQLite.execute(db,query,[event_name,recorded_date,location_text]).then(function(result) {
              q.resolve(result.rows.length);
      
    }, function(error) {
  
       q.reject(error); 
    });
    return q.promise;
    }

    this.deleteReminder = function(reminder_name,reminder_date){
        var q = $q.defer();
        var setStartDate = new Date(reminder_date);
         var tempDate = setStartDate;
         var setEndDate = moment(tempDate).add(1, 'hours').toISOString();
         setEndDate = new Date(setEndDate);

         console.log(setStartDate);
         console.log(setEndDate);
       
            $cordovaCalendar.deleteEvent({
            newTitle: reminder_name,
            location: '',
            notes: '',
            startDate: setStartDate,
            endDate: setEndDate
          }).then(function (result) {
                                    var query = "DELETE FROM tbl_reminders WHERE reminder_name = ?";
                                    $cordovaSQLite.execute(db,query,[reminder_name]).then(function(result) {
                                    q.resolve(result.rowsAffected);
                                    }, function(error) {
                                    q.reject(error)
                                    console.error(error);
         });
          }, function (err) {
            console.log(err);
          });

        return q.promise;
    }
     this.deleteEvent = function(event_name){
        var q = $q.defer();
    var query = "DELETE FROM tbl_events WHERE event_name = ?";
      $cordovaSQLite.execute(db,query,[event_name]).then(function(result) {
      q.resolve(result.rowsAffected);
    }, function(error) {
      q.reject(error)
      console.error(error);
    });
    return q.promise;
    }
     this.deleteAppointment = function(appointment_name){
        var q = $q.defer();
    var query = "DELETE FROM tbl_appointments WHERE appointment_name = ?";
      $cordovaSQLite.execute(db,query,[appointment_name]).then(function(result) {
      q.resolve(result.rowsAffected);
    }, function(error) {
      q.reject(error)
      console.error(error);
    });
    return q.promise;
    }
    this.updateReminders = function(oldReminderText,oldRecordedDate,newReminderText,newRecordedDate){ 
      console.log("in update");
         var q = $q.defer();
        
          var oldStartDate = new Date(oldRecordedDate);
         var tempDate = oldStartDate;
         var oldEndDate = moment(tempDate).add(1, 'hours').toISOString();
         oldEndDate = new Date(oldEndDate);
        
          var newStartDate = new Date(newRecordedDate);
         var tempNewDate = newStartDate;
         var newEndDate = moment(tempNewDate).add(1, 'hours').toISOString();
         newEndDate = new Date(newEndDate);
        


        var query = "UPDATE tbl_reminders SET reminder_name =? ,recorded_date =? WHERE reminder_name = ? and recorded_date = ?";
       // var recorded_date = moment().format("DD/MM/YYYY");
            $cordovaCalendar.deleteEvent({
                newTitle: oldReminderText,
                location: '',
                notes: '',
                startDate: oldStartDate,
                endDate: oldEndDate
              }).then(function (result) {
                console.log(result);                    
              }, function (err) {
               console.log(err);
              });          

              
            $cordovaCalendar.createEvent({
                title: newReminderText,
                location: '',
                notes: '',
                startDate: newStartDate,
                endDate: newEndDate
              }).then(function (result) {
                console.log(result);
                                         $cordovaSQLite.execute(db,query,[newReminderText,newRecordedDate,oldReminderText,oldRecordedDate]).then(function(result) {
                                         console.log(result);
                                         q.resolve();
                                         }, function(error) {
                                            console.error(error);
                                            q.reject(error); 
                                        });
              }, function (err) {
               console.log(err);
              });
            



        
        return q.promise;
    }
    this.updateEvents = function(oldEventText,oldRecordedDate,oldLocationText,newEventText,newRecordedDate,newEventLocation){ 
      console.log("in update");
         var q = $q.defer(); 
        var query = "UPDATE tbl_events SET event_name =? ,recorded_date =?,location_text =? WHERE event_name = ? and recorded_date = ? and location_text = ?";
       // var recorded_date = moment().format("DD/MM/YYYY");
        $cordovaSQLite.execute(db,query,[newEventText,newRecordedDate,newEventLocation,oldEventText,oldRecordedDate,oldLocationText]).then(function(result) {
        q.resolve();
        }, function(error) {
      console.error(error);
       q.reject(error); 
    });
    return q.promise;
    }
     this.updateAppointments = function(oldAppointmentText,oldRecordedDate,oldLocationText,newAppointmentText,newRecordedDate,newAppointmentLocation){ 
      console.log("in update");
         var q = $q.defer(); 
        var query = "UPDATE tbl_appointments SET appointment_name =? ,recorded_date =?,location_text = ? WHERE appointment_name = ? and recorded_date = ? and location_text = ?";
       // var recorded_date = moment().format("DD/MM/YYYY");
        $cordovaSQLite.execute(db,query,[newAppointmentText,newRecordedDate,newAppointmentLocation,oldAppointmentText,oldRecordedDate,oldLocationText]).then(function(result) {
        q.resolve();
        }, function(error) {
      console.error(error);
       q.reject(error); 
    });
    return q.promise;
    }


}