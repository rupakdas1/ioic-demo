angular
.module('app.services')
.service('SendEHSPin', SendEHSPin);

SendEHSPin.$inject = ['$http','$q','$cordovaDialogs','$filter'];

function SendEHSPin($http,$q,$cordovaDialogs,$filter){
    
    this.sendPin = function(userData){
        var deferred = $q.defer();
        var body = {
             PIN:userData.pin,
             email:userData.email  
            };
        return $http({
              method : "POST",
              url : "https://jsonmobile.pfizer.com/Hemo/SendPin",
              headers: {
                'Authorization': "Basic SGVtb19TT0FfQ29uc3VtZXJfRFA6Vm5xTUNtZlhpQkxq"
                },
              data :body,
              cache: false
        }).then(function(response){
            // promise is fulfilled
            deferred.resolve(response.data);
            // promise is returned
            return deferred.promise;
        }, function(response){
            // the following line rejects the promise
            deferred.reject(response);
            // promise is returned
            return deferred.promise;

        });
    } 
    this.verifyApp = function(ehsInstDate){
     
      var date = moment(ehsInstDate);
      var now = moment();
      if(now.diff(date, 'days') <0){
        $cordovaDialogs.alert($filter('translate')('DEVICE.DATE_ERR'), 'Date Error', $filter('translate')('QUESTFORDOCTOR.BUTTON1'))
                .then(function() {
                        console.log("Date error");
                        return;
                });
          
      }
    } 


    
}