angular
.module('app.services')
.service('Graph', Graph);

Graph.$inject = ['$cordovaSQLite','$q','$timeout'];

function Graph($cordovaSQLite,$q,$timeout){
    var service = this;
    this.setInitialGraph = function(){
         var query = " SELECT date,grade_first,grade_second,grade_third  FROM tbl_master order by date asc";
        var bufferArray = [];
 		var q = $q.defer();
		$cordovaSQLite.execute(db, query).then(function(res) {
            if(res.rows.length > 0) { 
                for(var i=0; i<res.rows.length; i++){				 
					bufferArray.push(res.rows.item(i));
				}
                q.resolve(bufferArray);
                 return bufferArray;
            } else {
                console.log("No results found");
                q.reject("No results found"); 
                return false;
            }
        }, function (err) {
            q.reject(err);
            console.error(err);
        });
        return q.promise;  
    }

   
  /* =================get Grade Data For Graph====================== */
    this.openGradeJason = function(gradeGraphData){
        var gradeDataForGraph = [];
           for(var i=0; i<gradeGraphData.length; i++){
                var gradeObj1 = JSON.parse(gradeGraphData[i].grade_first);
                var gradeObj2 = (gradeGraphData[i].grade_second != "undefined")? JSON.parse(gradeGraphData[i].grade_second) : null;
                var gradeObj3 = (gradeGraphData[i].grade_third  != "undefined")?JSON.parse(gradeGraphData[i].grade_third): null;
                 
                tempGradeObj = {};
                tempGradeObj.grade = gradeObj1.grade;
                tempGradeObj.record_time = gradeObj1.record_time;
                tempGradeObj.entered_grade = "first";
                tempGradeObj.date = gradeObj1.date;
                gradeDataForGraph.push(tempGradeObj);
              
                if(gradeObj2 != null){
                    tempGradeObj = {};
                    tempGradeObj.grade = gradeObj2.grade;
                    tempGradeObj.record_time = gradeObj2.record_time;
                    tempGradeObj.entered_grade = "second";
                    tempGradeObj.date = gradeObj2.date;
                    gradeDataForGraph.push(tempGradeObj);
                }
                
                 if(gradeObj3 != null){
                    tempGradeObj = {};
                    tempGradeObj.grade = gradeObj3.grade;
                    tempGradeObj.record_time = gradeObj3.record_time;
                    tempGradeObj.entered_grade = "third";
                    tempGradeObj.date = gradeObj3.date;
                    gradeDataForGraph.push(tempGradeObj);
                }
              
           }
            console.log(gradeDataForGraph);
            return gradeDataForGraph;
    }

    this.getGradeDataForGraph = function(gradeDataForGraph){
        
            for(var i=0; i<gradeDataForGraph.length; i++){
                gradeDataForGraph[i].x = i+1;
                gradeDataForGraph[i].y = gradeDataForGraph[i].grade-1;
                gradeDataForGraph[i].labelX = moment(gradeDataForGraph[i].date).format("M/DD");
            }
       
            return gradeDataForGraph;
       
     }


   
    this.getPlotdataNonGarde = function(field){
        console.log(field);
        var query = " SELECT "+field+",date FROM tbl_master where "+field+" != 0.0 and "+field+" != '' and "+field+" != '[]' order by date asc";
        var bufferArray = [];
 		var q = $q.defer();
		$cordovaSQLite.execute(db, query).then(function(res) {
            if(res.rows.length > 0) { 
                for(var i=0;i<res.rows.length;i++){				 
					bufferArray.push(res.rows.item(i));
				}  
                q.resolve(bufferArray);
                 return bufferArray;
               
            } else {
                console.log("No results found");
                q.reject("No results found"); 
                return false;
            }
        }, function (err) {
            q.reject(err);
            console.error(err);
        });
		//console.log(q.promise);
        return q.promise;  
    }
    

    this.getExerciseDataForGraph = function(exerciseGraphData){
            for(var i=0; i<exerciseGraphData.length; i++){
                exerciseGraphData[i].x = i+1;
                exerciseGraphData[i].y = exerciseGraphData[i].exercise;
                exerciseGraphData[i].labelX = moment(exerciseGraphData[i].date).format("M/DD");
            }
             return exerciseGraphData;
    }
  
    this.getSevenExerciseData =  function(data,operational_date){
        var flag =0;
        var exerciseGraphData = [];
        var showRightArrow = true;
        var showLeftArrow = true;
       for(var i=0;i<data.length;i++){
           if(moment(data[i].date).diff(moment(operational_date), 'days') <= 0){
             flag = i;
           }
       }
       for(i=flag;i>=0 && exerciseGraphData.length<7;i--){
          exerciseGraphData.push(data[i]);
          exerciseGraphData.lowerLimit = i;
          exerciseGraphData.upperLimit = flag;
       }
       exerciseGraphData.reverse();
        if(exerciseGraphData.length<7){
            for(i=flag+1;exerciseGraphData.length<7 && i<data.length;i++){
                exerciseGraphData.push(data[i]);
                exerciseGraphData.upperLimit = i;
            }
        }
        if(exerciseGraphData.upperLimit == data.length-1){
           showRightArrow = false;
        }
        if(exerciseGraphData.lowerLimit == 0){
           showLeftArrow = false;
        }
        return [exerciseGraphData,showRightArrow,showLeftArrow];
    }

    this.getStressDataForGraph = function(stressGraphData){
          
            for(var i=0; i<stressGraphData.length; i++){
                stressGraphData[i].x = i+1;
                if(stressGraphData[i].stress == 0.0){
                     stressGraphData[i].y=0;
                 }
                else if(stressGraphData[i].stress == 1.0){
                    stressGraphData[i].y=1;
                }
                else{
                    stressGraphData[i].y=2;
                }
                stressGraphData[i].labelX = moment(stressGraphData[i].date).format("M/DD");
            }
            console.log(stressGraphData);
             return stressGraphData;
    }

    this.getMedicationDataForGraph = function(medicationGraphData){
            for(var i=0; i<medicationGraphData.length; i++){
                medicationGraphData[i].x = i+1;
                medicationGraphData[i].y=JSON.parse(medicationGraphData[i].medication).length;
                medicationGraphData[i].labelX = moment(medicationGraphData[i].date).format("M/DD");
            }
            console.log(medicationGraphData);
             return medicationGraphData;
    }

   

    this.getPlotdataNonGardeSmoke = function(field){
         var query = " SELECT "+field+",date FROM tbl_master where "+field+" != '' order by date asc";
        var bufferArray = [];
 		var q = $q.defer();
		$cordovaSQLite.execute(db, query).then(function(res) {
            if(res.rows.length > 0) { 
                for(var i=0;i<res.rows.length;i++){				 
					bufferArray.push(res.rows.item(i));
				}  
                q.resolve(bufferArray);
                 return bufferArray;
               
            } else {
                console.log("No results found");
                q.reject(bufferArray); 
                return false;
            }
        }, function (err) {
            q.reject(err);
            console.error(err);
        });
		//console.log(q.promise);
        return q.promise;  
    }

    

    this.getSmokeDataForGraph = function(smokeGraphData){
          
            for(var i=0; i<smokeGraphData.length; i++){
                smokeGraphData[i].x = i+1;
                 switch(smokeGraphData[i].smoke)
                    {
                    case '0':
                      smokeGraphData[i].y = 0;
                      break;
                    case '<1':
                      smokeGraphData[i].y = 1;
                      break;
                    case '1+':
                      smokeGraphData[i].y = 2;
                      break;
                    }
                    smokeGraphData[i].labelX = moment(smokeGraphData[i].date).format("M/DD");
            }
            console.log(smokeGraphData);
              return smokeGraphData;
    }
    this.getDrinksDataForGraph = function(drinksGraphData){
       
            for(var i=0; i<drinksGraphData.length; i++){
                drinksGraphData[i].x = i+1;
                 switch(drinksGraphData[i].drinks)
                    {
                    case '0':
                      drinksGraphData[i].y = 0;
                      break;
                    case '1-2':
                      drinksGraphData[i].y = 1;
                      break;
                    case '3+':
                      drinksGraphData[i].y = 2;
                      break;
                    }
                    drinksGraphData[i].labelX = moment(drinksGraphData[i].date).format("M/DD");
            }
             return drinksGraphData;
    }
     this.getWeightDataForGraph = function(weightGraphData){
        
            for(var i=0; i<weightGraphData.length; i++){
                weightGraphData[i].x = i+1;
                weightGraphData[i].y = weightGraphData[i].weight;
                    weightGraphData[i].labelX = moment(weightGraphData[i].date).format("M/DD");
            }
              return weightGraphData;
    }

    this.getAvgSmoke = function(data){
        var smokeSum = 0;
        for(var i=0;i<data.length;i++){
          switch(data[i].smoke)
                    {
                    case '0':
                      smokeSum = smokeSum+0;
                      break;
                    case '<1':
                      smokeSum = smokeSum+2;
                      break;
                    case '1+':
                      smokeSum = smokeSum+4;
                      break;
                    }
         }
            smokeSum = smokeSum/data.length;
            if(smokeSum <1){
                return '0';
            }
            else if(smokeSum <3){
                return '<1'
            }
            else {
                return '1+'
            }

    }

     this.getAvgDrink = function(data){
        var drinkSum = 0;
        for(var i=0;i<data.length;i++){
          switch(data[i].drinks)
                    {
                    case '0':
                      drinkSum = drinkSum+0;
                      break;
                    case '1-2':
                      drinkSum = drinkSum+1.5;
                      break;
                    case '3+':
                      drinkSum = drinkSum+3;
                      break;
                    }
         }
            drinkSum = drinkSum/data.length;
            if(drinkSum <1){
                return '0';
            }
            else if(drinkSum <=2){
                return '1-2'
            }
            else {
                return '3+'
            }
     }

     this.getCommonFieldsAvg = function(res,field){
          var sum = 0;
          for(var i=0;i<res.length;i++){
             sum =  res[i][field] + sum;
          }
          return sum/res.length;
     }
     this.getStressAvg = function(data){
          var stressSum = 0;
        for(var i=0;i<data.length;i++){
           
           stressSum = stressSum+parseInt(data[i].stress);
         }
         stressSum = stressSum/data.length;
         return this.getStressText(stressSum);
         
     }

     this.getStressText = function(stress){
          console.log(stress);
        if(stress <= 1.0){
            return "LOW";
            }
            else if(stress <= 2.0){
                return "MED";
            }
            else{
                return "HIGH";
            }
     }
     this.getMedsAvg = function(data){
         var sumMeds = 0;
         for(var i=0;i<data.length;i++){
           sumMeds = JSON.parse(data[i].medication).length + sumMeds;
         }
         return sumMeds/data.length;
     }

     this.getLeftPlotData = function(data,oldShownData){
       var newShownData = [];
       var showRightArrow = true;
       var showLeftArrow = true;
           for(var i=oldShownData.lowerLimit-1;i>=0 && newShownData.length<7;i--){
              newShownData.push(data[i]);
              newShownData.lowerLimit = i;
           }
           newShownData.reverse();
           newShownData.upperLimit = oldShownData.lowerLimit-1;
           for(i=oldShownData.lowerLimit;newShownData.length<7 && i<data.length;i++){
              newShownData.push(data[i]);
              newShownData.upperLimit = i;
           }

          //newShownData.upperLimit = oldShownData.lowerLimit-1;
          
          if(newShownData.upperLimit == data.length-1){
             showRightArrow = false;
          }
          if(newShownData.lowerLimit == 0){
            showLeftArrow = false;
          }
       
        return [newShownData,showRightArrow,showLeftArrow];
     }

     this.getRightPlotData = function(data,oldShownData){
       var newShownData = [];
       var showRightArrow = true;
       var showLeftArrow = true;
           for(var i=oldShownData.upperLimit+1;newShownData.length<7 && i<data.length;i++){
                newShownData.push(data[i]);
                newShownData.upperLimit = i;
            }
          newShownData.lowerLimit = oldShownData.upperLimit+1;
          
          if(newShownData.upperLimit == data.length-1){
            showRightArrow = false;
          }
          if(newShownData.lowerLimit == 0){
             showLeftArrow = false;
          }
        return [newShownData,showRightArrow,showLeftArrow];
     }

    this.getPdfExercise = function(field){
        console.log(field);
        var query = " SELECT "+field+",date FROM tbl_master where "+field+" != 0.0 and "+field+" != '' and "+field+" != '[]' and date <= ? order by date asc limit 7";
        var bufferArray = [];
        var q = $q.defer();
        $cordovaSQLite.execute(db, query,[moment().format('YYYY-MM-DD')]).then(function(res) {
                if(res.rows.length > 0) { 
                    for(var i=0;i<res.rows.length;i++){        
              bufferArray.push(res.rows.item(i));
            }  
                    q.resolve(bufferArray);
                     return bufferArray;
                   
                } else {
                    console.log("No results found");
                    q.reject("No results found"); 
                    return false;
                }
            }, function (err) {
                q.reject(err);
                console.error(err);
            });
        //console.log(q.promise);
            return q.promise;  
        }

      this.getPdfSmoke = function(field){
        var query = " SELECT "+field+",date FROM tbl_master where "+field+" != '' and date <=? order by date asc limit 7";
        var bufferArray = [];
        var q = $q.defer();
        $cordovaSQLite.execute(db, query,[moment().format('YYYY-MM-DD')]).then(function(res) {
                if(res.rows.length > 0) { 
                    for(var i=0;i<res.rows.length;i++){        
              bufferArray.push(res.rows.item(i));
            }  
                    q.resolve(bufferArray);
                     return bufferArray;
                   
                } else {
                    console.log("No results found");
                    q.reject(bufferArray); 
                    return false;
                }
            }, function (err) {
                q.reject(err);
                console.error(err);
          });
    //console.log(q.promise);
        return q.promise;  
        }

        this.setInitialPdf = function(){
         var query = " SELECT date,grade_first,grade_second,grade_third  FROM tbl_master where date <=? order by date asc limit 7";
          var bufferArray = [];
          var q = $q.defer();
          $cordovaSQLite.execute(db, query,[moment().format('YYYY-MM-DD')]).then(function(res) {
                  if(res.rows.length > 0) { 
                      for(var i=0; i<res.rows.length; i++){        
                bufferArray.push(res.rows.item(i));
              }
                      q.resolve(bufferArray);
                       return bufferArray;
                  } else {
                      console.log("No results found");
                      q.reject("No results found"); 
                      return false;
                  }
              }, function (err) {
                  q.reject(err);
                  console.error(err);
              });
              return q.promise;  
    }
}