angular
.module('app.services')
.factory('Chats', function($filter) {
  // Might use a resource here that returns a JSON array
  var chats = [
    {
         "value":"0",
        "Answer":{
           "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER0.OPT1')+"<br><br>"+$filter('translate')('DIGITALCOACH.ANSWER0.OPT2')],
           "align":"left"
        },
      
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION1')],
          "no":"1",
          "align":"right"
          },
          {
            "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION2')],
             "no":"2",
             "align":"right"
        },
         {
            "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION3')],
             "no":"3",
             "align":"right"
        }
        ]
      
    },
		{
     
        "value":"1",
        "Answer":{
           "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER1')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION4')],
          "no":"4",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION5')],
          "no":"5",
          "align":"right"
        }]
      
    },
    {
      
        "value":"2",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER2')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION18')],
          "no":"18",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION19')],
          "no":"19",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION1')],
          "no":"1",
          "align":"right"
        }]
      
    },
    {
      
        "value":"3",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER3')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION22')],
          "no":"22",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION23')],
          "no":"23",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION44')],
          "no":"44",
          "align":"right"
        }]
      
    },
    {
      
        "value":"4",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER4.OPT1')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER4.OPT2')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER4.OPT3')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER4.OPT4')+"<br><br>"+$filter('translate')('DIGITALCOACH.ANSWER4.OPT5')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION6')],
          "no":"6",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION7')],
          "no":"7",
          "align":"right"
        }]
      
    },
    {
      
        "value":"5",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER5')],
           "align":"left",
           "hideAddQue":true
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION6')],
          "no":"6",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION7')],
          "no":"7",
          "align":"right"
        }]
      
    },
    {
      
        "value":"6",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER6')],
           "align":"left",
           "hideAddQue":true
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION8')],
          "no":"8",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION9')],
          "no":"9",
          "align":"right"
        },
        {
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION10')],
          "no":"10",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION11')],
          "no":"11",
          "align":"right"
        }
        ]
      
    },
    {
      
        "value":"7",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER7.OPT1')+"<br><br>"+$filter('translate')('DIGITALCOACH.ANSWER7.OPT2')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION6')],
          "no":"46",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION7')],
          "no":"46",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION7E')],
          "no":"46",
          "align":"right"
        }
        ]
      
    },
     {
      
        "value":"8",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER8.OPT1')+"<br><br>"+$filter('translate')('DIGITALCOACH.ANSWER8.OPT2')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION6')],
          "no":"6",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION7')],
          "no":"7",
          "align":"right"
        }]
      
    },
     {
      
        "value":"9",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER9.OPT1')+"<br><br>"+$filter('translate')('DIGITALCOACH.ANSWER9.OPT2')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION6')],
          "no":"6",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION7')],
          "no":"7",
          "align":"right"
        }]
      
    },
    {
      
        "value":"10",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER10.OPT1')+"<br><br>"+$filter('translate')('DIGITALCOACH.ANSWER10.OPT2')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION6')],
          "no":"6",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION7')],
          "no":"7",
          "align":"right"
        }]
      
    },
    {
      
        "value":"11",
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION12')],
          "no":"12",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION13')],
          "no":"13",
          "align":"right"
        },
        {
        "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION14')],
          "no":"14",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION15')],
          "no":"15",
          "align":"right"
        }]
      
    },
    {
      
        "value":"12",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER12.OPT1')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER12.OPT2')+"<br><br>"+$filter('translate')('DIGITALCOACH.ANSWER12.OPT3')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION6')],
          "no":"6",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION7')],
          "no":"7",
          "align":"right"
        }]
      
    },
    {
      
        "value":"13",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER13.OPT1')+"<br><br>"+$filter('translate')('DIGITALCOACH.ANSWER13.OPT2')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION6')],
          "no":"6",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION7')],
          "no":"7",
          "align":"right"
        }]
      
    },
    {
      
        "value":"14",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER14.OPT1')+"<br><br>"+$filter('translate')('DIGITALCOACH.ANSWER14.OPT2')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION6')],
          "no":"6",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION7')],
          "no":"7",
          "align":"right"
        }]
      
    },
     {
      
        "value":"15",
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION16')],
          "no":"16",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION17')],
          "no":"17",
          "align":"right"
        }]
      
    },
     {
      
        "value":"16",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER16.OPT1')+"<br><br>"+$filter('translate')('DIGITALCOACH.ANSWER16.OPT2')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION6')],
          "no":"6",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION7')],
          "no":"7",
          "align":"right"
        }]
      
    },
    {
      
        "value":"17",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER17.OPT1')+"<br><br>"+$filter('translate')('DIGITALCOACH.ANSWER17.OPT2')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION6')],
          "no":"6",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION7')],
          "no":"7",
          "align":"right"
        }]
      
    },
    {
      
        "value":"18",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER18')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION1')],
          "no":"1",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION3')],
          "no":"3",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION31')],
          "no":"31",
          "align":"right"
        }]
      
    },
    {
      
        "value":"19",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER19')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION1')],
          "no":"1",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION3')],
          "no":"3",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION31')],
          "no":"31",
          "align":"right"
        }]
      
    },
    {
      
        "value":"20",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER20.OPT1')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER20.OPT2')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER20.OPT3')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER20.OPT4')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION21')],
          "no":"21",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION3')],
          "no":"3",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION31')],
          "no":"31",
          "align":"right"
        }]
      
    },
    {
      
        "value":"21",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER21')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION20')],
          "no":"20",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION3')],
          "no":"3",
          "align":"right"
        },
        {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION31')],
          "no":"31",
          "align":"right"
        }]
      
    },
     {
      
        "value":"22",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER22.OPT1')+" "+
          "<a href='#/erectionHS'>"+$filter('translate')('DIGITALCOACH.ANSWER22.OPT2')+"</a>"+
          $filter('translate')('DIGITALCOACH.ANSWER22.OPT3')+"<br>"+
          $filter('translate')('DIGITALCOACH.ANSWER22.OPT4')+" "+
          "<a href='#/tab/timeline'>"+$filter('translate')('DIGITALCOACH.ANSWER22.OPT5')+"</a> "+
          $filter('translate')('DIGITALCOACH.ANSWER22.OPT6')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION23')],
          "no":"23",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION24')],
          "no":"24",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION25')],
          "no":"25",
          "align":"right"
        }]
      
    },
    {
      
        "value":"23",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER23.OPT1')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER23.OPT2')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER23.OPT3')+" "+$filter('translate')('DIGITALCOACH.ANSWER23.OPT4')+" "+$filter('translate')('DIGITALCOACH.ANSWER23.OPT5')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION24')],
          "no":"24",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION25')],
          "no":"25",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION22')],
          "no":"22",
          "align":"right"
        }]
      
    },
    {
      
        "value":"24",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER24')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION25')],
          "no":"25",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION20')],
          "no":"20",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION22')],
          "no":"22",
          "align":"right"
        }]
      
    },
    {
      
        "value":"25",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER25')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION26')],
          "no":"26",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION20')],
          "no":"20",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION27')],
          "no":"27",
          "align":"right"
        }]
      
    },
    {
      
        "value":"26",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER26')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION20')],
          "no":"20",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION27')],
          "no":"27",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION28')],
          "no":"28",
          "align":"right"
        }]
      
    },
    {
      
        "value":"27",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER27.OPT1')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER27.OPT2')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER27.OPT3')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER27.OPT4')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION28')],
          "no":"28",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION29')],
          "no":"29",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION30')],
          "no":"30",
          "align":"right"
        }]
      
    },
    {
      
        "value":"28",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER28.OPT1')+"<br>"
                    +$filter('translate')('DIGITALCOACH.ANSWER28.OPT2')+"<br>"
                    +$filter('translate')('DIGITALCOACH.ANSWER28.OPT3')+"<br>"
                    +$filter('translate')('DIGITALCOACH.ANSWER28.OPT4')+"<br>"
                    +$filter('translate')('DIGITALCOACH.ANSWER28.OPT5')+"<br>"
                    +$filter('translate')('DIGITALCOACH.ANSWER28.OPT6')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION29')],
          "no":"29",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION30')],
          "no":"30",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION31')],
          "no":"31",
          "align":"right"
        }]
      
    },
    {
      
        "value":"29",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER29')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION28')],
          "no":"28",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION30')],
          "no":"30",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION31')],
          "no":"31",
          "align":"right"
        }]
      
    },
    {
      
        "value":"30",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER30.OPT1')+" "+
          "<a href='#/tab/profile/profileMain'>"+$filter('translate')('DIGITALCOACH.ANSWER30.OPT2')+"</a> "+
          $filter('translate')('DIGITALCOACH.ANSWER30.OPT3')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION28')],
          "no":"28",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION29')],
          "no":"29",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION31')],
          "no":"31",
          "align":"right"
        }]
      
    },
    {
      
        "value":"31",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER31')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION32')],
          "no":"32",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION33')],
          "no":"33",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION35')],
          "no":"35",
          "align":"right"
        }]
      
    },
    {
      
        "value":"32",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER32')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION33')],
          "no":"33",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION34')],
          "no":"34",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION35')],
          "no":"35",
          "align":"right"
        }]
      
    },
    {
      
        "value":"33",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER33.OPT1')+"<br>"
                    +$filter('translate')('DIGITALCOACH.ANSWER33.OPT2')+"<br>"
                    +$filter('translate')('DIGITALCOACH.ANSWER33.OPT3')+"<br><br>"
                    +$filter('translate')('DIGITALCOACH.ANSWER33.OPT4')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION36')],
          "no":"36",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION34')],
          "no":"34",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION35')],
          "no":"35",
          "align":"right"
        }]
      
    },
    {
      
        "value":"34",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER34.OPT1')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER34.OPT2')
                    +"<br>"+$filter('translate')('DIGITALCOACH.ANSWER34.OPT3')
                    +"<br>"+$filter('translate')('DIGITALCOACH.ANSWER34.OPT4')
                    +"<br>"+$filter('translate')('DIGITALCOACH.ANSWER34.OPT5') 
                    +"<br>"+$filter('translate')('DIGITALCOACH.ANSWER34.OPT6')
                    +"<br>"+$filter('translate')('DIGITALCOACH.ANSWER34.OPT7')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION36')],
          "no":"36",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION35')],
          "no":"35",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION37')],
          "no":"37",
          "align":"right"
        }]
      
    },
    {
      
        "value":"35",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER35.OPT1')+" "+
                   "<a href='#/tab/profile/profileMain'>"+$filter('translate')('DIGITALCOACH.ANSWER35.OPT4')+"</a> "+
                    $filter('translate')('DIGITALCOACH.ANSWER35.OPT5')+"<br>"
                    +$filter('translate')('DIGITALCOACH.ANSWER35.OPT2')
                    +"<br>"+$filter('translate')('DIGITALCOACH.ANSWER35.OPT3')
                    ],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION36')],
          "no":"36",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION37')],
          "no":"37",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION33')],
          "no":"33",
          "align":"right"
        }]
      
    },
    {
      
        "value":"36",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER36')
                    ],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION37')],
          "no":"37",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION33')],
          "no":"33",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION35')],
          "no":"35",
          "align":"right"
        }]
      
    },
    {
      
        "value":"37",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER37.OPT1')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER37.OPT2')
                    +"<br>"+$filter('translate')('DIGITALCOACH.ANSWER37.OPT3')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER37.OPT4')
                    ],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION22')],
          "no":"22",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION46')],
          "no":"4",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION47')],
          "no":"6",
          "align":"right"
        }]
      
    },
     {
        "value":"38",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER38')
                    ],
           "align":"left",
           "hideAddQue":true
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION6')],
          "no":"40",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION7')],
          "no":"41",
          "align":"right"
        }]
      
    },
     {
        "value":"39",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER39')
                    ],
           "align":"left",
           "hideAddQue":true
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION31')],
          "no":"31",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION33')],
          "no":"33",
          "align":"right"
        },
        {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION1')],
          "no":"1",
          "align":"right"
        }]
      
    },
     {
        "value":"40",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER40')
                    ],
           "align":"left",
           "hideAddQue":true
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION6')],
          "no":"42",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION7')],
          "no":"43",
          "align":"right"
        }]
      
    },
    {
        "value":"41",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER41')],
           "align":"left",
           "hideAddQue":true
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION23')],
          "no":"23",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION24')],
          "no":"24",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION20')],
          "no":"20",
          "align":"right"
        }]
      
    },
    {
        "value":"42",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER42.OPT1')+"<br>"+
                    $filter('translate')('DIGITALCOACH.ANSWER42.OPT2')+" "+
                   "<a href='#/tab/timeline'>"+$filter('translate')('DIGITALCOACH.ANSWER42.OPT6')+"</a> "+
                    $filter('translate')('DIGITALCOACH.ANSWER42.OPT7')+" "+
                    "<a href='#/erectionHS'>"+$filter('translate')('DIGITALCOACH.ANSWER42.OPT8')+"</a> "
                    +"<br>"+$filter('translate')('DIGITALCOACH.ANSWER42.OPT3')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER42.OPT4')
                    +"<br>"+
                    $filter('translate')('DIGITALCOACH.ANSWER42.OPT5')+" "+
                    "<a href='#/tab/profile/profileMain'>"+$filter('translate')('DIGITALCOACH.ANSWER42.OPT9')+"</a>"
                    ],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION22')],
          "no":"22",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION25')],
          "no":"25",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION44')],
          "no":"44",
          "align":"right"
        }]
      
    },
    {
        "value":"43",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER43')
                    ],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION27')],
          "no":"27",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION28')],
          "no":"28",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION20')],
          "no":"20",
          "align":"right"
        }]
      
    },
    {
        "value":"44",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER44.OPT1')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER44.OPT2')
                    ],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION47')],
          "no":"6",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION45')],
          "no":"45",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION23')],
          "no":"23",
          "align":"right"
        }]
      
    },
    {
        "value":"45",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER45')
                    ],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION47')],
          "no":"6",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION23')],
          "no":"23",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION35')],
          "no":"35",
          "align":"right"
        }]
      
    },
    {
      
        "value":"46",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER7a')],
           "align":"left",
           "hideAddQue":true
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION6')],
          "no":"100",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION7')],
          "no":"100",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION7E')],
          "no":"100",
          "align":"right"
        }]
      
    },
    {
      
        "value":"47",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER7b')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION20')],
          "no":"20",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION3')],
          "no":"3",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION31')],
          "no":"31",
          "align":"right"
        }]
      
    },
     {
      
        "value":"48",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER7b')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION20')],
          "no":"20",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION21')],
          "no":"21",
          "align":"right"
        }]
      
    },
    {
        "value":"49",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER20.OPT1')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER20.OPT2')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER20.OPT3')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER20.OPT4')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION3')],
          "no":"21",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION44')],
          "no":"3",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION31')],
          "no":"31",
          "align":"right"
        }]
      
    },
     {
        "value":"50",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER38A')],
           "align":"left",
           "hideAddQue":true
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION38')],
          "no":"38",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION39')],
          "no":"39",
          "align":"right"
        }]
      
    } 

  ];

  return {
    all: function() {
      return chats;
    },
    getQuestion: function(quesNumber) {
      return chats[quesNumber];
    },
    
  };
});
