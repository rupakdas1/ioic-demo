angular
    .module('app.controllers')
    .filter('dateFormat',  function() {
       return function(x) {
         var date = moment(x).format("dddd, MMMM Do");
         console.log();
        return date.trim();
        }
      });
    
    angular
    .module('app.controllers')
	.filter('timeFormat',  function() {
       return function(x) {
         var time = moment(x).format("hh:mm A");
         console.log(time);
        return time.trim();
        }
      });