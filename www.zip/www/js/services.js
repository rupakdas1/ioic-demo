angular.module('app.services', []);

angular
.module('app.services')
.service('AddMedications', AddMedications);

AddMedications.$inject = ['$cordovaSQLite','$q'];

function AddMedications($cordovaSQLite,$q){
    
    var que_list = [];
    var que_camefrom = "";

    this.storeItemsInService = function(items){
        que_list = items;
    }
    this.getItemsFromService = function(){
       return que_list;     
     }
     this.setCamefrom =  function(camefrom){
         que_camefrom = camefrom;
     }
     this.getCamefrom =  function(){
         return que_camefrom;
     }
    /* =================Get  Medications service====================== */ 
    this.getMedications = function(){
        
        var query = "SELECT * FROM tbl_medications";		
 		var q = $q.defer();
         var bufferArray = [];
		$cordovaSQLite.execute(db, query).then(function(result) {
            if(result.rows.length > 0) {
			  for(var i=0; i<result.rows.length; i++){				 
					bufferArray.push(result.rows.item(i));
				}
			   q.resolve(bufferArray);
               return bufferArray; 
            } else {
                console.log("No results found");
                q.reject("No results found"); 
                return false;
            }
        }, function (err) {
            q.reject(err);
            console.error(err);
        });
        return q.promise;   
    } 
     /* =================Set  Medications service====================== */ 
    this.setMedications = function(medicationData){ 
         var q = $q.defer(); 
		var medication_name = medicationData;		
        var query = "INSERT INTO tbl_medications (medication_name,recorded_date) VALUES (?,?)";
        var recorded_date = moment();
        $cordovaSQLite.execute(db,query,[medication_name,recorded_date]).then(function(result) {
              q.resolve(result.rows.length);
			
		}, function(error) {
			console.error(error);
			 q.reject(error); 
		});
		return q.promise;
    }
     /* =================Delete  Medications service====================== */ 
    this.deleteMedicine = function(medication_name){
        var q = $q.defer();
		var query = "DELETE FROM tbl_medications WHERE medication_name = ?";
			$cordovaSQLite.execute(db,query,[medication_name]).then(function(result) {
			q.resolve(result.rowsAffected);
		}, function(error) {
			q.reject(error)
			console.error(error);
		});
		return q.promise;
    }
     /* =================Set  Questions  service====================== */ 
    this.setQuestions = function(que,ans,graphIndex){ 
         if(ans == null){
            ans = "";
         }
         var q = $q.defer(); 
        var query = "INSERT INTO tbl_queforDoctor (question_text,recorded_date,faq_answer,graphIndex) VALUES (?,?,?,?)";
        var recorded_date = moment();
        $cordovaSQLite.execute(db,query,[que,recorded_date,ans,graphIndex]).then(function(result) {
              q.resolve(result.rows.length);
			
		}, function(error) {
			console.error(error);
			 q.reject(error); 
		});
		return q.promise;
    }

     this.getQuestions = function(){
        
        var query = "SELECT * FROM tbl_queforDoctor";		
 		var q = $q.defer();
         var bufferArray = [];
		$cordovaSQLite.execute(db, query).then(function(result) {
            if(result.rows.length > 0) {
			  for(var i=0;i<result.rows.length;i++){				 
					bufferArray.push(result.rows.item(i));
				}
			   q.resolve(bufferArray);
               return bufferArray; 
            } else {
                console.log("No results found");
                q.reject("No results found"); 
                return false;
            }
        }, function (err) {
            q.reject(err);
            console.error(err);
        });
        return q.promise;   
    } 
    /* =================Delete  Questions====================== */ 
    this.deleteQuestion = function(que,ans){
        var q = $q.defer();
		var query = "DELETE FROM tbl_queforDoctor WHERE question_text = ? and faq_answer = ?";
			$cordovaSQLite.execute(db,query,[que,ans]).then(function(result) {
			q.resolve(result.rowsAffected);
		}, function(error) {
			q.reject(error)
			console.error(error);
		});
		return q.promise;
    }
     /* =================Update  Questions====================== */ 
    this.updateQuestions = function(old_que,new_que,ans){ 
         var q = $q.defer(); 
         console.log(ans);
        var query = "UPDATE tbl_queforDoctor SET question_text =? ,recorded_date =? WHERE question_text = ? and faq_answer = ?";
        var recorded_date = moment();
        $cordovaSQLite.execute(db,query,[new_que,recorded_date,old_que,ans]).then(function(result) {
            console.log(result);
		}, function(error) {
			console.error(error);
			 q.reject(error); 
		});
		return q.promise;
    }
}
angular
.module('app.services')
.service('AddRecords', AddRecords);

AddRecords.$inject = ['$cordovaSQLite','$q'];

function AddRecords($cordovaSQLite,$q){

    this.getRecords = function(){
        var query = "SELECT date FROM tbl_master";
		$cordovaSQLite.execute(db,query).then(function(result) {
			if(result.rows.length > 0) {			
			} else {
				console.log("NO ROWS EXIST");
			}
		}, function(error) {
			console.error(error);
		});
    } 
 /* =================Returm current time in 12 hour====================== */ 
	this.currentTime = function(date) {
		var hours = date.getHours();
		var minutes = date.getMinutes();
		var ampm = hours >= 12 ? 'PM' : 'AM';
		hours = hours % 12;
		hours = hours ? hours : 12; // the hour '0' should be '12'
		minutes = minutes < 10 ? '0'+minutes : minutes;
		var strTime = hours + ':' + minutes + ' ' + ampm;
		return strTime;
	}
	this.getGradeData = function(grade_date, grade_sl) {
        var grade_col = "";
		var x = '';
		var q = $q.defer();
		var query = "SELECT *  FROM tbl_master where date = ?";
		$cordovaSQLite.execute(db,query,[grade_date]).then(function(result) {
			if(result.rows.length > 0) {
				var bufferArray = [];
				 for(var i=0;i<result.rows.length;i++){	
					if(grade_sl == 0)			 
						bufferArray.push(result.rows.item(i).grade_first) ;
					if(grade_sl == 1)			 
						bufferArray.push( result.rows.item(i).grade_second) ;
					if(grade_sl == 2)			 
						bufferArray.push(result.rows.item(i).grade_third) ;
				}			
			   q.resolve(bufferArray);
			} else {				
				  return false; 
			}
		}, function(error) {
			 q.reject(error);			
			console.error(error);
		});
		 return q.promise;
	}
	/* =================Store record on tbl_master table===================== */ 
    this.setRecords = function(recordData, last_insert_id_value, gradeData){
		console.log(gradeData);
		var grade_first, grade_second, grade_third;
		var date = recordData.date;	
		if(gradeData != null){
			if(gradeData.length == 1){
				var gradeDataJson = {
					grade : gradeData[0].grade,
					record_time : gradeData[0].record_time,
					date : gradeData[0].date,
					is_wakeup: gradeData[0].is_wakeup,
					last_long_level : gradeData[0].last_long_level,
					luckyData: gradeData[0].luckyData
				}
				grade_first = JSON.stringify(gradeDataJson);
                if(recordData.gradeValueData.grade){					
					grade_second = JSON.stringify(recordData.gradeValueData);
					window.localStorage.setItem(date,2)
				}
			}
			else if(gradeData.length == 2){
				var gradeDataJson1 = {
					grade : gradeData[0].grade,
					record_time : gradeData[0].record_time,
					date : gradeData[0].date,
					is_wakeup: gradeData[0].is_wakeup,
					last_long_level : gradeData[0].last_long_level,
					luckyData: gradeData[0].luckyData
				}
				grade_first = JSON.stringify(gradeDataJson1);

				var gradeDataJson2 = {
					grade : gradeData[1].grade,
					record_time : gradeData[1].record_time,
					date : gradeData[1].date,
					is_wakeup: gradeData[1].is_wakeup,
					last_long_level : gradeData[1].last_long_level,
					luckyData: gradeData[1].luckyData
				}
				grade_second = JSON.stringify(gradeDataJson2);
				if(recordData.gradeValueData.grade){
					grade_third = JSON.stringify(recordData.gradeValueData);

					window.localStorage.setItem(date,3)
				}
			}
			else if(gradeData.length == 3){
				var gradeDataJson1 = {
					grade : gradeData[0].grade,
					record_time : gradeData[0].record_time,
					date : gradeData[0].date,
					is_wakeup: gradeData[0].is_wakeup,
					last_long_level : gradeData[0].last_long_level,
					luckyData: gradeData[0].luckyData
				}
				grade_first = JSON.stringify(gradeDataJson1);

				var gradeDataJson2 = {
					grade : gradeData[1].grade,
					record_time : gradeData[1].record_time,
					date : gradeData[1].date,
					is_wakeup: gradeData[1].is_wakeup,
					last_long_level : gradeData[1].last_long_level,
					luckyData: gradeData[1].luckyData
				}
				grade_second = JSON.stringify(gradeDataJson2);
				var gradeDataJson3 = {
					grade : gradeData[2].grade,
					record_time : gradeData[2].record_time,
					date : gradeData[2].date,
					is_wakeup: gradeData[2].is_wakeup,
					last_long_level : gradeData[2].last_long_level,
					luckyData: gradeData[2].luckyData
				}
				grade_third= JSON.stringify(gradeDataJson3);
			}		
			}
		else{
			grade_first = JSON.stringify(recordData.gradeValueData);
			window.localStorage.setItem(date,1)
		}
		var month_year = recordData.month_year;
		var exercise = recordData.exerciseData;
		var drinks = recordData.drinkData;
		var smoke = recordData.smokeData;
		var weight = recordData.weightData;
		var stress = recordData.stressData;
		var medication = JSON.stringify(recordData.medicationData);
		var last_insert_id = 0;
		 last_insert_id_value = 1;
			 if(window.localStorage.getItem(date) <= 3){
						console.log(last_insert_id);
						var query = "INSERT  OR REPLACE INTO tbl_master ( id, date,month_year,grade_first,grade_second,grade_third,exercise,drinks,smoke,weight,stress,medication) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
						$cordovaSQLite.execute(db,query,[last_insert_id_value,date,month_year,grade_first,grade_second,grade_third,exercise,drinks,smoke,weight,stress,medication]).then(function(result) {
							console.log("INSERT ID -> " + result.insertId);

						}, function(error) {
							console.error(error);
						});
				 }
    }
	/* =================Update record tbl_record table====================== */ 
	this.updateRecord = function(data, sl){
		var query;
		var q = $q.defer();
		switch(sl){
			case 0:
				query = "UPDATE tbl_master SET grade_first = '"+JSON.stringify(data)+"' WHERE date = ?";
				break;
			case 1:
				query = "UPDATE tbl_master SET grade_second = '"+JSON.stringify(data)+"' WHERE date = ?";
				break;
			case 2:
				query = "UPDATE tbl_master SET grade_third = '"+JSON.stringify(data)+"' WHERE date = ?";
				break;
		}	
		$cordovaSQLite.execute(db,query,[data.date]).then(function(result) {
			q.resolve(result.rowsAffected);
		}, function(error) {
			q.reject(error)
			console.error(error);
		});
		return q.promise;
	}
	/* ================= Delete a record===================== */ 
	this.deleteRecord = function(dateTodelete) {
		if(dateTodelete != '' || dateTodelete != undefined )
		var q = $q.defer();
		var query = "DELETE FROM tbl_master WHERE date = ?";
			$cordovaSQLite.execute(db,query,[dateTodelete]).then(function(result) {
			localStorage.removeItem(dateTodelete);
			q.resolve(result.rowsAffected);
		}, function(error) {
			q.reject(error)
			console.error(error);
		});
		return q.promise;
	}
}
angular
.module('app.services')
.service('AddReminders', AddReminders);

AddReminders.$inject = ['$cordovaSQLite','$q','$cordovaCalendar'];

function AddReminders($cordovaSQLite,$q,$cordovaCalendar){
    
    var rem_list = [];
    var eve_list = [];
    var app_list = [];
      // var db = $cordovaSQLite.openDB({ name: "ehs.db", location: 1 });
    this.storeItemsInService = function(items){
        rem_list = items;
    }
    this.getItemsFromService = function(){
        console.log(rem_list);
       return rem_list;     
     }
       this.getEventsFromService = function(){
        console.log(eve_list);
       return eve_list;     
     }
       this.getAppointmentsFromService = function(){
        console.log(app_list);
       return app_list;     
     }
     this.storeEventsInService = function(items){
        eve_list = items;
    }
    this.storeAppointmentsInService = function(items){
        app_list = items;
    }
    this.getLengthOfRemindres = function() {
       var query = "SELECT reminder_name  FROM tbl_reminders limit 1";   
    var q = $q.defer();
         var bufferArray = [];
    $cordovaSQLite.execute(db, query).then(function(result) {
        
            if(result.rows.length > 0) {
               q.resolve(result.rows);
               return result.rows; 
            } else {
                console.log("No results found");
                q.reject("No results found"); 
                return false;
            }
        }, function (err) {
            q.reject(err);
            console.error(err);
        });
        return q.promise;   
    }
    this.getLengthOfEvents = function() {
       var query = "SELECT event_name  FROM tbl_events limit 1";   
    var q = $q.defer();
         var bufferArray = [];
    $cordovaSQLite.execute(db, query).then(function(result) {
            if(result.rows.length > 0) {
               q.resolve(result.rows);
               return result.rows; 
            } else {
                console.log("No results found");
                q.reject("No results found"); 
                return false;
            }
        }, function (err) {
            q.reject(err);
            console.error(err);
        });
        return q.promise;    
    }
    this.getLengthOfAppointments = function() {
       var query = "SELECT appointment_name FROM tbl_appointments limit 1";   
    var q = $q.defer();
         var bufferArray = [];
    $cordovaSQLite.execute(db, query).then(function(result) {
     
           if(result.rows.length > 0) {
               q.resolve(result.rows);
               return result.rows; 
            } else {
                console.log("No results found");
                q.reject("No results found"); 
                return false;
            }
        }, function (err) {
            q.reject(err);
            console.error(err);
        });
        return q.promise;   
    }
  this.getReminders = function(){
        console.log("sd");
        var query = "SELECT * FROM tbl_reminders";      
        var q = $q.defer();
         var bufferArray = [];
        $cordovaSQLite.execute(db, query).then(function(result) {
            console.log(result)
            if(result.rows.length > 0) {
              for(var i=0;i<result.rows.length;i++){                 
                    bufferArray.push(result.rows.item(i));
                }
               q.resolve(bufferArray);
               return bufferArray; 
            } else {
                console.log("No results found");
                q.reject("No results found"); 
                return false;
            }
        }, function (err) {
            q.reject(err);
            console.error(err);
        });
        return q.promise;   
    } 
     this.getEvents = function(){
        var query = "SELECT * FROM tbl_events";    
    var q = $q.defer();
         var bufferArray = [];
    $cordovaSQLite.execute(db, query).then(function(result) {
      console.log(result)
            if(result.rows.length > 0) {
        for(var i=0;i<result.rows.length;i++){         
          bufferArray.push(result.rows.item(i));
        }
         q.resolve(bufferArray);
               return bufferArray; 
            } else {
                console.log("No results found");
                q.reject("No results found"); 
                return false;
            }
        }, function (err) {
            q.reject(err);
            console.error(err);
        });
        return q.promise;   
    } 
     this.getAppointments = function(){
        var query = "SELECT * FROM tbl_appointments";    
    var q = $q.defer();
         var bufferArray = [];
    $cordovaSQLite.execute(db, query).then(function(result) {
      console.log(result)
            if(result.rows.length > 0) {
        for(var i=0;i<result.rows.length;i++){         
          bufferArray.push(result.rows.item(i));
        }
         q.resolve(bufferArray);
               return bufferArray; 
            } else {
                console.log("No results found");
                q.reject("No results found"); 
                return false;
            }
        }, function (err) {
            q.reject(err);
            console.error(err);
        });
        return q.promise;   
    } 

    this.setReminders = function(reminderData,reminderDate){ 
         var q = $q.defer(); 
         var setStartDate = new Date(reminderDate);
         var tempDate = setStartDate;
         var setEndDate = moment(tempDate).add(1, 'hours').toISOString();
         setEndDate = new Date(setEndDate);
         console.log(setStartDate);
         console.log(setEndDate);
            var reminder_name = reminderData;       
        var query = "INSERT INTO tbl_reminders (reminder_name,recorded_date) VALUES (?,?)";
        var recorded_date =reminderDate // moment().format("DD/MM/YYYY");

        window.plugins.calendar.hasReadWritePermission(
                  function(result) {

                    $cordovaCalendar.createEvent({
                                title: reminderData,
                                location: '',
                                notes: '',
                                startDate: setStartDate,
                                endDate: setEndDate,
                                firstReminderMinutes: 60                                                   
                              }).then(function (result) {
                                                console.log(result);
                                                // success
                                                $cordovaSQLite.execute(db,query,[reminder_name,recorded_date]).then(function(result) {
                                                q.resolve(result.rows.length);
                                                
                                                }, function(error) {
                                                                    $cordovaCalendar.deleteEvent({
                                                                    title: reminderData,
                                                                    location: '',
                                                                    notes: '',
                                                                    startDate: setStartDate,
                                                                    endDate: setEndDate                                                                    
                                                                  }).then(function (result) {
                                                                     // success
                                                                      }, function (err) {
                                                                        // error
                                                                      });
                                                    q.reject(error); 
                                                });

                                     }, function (err) {
                                     console.log("err",err);
                                    // error
                                    });
                    // if this is 'false' you probably want to call 'requestReadWritePermission' now
                    console.log(result);
                  },
                  function(err){
                    window.plugins.calendar.requestReadWritePermission();
                    console.log(err);
                  }
                );              

 
        
        return q.promise;
    }

    this.setAppointments = function(appointmentData,appointmentDate,appointmentLocation){ 
         var q = $q.defer(); 
         console.log("appointmentData:",appointmentData);
         console.log("appointmentDate:",appointmentDate);
            console.log("appointmentLocation:",appointmentLocation);
        var appointment_name = appointmentData;
        var location_text= appointmentLocation;  
        var query = "INSERT INTO tbl_appointments (appointment_name,recorded_date,location_text) VALUES (?,?,?)";
        var recorded_date =appointmentDate // moment().format("DD/MM/YYYY");
        $cordovaSQLite.execute(db,query,[appointment_name,recorded_date,location_text]).then(function(result) {
              q.resolve(result.rows.length);
      
    }, function(error) {
       q.reject(error); 
    });
    return q.promise;
    }
     this.setEvents = function(eventData,eventDate,eventLocation){ 
         var q = $q.defer(); 
         console.log("eventData:",eventData);
         console.log("eventDate:",eventDate);
          console.log("eventLocation:",eventLocation);
        var event_name = eventData;
        var location_text=eventLocation;   
        var query = "INSERT INTO tbl_events (event_name,recorded_date,location_text) VALUES (?,?,?)";
        var recorded_date =eventDate // moment().format("DD/MM/YYYY");
        $cordovaSQLite.execute(db,query,[event_name,recorded_date,location_text]).then(function(result) {
              q.resolve(result.rows.length);
      
    }, function(error) {
  
       q.reject(error); 
    });
    return q.promise;
    }

    this.deleteReminder = function(reminder_name,reminder_date){
        var q = $q.defer();
        var setStartDate = new Date(reminder_date);
         var tempDate = setStartDate;
         var setEndDate = moment(tempDate).add(1, 'hours').toISOString();
         setEndDate = new Date(setEndDate);

         console.log(setStartDate);
         console.log(setEndDate);
       
            $cordovaCalendar.deleteEvent({
            newTitle: reminder_name,
            location: '',
            notes: '',
            startDate: setStartDate,
            endDate: setEndDate
          }).then(function (result) {
                                    var query = "DELETE FROM tbl_reminders WHERE reminder_name = ?";
                                    $cordovaSQLite.execute(db,query,[reminder_name]).then(function(result) {
                                    q.resolve(result.rowsAffected);
                                    }, function(error) {
                                    q.reject(error)
                                    console.error(error);
         });
          }, function (err) {
            console.log(err);
          });

        return q.promise;
    }
     this.deleteEvent = function(event_name){
        var q = $q.defer();
    var query = "DELETE FROM tbl_events WHERE event_name = ?";
      $cordovaSQLite.execute(db,query,[event_name]).then(function(result) {
      q.resolve(result.rowsAffected);
    }, function(error) {
      q.reject(error)
      console.error(error);
    });
    return q.promise;
    }
     this.deleteAppointment = function(appointment_name){
        var q = $q.defer();
    var query = "DELETE FROM tbl_appointments WHERE appointment_name = ?";
      $cordovaSQLite.execute(db,query,[appointment_name]).then(function(result) {
      q.resolve(result.rowsAffected);
    }, function(error) {
      q.reject(error)
      console.error(error);
    });
    return q.promise;
    }
    this.updateReminders = function(oldReminderText,oldRecordedDate,newReminderText,newRecordedDate){ 
      console.log("in update");
         var q = $q.defer();
        
          var oldStartDate = new Date(oldRecordedDate);
         var tempDate = oldStartDate;
         var oldEndDate = moment(tempDate).add(1, 'hours').toISOString();
         oldEndDate = new Date(oldEndDate);
        
          var newStartDate = new Date(newRecordedDate);
         var tempNewDate = newStartDate;
         var newEndDate = moment(tempNewDate).add(1, 'hours').toISOString();
         newEndDate = new Date(newEndDate);
        


        var query = "UPDATE tbl_reminders SET reminder_name =? ,recorded_date =? WHERE reminder_name = ? and recorded_date = ?";
       // var recorded_date = moment().format("DD/MM/YYYY");
            $cordovaCalendar.deleteEvent({
                newTitle: oldReminderText,
                location: '',
                notes: '',
                startDate: oldStartDate,
                endDate: oldEndDate
              }).then(function (result) {
                console.log(result);                    
              }, function (err) {
               console.log(err);
              });          

              
            $cordovaCalendar.createEvent({
                title: newReminderText,
                location: '',
                notes: '',
                startDate: newStartDate,
                endDate: newEndDate
              }).then(function (result) {
                console.log(result);
                                         $cordovaSQLite.execute(db,query,[newReminderText,newRecordedDate,oldReminderText,oldRecordedDate]).then(function(result) {
                                         console.log(result);
                                         q.resolve();
                                         }, function(error) {
                                            console.error(error);
                                            q.reject(error); 
                                        });
              }, function (err) {
               console.log(err);
              });
            



        
        return q.promise;
    }
    this.updateEvents = function(oldEventText,oldRecordedDate,oldLocationText,newEventText,newRecordedDate,newEventLocation){ 
      console.log("in update");
         var q = $q.defer(); 
        var query = "UPDATE tbl_events SET event_name =? ,recorded_date =?,location_text =? WHERE event_name = ? and recorded_date = ? and location_text = ?";
       // var recorded_date = moment().format("DD/MM/YYYY");
        $cordovaSQLite.execute(db,query,[newEventText,newRecordedDate,newEventLocation,oldEventText,oldRecordedDate,oldLocationText]).then(function(result) {
        q.resolve();
        }, function(error) {
      console.error(error);
       q.reject(error); 
    });
    return q.promise;
    }
     this.updateAppointments = function(oldAppointmentText,oldRecordedDate,oldLocationText,newAppointmentText,newRecordedDate,newAppointmentLocation){ 
      console.log("in update");
         var q = $q.defer(); 
        var query = "UPDATE tbl_appointments SET appointment_name =? ,recorded_date =?,location_text = ? WHERE appointment_name = ? and recorded_date = ? and location_text = ?";
       // var recorded_date = moment().format("DD/MM/YYYY");
        $cordovaSQLite.execute(db,query,[newAppointmentText,newRecordedDate,newAppointmentLocation,oldAppointmentText,oldRecordedDate,oldLocationText]).then(function(result) {
        q.resolve();
        }, function(error) {
      console.error(error);
       q.reject(error); 
    });
    return q.promise;
    }


}
/*     <canvas id="EHS_canvas" ></canvas>   // put this is html
*
*
*
*
*/


function LineGraph (ctx, graphData) {

	this.ctx  = ctx ;
	this.height = ctx.canvas.height;
	this.width = ctx.canvas.width;
	//alert(this.width);

	this.graphData = graphData;

	this.graphData.paddingPx=[];
	this.graphData.paddingPx[0] = Math.round(this.height*this.graphData.padding[0]/100);
	this.graphData.paddingPx[1] = Math.round(this.width*this.graphData.padding[1]/100);
	this.graphData.paddingPx[2] = Math.round(this.height*this.graphData.padding[2]/100);
	this.graphData.paddingPx[3] = Math.round(this.width*this.graphData.padding[3]/100);

}

LineGraph.prototype.setDimension = function(width,height){
	
  this.height = height;
  this.width = width;
}

LineGraph.prototype.setData = function(plotData){
	this.isGradeGraph = false;
	if(plotData=="")
	{
		//alert("No data");
		plotData=0;
		//this.graphData.labelX=[];
	}
	if(plotData != "" && plotData[0].grade!=undefined){
		this.isGradeGraph = true;
	}
	this.graphData.data = plotData;
}

LineGraph.prototype.draw = function() {

	this.ctx.clearRect(0,0,this.width,this.width);
	// Fill the background color
	this.ctx.fillStyle = this.graphData.backgroundColor || "#FFFFFF";
	this.ctx.fillRect(0, 0, this.width, this.height);
	
	//draw verticle grid
	var innerWidth = this.width - this.graphData.paddingPx[1] - this.graphData.paddingPx[3];
	var innerHeight = this.height - this.graphData.paddingPx[0] - this.graphData.paddingPx[2];  
	for(var i = 0; i<= this.graphData.verticalGrid; i++){
		this.ctx.beginPath();
		this.ctx.strokeStyle = this.graphData.gridColor;
		this.ctx.moveTo(Math.round(this.graphData.paddingPx[3]+i*innerWidth/this.graphData.verticalGrid ), Math.round(this.graphData.paddingPx[0]));
		this.ctx.lineTo(Math.round(this.graphData.paddingPx[3]+i*innerWidth/this.graphData.verticalGrid ), Math.round(this.height - this.graphData.paddingPx[2]));
		this.ctx.closePath();
		this.ctx.stroke()
	}

	//draw horizontal grid  
	for(var i = 0; i<= this.graphData.horizontalGrid; i++){
		this.ctx.beginPath();
		this.ctx.strokeStyle = this.graphData.gridColor;
		this.ctx.moveTo(Math.round(this.graphData.paddingPx[3]), Math.round(this.graphData.paddingPx[0]+i*innerHeight/this.graphData.horizontalGrid ));
		this.ctx.lineTo(Math.round(this.width - this.graphData.paddingPx[1]), Math.round(this.graphData.paddingPx[0]+i*innerHeight/this.graphData.horizontalGrid ));
		this.ctx.closePath();
		this.ctx.stroke()
	}

	//draw labelY
	for (var i = 0; i < this.graphData.labelY.length; i++) {
		this.ctx.fillStyle =  "#FFFFFF";
		this.ctx.textAlign = "end";
		this.ctx.textBaseline = "middle";
		this.ctx.font = 'bold ' +this.width*0.023 + "px sans-serif";
  		this.ctx.fillText(this.graphData.labelY[this.graphData.labelY.length-i-1], this.graphData.paddingPx[3]*0.85, Math.round(this.graphData.paddingPx[0]+i*innerHeight/this.graphData.horizontalGrid ));
	};

	//draw labelX
	for (var i = 0; i < this.graphData.data.length ; i++) {
		this.ctx.fillStyle =  "#FFFFFF";
		this.ctx.textAlign = "center";
		this.ctx.textBaseline = "middle";
		this.ctx.font = 'bold ' + this.width*0.023 + "px sans-serif";
		if(this.isGradeGraph){
  		  this.ctx.fillText(this.graphData.data[i].labelX, this.graphData.paddingPx[3]+innerWidth*(this.graphData.data[i].x)/(this.graphData.boundary.maxX-this.graphData.boundary.minX),innerHeight + this.graphData.paddingPx[2]-17);
	     }
	     else
	     	this.ctx.fillText(this.graphData.data[i].labelX, this.graphData.paddingPx[3]+innerWidth*(this.graphData.data[i].x)/(this.graphData.boundary.maxX-this.graphData.boundary.minX),innerHeight + this.graphData.paddingPx[2]);

	};

	if(this.isGradeGraph){
		 for (var i = 0; i < this.graphData.data.length ; i++) {
		this.ctx.fillStyle =  "#FFFFFF";
		this.ctx.textAlign = "center";
		this.ctx.textBaseline = "middle";
		this.ctx.font ='bold ' + this.width*0.022 + "px sans-serif";
  		this.ctx.fillText(this.graphData.data[i].record_time, this.graphData.paddingPx[3]+innerWidth*(this.graphData.data[i].x)/(this.graphData.boundary.maxX-this.graphData.boundary.minX),innerHeight + this.graphData.paddingPx[2]-3
  			);
	};

	}

	//plot data
	
	for(var i = 0; i<this.graphData.data.length;i++){
		if(i<this.graphData.data.length-1){
			this.ctx.beginPath();
			this.ctx.strokeStyle = this.graphData.plotColor;
			this.ctx.lineWidth = 3;
			this.ctx.moveTo(this.graphData.paddingPx[3]+innerWidth*(this.graphData.data[i].x)/(this.graphData.boundary.maxX-this.graphData.boundary.minX),
				this.height-this.graphData.paddingPx[2]-innerHeight*(this.graphData.data[i].y)/(this.graphData.boundary.maxY-this.graphData.boundary.minY));

			this.ctx.lineTo(this.graphData.paddingPx[3]+innerWidth*(this.graphData.data[i+1].x)/(this.graphData.boundary.maxX-this.graphData.boundary.minX),
				this.height-this.graphData.paddingPx[2]-innerHeight*(this.graphData.data[i+1].y)/(this.graphData.boundary.maxY-this.graphData.boundary.minY));
			this.ctx.closePath();
			this.ctx.stroke();
		}
		this.ctx.fillStyle =  this.graphData.pointColor || "white";
		this.ctx.beginPath();
		this.ctx.arc(this.graphData.paddingPx[3]+innerWidth*(this.graphData.data[i].x)/(this.graphData.boundary.maxX-this.graphData.boundary.minX),
			this.height-this.graphData.paddingPx[2]-innerHeight*(this.graphData.data[i].y)/(this.graphData.boundary.maxY-this.graphData.boundary.minY)

			, 9, 0, 2 * Math.PI, false);
		this.ctx.fill();

	}

};


LineGraph.prototype.refresh = function(){
	
	this.graphData.paddingPx[0] = Math.round(this.height*this.graphData.padding[0]/100);
	this.graphData.paddingPx[1] = Math.round(this.width*this.graphData.padding[1]/100);
	this.graphData.paddingPx[2] = Math.round(this.height*this.graphData.padding[2]/100);
	this.graphData.paddingPx[3] = Math.round(this.width*this.graphData.padding[3]/100);
}


angular
.module('app.services')
.factory('focus', function($timeout, $window) {
    return function(id) {
      $timeout(function() {
        var element = $window.document.getElementById(id);
        if(element)
          element.focus();
      });
    };
  });
angular
.module('app.services')
.service('Graph', Graph);

Graph.$inject = ['$cordovaSQLite','$q','$timeout'];

function Graph($cordovaSQLite,$q,$timeout){
    var service = this;
    this.setInitialGraph = function(){
         var query = " SELECT date,grade_first,grade_second,grade_third  FROM tbl_master order by date asc";
        var bufferArray = [];
 		var q = $q.defer();
		$cordovaSQLite.execute(db, query).then(function(res) {
            if(res.rows.length > 0) { 
                for(var i=0; i<res.rows.length; i++){				 
					bufferArray.push(res.rows.item(i));
				}
                q.resolve(bufferArray);
                 return bufferArray;
            } else {
                console.log("No results found");
                q.reject("No results found"); 
                return false;
            }
        }, function (err) {
            q.reject(err);
            console.error(err);
        });
        return q.promise;  
    }

   
  /* =================get Grade Data For Graph====================== */
    this.openGradeJason = function(gradeGraphData){
        var gradeDataForGraph = [];
           for(var i=0; i<gradeGraphData.length; i++){
                var gradeObj1 = JSON.parse(gradeGraphData[i].grade_first);
                var gradeObj2 = (gradeGraphData[i].grade_second != "undefined")? JSON.parse(gradeGraphData[i].grade_second) : null;
                var gradeObj3 = (gradeGraphData[i].grade_third  != "undefined")?JSON.parse(gradeGraphData[i].grade_third): null;
                 
                tempGradeObj = {};
                tempGradeObj.grade = gradeObj1.grade;
                tempGradeObj.record_time = gradeObj1.record_time;
                tempGradeObj.entered_grade = "first";
                tempGradeObj.date = gradeObj1.date;
                gradeDataForGraph.push(tempGradeObj);
              
                if(gradeObj2 != null){
                    tempGradeObj = {};
                    tempGradeObj.grade = gradeObj2.grade;
                    tempGradeObj.record_time = gradeObj2.record_time;
                    tempGradeObj.entered_grade = "second";
                    tempGradeObj.date = gradeObj2.date;
                    gradeDataForGraph.push(tempGradeObj);
                }
                
                 if(gradeObj3 != null){
                    tempGradeObj = {};
                    tempGradeObj.grade = gradeObj3.grade;
                    tempGradeObj.record_time = gradeObj3.record_time;
                    tempGradeObj.entered_grade = "third";
                    tempGradeObj.date = gradeObj3.date;
                    gradeDataForGraph.push(tempGradeObj);
                }
              
           }
            console.log(gradeDataForGraph);
            return gradeDataForGraph;
    }

    this.getGradeDataForGraph = function(gradeDataForGraph){
        
            for(var i=0; i<gradeDataForGraph.length; i++){
                gradeDataForGraph[i].x = i+1;
                gradeDataForGraph[i].y = gradeDataForGraph[i].grade-1;
                gradeDataForGraph[i].labelX = moment(gradeDataForGraph[i].date).format("M/DD");
            }
       
            return gradeDataForGraph;
       
     }


   
    this.getPlotdataNonGarde = function(field){
        console.log(field);
        var query = " SELECT "+field+",date FROM tbl_master where "+field+" != 0.0 and "+field+" != '' and "+field+" != '[]' order by date asc";
        var bufferArray = [];
 		var q = $q.defer();
		$cordovaSQLite.execute(db, query).then(function(res) {
            if(res.rows.length > 0) { 
                for(var i=0;i<res.rows.length;i++){				 
					bufferArray.push(res.rows.item(i));
				}  
                q.resolve(bufferArray);
                 return bufferArray;
               
            } else {
                console.log("No results found");
                q.reject("No results found"); 
                return false;
            }
        }, function (err) {
            q.reject(err);
            console.error(err);
        });
		//console.log(q.promise);
        return q.promise;  
    }
    

    this.getExerciseDataForGraph = function(exerciseGraphData){
            for(var i=0; i<exerciseGraphData.length; i++){
                exerciseGraphData[i].x = i+1;
                exerciseGraphData[i].y = exerciseGraphData[i].exercise;
                exerciseGraphData[i].labelX = moment(exerciseGraphData[i].date).format("M/DD");
            }
             return exerciseGraphData;
    }
  
    this.getSevenExerciseData =  function(data,operational_date){
        var flag =0;
        var exerciseGraphData = [];
        var showRightArrow = true;
        var showLeftArrow = true;
       for(var i=0;i<data.length;i++){
           if(moment(data[i].date).diff(moment(operational_date), 'days') <= 0){
             flag = i;
           }
       }
       for(i=flag;i>=0 && exerciseGraphData.length<7;i--){
          exerciseGraphData.push(data[i]);
          exerciseGraphData.lowerLimit = i;
          exerciseGraphData.upperLimit = flag;
       }
       exerciseGraphData.reverse();
        if(exerciseGraphData.length<7){
            for(i=flag+1;exerciseGraphData.length<7 && i<data.length;i++){
                exerciseGraphData.push(data[i]);
                exerciseGraphData.upperLimit = i;
            }
        }
        if(exerciseGraphData.upperLimit == data.length-1){
           showRightArrow = false;
        }
        if(exerciseGraphData.lowerLimit == 0){
           showLeftArrow = false;
        }
        return [exerciseGraphData,showRightArrow,showLeftArrow];
    }

    this.getStressDataForGraph = function(stressGraphData){
          
            for(var i=0; i<stressGraphData.length; i++){
                stressGraphData[i].x = i+1;
                if(stressGraphData[i].stress == 0.0){
                     stressGraphData[i].y=0;
                 }
                else if(stressGraphData[i].stress == 1.0){
                    stressGraphData[i].y=1;
                }
                else{
                    stressGraphData[i].y=2;
                }
                stressGraphData[i].labelX = moment(stressGraphData[i].date).format("M/DD");
            }
            console.log(stressGraphData);
             return stressGraphData;
    }

    this.getMedicationDataForGraph = function(medicationGraphData){
            for(var i=0; i<medicationGraphData.length; i++){
                medicationGraphData[i].x = i+1;
                medicationGraphData[i].y=JSON.parse(medicationGraphData[i].medication).length;
                medicationGraphData[i].labelX = moment(medicationGraphData[i].date).format("M/DD");
            }
            console.log(medicationGraphData);
             return medicationGraphData;
    }

   

    this.getPlotdataNonGardeSmoke = function(field){
         var query = " SELECT "+field+",date FROM tbl_master where "+field+" != '' order by date asc";
        var bufferArray = [];
 		var q = $q.defer();
		$cordovaSQLite.execute(db, query).then(function(res) {
            if(res.rows.length > 0) { 
                for(var i=0;i<res.rows.length;i++){				 
					bufferArray.push(res.rows.item(i));
				}  
                q.resolve(bufferArray);
                 return bufferArray;
               
            } else {
                console.log("No results found");
                q.reject(bufferArray); 
                return false;
            }
        }, function (err) {
            q.reject(err);
            console.error(err);
        });
		//console.log(q.promise);
        return q.promise;  
    }

    

    this.getSmokeDataForGraph = function(smokeGraphData){
          
            for(var i=0; i<smokeGraphData.length; i++){
                smokeGraphData[i].x = i+1;
                 switch(smokeGraphData[i].smoke)
                    {
                    case '0':
                      smokeGraphData[i].y = 0;
                      break;
                    case '1-3':
                      smokeGraphData[i].y = 1;
                      break;
                    case '4+':
                      smokeGraphData[i].y = 2;
                      break;
                    }
                    smokeGraphData[i].labelX = moment(smokeGraphData[i].date).format("M/DD");
            }
            console.log(smokeGraphData);
              return smokeGraphData;
    }
    this.getDrinksDataForGraph = function(drinksGraphData){
       
            for(var i=0; i<drinksGraphData.length; i++){
                drinksGraphData[i].x = i+1;
                 switch(drinksGraphData[i].drinks)
                    {
                    case '0':
                      drinksGraphData[i].y = 0;
                      break;
                    case '1-2':
                      drinksGraphData[i].y = 1;
                      break;
                    case '3+':
                      drinksGraphData[i].y = 2;
                      break;
                    }
                    drinksGraphData[i].labelX = moment(drinksGraphData[i].date).format("M/DD");
            }
             return drinksGraphData;
    }
     this.getWeightDataForGraph = function(weightGraphData){
        
            for(var i=0; i<weightGraphData.length; i++){
                weightGraphData[i].x = i+1;
                weightGraphData[i].y = weightGraphData[i].weight;
                    weightGraphData[i].labelX = moment(weightGraphData[i].date).format("M/DD");
            }
              return weightGraphData;
    }

    this.getAvgSmoke = function(data){
        var smokeSum = 0;
        for(var i=0;i<data.length;i++){
          switch(data[i].smoke)
                    {
                    case '0':
                      smokeSum = smokeSum+0;
                      break;
                    case '1-3':
                      smokeSum = smokeSum+2;
                      break;
                    case '4+':
                      smokeSum = smokeSum+4;
                      break;
                    }
         }
            smokeSum = smokeSum/data.length;
            if(smokeSum <1){
                return '0';
            }
            else if(smokeSum <3){
                return '1-3'
            }
            else {
                return '4+'
            }

    }

     this.getAvgDrink = function(data){
        var drinkSum = 0;
        for(var i=0;i<data.length;i++){
          switch(data[i].drinks)
                    {
                    case '0':
                      drinkSum = drinkSum+0;
                      break;
                    case '1-2':
                      drinkSum = drinkSum+1.5;
                      break;
                    case '3+':
                      drinkSum = drinkSum+3;
                      break;
                    }
         }
            drinkSum = drinkSum/data.length;
            if(drinkSum <1){
                return '0';
            }
            else if(drinkSum <=2){
                return '1-2'
            }
            else {
                return '3+'
            }
     }

     this.getCommonFieldsAvg = function(res,field){
          var sum = 0;
          for(var i=0;i<res.length;i++){
             sum =  res[i][field] + sum;
          }
          return sum/res.length;
     }
     this.getStressAvg = function(data){
          var stressSum = 0;
        for(var i=0;i<data.length;i++){
           
           stressSum = stressSum+parseInt(data[i].stress);
         }
         stressSum = stressSum/data.length;
         return this.getStressText(stressSum);
         
     }

     this.getStressText = function(stress){
          console.log(stress);
        if(stress <= 1.0){
            return "LOW";
            }
            else if(stress <= 2.0){
                return "MED";
            }
            else{
                return "HIGH";
            }
     }
     this.getMedsAvg = function(data){
         var sumMeds = 0;
         for(var i=0;i<data.length;i++){
           sumMeds = JSON.parse(data[i].medication).length + sumMeds;
         }
         return sumMeds/data.length;
     }

     this.getLeftPlotData = function(data,oldShownData){
       var newShownData = [];
       var showRightArrow = true;
       var showLeftArrow = true;
           for(var i=oldShownData.lowerLimit-1;i>=0 && newShownData.length<7;i--){
              newShownData.push(data[i]);
              newShownData.lowerLimit = i;
           }
           newShownData.reverse();
           newShownData.upperLimit = oldShownData.lowerLimit-1;
           for(i=oldShownData.lowerLimit;newShownData.length<7 && i<data.length;i++){
              newShownData.push(data[i]);
              newShownData.upperLimit = i;
           }

          //newShownData.upperLimit = oldShownData.lowerLimit-1;
          
          if(newShownData.upperLimit == data.length-1){
             showRightArrow = false;
          }
          if(newShownData.lowerLimit == 0){
            showLeftArrow = false;
          }
       
        return [newShownData,showRightArrow,showLeftArrow];
     }

     this.getRightPlotData = function(data,oldShownData){
       var newShownData = [];
       var showRightArrow = true;
       var showLeftArrow = true;
           for(var i=oldShownData.upperLimit+1;newShownData.length<7 && i<data.length;i++){
                newShownData.push(data[i]);
                newShownData.upperLimit = i;
            }
          newShownData.lowerLimit = oldShownData.upperLimit+1;
          
          if(newShownData.upperLimit == data.length-1){
            showRightArrow = false;
          }
          if(newShownData.lowerLimit == 0){
             showLeftArrow = false;
          }
        return [newShownData,showRightArrow,showLeftArrow];
     }

}
angular
.module('app.services')
.service('SendEHSPin', SendEHSPin);

SendEHSPin.$inject = ['$http','$q','$cordovaDialogs','$filter'];

function SendEHSPin($http,$q,$cordovaDialogs,$filter){
    
    this.sendPin = function(userData){
        var deferred = $q.defer();
        var body = {
             PIN:userData.pin,
             email:userData.email  
            };
        return $http({
              method : "POST",
              url : "https://jsonmobile.pfizer.com/Hemo/SendPin",
              headers: {
                'Authorization': "Basic SGVtb19TT0FfQ29uc3VtZXJfRFA6Vm5xTUNtZlhpQkxq"
                },
              data :body,
              cache: false
        }).then(function(response){
            // promise is fulfilled
            deferred.resolve(response.data);
            // promise is returned
            return deferred.promise;
        }, function(response){
            // the following line rejects the promise
            deferred.reject(response);
            // promise is returned
            return deferred.promise;

        });
    } 
    this.verifyApp = function(ehsInstDate){
     
      var date = moment(ehsInstDate);
      var now = moment();
      if(now.diff(date, 'days') <0){
        $cordovaDialogs.alert($filter('translate')('DEVICE.DATE_ERR'), 'Date Error', $filter('translate')('QUESTFORDOCTOR.BUTTON1'))
                .then(function() {
                        console.log("Date error");
                        return;
                });
          
      }
    } 


    
}
angular
.module('app.services')
.factory('Chats', function($filter) {
  // Might use a resource here that returns a JSON array
  // Some fake testing data
  var chats = [
    {
         "value":"0",
        "Answer":{
           "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER0.OPT1')+"<br><br>"+$filter('translate')('DIGITALCOACH.ANSWER0.OPT2')],
           "align":"left"
        },
      
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION1')],
          "no":"1",
          "align":"right"
          },
          {
            "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION2')],
             "no":"2",
             "align":"right"
        },
         {
            "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION3')],
             "no":"3",
             "align":"right"
        }
        ]
      
    },
		{
     
        "value":"1",
        "Answer":{
           "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER1')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION4')],
          "no":"4",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION5')],
          "no":"5",
          "align":"right"
        }]
      
    },
    {
      
        "value":"2",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER2')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION18')],
          "no":"18",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION19')],
          "no":"19",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION1')],
          "no":"1",
          "align":"right"
        }]
      
    },
    {
      
        "value":"3",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER3')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION22')],
          "no":"22",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION23')],
          "no":"23",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION44')],
          "no":"44",
          "align":"right"
        }]
      
    },
    {
      
        "value":"4",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER4.OPT1')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER4.OPT2')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER4.OPT3')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER4.OPT4')+"<br><br>"+$filter('translate')('DIGITALCOACH.ANSWER4.OPT5')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION6')],
          "no":"6",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION7')],
          "no":"7",
          "align":"right"
        }]
      
    },
    {
      
        "value":"5",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER5')],
           "align":"left",
           "hideAddQue":true
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION6')],
          "no":"6",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION7')],
          "no":"7",
          "align":"right"
        }]
      
    },
    {
      
        "value":"6",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER6')],
           "align":"left",
           "hideAddQue":true
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION8')],
          "no":"8",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION9')],
          "no":"9",
          "align":"right"
        },
        {
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION10')],
          "no":"10",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION11')],
          "no":"11",
          "align":"right"
        }
        ]
      
    },
    {
      
        "value":"7",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER7.OPT1')+"<br><br>"+$filter('translate')('DIGITALCOACH.ANSWER7.OPT2')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION6')],
          "no":"46",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION7')],
          "no":"46",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION7E')],
          "no":"46",
          "align":"right"
        }
        ]
      
    },
     {
      
        "value":"8",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER8.OPT1')+"<br><br>"+$filter('translate')('DIGITALCOACH.ANSWER8.OPT2')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION6')],
          "no":"6",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION7')],
          "no":"7",
          "align":"right"
        }]
      
    },
     {
      
        "value":"9",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER9.OPT1')+"<br><br>"+$filter('translate')('DIGITALCOACH.ANSWER9.OPT2')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION6')],
          "no":"6",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION7')],
          "no":"7",
          "align":"right"
        }]
      
    },
    {
      
        "value":"10",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER10.OPT1')+"<br><br>"+$filter('translate')('DIGITALCOACH.ANSWER10.OPT2')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION6')],
          "no":"6",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION7')],
          "no":"7",
          "align":"right"
        }]
      
    },
    {
      
        "value":"11",
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION12')],
          "no":"12",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION13')],
          "no":"13",
          "align":"right"
        },
        {
        "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION14')],
          "no":"14",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION15')],
          "no":"15",
          "align":"right"
        }]
      
    },
    {
      
        "value":"12",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER12.OPT1')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER12.OPT2')+"<br><br>"+$filter('translate')('DIGITALCOACH.ANSWER12.OPT3')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION6')],
          "no":"6",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION7')],
          "no":"7",
          "align":"right"
        }]
      
    },
    {
      
        "value":"13",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER13.OPT1')+"<br><br>"+$filter('translate')('DIGITALCOACH.ANSWER13.OPT2')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION6')],
          "no":"6",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION7')],
          "no":"7",
          "align":"right"
        }]
      
    },
    {
      
        "value":"14",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER14.OPT1')+"<br><br>"+$filter('translate')('DIGITALCOACH.ANSWER14.OPT2')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION6')],
          "no":"6",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION7')],
          "no":"7",
          "align":"right"
        }]
      
    },
     {
      
        "value":"15",
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION16')],
          "no":"16",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION17')],
          "no":"17",
          "align":"right"
        }]
      
    },
     {
      
        "value":"16",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER16.OPT1')+"<br><br>"+$filter('translate')('DIGITALCOACH.ANSWER16.OPT2')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION6')],
          "no":"6",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION7')],
          "no":"7",
          "align":"right"
        }]
      
    },
    {
      
        "value":"17",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER17.OPT1')+"<br><br>"+$filter('translate')('DIGITALCOACH.ANSWER17.OPT2')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION6')],
          "no":"6",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION7')],
          "no":"7",
          "align":"right"
        }]
      
    },
    {
      
        "value":"18",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER18')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION1')],
          "no":"1",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION3')],
          "no":"3",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION31')],
          "no":"31",
          "align":"right"
        }]
      
    },
    {
      
        "value":"19",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER19')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION1')],
          "no":"1",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION3')],
          "no":"3",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION31')],
          "no":"31",
          "align":"right"
        }]
      
    },
    {
      
        "value":"20",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER20.OPT1')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER20.OPT2')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER20.OPT3')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER20.OPT4')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION21')],
          "no":"21",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION3')],
          "no":"3",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION31')],
          "no":"31",
          "align":"right"
        }]
      
    },
    {
      
        "value":"21",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER21')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION20')],
          "no":"20",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION3')],
          "no":"3",
          "align":"right"
        },
        {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION31')],
          "no":"31",
          "align":"right"
        }]
      
    },
     {
      
        "value":"22",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER22.OPT1')+" "+
          "<a href='#/erectionHS'>"+$filter('translate')('DIGITALCOACH.ANSWER22.OPT2')+"</a>"+
          $filter('translate')('DIGITALCOACH.ANSWER22.OPT3')+"<br>"+
          $filter('translate')('DIGITALCOACH.ANSWER22.OPT4')+" "+
          "<a href='#/tab/timeline'>"+$filter('translate')('DIGITALCOACH.ANSWER22.OPT5')+"</a> "+
          $filter('translate')('DIGITALCOACH.ANSWER22.OPT6')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION23')],
          "no":"23",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION24')],
          "no":"24",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION25')],
          "no":"25",
          "align":"right"
        }]
      
    },
    {
      
        "value":"23",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER23.OPT1')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER23.OPT2')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER23.OPT3')+" "+$filter('translate')('DIGITALCOACH.ANSWER23.OPT4')+" "+$filter('translate')('DIGITALCOACH.ANSWER23.OPT5')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION24')],
          "no":"24",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION25')],
          "no":"25",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION22')],
          "no":"22",
          "align":"right"
        }]
      
    },
    {
      
        "value":"24",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER24')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION25')],
          "no":"25",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION20')],
          "no":"20",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION22')],
          "no":"22",
          "align":"right"
        }]
      
    },
    {
      
        "value":"25",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER25')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION26')],
          "no":"26",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION20')],
          "no":"20",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION27')],
          "no":"27",
          "align":"right"
        }]
      
    },
    {
      
        "value":"26",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER26')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION20')],
          "no":"20",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION27')],
          "no":"27",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION28')],
          "no":"28",
          "align":"right"
        }]
      
    },
    {
      
        "value":"27",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER27.OPT1')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER27.OPT2')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER27.OPT3')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER27.OPT4')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION28')],
          "no":"28",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION29')],
          "no":"29",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION30')],
          "no":"30",
          "align":"right"
        }]
      
    },
    {
      
        "value":"28",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER28.OPT1')+"<br>"
                    +$filter('translate')('DIGITALCOACH.ANSWER28.OPT2')+"<br>"
                    +$filter('translate')('DIGITALCOACH.ANSWER28.OPT3')+"<br>"
                    +$filter('translate')('DIGITALCOACH.ANSWER28.OPT4')+"<br>"
                    +$filter('translate')('DIGITALCOACH.ANSWER28.OPT5')+"<br>"
                    +$filter('translate')('DIGITALCOACH.ANSWER28.OPT6')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION29')],
          "no":"29",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION30')],
          "no":"30",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION31')],
          "no":"31",
          "align":"right"
        }]
      
    },
    {
      
        "value":"29",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER29')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION28')],
          "no":"28",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION30')],
          "no":"30",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION31')],
          "no":"31",
          "align":"right"
        }]
      
    },
    {
      
        "value":"30",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER30.OPT1')+" "+
          "<a href='#/tab/profile/profileMain'>"+$filter('translate')('DIGITALCOACH.ANSWER30.OPT2')+"</a> "+
          $filter('translate')('DIGITALCOACH.ANSWER30.OPT3')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION28')],
          "no":"28",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION29')],
          "no":"29",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION31')],
          "no":"31",
          "align":"right"
        }]
      
    },
    {
      
        "value":"31",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER31')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION32')],
          "no":"32",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION33')],
          "no":"33",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION35')],
          "no":"35",
          "align":"right"
        }]
      
    },
    {
      
        "value":"32",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER32')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION33')],
          "no":"33",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION34')],
          "no":"34",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION35')],
          "no":"35",
          "align":"right"
        }]
      
    },
    {
      
        "value":"33",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER33.OPT1')+"<br>"
                    +$filter('translate')('DIGITALCOACH.ANSWER33.OPT2')+"<br>"
                    +$filter('translate')('DIGITALCOACH.ANSWER33.OPT3')+"<br><br>"
                    +$filter('translate')('DIGITALCOACH.ANSWER33.OPT4')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION36')],
          "no":"36",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION34')],
          "no":"34",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION35')],
          "no":"35",
          "align":"right"
        }]
      
    },
    {
      
        "value":"34",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER34.OPT1')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER34.OPT2')
                    +"<br>"+$filter('translate')('DIGITALCOACH.ANSWER34.OPT3')
                    +"<br>"+$filter('translate')('DIGITALCOACH.ANSWER34.OPT4')
                    +"<br>"+$filter('translate')('DIGITALCOACH.ANSWER34.OPT5') 
                    +"<br>"+$filter('translate')('DIGITALCOACH.ANSWER34.OPT6')
                    +"<br>"+$filter('translate')('DIGITALCOACH.ANSWER34.OPT7')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION36')],
          "no":"36",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION35')],
          "no":"35",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION37')],
          "no":"37",
          "align":"right"
        }]
      
    },
    {
      
        "value":"35",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER35.OPT1')+" "+
                   "<a href='#/tab/profile/profileMain'>"+$filter('translate')('DIGITALCOACH.ANSWER35.OPT4')+"</a> "+
                    $filter('translate')('DIGITALCOACH.ANSWER35.OPT5')+"<br>"
                    +$filter('translate')('DIGITALCOACH.ANSWER35.OPT2')
                    +"<br>"+$filter('translate')('DIGITALCOACH.ANSWER35.OPT3')
                    ],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION36')],
          "no":"36",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION37')],
          "no":"37",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION33')],
          "no":"33",
          "align":"right"
        }]
      
    },
    {
      
        "value":"36",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER36')
                    ],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION37')],
          "no":"37",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION33')],
          "no":"33",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION35')],
          "no":"35",
          "align":"right"
        }]
      
    },
    {
      
        "value":"37",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER37.OPT1')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER37.OPT2')
                    +"<br>"+$filter('translate')('DIGITALCOACH.ANSWER37.OPT3')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER37.OPT4')
                    ],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION22')],
          "no":"22",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION46')],
          "no":"4",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION47')],
          "no":"6",
          "align":"right"
        }]
      
    },
     {
        "value":"38",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER38')
                    ],
           "align":"left",
           "hideAddQue":true
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION6')],
          "no":"40",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION7')],
          "no":"41",
          "align":"right"
        }]
      
    },
     {
        "value":"39",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER39')
                    ],
           "align":"left",
           "hideAddQue":true
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION31')],
          "no":"31",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION33')],
          "no":"33",
          "align":"right"
        },
        {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION1')],
          "no":"1",
          "align":"right"
        }]
      
    },
     {
        "value":"40",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER40')
                    ],
           "align":"left",
           "hideAddQue":true
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION6')],
          "no":"42",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION7')],
          "no":"43",
          "align":"right"
        }]
      
    },
    {
        "value":"41",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER41')],
           "align":"left",
           "hideAddQue":true
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION23')],
          "no":"23",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION24')],
          "no":"24",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION20')],
          "no":"20",
          "align":"right"
        }]
      
    },
    {
        "value":"42",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER42.OPT1')+"<br>"+
                    $filter('translate')('DIGITALCOACH.ANSWER42.OPT2')+" "+
                   "<a href='#/tab/timeline'>"+$filter('translate')('DIGITALCOACH.ANSWER42.OPT6')+"</a> "+
                    $filter('translate')('DIGITALCOACH.ANSWER42.OPT7')+" "+
                    "<a href='#/erectionHS'>"+$filter('translate')('DIGITALCOACH.ANSWER42.OPT8')+"</a> "
                    +"<br>"+$filter('translate')('DIGITALCOACH.ANSWER42.OPT3')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER42.OPT4')
                    +"<br>"+
                    $filter('translate')('DIGITALCOACH.ANSWER42.OPT5')+" "+
                    "<a href='#/tab/profile/profileMain'>"+$filter('translate')('DIGITALCOACH.ANSWER42.OPT9')+"</a>"
                    ],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION22')],
          "no":"22",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION25')],
          "no":"25",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION44')],
          "no":"44",
          "align":"right"
        }]
      
    },
    {
        "value":"43",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER43')
                    ],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION27')],
          "no":"27",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION28')],
          "no":"28",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION20')],
          "no":"20",
          "align":"right"
        }]
      
    },
    {
        "value":"44",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER44.OPT1')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER44.OPT2')
                    ],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION47')],
          "no":"6",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION45')],
          "no":"45",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION23')],
          "no":"23",
          "align":"right"
        }]
      
    },
    {
        "value":"45",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER45')
                    ],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION47')],
          "no":"6",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION23')],
          "no":"23",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION35')],
          "no":"35",
          "align":"right"
        }]
      
    },
    {
      
        "value":"46",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER7a')],
           "align":"left",
           "hideAddQue":true
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION6')],
          "no":"100",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION7')],
          "no":"100",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION7E')],
          "no":"100",
          "align":"right"
        }]
      
    },
    {
      
        "value":"47",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER7b')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION20')],
          "no":"20",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION3')],
          "no":"3",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION31')],
          "no":"31",
          "align":"right"
        }]
      
    },
     {
      
        "value":"48",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER7b')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION20')],
          "no":"20",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION21')],
          "no":"21",
          "align":"right"
        }]
      
    },
    {
        "value":"49",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER20.OPT1')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER20.OPT2')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER20.OPT3')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER20.OPT4')],
           "align":"left"
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION3')],
          "no":"21",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION44')],
          "no":"3",
          "align":"right"
        },
         {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION31')],
          "no":"31",
          "align":"right"
        }]
      
    },
     {
        "value":"50",
        "Answer":{
          "Answer1":[$filter('translate')('DIGITALCOACH.ANSWER38A')],
           "align":"left",
           "hideAddQue":true
        },
        "Ques":[{
          "Answer1":[$filter('translate')('DIGITALCOACH.QUESTION38')],
          "no":"38",
          "align":"right"
          },
          {"Answer1":[$filter('translate')('DIGITALCOACH.QUESTION39')],
          "no":"39",
          "align":"right"
        }]
      
    } 

  ];

  return {
    all: function() {
      return chats;
    },
    getQuestion: function(quesNumber) {
      return chats[quesNumber];
    },
    
  };
});

angular
.module('app.services')
.service('Timeline', Timeline);

Timeline.$inject = ['$cordovaSQLite','$q','$timeout','$ionicPlatform'];

function Timeline($cordovaSQLite,$q,$timeout,$ionicPlatform){
   var monthlyTimline = [];
   var months= ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  
   var latest_slide_index = 0;
   var timeline_param = "";
     this.setTimelineParams = function(params){
       timeline_param = params;
     }
     this.getTimelineParams = function(){
       return timeline_param;
     }
    this.setCurrentSlideIndex = function(current_slide_index){
        latest_slide_index = current_slide_index;
    }
    this.getCurrentSlideIndex = function(){
        return latest_slide_index;
    }
    this.getMonthYear = function(){
		var query = " SELECT distinct month_year  FROM tbl_master order by date asc";
        var bufferArray = [];
 		var q = $q.defer();
		$cordovaSQLite.execute(db, query).then(function(res) {
			
            if(res.rows.length > 0) { 
				for(var i=0;i<res.rows.length;i++){	        	 
					bufferArray.push(res.rows.item(i).month_year);
				}
                 q.resolve(bufferArray);
                return bufferArray; 
            } else {
                console.log("No results found");
                q.reject("No results found"); 
                return false;
            }
        }, function (err) {
            q.reject(err);
            console.error(err);
        });
        return q.promise;   
    }

    this.getDataForDate = function(date){
       var query = " SELECT *  FROM tbl_master where date = ?";
 		var q = $q.defer();
        var bufferArray = [];
		$cordovaSQLite.execute(db, query,[date]).then(function(res) {
            
            if(res.rows.length > 0) {  
                for(var i=0;i<res.rows.length;i++){				 
					bufferArray.push(res.rows.item(i));
				}
			   q.resolve(bufferArray);
                return bufferArray; 
            } else {
                
                q.reject("No results found"); 
                return false;
            }
        }, function (err) {
            q.reject(err);
            console.error(err);
        });
        return q.promise;   
    }

    this.setDataToDate = function(bufferArray){
        
                                var obj1 = JSON.parse(bufferArray.grade_first);
                                var obj2 = (bufferArray.grade_second != "undefined")? JSON.parse(bufferArray.grade_second) : null;
                                var obj3 = (bufferArray.grade_third  != "undefined")?JSON.parse(bufferArray.grade_third): null;
                                var medication_value = JSON.parse(bufferArray.medication).length;
                                switch (bufferArray.stress) {
                                    case '1.0':
                                       bufferArray.stress_value="LOW";//data to be saved
                                        break;
                                    case '2.0':
                                       bufferArray.stress_value="MED";//data to be saved
                                        break;
                                    case '3.0':
                                       bufferArray.stress_value="HIGH";//data to be saved
                                        break;
                                    default:
                                        bufferArray.stress_value=0;
                                 }
				
                                bufferArray.medication_value=medication_value;
                                bufferArray.grade_obj1 = obj1;
                                bufferArray.grade_obj2 = obj2;
                                bufferArray.grade_obj3 = obj3;
                                bufferArray.today = this.checkToday(bufferArray.date);
                                if(obj2 == null){
                                    bufferArray.avg_grade =  obj1.grade;
                                }
                                else if(obj3 == null){
                                     bufferArray.avg_grade =  ((obj1.grade+obj2.grade)/2);
                                     if(bufferArray.avg_grade % 1 != 0){
                                         bufferArray.avg_grade = (bufferArray.avg_grade).toFixed(2);
                                     }
                                }
                                else{
                                     bufferArray.avg_grade =  ((obj1.grade+obj2.grade+obj3.grade)/3);
                                     if(bufferArray.avg_grade % 1 != 0){
                                         bufferArray.avg_grade = (bufferArray.avg_grade).toFixed(2);
                                     }
                                }
                    return bufferArray;
    }

	this.getRecordsByMonth = function(month_year){
		var query = " SELECT *  FROM tbl_master where month_year = ? order by date asc";
 		var q = $q.defer();
        var bufferArray = [];
		$cordovaSQLite.execute(db, query,[month_year]).then(function(res) {
            
            if(res.rows.length > 0) {  
                for(var i=0;i<res.rows.length;i++){				 
					bufferArray.push(res.rows.item(i));
				}
                
			   q.resolve(bufferArray);
                return bufferArray; 
            } else {
                console.log("No results found");
                q.reject("No results found"); 
                return false;
            }
        }, function (err) {
            q.reject(err);
            console.error(err);
        });
        return q.promise;   
    }

  this.getAllMonthsTillNow = function(fisrtMonthYear){
      firstMonth = months.indexOf(fisrtMonthYear.split("_")[0]);
      firstYear = fisrtMonthYear.split("_")[1];
      nowNormalized = moment().startOf("month")+1, /* the first of current month */
      startDate = moment([firstYear, firstMonth,1]);
      startDateNormalized = startDate.clone().startOf("month").add("M", 0), /* the first of startDate + 1 Month - as it was asked for the months in between startDate and now */
      monthTillNow = [];
    /* .isBefore() as it was asked for the months in between startDate and now */
      while (startDateNormalized.isBefore(nowNormalized)) {
            var temp = {id:startDateNormalized.format("MMMM")+"_"+startDateNormalized.format("YYYY")}
            monthTillNow.push(temp);
            startDateNormalized.add("M", 1);
        }
    return monthTillNow;
  }

  this.checkToday = function(checkDate){
     return moment(checkDate).isSame(moment().format('YYYY-MM-DD'));
  }
   
  this.isSameMonth = function(checkDate){
      return moment(checkDate).isSame(moment(),'month');
  } 

  this.setAllDataEntry = function(all_data_month,month_year,monthlyTimeline,current_slide_index){
      console.log("6");
      if(monthlyTimeline[current_slide_index].loaded == true)
      {
           console.log("7");
          return monthlyTimeline;
      }
    
        var first_date = month_year.split("_")[1]+"-"+moment().month(month_year.split("_")[0]).format("MM")+"-01";//setting first late
        var last_date = "";
        
        if(current_slide_index == monthlyTimeline.length-1){
             last_date = moment();
        }
        else{
            last_date = moment(first_date).endOf('month');
        }
        if(current_slide_index == 0){
          console.log(all_data_month[0]);
            first_date = all_data_month[0].date;
        }
        
        for (var m = moment(first_date); m.diff(last_date, 'days') <=0; m.add(1, 'days')) { //loop to first date till today
            
           if(m<last_date){
               
                    var temp_count = 0;
                    for(var i=0;i<all_data_month.length;i++){
                            if(m.isSame(all_data_month[i].date)) //if data found,setting obj to monthly timelime
                            {
                                
                                var obj1 = JSON.parse(all_data_month[i].grade_first);
                                var obj2 = (all_data_month[i].grade_second != "undefined")? JSON.parse(all_data_month[i].grade_second) : null;
                                var obj3 = (all_data_month[i].grade_third  != "undefined")?JSON.parse(all_data_month[i].grade_third): null;
                                var medication_value = JSON.parse(all_data_month[i].medication).length;
                                if(all_data_month[i].stress == ""){
                                    all_data_month[i].stress_value=0;
                                }
                                else if(all_data_month[i].stress == 0.0){
                                    all_data_month[i].stress_value="LOW";
                                }
                                else if(all_data_month[i].stress == 1.0){
                                    all_data_month[i].stress_value="MED";
                                }
                                else{
                                    all_data_month[i].stress_value="HIGH";
                                }
                                 if(all_data_month[i].exercise==60){
                                    all_data_month[i].exercise="60+";
                                }
                                all_data_month[i].medication_value=medication_value;
                                all_data_month[i].grade_obj1 = obj1;
                                all_data_month[i].grade_obj2 = obj2;
                                all_data_month[i].grade_obj3 = obj3;
                                all_data_month[i].today = this.checkToday(all_data_month[i].date);
                                if(obj2 == null){
                                    all_data_month[i].avg_grade =  obj1.grade;
                                }
                                else if(obj3 == null){
                                     all_data_month[i].avg_grade =  ((obj1.grade+obj2.grade)/2);
                                     if(all_data_month[i].avg_grade % 1 != 0){
                                         all_data_month[i].avg_grade = (all_data_month[i].avg_grade).toFixed(2);
                                     }
                                }
                                else{
                                     all_data_month[i].avg_grade =  ((obj1.grade+obj2.grade+obj3.grade)/3);
                                     if(all_data_month[i].avg_grade % 1 != 0){
                                         all_data_month[i].avg_grade = (all_data_month[i].avg_grade).toFixed(2);
                                     }
                                }

                                monthlyTimeline[current_slide_index].data.push(all_data_month[i]);
                                 monthlyTimeline[current_slide_index].loaded=true;
                                temp_count = 1;
                                
                               
                               
                                break;
                            }


                    }
                    if(temp_count==0){ // no data found then setting no data to object
                            var no_data = {};
                            no_data.today = this.checkToday(m);
                            no_data.date = m.format("YYYY-MM-DD");
                            no_data.grade_obj1 = null;
                            no_data.grade_obj2 = null;
                            no_data.grade_obj3 = null;
                            no_data.avg_grade = 0;

                            monthlyTimeline[current_slide_index].data.push(no_data);
                            
                            monthlyTimeline[current_slide_index].loaded=true;
                    }
           }
         
      }
      console.log("11");
console.log(monthlyTimeline);
        return monthlyTimeline;
  }

  this.addNewDay = function(monthlyTimeline,$scope){
     
      var lastMonth = monthlyTimeline[monthlyTimeline.length-1];
      
    //  if(!this.checkToday(lastMonth.data[lastMonth.data.length-1].date)){
    //      console.log(this.isSameMonth(lastMonth.data[lastMonth.data.length-1].date));
    //      if(this.isSameMonth(lastMonth.data[lastMonth.data.length-1].date))
    //      {
    //         var no_data = {};
    //         no_data.today = true;
    //         no_data.date = moment().format("YYYY-MM-DD");
    //         no_data.grade_obj1 = null;
    //         no_data.grade_obj2 = null;
    //         no_data.grade_obj3 = null;
    //         no_data.avg_grade = 0;
    //         monthlyTimeline[monthlyTimeline.length-1].data[monthlyTimeline[monthlyTimeline.length-1].data.length-1].today=false;
    //        //creating variable panelData and using timeout to give time to DOM to replicate result of ng-class 
    //         var panelData = monthlyTimeline[monthlyTimeline.length-1].data;
    //         panelData.push(no_data); 
    //         monthlyTimeline[monthlyTimeline.length-1].data=[];
    //         $timeout(function(){
    //            monthlyTimeline[monthlyTimeline.length-1].data = panelData; 
    //         },1);
    //         monthlyTimeline[monthlyTimeline.length-1].loaded=true;
    //        }
    //        else{
    //            monthlyTimeline.push ={};
    //        }
    //   }
      return monthlyTimeline;
      
  }
  this.getRecordsByDate = function(date){
		var query = " SELECT *  FROM tbl_master where date = ?";
        var bufferArray = [];
 		var q = $q.defer();
		$cordovaSQLite.execute(db, query, [date]).then(function(res) {
            if(res.rows.length > 0) { 

                for(var i=0;i<res.rows.length;i++){				 
					bufferArray.push(res.rows.item(i));
				}  
			   q.resolve(bufferArray);
			  // console.log(res.rows)
                 
            } else {
                console.log("No results found");
                q.reject("No results found"); 
                return false;
            }
        }, function (err) {
            q.reject(err);
            console.error(err);
        });
		//console.log(q.promise);
        return q.promise;   
    }
    

}