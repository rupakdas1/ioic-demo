angular.module('app.directives', []);

angular
    .module('app.controllers')
	.directive('dashboardPanel', function() {
	  return {
	    restrict: 'E',
	    templateUrl: 'templates/directives/dashboardPanel.html',
	    scope:{
            data:'=',
            action:'&',
            active:'&',
            expanded:'&',
            isExpanded:'='
	    },
      link: function(scope,element,attrs){            
            /* send an object to the function */
        },
        controllerAs: 'vm',
        controller: function($scope,$filter) {
           var vm =this;
           vm.panelClass= "grd3-panel";
           vm.getPanelClass = function(data){
            if(data.avg_grade == 0){
              vm.panelClass = 'noData-panel';
            }
            else if(data.avg_grade>0 && data.avg_grade<1.50){
              vm.panelClass = 'grd1-panel';
            }
            else if(data.avg_grade>=1.50 && data.avg_grade<2.50){
              vm.panelClass = 'grd2-panel';
            }
            else if(data.avg_grade>=2.50 && data.avg_grade<3.50){
              vm.panelClass = 'grd3-panel';
            }
            else{
              vm.panelClass = 'grd4-panel';
            }
           }
           vm.getDayAndDate = function(data){
             if(data.today){
               vm.dayAndDate = $filter('translate')('TIMELINE.TEXT2');
             }
             else{
             vm.dayAndDate = angular.uppercase(moment(data.date).format("ddd"))+"<br>"+moment(data.date).format("MM/DD");
             }
           }   
         
        }
	  }
	});
angular.module('app.controllers')
.directive('dynamicHeight', function($timeout) {
   return {
        restrict: 'A',
        link: function(scope, element, attrs) {
            scope.$watch (
                function () {
                    console.log(attrs.slideChildClass);
                    var activeSlideElement = angular.element(element[0].getElementsByClassName(attrs.slideChildClass+"-active"));
                    //constantly remove max height from current element to allow it to expand if required
                    activeSlideElement.css("max-height","none");
                    //if activeSlideElement[0] is undefined, it means that it probably hasn't loaded yet
                    return angular.isDefined(activeSlideElement[0])? activeSlideElement[0].offsetHeight : 20 ;
                },
                function (newHeight, oldHeight) {
                    var sildeElements = angular.element(element[0].getElementsByClassName(attrs.slideChildClass));
                    sildeElements.css("max-height",newHeight+"px");
                }
            );
        }
    }
})
angular
    .module('app.controllers')
.directive('showFocus', function($timeout) {
  return function(scope, element, attrs) {
    scope.$watch(attrs.showFocus, 
      function (newValue) { 
        $timeout(function() {
            element[0].focus();
        });
      },true);
  };    
});
/**
  * <grade-data /> directive for showing grade data on add record page
  **/
angular
    .module('app.directives')
	.directive('gradeData', function() {
	  return {
	    restrict: 'E',
	    templateUrl: 'templates/directives/gradeData.html',
      link: function(scope,element,attrs){            
        /* send an object to the function */  
        }     
       
	  }
	});
angular
    .module('app.controllers')
    .directive('limitChar', function() {
    return {
        restrict: 'A',
        scope: {
            limit: '=limit',
            ngModel: '=ngModel'
        },
        link: function(scope) {
            scope.$watch('ngModel', function(newValue, oldValue) {
                if (newValue) {
                    var length = newValue.toString().length;
                    if (length > scope.limit) {
                        scope.ngModel = oldValue;
                    }
                }
            });
        }
    };
})
angular
    .module('app.controllers')
	.directive('messageCoach', function() {
	  return {
	    restrict: 'E',
	    templateUrl: 'templates/directives/messageCoach.html',
	    scope:{
            data:'=',
            active: '&'
	    },
			controller: function($scope) {
        
        },
        //controllerAs: 'vm'
		}
	});
/**
  * <non-grade-data /> directive for showing non-grade  data for add record page
  **/
angular
    .module('app.directives')
	.directive('nonGradeData', function() {
	  return {
	    restrict: 'E',
	    templateUrl: 'templates/directives/nonGradeData.html',
      link: function(scope,element,attrs){            
        /* send an object to the function */  
        }
	  }
	});
/**
  * <quesDfirst /> directive
  **/
angular
    .module('app.controllers')
	.directive('quesDfirst', function() {
	  return {
	    restrict: 'E',
	    templateUrl: 'templates/directives/quesDfirst.html',
	     scope:{
            data:'=',
						action:'&'
	    }

	  }
	});
angular
    .module('app.controllers')
	.directive('tlExpand', function() {
	  return {
	    restrict: 'E',
	    templateUrl: 'templates/directives/tlExpand.html',
	    scope:{
            data:'='
	    }
	  }
	});