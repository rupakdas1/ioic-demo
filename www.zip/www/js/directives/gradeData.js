/**
  * <grade-data /> directive for showing grade data on add record page
  **/
angular
    .module('app.directives')
	.directive('gradeData', function() {
	  return {
	    restrict: 'E',
	    templateUrl: 'templates/directives/gradeData.html',
      link: function(scope,element,attrs){            
        /* send an object to the function */  
        }     
       
	  }
	});