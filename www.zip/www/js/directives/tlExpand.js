angular
    .module('app.controllers')
	.directive('tlExpand', function() {
	  return {
	    restrict: 'E',
	    templateUrl: 'templates/directives/tlExpand.html',
	    scope:{
            data:'='
	    }
	  }
	});