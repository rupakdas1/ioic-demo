/**
  * <non-grade-data /> directive for showing non-grade  data for add record page
  **/
angular
    .module('app.directives')
	.directive('nonGradeData', function() {
	  return {
	    restrict: 'E',
	    templateUrl: 'templates/directives/nonGradeData.html',
      link: function(scope,element,attrs){            
        /* send an object to the function */  
        }
	  }
	});