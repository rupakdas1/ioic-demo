angular
    .module('app.controllers')
	.directive('dashboardPanel', function() {
	  return {
	    restrict: 'E',
	    templateUrl: 'templates/directives/dashboardPanel.html',
	    scope:{
            data:'=',
            action:'&',
            active:'&',
            expanded:'&',
            isExpanded:'='
	    },
      link: function(scope,element,attrs){            
            /* send an object to the function */
        },
        controllerAs: 'vm',
        controller: function($scope,$filter) {
           var vm =this;
           vm.panelClass= "grd3-panel";
           vm.getPanelClass = function(data){
            if(data.avg_grade == 0){
              vm.panelClass = 'noData-panel';
            }
            else if(data.avg_grade>0 && data.avg_grade<1.50){
              vm.panelClass = 'grd1-panel';
            }
            else if(data.avg_grade>=1.50 && data.avg_grade<2.50){
              vm.panelClass = 'grd2-panel';
            }
            else if(data.avg_grade>=2.50 && data.avg_grade<3.50){
              vm.panelClass = 'grd3-panel';
            }
            else{
              vm.panelClass = 'grd4-panel';
            }
           }
           vm.getDayAndDate = function(data){
             if(data.today){
               vm.dayAndDate = $filter('translate')('TIMELINE.TEXT2');
             }
             else{
             vm.dayAndDate = angular.uppercase(moment(data.date).format("ddd"))+"<br>"+moment(data.date).format("MM/DD");
             }
           }   
         
        }
	  }
	});