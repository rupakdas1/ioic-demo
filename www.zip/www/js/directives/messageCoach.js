angular
    .module('app.controllers')
	.directive('messageCoach', function() {
	  return {
	    restrict: 'E',
	    templateUrl: 'templates/directives/messageCoach.html',
	    scope:{
            data:'=',
            active: '&'
	    },
			controller: function($scope) {
        
        },
        //controllerAs: 'vm'
		}
	});