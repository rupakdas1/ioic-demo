/**
  * <quesDfirst /> directive
  **/
angular
    .module('app.controllers')
	.directive('quesDfirst', function() {
	  return {
	    restrict: 'E',
	    templateUrl: 'templates/directives/quesDfirst.html',
	     scope:{
            data:'=',
						action:'&'
	    }

	  }
	});