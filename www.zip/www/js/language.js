var lang = {
    ANALYTICS: 'UA-85223564-1', //-1 is dev // 2 for prod
    DIGITALCOACH: {
        TEXT1:'Digital Conversation Coach',
        GREETING1:'Welcome to ED&Me!',
        GREETING2:'Before we get started, what’s your name?',
        GREETING3:'Hi! My name is...',
        GREETING5:'Hey there ',
        GREETING6:{
            OPT1:'Welcome Back ',
            OPT2:'. Good to see you again.'
        },
        GREETING7:{
            OPT1:'Hi ',
            OPT2:'. I’m glad you are back!'
        },
        BUTTON1:'Skip for now',
        BUTTON2:'OK, Thanks for now!',
        GREETING4:{
           OPT1:"Hi ",
           OPT2:"! ",
           OPT3:"Since you are here, I’m sure that you want to know more about erectile dysfunction."
        },
        QUESTION1: 'What can cause ED?',
        QUESTION2: 'How common is ED?',     
        QUESTION3: 'How is ED diagnosed?', 
        QUESTION4: "Yes",
        QUESTION5: 'No',
        QUESTION6: 'Yes',
        QUESTION7: 'No',
        QUESTION7E:'Skip for now',
		QUESTION8: 'Depression',
		QUESTION9: 'Diabetes',
        QUESTION10: 'Heart Disease',
        QUESTION11: 'More…',
        QUESTION12: 'High Blood Pressure',
        QUESTION13: 'High Cholesterol',
        QUESTION14: 'Obesity',
        QUESTION15: 'More…',
        QUESTION16: 'Prostate Cancer Treatment',
        QUESTION17: 'Spinal Cord Injury',
        QUESTION18: "I'm too young to have ED.",
        QUESTION19: "I'm too old to have ED.",
        QUESTION20: 'Could lifestyle changes, like diet and exercise, help my ED?',
        QUESTION21: 'Could smoking and/or alcohol be causing my ED?',
        QUESTION22: 'Is there a test I can do at home?',
        QUESTION23: 'How is ED treated?',
        QUESTION24: 'Do I have to take medication?',
        QUESTION25: 'How does ED medication work?',
        QUESTION26: 'What about side effects?',
        QUESTION27: 'Is there anything I should do when taking ED medication?',
        QUESTION28: 'What else can I do in addition to taking a medication?',
        QUESTION29: 'Can I drink alcohol while taking ED medication?',
        QUESTION30: 'Do you have any other advice for making the most out of an ED medication?',
        QUESTION31: 'How do I find a doctor?',
        QUESTION32: 'Do I need to see a specialist or a urologist?',
        QUESTION33: 'Do you have any tips for starting the conversation with my doctor?',
        QUESTION34: 'Do you have any tips for talking to my partner?',
        QUESTION35: 'What are my next steps?',
        QUESTION36: 'What questions should I ask my doctor?',
        QUESTION37: 'Help me prepare for my doctor’s visit.',
        QUESTION38: 'Yes',
        QUESTION39: 'No, not yet.',
        QUESTION40: 'Yes',
        QUESTION41: 'No',
        QUESTION42: 'Yes',
        QUESTION43: 'No',
        QUESTION44: 'Can ED be a sign of a more serious medical condition?',
        QUESTION45: 'Can I treat my ED by treating the condition that caused it?',
        QUESTION46: 'Tell me more about medications that affect ED.',
        QUESTION47: 'Tell me more about medical conditions that affect ED.',
        ANSWER0:{
            OPT1:'Erectile dysfunction is when a man has difficulty getting an erection. Or keeping it long enough for sex. It’s also known as ED or impotence. It happens when not enough blood flows to the penis, preventing an erection.',
            OPT2:'Can I help answer any of your questions about ED?',
        },
        ANSWER1: 'ED is often caused by something physical, such as a disease, injury, or side effects from other drugs. Diseases most commonly associated with ED are high blood pressure, high cholesterol, and diabetes. Are you currently taking medication?',
        ANSWER2: 'ED affects about 30 million men in the U.S. Some guys with ED find it difficult to either get or keep an erection every time they try to have sex. For others, ED symptoms can happen just once in a while. Either way, you should know that you’re not alone.',
        ANSWER3: 'ED is diagnosed by a combination of a physical exam, an "interview" about your personal and sexual history, and sometimes medical tests.',
        ANSWER4: {
            OPT1: "In some men, ED is a side effect of some medications. These medications might include drugs used to treat:",
            OPT2: "• High blood pressure",
			OPT3: "• Heart disease",
			OPT4: "• Depression",
			OPT5: "Are you concerned about these, or any other medical conditions?"
        },
					
        ANSWER5: 'Are you concerned about any medical conditions?',
        ANSWER6: 'What medical conditions would you like to learn more about?',
        ANSWER7: { 
            OPT1:"Lets talk about lifestyle then.  Some lifestyle and psychological factors can play a role in causing ED, such as smoking, drinking, and stress because they may lead to conditions that affect blood circulation.",
            OPT2:'Do you currently smoke?',
        },
        ANSWER7a:'Do you currently drink alcohol?',
        ANSWER7b:'Smoking and alcohol are both common causes of erectile dysfunction, so it’s helpful to take note of those behaviors.',
		ANSWER8: {
            OPT1: "Although most cases of ED have a physical cause, thoughts that lead to depression, worry, or anxiety can also cause ED.  Even when ED has a physical cause, it can be made worse if it leads to depression and worry.",
            OPT2: "Would you like to learn about another medical condition?",
        },
		ANSWER9: {
            OPT1: 'Diabetes is a condition where there is too much sugar, or glucose, in the blood. Over time, high blood sugar levels can damage nerves and blood vessels—like the ones that produce erections. When this occurs, diabetes can lead to ED.  In a study, up to 83% of men with diabetes had some form of ED.',
            OPT2: 'Would you like to learn about another medical condition?',
        },
		ANSWER10: {
            OPT1: 'Heart disease can clog or narrow the arteries. This can stop blood from flowing to the penis, and may cause ED. Talk to your doctor to make sure your heart is healthy enough for sex.',
            OPT2: 'Would you like to learn about another medical condition?',
        },
		ANSWER11: '',
		ANSWER12: {
            OPT1: 'High blood pressure makes the heart work harder. This puts strain on the blood vessels, which then harden and narrow. This can prevent blood from getting to the penis and lead to ED. In a study, more than 65% of men with high blood pressure also had ED',
            OPT3: 'Would you like to learn about another medical condition?',
			OPT2: 'Additionally, some medications used to treat high blood pressure can lead to ED. Make sure your doctor is aware of all medications you are taking.'
        },
		ANSWER13: {
            OPT1: "High cholesterol can clog your arteries. This can slow blood flow to the penis. The result? It can affect the quality of your erections.  In a study, high cholesterol raised men's risk of erectile dysfunction by 80%.",
            OPT2: 'Would you like to learn about another medical condition?',
        },
		ANSWER14: {
            OPT1: "Obesity can cause real harm to your health. For example, it's associated with medical conditions that can affect blood flow. And when blood flow is affected, it can cause ED.",
            OPT2: 'Would you like to learn about another medical condition?',
        },
        ANSWER15: '',
		ANSWER16: {
            OPT1: "The prostate is a small gland near your bladder. It's next to the nerves that are necessary for an erection to happen. For men with prostate cancer, surgical removal of the prostate can lead to ED.",
            OPT2: 'Would you like to learn about another medical condition?',
        },
		ANSWER17: {
            OPT1: "An injury to the spine can affect many functions in the body. Erectile function is no exception.  Due to nerve damage, some men with spinal cord injuries can't get erections. Others can—but can't keep them hard enough or long enough for sex.",
            OPT2: 'Would you like to learn about another medical condition?',
        },
		ANSWER18: 'ED is not all in your head. It’s a real medical condition, so it should be addressed like one. If you think you have ED symptoms, talk to a doctor.',
		ANSWER19: '50% of men over 40 have some degree of ED.  ED is not all in your head. It’s not just a part of aging that you have to accept. It’s a real medical condition, so it should be addressed like one. If you think you have ED symptoms, talk to a doctor.',
		ANSWER20: {
            OPT1: "There are things you can do each day to improve your circulation and avoid some of the conditions that can lead to ED.",
            OPT2: "Find ways to stay more active (mowing the lawn, walking the dog).",
			OPT3: "Help manage your weight by eating healthy and watching your portion size.",
			OPT4: "Look for ways to reduce stress in your daily life.",
        },
		ANSWER21: 'Absolutely!  Try to drink less alcohol and quit smoking. The results can be significant.',
		ANSWER22: {
            OPT1: "Try using",
            OPT2: "The Erection Hardness Score",
            OPT3:", a self-assessment tool used in many clinical studies, to rate your own erection. If you’re concerned about your hardness score, ask your doctor about treatment options.",
            OPT4: "You can use this app to keep a",
            OPT5:"record", 
            OPT6:"of your Erection Hardness Score."
        },
		ANSWER23: {
            OPT1: "Treatment options will depend on the cause of your ED.",
            OPT2: "If a medication is causing your ED, your doctor may lower your dose or try a different drug altogether.",
            OPT31:"You may find that simple lifestyle changes will help, like losing weight.",
            OPT32:"You may find that simple lifestyle changes will help, like losing weight or drinking less alcohol.",
            OPT33:"You may find that simple lifestyle changes will help, like losing weight or quitting smoking.",
            OPT34:"You may find that simple lifestyle changes will help, like losing weight, drinking less alcohol, or quitting smoking.",
            OPT4: "If anxiety or stress is causing your ED, it may help to talk to a professional therapist.",
			OPT5: "Of course, there are a number of medications used to treat ED."
        },
		ANSWER24: 'Your doctor will work with you to determine the best course of treatment based on the cause of your ED.  Medication may, or may not, be a part of your treatment plan.',
		ANSWER25: 'Medication works for men with erectile dysfunction (ED) by increasing blood flow to the penis so you can get and keep an erection hard enough for sex.',
		ANSWER26: 'Safety is important. And it helps to know about possible side effects. Side effects will vary based on the treatment option prescribed. Be sure to ask your doctor or pharmacist for more information.  Tell your healthcare provider if you have any side effect that bothers you or does not go away.',
		ANSWER27: {
            OPT1: "There sure is:",
            OPT2: "Get into the mood.  You will not get an erection just by taking medication. You must be sexually stimulated for it to work.",
			OPT3: "Take your time.  There's no need to rush.",
            OPT4: "Eat smart before you start. Medication can be taken with or without food. If you take medication after a high-fat meal (such as a cheeseburger and french fries), it may take a little longer to start working."
        },
		ANSWER28: {
            OPT1: "There are things you can do each day to improve your circulation, which may help your ED.",
            OPT2: "Find ways to stay more active (mowing the lawn, walking the dog).",
			OPT3: "Help manage your weight by eating healthy and watching your portion size.",
            OPT4: "Try to drink less alcohol.",
			OPT5: "Quit smoking. The results can be significant.",
            OPT6: "Look for ways to reduce stress in your daily life."
        },
		ANSWER29: 'You can drink alcohol in moderation while taking ED medication.  However, if alcohol use is the cause of your ED, you should reduce your alcohol consumption or avoid alcohol all together.',
		ANSWER30: 
        {
            OPT1: "Use Viagra tips, e.g. make it a",
            OPT2: "PLANNED event",
			OPT3: ", set the mood, use candles, etc."
        },
		ANSWER31: 'You should start by talking with your regular doctor.',
		ANSWER32: 'You can talk with your regular doctor. Or you can talk to a specialist, like a urologist. Either one can diagnosis and treat ED. You might also consider talking to your partner.',
		ANSWER33: {
            OPT1: "You can expect that once you bring up the topic of ED, your doctor can take it from there. So here are some ways to break the ice when he asks how everything’s going:",
            OPT2: '1. "I have trouble sometimes in bed. Could it be ED?"',
			OPT3: '2. "I think I might have ED. What can I do about it?"',
            OPT4: "80% of men felt relieved after talking to their doctor about erectile dysfunction."
        },
		
		ANSWER34: {
            OPT1: "The best way to communicate with your partner is to talk openly about sex and your relationship.",
            OPT2: "Here are some tips to help get the conversation started:",
			OPT3: "Explain ED and what may be causing this condition.",
            OPT4: "Discuss treatment options.",
			OPT5: "Explore alternative techniques to receive sexual pleasure.",
            OPT6: "Keep the lines of communication open.",
			OPT7: "Consider couples counseling."
        },
		ANSWER35: {
            OPT1: "Make an", 
            OPT4: "appointment",
            OPT5: "to see your doctor.",
            OPT2: "Talk to your doctor about your symptoms and full medical history.",
			OPT3: "Ask if treatment is right for you."
        },
		ANSWER36: 'By asking questions about ED, you can help make the most of your visit. It helps your doctor get the information he needs to find out if you have ED and if there is a treatment option that’s right for you.',
		ANSWER37: {
            OPT1: "You should be prepared to tell your doctor:",
            OPT2: "• How often you have difficulty getting or maintaining an erection.",
			OPT3: "• What types of medicine you are currently taking.",
            OPT4: "• All other medical conditions."
        },
        ANSWER38A: 'So have you made an appointment to see your doctor?',
		ANSWER38: 'Have you started taking an ED medication?',
		ANSWER39: 'So how can I help you?  ',
		ANSWER40: 'Do you think the ED medication is working?',
		ANSWER41: 'Maybe you need some more information before starting a new medication.',
		ANSWER42: {
            OPT1: "That’s great!  Here are a few tips to help you make the most of your medication:",
            OPT2: "Use the",
            OPT6: "Tracking Tool",
            OPT7: "in this app to record and monitor your",
            OPT8: "Erection Hardness Score",
			OPT3: ".Keep talking to your partner and your doctor, especially since ED can be a sign of a more serious medical condition.",
			OPT4: "Tell your healthcare provider if you have any side effect that bothers you or does not go away.",
			OPT5: "And finally, don’t forget to ",
            OPT9: "refill your prescription."

        },
		ANSWER43: "If you’ve tried medication and if you're still not getting results, ask your doctor to see if adjusting your dose or treatment option might help.",
		ANSWER44: {
            OPT1: "Absolutely.  Erections depend on healthy blood flow to the penis, so ED may be an indication of heart disease.",
            OPT2: "ED can also be a flag for low testosterone levels, diabetes, or HIV.  If you are experiencing symptoms of ED, it is important to see your health care provider for a full physical exam."
        },
		ANSWER45: 'Yes, in many cases, treating the medical condition that is causing ED will eliminate the symptoms you are experiencing.',

    },
    HOME: {
        BUTTON1: "Get Started"
    },
    TANDC:{
         TITLE: 'Terms & Privacy',
         TERMS: 'Terms',
         PRIVACY:'Privacy'
    },
    DCHOWTO:{
         QUESTION1:'What Causes ED?',
         QUESTION2:'Another Question',
         TEXT1:'DCC Question...',
         TEXT2:'Below each dialog there are predetermined questions that the Digital Conversation Coach will answer.These questions will change based on your conversation.',
         TEXT3:'Next',
         GREETING:'Hey James! How are you doing? What can i do for you?',
         QUESTION:'What is ED?',
         TEXT4:'Digital Conversation Coach',
         TEXT5:'Your Digital Conversation Coach is an automated response chatbot. It will your questions about ED.',
         TEXT6:'Doctor Notes…',
         TEXT7:'When you see one of these buttons appear next to an answer, or in a graph, you can click on the “+” to save a question for your doctor.This will help you get prepared for your appointment.',
         TEXT8:'Ok, Thanks!',
         ANSWER:'ED affects about 30 million men in the U.S. Some guys with ED find it difficult to either get or keep an erection every time they try to have sex.'
    },
    TLHOWTO:{
         TEXT4:'Timeline…',
         TEXT1:'Here is an example of what your timeline might look like.',
         TEXT2:'This view shows you the Grade you recorded for each day.',
         TEXT3:'Timeline Expanded…',
         TEXT5:'Clicking on any of the days will open up an expanded view that shows more info you added for that day.',
         TEXT6:'Clicking on the date again will hide this information.',
         TEXT7:'Graph View…',
         TEXT8:'By turning your device to landscape, you will get a view of each category in better details represented by a graph. Here you can click on each icon to view each detail.',
         TEXT9:'Add an Entry…',
         TEXT10:'Clicking “+” button on the screen will allow you to add an entry for that day.',
         TEXT11:'This will open a form to enter your data.',
    },
    PROFILEHOWTO:{
         TEXT4:'You can use this section to make plans (such as a Dinner Date) and set reminders.',
         TEXT5:'Reminders can be Event-based - make dinner reservation, pick up flowers, etc Or reminders can be Health-based - to make an appointment with your doctor, take your medication or refill your prescription.',
         TEXT6:'My Meds:',
         TEXT7:'Add/View any medications you are taking.',
         TEXT8:'Erection Hardness Score:',
         TEXT9:'Describes this ED self-assessment tool.',
         TEXT10:'Questions for Doctor:',
         TEXT11:'Listing of questions saved to ask your doctor.',
         TEXT12:'Export my Data:',
         TEXT13:'Share your data via email with your doctor.',
         TEXT11:'This will open a form to enter your data.',
         TEXT1:'Main Buttons…',
         TEXT3:'Upcoming event',
         TEXT14:'Dinner Date',
         TEXT15:'Saturday, June 25th'
    },
    SUCCESSASK:{
          TEXT1:'Your question has been Saved!',
          TEXT2:'You can go view all your questions or',
          TEXT3:'you can go back to the',
          TEXT4:'Digital Conversation Coach.',
          BUTTON1:'Go to my Questions',
          BUTTON2:'Back to Digital Conversation Coach',
          TITLE:'Ask a Question'
    },
    TIMELINE:{
         TEXT1:'Grade',
         TEXT2:'Today',
         TEXT3:'mins',
         TEXT4:'Pack',
         TEXT5:'Drinks',
         TEXT6:'Meds',
         TEXT7:'kg',
         TEXT8:'Let’s Build a Timeline!',
         TEXT9:'Looks like you don’t have',
         TEXT18:'Looks like there isn’t any data recorded here yet.',
         TEXT19:'Go to your Timeline and select a day to enter your',
         TEXT91:'any data here yet, but that’s ok! Just',
         TEXT92:'use the “+” button to add your first entry.',
         TEXT10:'Dashboard',
         MONTHS:[ "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
         TEXT11:'grade.',
         TEXT12:'time',
         TEXT13:'smokes',
         TEXT14:'drinks',
         TEXT15:'weight',
         TEXT16:'stress',
         TEXT17:'meds',
         TEXT20:'Current : ',
         TEXT21:'Average : ',
         TEXT22:'GRADE CHART',
         TEXT23:'EXERCISE CHART',
         TEXT24:'SMOKING CHART',
         TEXT25:'DRINKING CHART',
         TEXT26:'WEIGHT CHART',
         TEXT27:'STRESS CHART',
         TEXT28:'MEDICATION CHART'
    },
	ADD_RECORD:{
        HEADER1 : "Add a Record",
        HEADER2 : "Cancel",
        HEADER3 : "Save",
        HEADER4 : "Edit Record",
        HEADER5 : "Edit Grade",
        HEADER6 : "Delete Record",
        LINE1 : "Hardness",
        LINE2 : "Select Grade",
        LINE3 : "What time did it happen?",
        LINE4 : "Select a Time",
        LINE5 : {
            Question : "Was it upon waking?",
            OPTION1 : "Yes",
            OPTION2 : "No"
        },
        LINE6 : "How long did it last?",
        LINE7 : "Partner",
        LINE8 : "How much exercise did you have?",
        LINE9 : "How much did you smoke?",
        LINE10 : "How many drinks did you have?",
        LINE11 : "What's your current weight?",
        LINE12 : "Have you taken or will you take any of these medications today?",
        LINE13 : "What is your current stress level?",
        LINE14 : "Select a Time",
        LINE15 : "Add a New Medicine",
        LINE16 : "Are you sure you want to delete this record?",
        LINE17 : "Delete Record",
        LINE18: 'mins',
        LINE19: 'You have added your total of 3 grades fo the day. They are listed above.',
        LINE20: 'Recorded:',

        GRADES: {
            clickText1:"Grade 1: Penis is larger but not hard.",
            clickText2:"Grade 2: Hard but not hard enough for penetration.",
            clickText3:"Grade 3: Hard enough for penetration but not completely hard.",
            clickText4:"Grade 4: Completely hard and fully rigid.",
        },
        LUCKY: {
            text1: "Spouse",
            text2: "New Partner",
            text3: "Solo"
        },
        WALKING: {
            text1: "Yes",
            text2: "No"
        },
         SMOKES: {
            text1: "None",
            text2: "Less than 1 Pack",
            text3: "1+ Pack",
            no_smoke: '0',
            smoke_less: '<1',
            smoke_plus: '1+'

        },
         DRINKS: {
            text1: "0",
            text2: "1-2",
            text3: "3+"
        },
        EXERCISE: {
                text1: "0",
                text2: "30 mins",
                text3: "60+ mins"
        },
        STRESS: {
                text1: "Low",
                text2: "Medium",
                text3: "High"
        },
        ALERT: 'Alert',
        ALERT_TEXT: 'Grade time required!!!'


    },
    MEDICATION:{
        HEADER:"Medication",
        CANCEL: "Cancel",
        ERROR:"Medication name already exist!"
    },
	PROFILE:{
         TITLE: 'Profile',
         PLANS: 'Make Plans',
         REMINDER:'Set Reminder',
         APPOINTMENTS: 'Enter Appointment',
         NO_PLANS_TEXT1: 'Looks like you don’t have',
         NO_PLANS_TEXT2: 'any upcoming events.',
         BUTTON_MEDS: 'My Meds',
         BUTTON_EHS: 'Erection Hardness Score',
         BUTTON_QUESTIONS: 'Questions For Doctor',
         BUTTON_EXPORT: 'Export My Data',
         EVENTS_SUCCESS: 'Your Next Event',
         APPOINTMENTS_SUCCESS: 'Your Next Appointment', 
         NO_APP_PLANS_TEXT1: 'Looks like you don’t have',
         NO_APP_PLANS_TEXT2: 'any upcoming appointments.'

     },
     MYMEDS:{
        TITLE: 'My Meds',
        MEDADDDATE: 'Added on',
        DELETE: 'Delete',
        DIALOGTEXT:'Are you sure you want to delete this medication?',
        DIALOGTITLE:'Delete Medication',
        TEXT1:'No medication has been added here yet, Just use the “+” button to add medication.',
         TEXT2:'Edit Medication'
     },
     EHS:{
        TITLE: 'Erection Hardness Score',
        HEADER_TEXT: 'Try using The Erection Hardness Score, a self-assessment tool used in clinical studies, to rate your own erection.',
        GRADE1_TEXT1: 'Penis is larger',
        GRADE1_TEXT2: 'but not hard',
        GRADE2_TEXT: 'Hard but not hard enough for penetration',
        GRADE3_TEXT: 'Hard enough for penetration but not completely hard',
        GRADE4_TEXT1: 'Completely hard',
        GRADE4_TEXT2: 'and fully rigid'
     },
     QUESTFORDOCTOR:{
        TITLE: 'Questions for Doctor',
        DIALOGTEXT:'Are you sure you want to delete this question?',
        DIALOGTITLE:'Delete Question',
        BUTTON1:'OK',
        BUTTON2:'Cancel',
        BUTTON:'Yes',
        BUTTON3: 'Edit',
        BUTTON4: 'Save',
        TEXT1:'No question has been added here yet, Just use the “+” button to add question.',
        TEXT2: 'Answer:',
        TEXT3: 'Your Question:',
        TEXT4: 'Question'

     },
     SETTINGS:{
        TITLE: 'Settings',
        APPHOWTOS: "App How To's",
        PIN: '4-Digit PIN',
        RATEAPP: 'Rate this app',
        MSG_INVALID1: '*Email is invalid'
     },
    APPHOWTOS:{
        TIMELINE: 'Timeline'
    },

 SETREMINDER:{
        TITLE: 'Set Reminder',
        TITLE2:'Edit Reminder',
        SELECTDATE: 'Select Date',
        DATE:'Date',
        DIALOGTEXT:'Are you sure you want to delete this reminder?',
        ERRORTEXT:'Same reminder already exists',
        TIME:'Time',
        PAST_TIME:'Reminder can not be set on past time',
        SOUND:'Sound',
         DIALOGTITLE:'Delete Reminder',
        SELECTSOUND:'Default',
        REMINDERS:'Reminders',
        PLACEHOLDER:'Reminder Name',
        TEXT1:'No reminder has been added here yet, Just use the “+” button to add reminder.',
        DELETE:'Delete Reminder'
    },
    EVENT:{
       TITLE: 'Create Event',
        TITLE2:'Edit Event',
        EVENTS:'Events',
        PAST_TIME:'Event can not be set on past time',
        DIALOGTEXT:'Are you sure you want to delete this event?',
        ERRORTEXT:'Same event already exists',
         DIALOGTITLE:'Delete Event',
        LOCATION:'Location',
        PLACEHOLDER:'Event Name',
        DELETE:'Delete Event',
        SELECTLOCATION:'Select Location',
        NO_EVENTS:{
            OPT1:'Looks like you don’t have', 
            OPT2: 'any upcoming events.'
        },
        UPCOMMING_EVENT:'Upcoming event',
        TEXT1:'No event has been added here yet, Just use the “+” button to add event.'
    },
     APPOINTMENT:{
         TITLE: 'Create Appointment',
        TITLE2:'Edit Appointment',
         DIALOGTEXT:'Are you sure you want to delete this appointment?',
        PAST_TIME:'Appointment can not be set on past time',
        ERRORTEXT:'Same appointment already exists',
         DIALOGTITLE:'Delete Appointment',
         PLACEHOLDER:'Appointment Name',
         DELETE:'Delete Appointment',
         NO_APPOINTMENTS:{
            OPT1:'All good here.', 
            OPT2: 'No appointments yet!'
        },
        APPOINTMENTS:'Appointments',
        UPCOMMING_APPOINTMENT:'Your Next Appointment',
        TEXT1:'No appointment has been added here yet, Just use the “+” button to add appointment.'
    },
    ENTERPIN:{
        TITLE: 'Set Up PIN',
        PIN_TEXT1: 'Enter your PIN',
        PIN_TEXT2: 'Enter a 4 digit PIN below',
        RE_PIN_TEXT1: 'Re-enter your PIN',
        RE_PIN_TEXT2: 'Enter a 4 digit PIN again',
        MISMATCH_TEXT1: 'Oops! Looks like the PINs don’t match.',
        MISMATCH_TEXT2: 'Try Again.',
        SAVEPIN_TEXT1: 'PIN Saved!',
        SAVEPIN_TEXT2: 'You’re all set! You can now use',
        SAVEPIN_TEXT3: 'this PIN to log into the app.',
        BACKTOSETTINGS_BUTTON: 'Back to Settings',
        EMAIL_TEXT1: 'Enter Email',
        EMAIL_TEXT2: 'Just enter an email address below so we can send you information if you ever forget your PIN.',
        EMAIL_TEXT3: 'You don’t need to enter an email, but you will be unable to recover your PIN if you forget it in the future.',
        EMAIL_PLACEHOLDER: 'Enter an Email Address',
        CONTINUE: 'Continue',
        LOGINPIN_TEXT: 'Enter your 4 digit PIN to log in.',
        FORGETPIN_TEXT1: 'Forgot your PIN?',
        WRONGPIN_TEXT: 'Oops! Looks like that was the wrong PIN.',
        FORGETPIN_TEXT2: 'Forgot your PIN',
        FORGETPIN_TEXT3: 'Click “Send Email” below and we’ll send you instructions on how to reset your PIN.',
        SENDMAIL_BUTTON: 'Send Email',
        CANCEL: 'Cancel',
        SENDMAIL_TEXT1: 'Email Sent!',
        SENDMAIL_TEXT2: 'Check your email inbox soon for instructions on your PIN.',
        BACKTOPIN_BUTTON: 'Back to PIN',
        PIN_TEXT3: 'Skip this step'
    },
	VERIFYPIN:{
        NETWORK_ERROR: 'Network Error',
        NETWORK_MSG: 'No Internet Connection'
    },
     EXPORTDATA:{
        EXPORT_TEXT: 'Export Data',
        SEND: 'Send',
        TO:'To:',
        CC:'Cc/Bcc:',
        SUBJECT:'Subject:',
        ERROR:'No Data present to Export'
    },
    DEVICE:{
        DATE_ERR: 'Device current date is older than the Date on which app installed on. Please check device date and refresh app',
    }
 }


    
