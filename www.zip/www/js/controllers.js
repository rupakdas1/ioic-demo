angular.module('app.controllers', []);



(function() {
	'use strict';
	 angular
      .module('app.controllers')
      .controller('addRecords', addRecords);
	   addRecords.$inject = ['$scope', '$state','$ionicScrollDelegate','AddRecords','Timeline','AddMedications', 'ionicTimePicker', '$stateParams','$ionicModal','$window','$ionicPopup','$cordovaDialogs','$filter','$ionicLoading','$ionicPlatform'];
	   function addRecords($scope, $state,$ionicScrollDelegate,AddRecords,Timeline,AddMedications,ionicTimePicker,$stateParams,$ionicModal, $window,$ionicPopup,$cordovaDialogs,$filter,$ionicLoading,$ionicPlatform) {
           $scope.$on('$ionicView.beforeEnter', function (event, viewData) {
              
                AddMedications.getMedications().then(
                    function(res){
                     
                    vm.medication_names =[];
                    for(var i=0;i<res.length;i++){				 
					     vm.medication_names.push(res[i].medication_name);
                      }
				    },
                    function(err){
                        console.log(err);  
                    });
                $ionicPlatform.ready(function() {
                   screen.lockOrientation('portrait')
                }); 
                
            });        
			var vm = this;
            vm.page_title = 1
            vm.active = null;
            vm.cur_date  =  new Date();
            vm.display_date = new Date();
            vm.waking_active = null;
            vm.last_long = {'level' : 0,'level_edit': 0};
            vm.exercise = {'level' : 0};
            vm.drink_active = "";
            vm.smoke_active  = "";
            vm.partner_active  = "";            
            vm.checkMedication = {};
            vm.showSmoke = true;
            vm.showDrink = true;
            vm.stress_active = '';
            // Last long slider on grade data
            vm.range_last_long = {  
                value:vm.last_long.level,           
                options: {
                floor: 0,
                ceil: 60,
                showSelectionBar: true
            }
            };
            // Last long slider on edit grade data
            vm.range_last_long_edit = {  
                value:vm.last_long.level_edit,           
                options: {
                floor: 0,
                ceil: 60,
                showSelectionBar: true
            }
            };
			 // Exercise slider on non grade data
            vm.range_exercise = {  
                value:vm.exercise.level,           
                options: {
                floor: 0,
                ceil: 60,
                showSelectionBar: true
            }
            };
           /* =================Wieight scale  section===================== */
            vm.weightArr = [];			
            if(window.localStorage.getItem("isSmoking") == "No")
                vm.showSmoke = false;
             if(window.localStorage.getItem("isAlchoholic") == "No")
                vm.showDrink = false;
            for(var i = 0; i <= 215; i =i+5){
                vm.weightArr.push(i);
            }
            vm.weight_selected="";
            var multiplier=50;
            vm.clickItem = function(idx){
                var left = idx*multiplier-multiplier*4.5;
                var left1 = idx*multiplier-multiplier*3;
                $ionicScrollDelegate.$getByHandle('mainScroll').scrollTo(left1, 0, true);
            }
            vm.onScrollWeight = function(){
                //console.log($ionicScrollDelegate.$getByHandle('mainScroll').getScrollPosition());
                var left = $ionicScrollDelegate.$getByHandle('mainScroll').getScrollPosition().left;     
                vm.weight_selected = Math.round((((left+multiplier*5)/10)-10))
                $scope.$apply();
            }                
        /* =================Delete a record confirmation===================== */
            vm.showConfirm = function() {
                 $cordovaDialogs.confirm($filter('translate')('ADD_RECORD.LINE16'), $filter('translate')('ADD_RECORD.LINE17'), [$filter('translate')('QUESTFORDOCTOR.BUTTON1'),$filter('translate')('QUESTFORDOCTOR.BUTTON2')])
                .then(function(buttonIndex) {
                        if(buttonIndex==1){
                          console.log("asf")
                            AddRecords.deleteRecord(vm.display_date).then(function(res){
                            if(res == 1){
                                console.log(vm.display_date);
                                 $ionicLoading.show({
                                    template: 'Loading...',
                                    duration: 3000
                                    }).then(function(){
                                    console.log("The loading indicator is now displayed");
                                    });
                                     Timeline.setTimelineParams(vm.display_date);
                                $state.go('tab.timeline');    
                            }
                          });
                        }
                });
            };
             /* =================Grade related Data====================== */
             vm.gradeData = {
                grades:{
                    items: [{
                            text: '1',
                            clickText: $filter('translate')('ADD_RECORD.GRADES.clickText1')
                        },{
                            text: '2',
                            clickText:  $filter('translate')('ADD_RECORD.GRADES.clickText2')
                        },{
                            text: '3',
                            clickText:  $filter('translate')('ADD_RECORD.GRADES.clickText3')
                        },
                        {
                            text: '4',
                            clickText:  $filter('translate')('ADD_RECORD.GRADES.clickText4')
                        }
                    ]
                },                
                lucky:{
                    items: [{
                            class: 'icon-spouse',                             
                            text:  $filter('translate')('ADD_RECORD.LUCKY.text1')  
                        },{
                            class: 'icon-partner',

                            text:  $filter('translate')('ADD_RECORD.LUCKY.text2')   
                        },{
                            class: 'icon-solo',
                            text:  $filter('translate')('ADD_RECORD.LUCKY.text3')   
                        }
                    ]
                },   
                waking:{
                    items : [{

                        text:  $filter('translate')('ADD_RECORD.WALKING.text1')    
                    },{

                         text:  $filter('translate')('ADD_RECORD.WALKING.text2')
                    }]
                }
            }
             /* =================Non Grade related Data====================== */
            vm.nonGradeData = {
                smokes:{
                        items: [{
                            text:  $filter('translate')('ADD_RECORD.SMOKES.text1')    
                        },{
                            text:  $filter('translate')('ADD_RECORD.SMOKES.text2')
                        },{
                            text:  $filter('translate')('ADD_RECORD.SMOKES.text3')
                        }
                        ]
                    },
                drinks : {
                    items: [{
                        text:  $filter('translate')('ADD_RECORD.DRINKS.text1')    
                    },{
                        text:  $filter('translate')('ADD_RECORD.DRINKS.text2')
                    },{
                        text:  $filter('translate')('ADD_RECORD.DRINKS.text3')
                    }
                    ]
                },
                partners : {
                    items: [{
                       text:  $filter('translate')('ADD_RECORD.STRESS.text1')   
                    },{
                       text:  $filter('translate')('ADD_RECORD.STRESS.text2')               
                    },{
                       text:  $filter('translate')('ADD_RECORD.STRESS.text3')
                    }
                    ]
                }
            }
			 //Stress click
            vm.stressClick = function(index) {              
                vm.stress_active = index;  
            }; 
            /* =================Record by date====================== */
            if($stateParams.record_by_date){
                var c = JSON.parse($stateParams.record_by_date);
                vm.display_date = c[0].date;
                vm.prev_grade = [];
                for(var i = 0; i< c.length; i++){
                     // Grade data
                    if(c[i].grade_first != null && c[i].grade_first != 'undefined')                      
                        vm.prev_grade.push(JSON.parse(c[i].grade_first));
                    if(c[i].grade_second != null && c[i].grade_second != 'undefined')              
                         vm.prev_grade.push(JSON.parse(c[i].grade_second));                 
                    if(c[i].grade_third != null &&  c[i].grade_third != 'undefined')                         
                       vm.prev_grade.push(JSON.parse(c[i].grade_third));
                         // Non Grade data                       
                        vm.drink_active = c[i].drinks;                    
                        vm.smoke_active = c[i].smoke;
						vm.stressClick(parseInt(c[i].stress));
                        vm.range_exercise.value = c[i].exercise;
                        vm.date_of_record = c[i].date;
                        vm.weight_selected = c[i].weight;
                         if(c[i].medication.length > 0){
                            var madication_for_date = JSON.parse(c[i].medication);          
                            angular.forEach(madication_for_date, function(value, key) {
                            vm.checkMedication[value] = true
                            });
                        }    
                        vm.page_title = 2;
                        vm.showSave = true
                }
                console.log(vm.prev_grade)
            }
            /* Prev date entry */
             if($stateParams.record_date){
                 vm.display_date = $stateParams.record_date;
             }
            var grade,grade_date, is_wakeup, last_long_level, record_time;
            var exercise = "";
            var drink = "";
            var weight = "";
            var stress = "";
            var smoke = "";
            var medication = [];
            var lucky = "";
            var month_year = "";
            var dateData = "";
            var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
             /* =================Edit Grade Modal====================== */
            $ionicModal.fromTemplateUrl('templates/editGradeModal.html', {
                scope: $scope,
                animation: 'slide-in-up'
            }).then(function(modal) {
                $scope.editGrademodal = modal;
            });	          
            vm.getRowId = 0;
               var gradeSl;
            vm.editGrade = function(grade_date,grade_sl){   
                gradeSl = grade_sl;                
                AddRecords.getGradeData(grade_date,grade_sl).then(
                     function(res){                                 
                            var gd_data = JSON.parse(res)
                            vm.grade_edit = gd_data.grade;
                            vm.gradeTxt_edit = vm.gradeData.grades.items[gd_data.grade-1].clickText;
                            vm.waking_active_edit = gd_data.is_wakeup;
                            vm.record_time_edit = gd_data.record_time;
                            vm.range_last_long_edit.value = gd_data.last_long_level;
                            lucky = gd_data.luckyData;
                            is_wakeup = gd_data.is_wakeup;                   
                            switch(gd_data.luckyData){
                                case 'Spouse':
                                    vm.lucky_active_edit = 0;
                                    break;
                                case 'New Partner':
                                    vm.lucky_active_edit = 1;
                                    break;
                                case 'Solo':
                                    vm.lucky_active_edit = 2;
                                    break;
                            }
                           $scope.editGrademodal.show();
                    },
                    function(err){
                        console.log(err);  
                    });
            }
        /* =================Close Modal Popup====================== */
            vm.closeModal = function(modalType){
                if(modalType == 'editGrade'){
                    vm.active_edit = '';
                    vm.grade_edit = '';                
                  $scope.editGrademodal.hide();
                }
                else if(modalType == 'medicate'){
                    vm.medication_input = '';
                    vm.medication_err = false;         
                     $scope.addMedication.hide();
                }
            }                
          vm.gradeClick = function(index,isEdit) {
			vm.showSave = false;
			vm.grade_l = true;
            if(isEdit){
                vm.active_edit = index;
                vm.grade_edit = index+1;
                vm.gradeTxt_edit = vm.gradeData.grades.items[index].clickText;
            }else{
                vm.active = index;
                vm.gradeTxt = vm.gradeData.grades.items[index].clickText;
                 vm.grade = index+1; 
            } 
            var gradeDate = "";
            if($stateParams.record_by_date){
                    var recordData = JSON.parse($stateParams.record_by_date);
                    gradeDate = recordData[0].date;
            }else if($stateParams.record_date){
                    gradeDate = $stateParams.record_date;
            }else{
                var dateData = new Date();
                gradeDate = dateData.toISOString().split("T")[0];
            }
            grade_date = gradeDate; 
          }
           vm.wakingClick = function(index,isEdit) {
			vm.walking = true
               if(isEdit){
                   vm.waking_active_edit =  index;
                   is_wakeup = index; 
               }else{
                vm.waking_active = index;			 
                is_wakeup = index;      
               }                           
          }
           vm.luckyClick = function(index,isEdit){
				vm.lucky = true
               if(isEdit){
                    vm.lucky_active_edit = index;
                    lucky = vm.gradeData.lucky.items[index].text;
               }else{
                    vm.lucky_active = index;
                    lucky = vm.gradeData.lucky.items[index].text;                   
               }
          }
		  vm.drinkClick = function(index) {
            vm.drink_active = index;
            drink = vm.nonGradeData.drinks.items[index].text;
          };
		   vm.smokeClick = function(index) {               
            vm.smoke_active = index;
            smoke = vm.nonGradeData.smokes.items[index].text;
          };            
          vm.goBack = function(){
             Timeline.setTimelineParams('cancel');
             $state.go('tab.timeline');
          }
          /* =================Save Medication ====================== */            
           vm.saveMedication = function(){
              if(vm.medication_input != ""){
                var medicationData = vm.medication_input;       
                 AddMedications.setMedications(medicationData).then(function(res){
                            AddMedications.getMedications().then(
                            function(res){
                                vm.medication_names =[];
                             for(var i=0;i<res.length;i++){				 
                                    vm.medication_names.push(res[i].medication_name);
                                }                                                                                     
                            },
                            function(err){
                                console.log(err);
                            });       
                            $scope.addMedication.hide();
                        },function(err){
                            vm.medication_err = 1;
                        });
                }              
            }
             $ionicModal.fromTemplateUrl('templates/addMedication.html', {
                scope: $scope,
                animation: 'slide-in-up'
            }).then(function(modal) {
                $scope.addMedication = modal;
            });	
          vm.navigateToMedication = function(){
                vm.medication_input = '';
                $scope.addMedication.show();
          }  
			vm.textUpdate = function(){
			   vm.medication_err = false;             
			}  		  
     /* =================Time Picker====================== */
        vm.openTimer= function(isEdit, time_edit){
			if(time_edit){
				var momentObj = moment(time_edit, ["h:mm A"]).format("HH:mm");
				var display_time = moment.duration(momentObj).asSeconds()
			}else{
				var display_time = (((new Date()).getHours() * 60 * 60) + ((new Date()).getMinutes() * 60))
			}
            var ipObj = {
            callback: function (val) {//Mandatory
            if (typeof (val) === 'undefined') {
                 console.log('Time not selected');
            } else {
            var selectedTime = new Date(val * 1000);
               // console.log('Selected epoch is : ', val, 'and the time is ', selectedTime.getUTCHours(), 'H :', selectedTime.getUTCMinutes(), 'M');
                var ampm = selectedTime.getUTCHours() >= 12 ? 'PM' : 'AM';
                var hours = selectedTime.getUTCHours() % 12;
                    hours = hours ? hours : 12;
                var minutes = selectedTime.getUTCMinutes();
                if (minutes< 10) {
                    minutes = "0" + minutes;
                }    
     
                if(isEdit){
                    vm.record_time_edit = hours+ ':'+minutes+' '+ ampm;
                }else{
                    vm.record_time = hours+ ':'+minutes+' '+ ampm;
                }
				 vm.chooseTime = true;
            }
            },
            inputTime: display_time, 
            format: 12,        
            step: 5,          
            setLabel: 'Set'
            };
            ionicTimePicker.openTimePicker(ipObj);
        }
        /* =================save a record====================== */
          vm.saveRecord = function(){
            
              var monthYear = "";
               medication = [];
               if(Object.keys(vm.checkMedication).length > 0){
                    for(var i in vm.checkMedication) {
                        if(vm.checkMedication[i] == true) {
                        medication.push(i);
                        }
                    }
               }             
               var presentDate = new Date();
                dateData = new Date();
                 if($stateParams.record_by_date){
                   var recordData = JSON.parse($stateParams.record_by_date);
                   dateData = recordData[0].date;
                   var monthIndex = dateData[5] + dateData[6];
                   monthYear = months[(monthIndex-'0')-1] + '_'+dateData.split("-")[0] ;
                   console.log(monthYear);
                }else if( $stateParams.record_date){
                    dateData = $stateParams.record_date;
                    var monthIndex = dateData[5] + dateData[6];
                   monthYear = months[(monthIndex-'0')-1] + '_'+dateData.split("-")[0] ;
                }
                else{                   
                    dateData = new Date();
                    monthYear = months[dateData.getMonth()] + '_' + dateData.getFullYear();
                    dateData = dateData.toISOString().split("T")[0];                                                      
                }
                var recordData = {
                    date: dateData,
                    month_year : monthYear, 
                    gradeValueData:{
                        grade : vm.grade,
                        record_time: vm.record_time ? vm.record_time: AddRecords.currentTime(presentDate),
                        date : grade_date,
                        luckyData:lucky,
                        is_wakeup: is_wakeup,
                        last_long_level: vm.range_last_long.value
                    },
                    exerciseData:vm.range_exercise.value,
                    drinkData:(drink)?drink:vm.drink_active,
                    smokeData :(smoke)?smoke:vm.smoke_active,
                    weightData:vm.weight_selected,
                    stressData:vm.stress_active,
                    medicationData:medication                    
                }
           if(localStorage.getItem(dateData) >= 0 && localStorage.getItem(dateData) != null){
               //console.log("currentRowId");
            AddRecords.setRecords(recordData,1, vm.prev_grade);
             Timeline.setTimelineParams(vm.display_date);
            $state.go('tab.timeline');   
           }
           else{
            AddRecords.setRecords(recordData,1, vm.prev_grade); 
             Timeline.setTimelineParams(vm.display_date);
            $state.go('tab.timeline');    
           }
          }
         AddRecords.getRecords();      
         /* =================Edit a saved Grade====================== */ 
          vm.editSaveGrade=function(){  
              	vm.gradeEditedData = {
                        grade : vm.grade_edit,
                        record_time: vm.record_time_edit ? vm.record_time_edit: AddRecords.currentTime(new Date()),
                        date : vm.prev_grade[gradeSl].date,
                        luckyData:lucky,
                        is_wakeup: is_wakeup,
                        last_long_level: vm.range_last_long_edit.value
                    };           
                     AddRecords.updateRecord(vm.gradeEditedData,gradeSl).then(function(restxt){
                         if(restxt == 1){
                        Timeline.getRecordsByDate(vm.gradeEditedData.date).then(
                            function(res){           
                                var bufferArray = [];                            
                                for(var i=0; i<res.length;i++){                             
                                bufferArray.push(res[i]);                            
                                }                           
                                vm.prev_grade = [];
                                for(var i = 0; i< bufferArray.length; i++){
                                     // Grade data 
                                    if(bufferArray[i].grade_first != null)              
                                         vm.prev_grade.push(JSON.parse(bufferArray[i].grade_first));                                 
                                    if(bufferArray[i].grade_second != null && bufferArray[i].grade_second != 'undefined')                           
                                        vm.prev_grade.push(JSON.parse(bufferArray[i].grade_second));          
                                    if(bufferArray[i].grade_third != null && bufferArray[i].grade_third != 'undefined')                              
                                        vm.prev_grade.push(JSON.parse(bufferArray[i].grade_third));                                                                  
                                }                    
                                vm.active_edit = "";
                                vm.grade_edit = "";
                               $scope.editGrademodal.hide();
                             
                            },function(err){
                                console.log(err);  
                            });  
                         }
                    },function(err){
                        console.log(err);
                    });                
            }
		}			
})();
(function() {
	'use strict';
	
	 angular
      .module('app.controllers')
      .controller('appHowTo', appHowTo);
	   appHowTo.$inject = ['$scope', '$state'];	   
	   function appHowTo($scope, $state) {
	   	var vm = this;
	   	vm.goBack =  function(){
            window.history.back();
        }	
		vm.goToTimeline = function(){
			$state.go('tlHowTo');
		}	
		vm.goToDigitalCoach = function(){
			$state.go('dcHowTo');
		}
		vm.goToProfileHowTo = function(){
			$state.go('profileHowTo');
		}
	   }	   
	}
)();
(function() {
	'use strict';
	
	 angular
      .module('app.controllers')
      .controller('askQuestion', askQuestion);
	   askQuestion.$inject = ['$scope', '$state','$stateParams','AddMedications','$ionicPlatform','$ionicScrollDelegate'];
	   
	   function askQuestion($scope, $state,$stateParams,AddMedications,$ionicPlatform,$ionicScrollDelegate) {
             var vm=this; 
             vm.graphQue = false; 
             vm.ansOfQues = "";
             vm.imageIndex = 8;
             vm.imgsrc = [
               "img/graph/grade_btn@2x.png",
               "img/graph/exercise_btn@2x.png",
               "img/graph/smoke_btn@2x.png",
               "img/graph/drink_btn@2x.png",
               "img/graph/weight_btn@2x.png",
               "img/graph/stress_btn@2x.png",
               "img/graph/meds_btn@2x.png"
             ]
		     $scope.$emit('pageChange', {
              title: 'Ask a Question',
              leftButton:'Cancel',
              rightButton:'Save'
            })
        $scope.$on('$ionicView.afterEnter', function (event, viewData) {
          vm.ansOfQues= viewData.stateParams.ans;
          if(typeof vm.ansOfQues == 'object' && vm.ansOfQues != null){
             vm.graphQue = true; 
             vm.imageIndex = parseInt(vm.ansOfQues.selectedGraph);
             vm.ansOfQues=vm.ansOfQues.ans;
             $ionicPlatform.ready(function() {
                   screen.lockOrientation('landscape')
                }); 
          }
          else{
            vm.graphQue = false;  
          }
          $ionicScrollDelegate.scrollTop();
        });
        // $scope.$on('$ionicView.beforeLeave', function (event, viewData) {
        //    $ionicPlatform.ready(function() {
        //            screen.lockOrientation('portrait')
        //         }); 
        // });
            vm.saveQuestion = function(){
               AddMedications.setQuestions(vm.questionText,vm.ansOfQues,vm.imageIndex);
               vm.questionText="";
               if(vm.ansOfQues=="" || vm.ansOfQues==null){
                $state.go('myQuestions',{camefrom:"showQueSave"});
               }
               else if(vm.graphQue == true){
                 $state.go('tab.timeline');
               }
               else{
                 $state.go('successAsk');
               }
            }
             vm.goBack = function(){
              vm.questionText="";
              window.history.back();    
            }           
		}
				
})();
(function() {
	'use strict';
	
	 angular
      .module('app.controllers')
      .controller('createAppointment', createAppointment);
	   createAppointment.$inject = ['$scope', '$state','$stateParams','ionicTimePicker','ionicDatePicker','$location','AddReminders','$cordovaDialogs','$filter'];
	   
	   function createAppointment($scope, $state,$stateParams,ionicTimePicker,ionicDatePicker,$location,AddReminders,$cordovaDialogs,$filter) {
              
             var vm=this; 
              var appointmentObj = {};
             vm.oldAppointmentText=null;
             vm.oldRecordedDate=null;
             vm.oldAppointmentLocation=null;
             vm.oldDate=null;
             vm.oldTime=null;
              var path = $location.path();
              console.log("path",path);
             if(path=='/editAppointment'){
              vm.editScreen=true;
               $scope.$on('$ionicView.beforeEnter', function (event, viewData) {  
                 appointmentObj = {};
                 appointmentObj = JSON.parse(viewData.stateParams.items);
                 console.log("appointment",appointmentObj);
                 vm.oldAppointmentText=vm.appointmentText=appointmentObj.appointment_name;
                vm.oldRecordedDate=appointmentObj.recorded_date;
                vm.oldAppointmentLocation=vm.locationText=appointmentObj.location_text;
                vm.oldDate= vm.set_date_edit=moment(appointmentObj.recorded_date).format("dddd, MMMM Do");
                vm.oldTime=vm.record_time_edit=moment(appointmentObj.recorded_date).format("hh:mm A");
             });
             }else{
              vm.appointmentText="";
               vm.set_date_edit="";
               vm.record_time_edit="";
               vm.locationText="";
              vm.editScreen=false;
             }
		     $scope.$emit('pageChange', {
              title: 'Create Appointment',
              leftButton:'Cancel',
              rightButton:'Save'
            })
            // vm.ansOfQues=($stateParams.ans);
            // console.log(vm.ansOfQues);
            vm.saveAppointment = function(){
             if(vm.appointmentText != "" && vm.set_date_edit !="" && vm.record_time_edit !="" ){
                var appointmentData = vm.appointmentText;
                var appointmentDate= vm.set_date_edit;
                var appointmentTime = vm.record_time_edit;
                var appointmentLocation=vm.locationText;
                var appointmentDate=moment(vm.set_date_edit+' '+vm.record_time_edit,"dddd, MMMM Do hh:mm a").toISOString();
               
                 AddReminders.setAppointments(appointmentData,appointmentDate,appointmentLocation).then(
                    function(res){
                        console.log(res);
                          vm.appointmentText=null;
                         vm.set_date_edit=null;
                         vm.record_time_edit=null;
                         vm.locationText=null; 
                        $state.go("myAppointments");            
                    },
                      function(err){
                 $cordovaDialogs.alert($filter('translate')('APPOINTMENT.ERRORTEXT'),[$filter('translate')('QUESTFORDOCTOR.BUTTON1')])
                 .then(function(buttonIndex) {
                       
                    });                 
                    });
                }              
            }
             vm.updateAppointment = function(){
             var appointmentData = vm.appointmentText;
             var appointmentDate=moment(vm.set_date_edit+' '+vm.record_time_edit,"dddd, MMMM Do hh:mm a").toISOString();
             var appointmentLocation=vm.locationText;
                console.log("oldAppointmentText",vm.oldAppointmentText,"oldRecordedDate",vm.oldRecordedDate);
               AddReminders.updateAppointments(vm.oldAppointmentText,vm.oldRecordedDate,vm.oldAppointmentLocation,appointmentData,appointmentDate,appointmentLocation).then(
                    function(res){
                        console.log(res); 
                        // $state.go("myReminders");
                         $state.go('myAppointments', {cameFrom:"editAppointment"});       
                    },
                    function(err){

                        console.log(err);  
                    });
            }
             vm.goBack = function(){
                vm.appointmentText=null;
                vm.set_date_edit=null;
                vm.record_time_edit=null;
                vm.locationText=null; 
               $state.go('myAppointments', {cameFrom:"editAppointment"});   
            }
             vm.goToAppointments = function(){
               vm.appointmentText=null;
               vm.set_date_edit=null;
               vm.record_time_edit=null; 
               vm.locationText=null;
               $state.go('tab.profileMain');
            }
            
            vm.deleteAppointment =function(){
               $cordovaDialogs.confirm($filter('translate')('APPOINTMENT.DIALOGTEXT'), $filter('translate')('SETREMINDER.DIALOGTITLE'), [$filter('translate')('QUESTFORDOCTOR.BUTTON1'),$filter('translate')('QUESTFORDOCTOR.BUTTON2')])
                .then(function(buttonIndex) {
                // no button = 0, 'OK' = 1, 'Cancel' = 2
                        if(buttonIndex==1){
                            AddReminders.deleteAppointment(vm.oldAppointmentText).then(
                                    function(res){    
                                    $state.go('myAppointments', {cameFrom:"editAppointment"});                 
                                    },
                                    function(err){
                                      console.log(err);  
                          });
                          
                        }
                });
            }
    vm.dateCheck=function(date){
                  var date = new Date(date);
                  var  year = date.getFullYear();
                  var  month = date.getMonth()+1;
                  var  dt = date.getDate();

                    if (dt < 10) {
                    dt = '0' + dt;
                    }
                    if (month < 10) {
                    month = '0' + month;
                    }
                    return year+'-' + month + '-'+dt;        
            }
             vm.TimeCheck=function(time){
                 var selectedTime = new Date(time * 1000);
                // console.log('Selected epoch is : ', val, 'and the time is ', selectedTime.getUTCHours(), 'H :', selectedTime.getUTCMinutes(), 'M');
                  var ampm = selectedTime.getUTCHours() >= 12 ? 'PM' : 'AM';
                 var hours = selectedTime.getUTCHours() % 12;
                             hours = hours ? hours : 12;
                 var minutes = selectedTime.getUTCMinutes();
                    if (minutes< 10) {
                          minutes = "0" + minutes;
                        }     
                return hours+ ':'+minutes+' '+ ampm;
            }

            vm.selectDate =function(){
             var ipObj1 = {
              callback: function (val) {  //Mandatory
                console.log('Return value from the datepicker popup is : ' + val);              
                vm.set_date_edit=moment(val).format("dddd, MMMM Do");
                if(vm.record_time_edit){
                    var datechek=vm.dateCheck(new Date(val).toISOString());
                      var d = new Date().toISOString();
                      var currentDate=vm.dateCheck(d);
                      if(datechek==currentDate){
                       var display_time = (((new Date()).getHours() * 60 * 60) + ((new Date()).getMinutes() * 60));  
                        var checkTime=vm.TimeCheck(display_time);
                        console.log("checkTime",checkTime);
                        var beginningTime = moment(vm.record_time_edit ,'h:mma');
                         var endTime = moment(checkTime, 'h:mma');
                         console.log("beginningTime",beginningTime);
                         console.log("endTime",endTime); 
                         if(beginningTime.isBefore(endTime)){
                         vm.set_date_edit='';
                        //  vm.record_time_edit='';
                         $cordovaDialogs.alert($filter('translate')('APPOINTMENT.PAST_TIME'),[$filter('translate')('QUESTFORDOCTOR.BUTTON1')])
                         .then(function(buttonIndex) {
                                        
                         });

                         }    
                      }
                }
              },
              from: new Date(), //Optional
            //  to: new Date(2016, 10, 30), //Optional
              inputDate: new Date(),      //Optional
              mondayFirst: true,          //Optional
              closeOnSelect: false,       //Optional
              templateType: 'popup',      //Optional
              dateFormat: 'dd MMMM yyyy',
            };
              ionicDatePicker.openDatePicker(ipObj1);
            }
           vm.openTimer= function(isEdit,time_edit){
        
               if(vm.set_date_edit){
                   var a=moment(vm.set_date_edit,"dddd, MMMM Do").toISOString();
                   var d = new Date().toISOString();
                var selected_date = vm.dateCheck(a);
                var current_Date = vm.dateCheck(d); 
                console.log("selected_date",selected_date);
                console.log("current_Date",current_Date);
                if(selected_date==current_Date){
                  vm.avoidPastTime=true;
                }else{
                     vm.avoidPastTime=false;
                }
            
               }
              
                var display_time = (((new Date()).getHours() * 60 * 60) + ((new Date()).getMinutes() * 60));


              console.log("open Timmer")
            var ipObj = {
                            callback: function (val) {  //Mandatory
                             
                            if (typeof (val) === 'undefined') {
                                 console.log('Time not selected');
                            } else {
                            var selectedTime = new Date(val * 1000);
                               // console.log('Selected epoch is : ', val, 'and the time is ', selectedTime.getUTCHours(), 'H :', selectedTime.getUTCMinutes(), 'M');
                                var ampm = selectedTime.getUTCHours() >= 12 ? 'PM' : 'AM';
                                var hours = selectedTime.getUTCHours() % 12;
                                    hours = hours ? hours : 12;
                                var minutes = selectedTime.getUTCMinutes();
                                if (minutes< 10) {
                                    minutes = "0" + minutes;
                                }    
                     
                                if(isEdit){
                                    vm.record_time_edit = hours+ ':'+minutes+' '+ ampm;
                                    console.log('vm.record_time_edit',vm.record_time_edit);
                                    if( vm.avoidPastTime==true){
                                       var display_time = (((new Date()).getHours() * 60 * 60) + ((new Date()).getMinutes() * 60));  
                                       var checkTime=vm.TimeCheck(display_time);
                                       console.log("checkTime",checkTime);
                                       var beginningTime = moment(vm.record_time_edit ,'h:mma');
                                        var endTime = moment(checkTime, 'h:mma');
                                        console.log("beginningTime",beginningTime);
                                           console.log("endTime",endTime);
                                       
                                        if(beginningTime.isBefore(endTime)){
                                          vm.record_time_edit='';
                                          $cordovaDialogs.alert($filter('translate')('APPOINTMENT.PAST_TIME'),[$filter('translate')('QUESTFORDOCTOR.BUTTON1')])
                                          .then(function(buttonIndex) {
                                        
                                           });

                                        }
                                    }
                                }else{
                                      
                                    vm.record_time = hours+ ':'+minutes+' '+ ampm;
                                }
                         vm.chooseTime = true;
                            }
                            },
                            inputTime: display_time, 
                            format: 12,        
                            step: 1,          
                            setLabel: 'Set'
                  };

                ionicTimePicker.openTimePicker(ipObj);
            }
		}
				
})();
(function() {
	'use strict';
	
	 angular
      .module('app.controllers')
      .controller('createEvent', createEvent);
	   createEvent.$inject = ['$scope', '$state','$stateParams','ionicTimePicker','ionicDatePicker','$location','$cordovaDialogs','$filter','AddReminders'];
	   
	   function createEvent($scope, $state, $stateParams, ionicTimePicker, ionicDatePicker, $location, $cordovaDialogs, $filter,AddReminders) {             
             var vm = this; 
             var eventObj = {};
             vm.oldEventText = null;
             vm.oldRecordedDate = null;
             vm.oldDate = null;
             vm.oldTime = null;
             vm.oldLocationText=null;
             var path = $location.path();
              console.log("path",path);
             if(path == '/editEvent'){
              vm.editScreen=true;
              $scope.$on('$ionicView.beforeEnter', function (event, viewData) {  
                 eventObj = {};
                 eventObj = JSON.parse(viewData.stateParams.items);
                 console.log("reminder",eventObj);
                 vm.oldEventText=vm.eventText=eventObj.event_name;
                 vm.oldLocationText=vm.locationText=eventObj.location_text;
                 vm.oldRecordedDate=eventObj.recorded_date;
               vm.oldDate= vm.set_date_edit=moment(eventObj.recorded_date).format("dddd, MMMM Do");
                vm.oldTime=vm.record_time_edit=moment(eventObj.recorded_date).format("hh:mm A");
             });
             }else{
             console.log("insetEvent");
              vm.eventText="";
               vm.set_date_edit="";
               vm.record_time_edit="";
               vm.locationText="";
              vm.editScreen=false;
             }
		     $scope.$emit('pageChange', {
              title: 'Create Event',
              leftButton:'Cancel',
              rightButton:'Save'
            })
			/* =================Add an Event===================== */
            vm.saveEvent = function(){
               if(vm.eventText != "" && vm.set_date_edit !="" && vm.record_time_edit !=""){
                var eventData = vm.eventText;
                var eventDate= vm.set_date_edit;
                var eventTime = vm.record_time_edit;
                var eventDate=moment(vm.set_date_edit+' '+vm.record_time_edit,"dddd, MMMM Do hh:mm a").toISOString();
                var eventLocation=vm.locationText;
                 AddReminders.setEvents(eventData,eventDate,eventLocation).then(
                    function(res){
                        console.log(res);
                        vm.eventText=null;
                         vm.set_date_edit=null;
                         vm.record_time_edit=null; 
                         vm.locationText=null;
                        $state.go("myEvents");            
                    },
                     function(err){
                 $cordovaDialogs.alert($filter('translate')('EVENT.ERRORTEXT'),[$filter('translate')('QUESTFORDOCTOR.BUTTON1')])
                 .then(function(buttonIndex) {
                       
                    });                 
                    });
                }              
            }
             vm.updateEvent = function(){
             var eventData = vm.eventText;
             var eventDate=moment(vm.set_date_edit+' '+vm.record_time_edit,"dddd, MMMM Do hh:mm a").toISOString();
             var eventLocation=vm.locationText;
                console.log("oldEventText",vm.oldEventText,"oldRecordedDate",vm.oldRecordedDate);
               AddReminders.updateEvents(vm.oldEventText,vm.oldRecordedDate,vm.oldLocationText,eventData,eventDate,eventLocation).then(
                    function(res){                                            
                         $state.go('myEvents', {cameFrom:"editEvent"});       
                    },
                    function(err){
                        console.log(err);  
                    });
            }
             vm.goBack = function(){
               vm.eventText=null;
               vm.set_date_edit=null;
               vm.record_time_edit=null; 
                vm.locationText=null;
               $state.go('myEvents', {cameFrom:"editEvent"});   
            }
            vm.goToEvents = function(){
               vm.eventText=null;
               vm.set_date_edit=null;
               vm.record_time_edit=null; 
               vm.locationText=null;
               $state.go('tab.profileMain');
            }
			/* =================Delete an event===================== */
            vm.deleteEvent=function(){            
                  $cordovaDialogs.confirm($filter('translate')('EVENT.DIALOGTEXT'), $filter('translate')('SETREMINDER.DIALOGTITLE'), [$filter('translate')('QUESTFORDOCTOR.BUTTON1'),$filter('translate')('QUESTFORDOCTOR.BUTTON2')])
                .then(function(buttonIndex) {               
                        if(buttonIndex == 1){
                            AddReminders.deleteEvent(vm.oldEventText).then(
                                    function(res){    
                                    $state.go('myEvents', {cameFrom:"editEvent"});                 
                                    },
                                    function(err){
                                      console.log(err);  
                          });
                          
                        }
                });
              
            }
            
            vm.dateCheck=function(date){
                  var date = new Date(date);
                  var  year = date.getFullYear();
                  var  month = date.getMonth()+1;
                  var  dt = date.getDate();

                    if (dt < 10) {
                    dt = '0' + dt;
                    }
                    if (month < 10) {
                    month = '0' + month;
                    }
                    return year+'-' + month + '-'+dt;        
            }
             vm.TimeCheck=function(time){
                 var selectedTime = new Date(time * 1000);
                // console.log('Selected epoch is : ', val, 'and the time is ', selectedTime.getUTCHours(), 'H :', selectedTime.getUTCMinutes(), 'M');
                  var ampm = selectedTime.getUTCHours() >= 12 ? 'PM' : 'AM';
                 var hours = selectedTime.getUTCHours() % 12;
                             hours = hours ? hours : 12;
                 var minutes = selectedTime.getUTCMinutes();
                    if (minutes< 10) {
                          minutes = "0" + minutes;
                        }     
                return hours+ ':'+minutes+' '+ ampm;
            }

            vm.selectDate =function(isEdit,time_edit){
             var ipObj1 = {
              callback: function (val) {  //Mandatory
                console.log('Return value from the datepicker popup is : ' + val);              
                vm.set_date_edit=moment(val).format("dddd, MMMM Do");
                if(vm.record_time_edit){
                    var datechek=vm.dateCheck(new Date(val).toISOString());
                      var d = new Date().toISOString();
                      var currentDate=vm.dateCheck(d);
                      if(datechek==currentDate){
                       var display_time = (((new Date()).getHours() * 60 * 60) + ((new Date()).getMinutes() * 60));  
                        var checkTime=vm.TimeCheck(display_time);
                        console.log("checkTime",checkTime);
                        var beginningTime = moment(vm.record_time_edit ,'h:mma');
                         var endTime = moment(checkTime, 'h:mma');
                         console.log("beginningTime",beginningTime);
                         console.log("endTime",endTime); 
                         if(beginningTime.isBefore(endTime)){
                        
                         $cordovaDialogs.alert($filter('translate')('EVENT.PAST_TIME'),[$filter('translate')('QUESTFORDOCTOR.BUTTON1')])
                         .then(function(buttonIndex) {
                                        
                         });
                           
                               vm.set_date_edit='';
                            //    vm.record_time_edit='';
                           
                         }    
                      }
                }
              },
              from: new Date(), //Optional
            //  to: new Date(2016, 10, 30), //Optional
              inputDate: new Date(),      //Optional
              mondayFirst: true,          //Optional
              closeOnSelect: false,       //Optional
              templateType: 'popup',      //Optional
              dateFormat: 'dd MMMM yyyy',
            };
              ionicDatePicker.openDatePicker(ipObj1);
            }
           vm.openTimer= function(isEdit,time_edit){
        
               if(vm.set_date_edit){
                   var a=moment(vm.set_date_edit,"dddd, MMMM Do").toISOString();
                   var d = new Date().toISOString();
                var selected_date = vm.dateCheck(a);
                var current_Date = vm.dateCheck(d); 
                console.log("selected_date",selected_date);
                console.log("current_Date",current_Date);
                if(selected_date==current_Date){
                  vm.avoidPastTime=true;
                }else{
                     vm.avoidPastTime=false;
                }
            
               }
           
        
         var display_time = (((new Date()).getHours() * 60 * 60) + ((new Date()).getMinutes() * 60));
              

              console.log("open Timmer")
            var ipObj = {
                            callback: function (val) {  //Mandatory
                             
                            if (typeof (val) === 'undefined') {
                                 console.log('Time not selected');
                            } else {
                            var selectedTime = new Date(val * 1000);
                               // console.log('Selected epoch is : ', val, 'and the time is ', selectedTime.getUTCHours(), 'H :', selectedTime.getUTCMinutes(), 'M');
                                var ampm = selectedTime.getUTCHours() >= 12 ? 'PM' : 'AM';
                                var hours = selectedTime.getUTCHours() % 12;
                                    hours = hours ? hours : 12;
                                var minutes = selectedTime.getUTCMinutes();
                                if (minutes< 10) {
                                    minutes = "0" + minutes;
                                }    
                     
                                if(isEdit){
                                    vm.record_time_edit = hours+ ':'+minutes+' '+ ampm;
                                    console.log('vm.record_time_edit',vm.record_time_edit);
                                    if( vm.avoidPastTime==true){
                                       var display_time = (((new Date()).getHours() * 60 * 60) + ((new Date()).getMinutes() * 60));  
                                       var checkTime=vm.TimeCheck(display_time);
                                       console.log("checkTime",checkTime);
                                       var beginningTime = moment(vm.record_time_edit ,'h:mma');
                                        var endTime = moment(checkTime, 'h:mma');
                                        console.log("beginningTime",beginningTime);
                                           console.log("endTime",endTime);
                                       
                                        if(beginningTime.isBefore(endTime)){
                                          $cordovaDialogs.alert($filter('translate')('EVENT.PAST_TIME'),[$filter('translate')('QUESTFORDOCTOR.BUTTON1')])
                                          .then(function(buttonIndex) {
                                        
                                           });
                                      
                                           vm.record_time_edit='';
                                           
                                        }
                                    }
                                }else{
                                      
                                    vm.record_time = hours+ ':'+minutes+' '+ ampm;
                                }
                         vm.chooseTime = true;
                            }
                            },
                            inputTime: display_time, 
                            format: 12,        
                            step: 1,          
                            setLabel: 'Set'
                  };

                ionicTimePicker.openTimePicker(ipObj);
            }
		}
				
})();
(function() {
	'use strict';
	
	 angular
      .module('app.controllers')
      .controller('dcHowTo', dcHowTo);
	   dcHowTo.$inject = ['$scope', '$state','$stateParams','$ionicSlideBoxDelegate','$ionicScrollDelegate'];
	   
	   function dcHowTo($scope, $state,$stateParams,$ionicSlideBoxDelegate,$ionicScrollDelegate) {
              
             $scope.$on('$ionicView.beforeEnter', function (event, viewData) {
                 $ionicSlideBoxDelegate.slide(0);
            });   
             var vm=this; 

             vm.timelineData = [
                 {
                         avg_grade:3,
                         date:"2016-06-16",
                         today:true
                     
                 },
                     {
                         avg_grade:2,
                         date:"2016-06-15",
                         today:false
                     },
                      {
                         avg_grade:2,
                         date:"2016-06-14",
                         today:false
                     }
                 
             ];
             vm.today_date = moment("2016-06-16").format("dddd, MMMM Do");

             console.log(vm.timelineData);
             vm.lockSlide = function(){
                    $ionicSlideBoxDelegate.enableSlide(false);
             }
            
             vm.goBack = function(){
                 window.history.back();
             }
             vm.goNext = function(){
                 $ionicScrollDelegate.scrollTop();
                 $ionicSlideBoxDelegate.next();
             } 
		    
		}
				
})();
(function() {
	'use strict';
	
	 angular
      .module('app.controllers')
      .controller('digitalCoach', digitalCoach);
	   digitalCoach.$inject = ['$scope', '$state','Chats','$ionicScrollDelegate','$filter','$ionicTabsDelegate','$timeout','$cordovaKeyboard','focus','$ionicPlatform','AddReminders'];
	   
	   function digitalCoach($scope, $state, Chats,$ionicScrollDelegate,$filter,$ionicTabsDelegate,$timeout,$cordovaKeyboard,focus,$ionicPlatform,AddReminders) {
       
	   $ionicTabsDelegate.showBar(false);
	    $scope.$on('$ionicView.beforeEnter', function (event, viewData) {
				if(window.localStorage.getItem("returnUser")!="Y"){
					 vm.msgName=false;
                     vm.showInput = false;
				}
				 $ionicPlatform.ready(function() {
                   screen.lockOrientation('portrait')
                }); 

			});
		 var vm = this;
		 
		 vm.outsideTab=true;
         vm.chats=Chats.all();
         vm.messages=[];
		 vm.namePara="";
		 vm.greeting = "";
		 vm.isSmoking=window.localStorage.getItem("isSmoking");
		 vm.isAlchoholic=window.localStorage.getItem("isAlchoholic");
		 $ionicScrollDelegate.resize();
		 /* =================Get name from localStorage====================== */ 
		 if(window.localStorage.getItem("person_name") != null){
            vm.namePara=window.localStorage.getItem("person_name").split(' ')[0];
		 }
		 /* =================Setting up a greeting text randomly====================== */ 
		 var random = Math.floor(Math.random() * 3) + 1;
		  switch (random) {
					case 1:
						  vm.greeting = $filter('translate')('DIGITALCOACH.GREETING5') + vm.namePara;
						break;
					case 2:
						  vm.greeting = $filter('translate')('DIGITALCOACH.GREETING6.OPT1') + vm.namePara+$filter('translate')('DIGITALCOACH.GREETING6.OPT2');
						break;
					case 3:
					      vm.greeting = $filter('translate')('DIGITALCOACH.GREETING7.OPT1') + vm.namePara+$filter('translate')('DIGITALCOACH.GREETING7.OPT2')
		  }
           if(window.localStorage.getItem("returnUser")=="Y"){
						$ionicTabsDelegate.showBar(true);
						vm.outsideTab=false;
						 AddReminders.getLengthOfAppointments().then(
							function(res){
								if(window.localStorage.getItem('isEDMedTaken')!='Y'){
									vm.currentQues=vm.chats[38].Ques;
									vm.questionToAsk=Chats.getQuestion(38);
									vm.messages.push(vm.questionToAsk.Answer);
								}
								else{
									vm.currentQues=vm.chats[40].Ques;
									vm.questionToAsk=Chats.getQuestion(40);
									vm.messages.push(vm.questionToAsk.Answer);
								}
							},
							function(err){
								vm.currentQues=vm.chats[50].Ques;
								vm.questionToAsk=Chats.getQuestion(50);
								vm.messages.push(vm.questionToAsk.Answer);
						     });
						vm.returnUser=true;
			}
			else {
						vm.currentQues=vm.chats[0].Ques;
						vm.returnUser=false;
			}
		
		  var scrollUp = function(){
			  $timeout(function(){
			   var clientHeight = document.getElementById('bottomQues').clientHeight;
               document.getElementById('dummyDiv').style.height = clientHeight + "px";
			   $ionicScrollDelegate.resize();
			   $ionicScrollDelegate.scrollBottom(true);
		   },100);
		 }
		vm.getQuestion = function(data){
			vm.questionToAsk=Chats.getQuestion(data.no);
			switchCalled(data)
			vm.messages.push(data); //pusshing that question to be asked in array
			vm.messages.push(vm.questionToAsk.Answer);//pushing answer also
			vm.currentQues=vm.questionToAsk.Ques;// assgining further question to ask
			scrollUp();
        }
		  /* =================Switch Digital coach====================== */ 
        var switchCalled = function(data){
			 switch (data.no) {
					case '46':
						  vm.isSmoking=data.Answer1;//data to be saved
						  window.localStorage.setItem("isSmoking",vm.isSmoking);
						break;
					case '100':
						 vm.isAlchoholic=data.Answer1; //data to be saved
						 console.log(vm.isAlchoholic)
							if(vm.isSmoking == "No" && vm.isAlchoholic == "No"){
								data.no=47;
								vm.questionToAsk=Chats.getQuestion(data.no);
								window.localStorage.setItem("isAlchoholic",vm.isAlchoholic);
							}
							else{
								data.no=48;
								vm.questionToAsk=Chats.getQuestion(data.no);
							}
						break;
					case '20':
						if(vm.isSmoking == "No" && vm.isAlchoholic == "No"){
							data.no=49;
							vm.questionToAsk=Chats.getQuestion(data.no);
						}
						break;
					case '23':
					    if(vm.isSmoking == "No" && vm.isAlchoholic == "No"){
						 vm.questionToAsk.Answer.Answer1=[$filter('translate')('DIGITALCOACH.ANSWER23.OPT1')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER23.OPT2')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER23.OPT31')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER23.OPT4')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER23.OPT5')];
						}
						 else if(vm.isSmoking == "No" && (vm.isAlchoholic == "Yes" || vm.isAlchoholic == "Skip for now")){
						 vm.questionToAsk.Answer.Answer1=[$filter('translate')('DIGITALCOACH.ANSWER23.OPT1')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER23.OPT2')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER23.OPT32')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER23.OPT4')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER23.OPT5')];
						}
						 else if((vm.isSmoking == "Yes" || vm.isSmoking == "Skip for now")  && vm.isAlchoholic == "No"){
						 vm.questionToAsk.Answer.Answer1=[$filter('translate')('DIGITALCOACH.ANSWER23.OPT1')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER23.OPT2')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER23.OPT33')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER23.OPT4')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER23.OPT5')];
						}
						 else {
						 vm.questionToAsk.Answer.Answer1=[$filter('translate')('DIGITALCOACH.ANSWER23.OPT1')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER23.OPT2')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER23.OPT34')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER23.OPT4')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER23.OPT5')];
						}
						break;
					case '27':
					    if(vm.isAlchoholic == "No"){
						   if(vm.questionToAsk.Ques.length>2){
							  vm.questionToAsk.Ques.splice(1, 1);
							}
						}
						break;
					case '28':
					    if(vm.isAlchoholic == "No"){
							if(vm.questionToAsk.Ques.length>2){
							  vm.questionToAsk.Ques.splice(0, 1);
							}
					    }
						break;
					case '30':
					    if(vm.isAlchoholic == "No"){
							if(vm.questionToAsk.Ques.length>2){
							  vm.questionToAsk.Ques.splice(1, 1);
							}
					    }
					   break;
					case '40':
					      window.localStorage.setItem('isEDMedTaken','Y');
						  break; 
					case '7':
					   if(window.localStorage.getItem("isSmoking") == "Yes" || window.localStorage.getItem("isSmoking") == "No")
					   {
						   if(window.localStorage.getItem("isSmoking") == "Yes" || window.localStorage.getItem("isSmoking") == "No")
						   {
							   console.log("i came")
							   data.no = '100';
							   switchCalled(data);
						   }
						   else{
							   data.no = '46';
							   vm.questionToAsk=Chats.getQuestion(data.no);
							   switchCalled(data);
						   }
						       
					   }
				}
		}
		 /* ================= Digital coach form changed====================== */ 
		vm.formChanged = function(){
					if(vm.user_name != ""){
						return true;
					}
			 	$ionicScrollDelegate.resize();
				return false;				
		}
		vm.msgName=false;
		
		  /* =================Set Name for user====================== */ 
		vm.setName = function(){
				window.localStorage.setItem("returnUser","Y");
				vm.namePara = vm.user_name;
				vm.namePara=vm.namePara.split(' ')[0];//setting only first name
				window.localStorage.setItem("person_name",vm.namePara)
				vm.messages.push(vm.chats[0].Answer);
				vm.msgName=true;
				vm.showInput = false;
				vm.skipName=false;
				$cordovaKeyboard.close();
				 $timeout(function(){
				 	$cordovaKeyboard.close();
				    document.getElementById('dummyDiv').style.height= 38 + "vh";
					$ionicScrollDelegate.resize();
					$ionicScrollDelegate.scrollBottom(true);
				 },10);

				return true;
				}
		vm.goToDigitalCoachTab = function(){
				$ionicTabsDelegate.showBar(true);
				vm.outsideTab=false;
				$ionicScrollDelegate.resize();	  
			   }
		vm.showInput=false;
		$timeout(function() {
          console.log('mandatory');
		}, 10);
		vm.openInput = function(){
				   $timeout(function(){
                       console.log('showKeyboard');
                      vm.showInput = true;
                      vm.msgName=true;
				   },1);
				   if(ionic.Platform.isAndroid()){
			         vm.showInput = true;
				   }
				   	$ionicScrollDelegate.resize();
			   }			    
		vm.openQues = function(){
			        window.localStorage.setItem("returnUser","Y");
					vm.msgName=true;
				    vm.showInput = false;
					vm.skipName=true;
				    vm.messages.push(vm.chats[0].Answer);
					 $timeout(function(){
					    document.getElementById('dummyDiv').style.height= 38 + "vh";
						$ionicScrollDelegate.scrollBottom(true);
						$ionicScrollDelegate.resize();
					 },5);
							    
			   }
		vm.gotQuestion =function(ans){
                   $state.go('askQuestion',{ans:ans});
			   }
		vm.goTotAndC = function(){
			      $state.go('tAndC',{cameFrom:"digitalCoach"});
		}
		vm.goToHowTo = function(){
			      $state.go('dcHowTo');
		} 
		}
				
})();
(function() {
	'use strict';
	
	 angular
      .module('app.controllers')
      .controller('enterPin', enterPin);

	   enterPin.$inject = ['$scope', '$state', '$window', '$timeout','$cordovaKeyboard'];
	   
	   function enterPin($scope, $state, $window, $timeout,$cordovaKeyboard) {
	   	var vm = this;
			
		vm.enterEmail = true;
		vm.userEmail = '';  
		$scope.$on('$ionicView.beforeEnter', function (event, viewData) {
			vm.userEmail = null;  
	   	vm.enterEmail = true;
	   	vm.reEnterPin = false;
	   	vm.wrongPin = false;
	   	vm.pinSaved = true;
	   	vm.pins = [0,1,2,3];
	   	vm.finalPin = '';
	   	vm.password = '';
		vm.pinDotVisible = {};
		vm.validate_email = false;
		});
	 
	   	var getData="", storedData="";

		vm.keyboardSettings = {
		showLetters: true,
		//theme: 'dark',
		
		action: function(number) {
			if (vm.password.length < 4)
			{
				vm.password += number;
				vm.pinDotVisible[vm.password.length] = true;
				vm.wrongPin = null;
			}
			$timeout(function(){
			if(vm.password.length == 4)
			{
				if(!(vm.reEnterPin || vm.enterEmail))
				{
					
						vm.reEnterPin =true;

					vm.finalPin = vm.password;
					vm.password = '';
					vm.pinDotVisible = {};
					console.log(vm.finalPin);
				}
				else if(vm.reEnterPin && vm.pinSaved)
				{
					if(vm.password == vm.finalPin)
					{
						vm.pinSaved = false;	       					
	        			localStorage.setItem("pinValues", JSON.stringify(vm.finalPin));
	        			getData = localStorage.getItem('pinValues');
	        			storedData = JSON.parse(getData);
	        			console.log(storedData);
					}
					else
					{
						vm.wrongPin = true;
						vm.password = '';
						vm.pinDotVisible = {};
					}
				}
			}},500);
		},
		//no button
		leftButton: {
			html: '',
			action: function() {},
			style: {
				color: '#fff',
				bgColor: '#ddd',
				activeBgColor: 'rgba(0, 0, 0, 0.50)',
				borderColor: 'transparent'
			}
		},

		// Backspace key
		rightButton: {
			html: '<i class="icon ion-backspace"></i>',
			action: function() 
			{
					vm.password = '';
					vm.pinDotVisible = {};
			},
			style: 
			{
				color: '#555',
				bgColor: '#ddd',
				activeBgColor: 'rgba(0, 0, 0, 0.50)',
				borderColor: 'transparent'
			}
		}
	}


	   
	   	//vm.focused = 0;
	   
	   	vm.showEnterEmail = function(){

	   		if(localStorage.getItem('pinValues') == null)
	   		{
	   			return true;
	   		}
	   		else
	   		{
	   			//console.log("showEnterEmail");
	   			vm.enterEmail = false;
	   			// vm.focused = 0;
	   			return false;
	   		}
	   	}

	   	vm.goBack =  function(){
	   		 console.log("pi verified");
	   		// console.log("showEnterEmail"+vm.enterEmail);
      //      console.log(vm.reEnterPin || vm.enterEmail)
      		if(vm.showEnterEmail() && vm.enterEmail){
      			$state.go('tab.settings');
      		}
	   		else if(localStorage.getItem('pinValues') == null)
	   		{
	   			localStorage.setItem("userMail","");
	   			// $state.go('enterPin');
	   			vm.password = '';
				//vm.focused = 0;
	   			vm.reEnterPin = false;
	   			vm.enterEmail = true;
	   			vm.showEnterEmail();	
	   		}
	   		else
           		window.history.back();
        } 
        vm.validateEmail = function(emailForm){
			 vm.validate_email = emailForm.userEmail.$error.email;
		}
	
        vm.continue = function(emailForm,user) { 
			vm.validate_email = emailForm.userEmail.$error.email;
			if(vm.validate_email){
			  validate_email = false;
			}
        	//cordova.plugins.Keyboard.close();
		    localStorage.setItem("userMail", user);
		};

		vm.goToSettings = function(){
				vm.enterEmail = true;
	   			vm.reEnterPin = false;
	   			vm.wrongPin = false;
	   			vm.pinSaved = true;
	   			vm.password = '';
	   			vm.finalPin = '';
	   			vm.pinDotVisible = {};
				$state.go('tab.settings');
		}
	   	   
	}
}
)();
(function() {
	'use strict';
	
	 angular
      .module('app.controllers')
      .controller('erectionHS', erectionHS);
	   erectionHS.$inject = ['$scope', '$state', '$window'];
	   
	   function erectionHS($scope, $state, $window) {
	   	var vm = this;

	   	vm.goBack =  function(){
            window.history.back();
        }
	   }
	   
	}
)();
(function () {
    'use strict';
	  angular
      .module('app.controllers')
      .controller('home', home);
	   home.$inject = ['$scope', '$state'];
	   
	   function home($scope, $state) {
			var vm=this;
			vm.coverShow = false;
			vm.goTotAndC = function(){
				$state.go('tAndC',{"cameFrom":"home"});
			}
		 /* =================Slide  Changed ====================== */ 
		vm.slideHasChanged = function($index){
			if($index > 0)
				vm.coverShow = true;
			else
				vm.coverShow = false;
		}
	   }
})();
(function() {
	'use strict';
	
	 angular
      .module('app.controllers')
      .controller('myAppointments', myAppointments);
	   myAppointments.$inject = ['$scope', '$state', '$window','$ionicModal','$cordovaDialogs','$filter','AddReminders','$ionicListDelegate'];
	   
	   function myAppointments($scope, $state, $window,$ionicModal,$cordovaDialogs,$filter,AddReminders,$ionicListDelegate) {
	   	var vm = this;
           vm.showlist=true;
           vm.Appointments=[];
            $scope.$on('$ionicView.beforeEnter', function (event, viewData) {
            $ionicListDelegate.closeOptionButtons();
            AddReminders.getAppointments().then(
                    function(res){
                          if(viewData.stateParams.cameFrom=="editAppointment"){
                          vm.Appointments = AddReminders.getAppointmentsFromService();
                          vm.Appointments = res;
                          AddReminders.storeAppointmentsInService(vm.Appointments);
                          }
                          else{
                            console.log("else",AddReminders.getAppointmentsFromService());
                              for(var i = 0;i < res.length;i++){
                              vm.Appointments[i] =res[i];
                            }
                            AddReminders.storeAppointmentsInService(vm.Appointments);
                            console.log(vm.Appointments);
                           }
                          vm.showlist=true;                         
                          },
                        function(err){
                            vm.showlist=false;
                           $state.go('tab.profileMain');
                             vm.Appointments = [];
                        });
        
        });
	   	
		  vm.onItemDelete = function(item) {
        console.log("item",item)
                 $cordovaDialogs.confirm($filter('translate')('APPOINTMENT.DIALOGTEXT'), $filter('translate')('APPOINTMENT.DIALOGTITLE'), [$filter('translate')('QUESTFORDOCTOR.BUTTON1'),$filter('translate')('QUESTFORDOCTOR.BUTTON2')])
                .then(function(buttonIndex) {
                // no button = 0, 'OK' = 1, 'Cancel' = 2
                        if(buttonIndex==1){
                            AddReminders.deleteAppointment(item.appointment_name).then(
                                    function(res){                  
                                    },
                                    function(err){
                                      console.log(err);  
              });
                            vm.Appointments.splice(vm.Appointments.indexOf(item), 1);
                            console.log(vm.Appointments.length);
                            if(vm.Appointments.length==0){
                               vm.showlist=false;
                                $state.go('tab.profileMain');
                                  vm.Appointments = [];
                            }
                        }
                });
      };
      vm.goToEditAppointments = function(item){

      $state.go('editAppointment',{items:JSON.stringify(item)});
      vm.Appointments = [];
      }
      vm.goCreateAppointment=function(){
       
        $state.go('createAppointment');
          vm.Appointments = [];
      }
	   	vm.goBack =  function(){
           $state.go('tab.profileMain');
             vm.Appointments = [];
        }
		}
	   
	}
)();
(function() {
	'use strict';
	
	 angular
      .module('app.controllers')
      .controller('myEvents', myEvents);
	   myEvents.$inject = ['$scope', '$state', '$window','AddReminders','$ionicModal','$cordovaDialogs','$filter','$ionicListDelegate'];
	   
	   function myEvents($scope, $state, $window,AddReminders,$ionicModal,$cordovaDialogs,$filter,$ionicListDelegate) {
	     var vm = this;
           vm.showlist=true;
             vm.Events=[];
     $scope.$on('$ionicView.beforeEnter', function (event, viewData) {
            $ionicListDelegate.closeOptionButtons();
            AddReminders.getEvents().then(
                    function(res){
                          if(viewData.stateParams.cameFrom=="editEvent"){
                          vm.Events = AddReminders.getEventsFromService();
                          vm.Events = res;
                          AddReminders.storeEventsInService(vm.Events);
                          }
                          else{
                            console.log("else",AddReminders.getEventsFromService());
                             for(var i=0;i<res.length;i++){
                              vm.Events[i] =res[i];
                            }
                            AddReminders.storeEventsInService(vm.Events);
                            console.log(vm.Events);
                           }
                          vm.showlist=true;                         
                          },
                        function(err){
                            vm.showlist=false;
                             $state.go('tab.profileMain');
                             vm.Events = [];
                        });
        
        });
	   	
		  vm.onItemDelete = function(item) {
        console.log("item",item)
                 $cordovaDialogs.confirm($filter('translate')('EVENT.DIALOGTEXT'), $filter('translate')('EVENT.DIALOGTITLE'), [$filter('translate')('QUESTFORDOCTOR.BUTTON1'),$filter('translate')('QUESTFORDOCTOR.BUTTON2')])
                .then(function(buttonIndex) {
                // no button = 0, 'OK' = 1, 'Cancel' = 2
                        if(buttonIndex==1){
                            AddReminders.deleteEvent(item.event_name).then(
                                    function(res){                  
                                    },
                                    function(err){
                                      console.log(err);  
              });
                            vm.Events.splice(vm.Events.indexOf(item), 1);
                            console.log(vm.Events.length);
                            if(vm.Events.length==0){
                               vm.showlist=false;
                                $state.go('tab.profileMain');
                                vm.Events = [];
                            }
                        }
                });
      };
      vm.goToEditEvent = function(item){

         $state.go('editEvent',{items:JSON.stringify(item)});
         vm.Events = [];
      }
      vm.goToCreateEvent = function(){
         $state.go('createEvent');
         vm.Events = [];
      }	
	   	vm.goBack =  function(){
            $state.go('tab.profileMain');
            vm.Events = [];
        }
	   }
	   
	}
)();
(function() {
	'use strict';
	
	 angular
      .module('app.controllers')
      .controller('myMeds', myMeds);
	   myMeds.$inject = ['$scope', '$state', '$window','AddMedications','$ionicModal','$cordovaDialogs','$filter','$ionicScrollDelegate','$ionicListDelegate'];
	   
	   function myMeds($scope, $state, $window,AddMedications,$ionicModal,$cordovaDialogs,$filter,$ionicScrollDelegate,$ionicListDelegate) {
	   	var vm = this;
        vm.showlist = true;
        vm.Medicines = [];	   	
        vm.onItemDelete = function(item) {
                 $cordovaDialogs.confirm($filter('translate')('MYMEDS.DIALOGTEXT'), $filter('translate')('MYMEDS.DIALOGTITLE'), [$filter('translate')('QUESTFORDOCTOR.BUTTON1'),$filter('translate')('QUESTFORDOCTOR.BUTTON2')])
                .then(function(buttonIndex) {
                // no button = 0, 'OK' = 1, 'Cancel' = 2
                        if(buttonIndex == 1){
                            AddMedications.deleteMedicine(item.medication_name).then(
                                function(res){                  
                                },
                                function(err){
                                    console.log(err);  
                                });
                            vm.Medicines.splice(vm.Medicines.indexOf(item), 1);
                            if(vm.Medicines.length == 0){
                               vm.showlist=false;
                            }
                        }
                });
  		};
  		var getMedicine = function(){ 
            $ionicScrollDelegate.scrollTop();
            AddMedications.getMedications().then(
            function(res){
                 for(var i = vm.Medicines.length;i<res.length;i++){               
                    vm.Medicines[i] = res[i]
                    }
                vm.showlist = true;                   
            },
            function(err){
                vm.showlist = false;
                console.log(err);  
            });
		  }
        $scope.$on('$ionicView.beforeEnter', function (event, viewData) {
              //$state.go($state.current, {}, {reload: true}); 
                $ionicListDelegate.closeOptionButtons();
		        getMedicine();

        });
	   	vm.goBack =  function(){
            window.history.back();
        }
         /* =================Close Medication Modal====================== */ 
		vm.closeModal = function(modalType){
                     vm.medication_err = 0;
                    vm.medication_input = '';
                     $scope.addMedication.hide();
                
            }   
            /* =================Open Medication Modal====================== */
		 $ionicModal.fromTemplateUrl('templates/addMedication.html', {
                scope: $scope,
                animation: 'slide-in-up'
            }).then(function(modal) {
                $scope.addMedication = modal;
            });	
        vm.addMed = function(){
			vm.medication_input = '';
              $scope.addMedication.show();
		}

        vm.getDateFormatted = function(date){
			return moment(date).format("M/DD/YYYY");
		}
        
		 vm.textUpdate = function(){
               vm.medication_err = false;
            }      
            vm.saveMedication = function(){
              if(vm.medication_input != ""){
                var medicationData = vm.medication_input;
                 AddMedications.setMedications(medicationData).then(function(res){
                        $scope.addMedication.hide();
                 },function(err){
                        vm.medication_err = 1;
                    }); 
				   getMedicine();
                }
            }

	   }
	   
	}
)();
(function() {
	'use strict';
	
	 angular
      .module('app.controllers')
      .controller('myQuestions', myQuestions);
	   myQuestions.$inject = ['$scope', '$state', '$window','AddMedications','$filter','$cordovaDialogs','$ionicLoading','$timeout','$ionicHistory','$stateParams','$ionicScrollDelegate','$ionicListDelegate'];
	   
	   function myQuestions($scope, $state, $window, AddMedications, $filter, $cordovaDialogs, $ionicLoading, $timeout,$ionicHistory,$stateParams,$ionicScrollDelegate,$ionicListDelegate) {
			var vm = this;
			vm.showlist = false;
			vm.items = [];
			var  temp = [];
			var camefrom = "";			
	   	$scope.$on('$ionicView.beforeEnter', function (event, viewData) {
			   $ionicListDelegate.closeOptionButtons();
			     $ionicLoading.show({
						template: 'Loading...',
						duration: 2000
						}).then(function(){
						console.log("The loading indicator is now displayed");
						});
				
               AddMedications.getQuestions().then(
                    function(res){
						$ionicScrollDelegate.scrollTop();
						vm.showlist = true;  
						console.log(viewData.stateParams.camefrom);
						if(viewData.stateParams.camefrom=="showQueCancel"){
							vm.items = AddMedications.getItemsFromService();
							vm.items =res;
							AddMedications.storeItemsInService(vm.items);
					   }
					   else if(viewData.stateParams.camefrom=="showQueSave"){
					   	    for(var i = 0;i<res.length;i++){
								vm.items[i] =res[i];
							}
							AddMedications.storeItemsInService(vm.items);
					   }
					   else{
						   for(var i = 0;i<res.length;i++){
								vm.items[i] =res[i];
							}
							AddMedications.storeItemsInService(vm.items);
							 if(viewData.stateParams.camefrom == "profileMain"){
								AddMedications.setCamefrom("profileMain");
							} 
							else{
								AddMedications.setCamefrom("successAsk");
							}							
					   }
						 $ionicLoading.hide().then(function(){
                           
                            });                     
                    },
                    function(err){
						 $ionicLoading.hide().then(function(){
                            });   
						 if(viewData.stateParams.camefrom == "profileMain"){
								AddMedications.setCamefrom("profileMain");
							} 
							else{
								AddMedications.setCamefrom("successAsk");
							}
                        console.log(err); 
						vm.showlist=false; 
                    });               
        });
		/* ================= Delete Question event===================== */
  		 vm.onItemDelete = function(item) {				
				 $cordovaDialogs.confirm($filter('translate')('QUESTFORDOCTOR.DIALOGTEXT'), $filter('translate')('QUESTFORDOCTOR.DIALOGTITLE'), [$filter('translate')('QUESTFORDOCTOR.BUTTON1'),$filter('translate')('QUESTFORDOCTOR.BUTTON2')])
                .then(function(buttonIndex) {
                // no button = 0, 'OK' = 1, 'Cancel' = 2
                        if(buttonIndex == 1){
                            AddMedications.deleteQuestion(item.question_text,item.faq_answer).then(
						    function(res){                  
							},
							function(err){
								console.log(err);  
							});
                            vm.items.splice(vm.items.indexOf(item), 1);
							  if(vm.items.length == 0){
							  	$timeout(function() {
							  		vm.showlist = false;
							  	}, 100);
                               
                            }
                        }
                });
  		};
        vm.itemClicked = function(item,index){
			vm.items =[];
			if(item.faq_answer == null){
				item.faq_answer = "";
			}
			$state.go('showQuestion',{items:JSON.stringify(item)});
		}  	
	   	vm.goBack =  function(){
			   if($stateParams.camefrom == "profileMain" || $stateParams.camefrom == "successAsk"){
                   window.history.back();
                   vm.items = [];
			   }
			   else{				  
				   if(AddMedications.getCamefrom() == "profileMain"){
					   $state.go('tab.profileMain');
					   vm.items = [];
				   } 
				   else{
					   $state.go('successAsk');
					    vm.items = [];
				   }
			   }           
        }
		vm.addQue = function(){
			$state.go('askQuestion');
			vm.items =[];
		}
		vm.getDateFormatted = function(date){
			return moment(date).format("M/DD/YYYY");
		}		 
	   }	   
	}
)();
(function() {
	'use strict';
	
	 angular
      .module('app.controllers')
      .controller('myReminders', myReminders);
      

	   myReminders.$inject = ['$scope', '$state', '$window','AddReminders','$ionicModal','$cordovaDialogs','$filter','$ionicHistory','$ionicListDelegate'];
	   
	   function myReminders($scope, $state, $window,AddReminders,$ionicModal,$cordovaDialogs,$filter,$ionicHistory,$ionicListDelegate) {
	   	var vm = this;
           vm.showlist=true;
             vm.Reminders=[];
     $scope.$on('$ionicView.beforeEnter', function (event, viewData) {
            $ionicListDelegate.closeOptionButtons();
            AddReminders.getReminders().then(
                    function(res){
                          if(viewData.stateParams.cameFrom=="editReminder"){
                          vm.Reminders = AddReminders.getItemsFromService();
                          vm.Reminders = res;
                          AddReminders.storeItemsInService(vm.Reminders);
                          }
                          else{
                            console.log("else",AddReminders.getItemsFromService());
                            for(var i = 0;i<res.length;i++){
                              vm.Reminders[i] =res[i];
                            }
                            AddReminders.storeItemsInService(vm.Reminders);
                            console.log(vm.Reminders);
                           }
                          vm.showlist=true;                         
                          },
                        function(err){
                            vm.showlist=false;
                             $state.go('tab.profileMain');
                             vm.Reminders = [];
                        });
        
        });
	   
		  vm.onItemDelete = function(item) {
        console.log("item",item)
                 $cordovaDialogs.confirm($filter('translate')('SETREMINDER.DIALOGTEXT'), $filter('translate')('SETREMINDER.DIALOGTITLE'), [$filter('translate')('QUESTFORDOCTOR.BUTTON1'),$filter('translate')('QUESTFORDOCTOR.BUTTON2')])
                .then(function(buttonIndex) {
                // no button = 0, 'OK' = 1, 'Cancel' = 2
                        if(buttonIndex==1){
                            AddReminders.deleteReminder(item.reminder_name,item.recorded_date).then(
                                    function(res){                  
                                    },
                                    function(err){
                                      console.log(err);  
							});
                            vm.Reminders.splice(vm.Reminders.indexOf(item), 1);
                            console.log(vm.Reminders.length);
                            if(vm.Reminders.length==0){
                              vm.showlist=false;
                               $state.go('tab.profileMain');
                               vm.Reminders = [];
                            }
                        }
                });
  		};
      vm.gotToEditReminder=function(item){
        $state.go('editReminder',{items:JSON.stringify(item)});
        vm.Reminders = [];

      }
      vm.goToSetReminder=function(){
     
          $state.go('setReminder');
          vm.Reminders = [];
      }
  				
	   	vm.goBack =  function(){
             $state.go('tab.profileMain');
             vm.Reminders = [];
        }
            
	   }
	   
	}
)();
(function () {
    'use strict';

    angular
      .module('app.controllers')
      .controller('PageCtrl', PageCtrl);

    PageCtrl.$inject = ['$scope', '$state','$ionicHistory'];

    /* @ngInject */
    function PageCtrl($scope, $state, $ionicHistory) {
        var vm = this;
        vm.title = 'PageCtrl';
        vm.pageTitle = "";
        vm.isAskOuestion="false";
        vm.isTAndC="false";

        function activate() {
            
        }

        vm.goHome = function() {
            console.log("xdvc")
            window.history.back();
        }

        vm.goComparision = function() {
            $state.go('comparision');
        }

        $scope.$on('pageChange', function(e, data) {
            vm.pageTitle = data.title;
            vm.leftButton = data.leftButton;
            vm.rightButton= data.rightButton;
        })
    }

})();


(function() {
	'use strict';
	
	 angular
      .module('app.controllers')
      .controller('profileMain', profileMain);
	   profileMain.$inject = ['$scope', '$state','AddReminders','$filter','$ionicPlatform'];
	   
	   function profileMain($scope, $state,AddReminders, $filter,$ionicPlatform) {
	   	var vm = this;
		vm.upcommingEvents=[];
		vm.upcommingAppointments=[];
	   	vm.selectedTab = "Event";
		vm.showEvent = true;
   
     $ionicPlatform.ready(function() {
                document.addEventListener("resume", function() {
                   setUpcomingText();
                })
              });
     var setUpcomingText = function(){
       AddReminders.getEvents().then(
                    function(res){
                         
                          for(var i = 0;i<res.length;i++){
                             res[i].recorded_date=moment(res[i].recorded_date).toISOString();
                          }
                           res = $filter('orderBy')(res,'recorded_date',false);
                            // finalArray=sortedArray;
                           var currentEvent=0;
                           for(var i = 0;i<res.length;i++){
                            var currentTime=new Date().toISOString();
                             if(moment(res[i].recorded_date).isBefore(moment(currentTime))){
                               console.log("in");
                                 currentEvent=i+1;
                             }
                             res[i].recorded_date=moment(res[i].recorded_date).format("dddd, MMMM Do hh:mm a");
                          }
                          //Current Event
                          console.log('currentTime',currentTime);
                          console.log(res);  
                            vm.upcommingEvents=res[currentEvent];
                            
                            console.log('upcommingEvents',vm.upcommingEvents);
                       //    vm.upcommingEvents =$filter('translate')('PROFILE.EVENTS_SUCCESS')+"<br>"+res[0].event_name +"<br>"+ res[0].recorded_date;
                          },
                        function(err){
                            vm.upcommingEvents=undefined;
                          // vm.upcommingEvents = $filter('translate')('PROFILE.NO_PLANS_TEXT1')+"<br>"+$filter('translate')('PROFILE.NO_PLANS_TEXT2');
                          //  console.log(err); 
                        });

             AddReminders.getAppointments().then(
                    function(res){
                           for(var i = 0;i<res.length;i++){
                             res[i].recorded_date=moment(res[i].recorded_date).toISOString();
                          }
                           res = $filter('orderBy')(res,'recorded_date',false);
                            // finalArray=sortedArray;
                              var currentEvent=0;
                           for(var i = 0;i<res.length;i++){
                             var currentTime=new Date().toISOString();
                             if(moment(res[i].recorded_date).isBefore(moment(currentTime))){
                               console.log("in");
                                 currentEvent=i+1;
                             }
                             res[i].recorded_date=moment(res[i].recorded_date).format("dddd, MMMM Do hh:mm a")
                          }
                           vm.upcommingAppointments=res[currentEvent];
                          //  vm.upcommingAppointments =$filter('translate')('PROFILE.APPOINTMENTS_SUCCESS')+"<br>"+res[0].appointment_name +"<br>"+ res[0].recorded_date;
                          //  console.log(res[0]);                       
                          },
                        function(err){
                            vm.upcommingAppointments=undefined;
                          // vm.upcommingAppointments = $filter('translate')('PROFILE.NO_APP_PLANS_TEXT1')+"<br>"+$filter('translate')('PROFILE.NO_APP_PLANS_TEXT2');
                          //  console.log(err); 
                        });
     }

	$scope.$on('$ionicView.beforeEnter', function (event, viewData) {
              setUpcomingText();
               $ionicPlatform.ready(function() {
                   screen.lockOrientation('portrait')
                }); 
      });
	   	vm.goTotAndC = function(){
			      $state.go('tAndC',{cameFrom:"profileMain"});
		}
		vm.goToHowTo = function(){
			      $state.go('dcHowTo');
		}
		vm.isSelected = function(selectedTab){
			vm.selectedTab = selectedTab;
			vm.showEvent = selectedTab;
		}
		vm.goToMyMeds = function(){
			$state.go('myMeds');
		}
		vm.goToEHS = function(){
					$state.go('erectionHS');
		}
		vm.goToMyQuestions = function(){
					 $state.go('myQuestions',{camefrom:"profileMain"});
		}

		vm.goToVerifyPin = function(){
			 $state.go('sendEmail');
		}
       
	      vm.goToSetReminder = function(){
           AddReminders.getLengthOfRemindres().then(
                    function(res){
                        	$state.go('myReminders');
                    },
                      function(err){
						            console.log(err)
                         $state.go('setReminder');
                    });
		}
		vm.goToCreateEvent = function(){
				  AddReminders.getLengthOfEvents().then(
                    function(res){
                        	$state.go('myEvents');
                    },
                      function(err){
						             $state.go('createEvent');
                    });
		}
		 vm.goToCreateAppointment = function(){
				   AddReminders.getLengthOfAppointments().then(
                    function(res){
                        	$state.go('myAppointments');
                    },
                      function(err){
                          $state.go('createAppointment');
                    });
		}
	   }
	   
	}
)();
(function() {
	'use strict';
	
	 angular
      .module('app.controllers')
      .controller('setReminder', setReminder);
	   setReminder.$inject = ['$scope', '$state','$stateParams','ionicTimePicker','ionicDatePicker','$location','AddReminders','$cordovaDialogs','$filter'];
	   
	   function setReminder($scope, $state,$stateParams,ionicTimePicker,ionicDatePicker,$location,AddReminders,$cordovaDialogs,$filter) {
              
             var vm=this; 
             var reminderObj = {};
             vm.oldReminderText=null;
             vm.oldRecordedDate=null;
              vm.oldDate=null;
              vm.oldTime=null;
             var path = $location.path();
              console.log("path",path);
             if(path=='/editReminder'){
              vm.editScreen=true;
              $scope.$on('$ionicView.beforeEnter', function (event, viewData) {
                
                 reminderObj = {};
                 reminderObj = JSON.parse(viewData.stateParams.items);
                 console.log("reminder",reminderObj);
                vm.oldReminderText=vm.reminderText=reminderObj.reminder_name;
                vm.oldRecordedDate=reminderObj.recorded_date;
                vm.oldDate = vm.set_date_edit=moment(reminderObj.recorded_date).format("dddd, MMMM Do");
              vm.oldTime = vm.record_time_edit=moment(reminderObj.recorded_date).format("hh:mm A");
          
            });
             } else{
              console.log("insetReminder");
              vm.reminderText="";
               vm.set_date_edit="";
               vm.record_time_edit="";
              vm.editScreen=false;
             }
		     $scope.$emit('pageChange', {
              title: 'Set Reminder',
              leftButton:'Cancel',
              rightButton:'Save'
            })
       
            vm.saveReminder = function(){
               if(vm.reminderText != "" && vm.set_date_edit !="" && vm.record_time_edit !=""){
                var reminderData = vm.reminderText;
                var reminderDate= vm.set_date_edit;
                var reminderTime = vm.record_time_edit;
                var reminderDate=moment(vm.set_date_edit+' '+vm.record_time_edit,"dddd, MMMM Do hh:mm a").toISOString();
               
                 AddReminders.setReminders(reminderData,reminderDate).then(
                    function(res){
                        console.log(res);
                        vm.reminderText=null;
                         vm.set_date_edit=null;
                         vm.record_time_edit=null;
                        $state.go("myReminders");            
                    },
                    function(err){
                 $cordovaDialogs.alert($filter('translate')('SETREMINDER.ERRORTEXT'),[$filter('translate')('QUESTFORDOCTOR.BUTTON1')])
                 .then(function(buttonIndex) {
                       
                    });                 
                    });
                }              
            }
            vm.updateReminder = function(){
             var reminderData = vm.reminderText;
             var reminderDate=moment(vm.set_date_edit+' '+vm.record_time_edit,"dddd, MMMM Do hh:mm a").toISOString();
                console.log("oldReminderText",vm.oldReminderText,"oldRecordedDate",vm.oldRecordedDate);
               AddReminders.updateReminders(vm.oldReminderText,vm.oldRecordedDate,reminderData,reminderDate).then(
                    function(res){
                        console.log(res); 
                        // $state.go("myReminders");
                         $state.go('myReminders', {cameFrom:"editReminder"});       
                    },
                    function(err){

                        console.log(err);  
                    });
            }
            vm.goToReminders = function(){
                vm.reminderText=null;
                vm.set_date_edit=null;
                vm.record_time_edit=null;
              $state.go('tab.profileMain');
               }
            vm.goBack = function(){
                vm.reminderText=null;
                vm.set_date_edit=null;
                vm.record_time_edit=null;
               $state.go('myReminders', {cameFrom:"editReminder"});   
            }
          
            vm.deleteReminder=function(){
                 $cordovaDialogs.confirm($filter('translate')('SETREMINDER.DIALOGTEXT'), $filter('translate')('SETREMINDER.DIALOGTITLE'), [$filter('translate')('QUESTFORDOCTOR.BUTTON1'),$filter('translate')('QUESTFORDOCTOR.BUTTON2')])
                .then(function(buttonIndex) {
                // no button = 0, 'OK' = 1, 'Cancel' = 2
                        if(buttonIndex==1){
                            AddReminders.deleteReminder(vm.oldReminderText,vm.oldRecordedDate).then(
                                    function(res){    
                                    $state.go('myReminders', {cameFrom:"editReminder"});                 
                                    },
                                    function(err){
                                      console.log(err);  
                          });
                            // vm.Reminders.splice(vm.Reminders.indexOf(item), 1);
                            // console.log(vm.Reminders.length);
                            // if(vm.Reminders.length==0){
                            //    vm.showlist=false;
                            // }
                        }
                });

            }
            vm.dateCheck=function(date){
                  var date = new Date(date);
                  var  year = date.getFullYear();
                  var  month = date.getMonth()+1;
                  var  dt = date.getDate();

                    if (dt < 10) {
                    dt = '0' + dt;
                    }
                    if (month < 10) {
                    month = '0' + month;
                    }
                    return year+'-' + month + '-'+dt;        
            }
             vm.TimeCheck=function(time){
                 var selectedTime = new Date(time * 1000);
                // console.log('Selected epoch is : ', val, 'and the time is ', selectedTime.getUTCHours(), 'H :', selectedTime.getUTCMinutes(), 'M');
                  var ampm = selectedTime.getUTCHours() >= 12 ? 'PM' : 'AM';
                 var hours = selectedTime.getUTCHours() % 12;
                             hours = hours ? hours : 12;
                 var minutes = selectedTime.getUTCMinutes();
                    if (minutes< 10) {
                          minutes = "0" + minutes;
                        }     
                return hours+ ':'+minutes+' '+ ampm;
            }

            vm.selectDate =function(){
             var ipObj1 = {
              callback: function (val) {  //Mandatory
                console.log('Return value from the datepicker popup is : ' + val);              
                vm.set_date_edit=moment(val).format("dddd, MMMM Do");
                if(vm.record_time_edit){
                    var datechek=vm.dateCheck(new Date(val).toISOString());
                      var d = new Date().toISOString();
                      var currentDate=vm.dateCheck(d);
                      if(datechek==currentDate){
                       var display_time = (((new Date()).getHours() * 60 * 60) + ((new Date()).getMinutes() * 60));  
                        var checkTime=vm.TimeCheck(display_time);
                        console.log("checkTime",checkTime);
                        var beginningTime = moment(vm.record_time_edit ,'h:mma');
                         var endTime = moment(checkTime, 'h:mma');
                         console.log("beginningTime",beginningTime);
                         console.log("endTime",endTime); 
                         if(beginningTime.isBefore(endTime)){
                         vm.set_date_edit='';
                        //  vm.record_time_edit='';
                         $cordovaDialogs.alert($filter('translate')('EVENT.PAST_TIME'),[$filter('translate')('QUESTFORDOCTOR.BUTTON1')])
                         .then(function(buttonIndex) {
                                        
                         });

                         }    
                      }
                }
              },
              from: new Date(), //Optional
            //  to: new Date(2016, 10, 30), //Optional
              inputDate: new Date(),      //Optional
              mondayFirst: true,          //Optional
              closeOnSelect: false,       //Optional
              templateType: 'popup',      //Optional
              dateFormat: 'dd MMMM yyyy',
            };
              ionicDatePicker.openDatePicker(ipObj1);
            }
           vm.openTimer= function(isEdit,time_edit){
        
               if(vm.set_date_edit){
                   var a=moment(vm.set_date_edit,"dddd, MMMM Do").toISOString();
                   var d = new Date().toISOString();
                var selected_date = vm.dateCheck(a);
                var current_Date = vm.dateCheck(d); 
                console.log("selected_date",selected_date);
                console.log("current_Date",current_Date);
                if(selected_date==current_Date){
                  vm.avoidPastTime=true;
                }else{
                     vm.avoidPastTime=false;
                }
            
               }
              if(time_edit){
                var momentObj = moment(time_edit, ["h:mm A"]).format("HH:mm");
                var display_time = moment.duration(momentObj).asSeconds()
              }else{
                var display_time = (((new Date()).getHours() * 60 * 60) + ((new Date()).getMinutes() * 60));
              }

              console.log("open Timmer")
            var ipObj = {
                            callback: function (val) {  //Mandatory
                             
                            if (typeof (val) === 'undefined') {
                                 console.log('Time not selected');
                            } else {
                            var selectedTime = new Date(val * 1000);
                               // console.log('Selected epoch is : ', val, 'and the time is ', selectedTime.getUTCHours(), 'H :', selectedTime.getUTCMinutes(), 'M');
                                var ampm = selectedTime.getUTCHours() >= 12 ? 'PM' : 'AM';
                                var hours = selectedTime.getUTCHours() % 12;
                                    hours = hours ? hours : 12;
                                var minutes = selectedTime.getUTCMinutes();
                                if (minutes< 10) {
                                    minutes = "0" + minutes;
                                }    
                     
                                if(isEdit){
                                    vm.record_time_edit = hours+ ':'+minutes+' '+ ampm;
                                    console.log('vm.record_time_edit',vm.record_time_edit);
                                    if( vm.avoidPastTime==true){
                                       var display_time = (((new Date()).getHours() * 60 * 60) + ((new Date()).getMinutes() * 60));  
                                       var checkTime=vm.TimeCheck(display_time);
                                       console.log("checkTime",checkTime);
                                       var beginningTime = moment(vm.record_time_edit ,'h:mma');
                                        var endTime = moment(checkTime, 'h:mma');
                                        console.log("beginningTime",beginningTime);
                                           console.log("endTime",endTime);
                                       
                                        if(beginningTime.isBefore(endTime)){
                                          vm.record_time_edit='';
                                          $cordovaDialogs.alert($filter('translate')('EVENT.PAST_TIME'),[$filter('translate')('QUESTFORDOCTOR.BUTTON1')])
                                          .then(function(buttonIndex) {
                                        
                                           });

                                        }
                                    }
                                }else{
                                      
                                    vm.record_time = hours+ ':'+minutes+' '+ ampm;
                                }
                         vm.chooseTime = true;
                            }
                            },
                            inputTime: display_time, 
                            format: 12,        
                            step: 1,          
                            setLabel: 'Set'
                  };

                ionicTimePicker.openTimePicker(ipObj);
            }
		}
				
})();
(function() {
	'use strict';
	
	 angular
      .module('app.controllers')
      .controller('settings', settings);
	   settings.$inject = ['$scope', '$state','$ionicPlatform'];
	   
	   function settings($scope, $state,$ionicPlatform) {
	   	var vm = this;  
	   	$scope.$on('$ionicView.beforeEnter', function (event, viewData) {
           $ionicPlatform.ready(function() {
                   screen.lockOrientation('portrait')
                }); 
        });
	   	
		vm.goToAppHowTo = function(){
			$state.go("appHowTo");
		}
		vm.goToEnterPin = function(){
			$state.go("enterPin");
		}		
		vm.goTotAndC= function(){
			$state.go('tAndC');
		}
	   }
	   
	}
)();
(function() {
	'use strict';
	
	 angular
      .module('app.controllers')
      .controller('showQuestion', showQuestion);
	   showQuestion.$inject = ['$scope', '$state','$stateParams','AddMedications','$filter'];
	   
	   function showQuestion($scope, $state,$stateParams,AddMedications,$filter) {
              
             var vm=this;
             vm.saveText = $filter('translate')('QUESTFORDOCTOR.BUTTON3');
             vm.imgsrc = [
               "img/graph/grade_btn@2x.png",
               "img/graph/exercise_btn@2x.png",
               "img/graph/smoke_btn@2x.png",
               "img/graph/drink_btn@2x.png",
               "img/graph/weight_btn@2x.png",
               "img/graph/stress_btn@2x.png",
               "img/graph/meds_btn@2x.png"
             ]
            var queObj = {};
             	$scope.$on('$ionicView.beforeEnter', function (event, viewData) {
                queObj = {};
                queObj = JSON.parse(viewData.stateParams.items);
                vm.nonEditableQue=true; 
                vm.que_index =queObj.index;
                vm.ansOfQues=queObj.faq_answer;
                vm.questionText = queObj.question_text;
                vm.imageIndex = queObj.graphIndex;
                if(vm.imageIndex<8){
                    vm.graphQue=true;
                }
                else
                  vm.graphQue=false;
            });
           vm.editQuestion = function(){
               vm.nonEditableQue = false;
           }
             vm.goBack = function(){
              $state.go('myQuestions',{camefrom:"showQueCancel"});
            }
            vm.saveQuestion = function(){
              if(vm.nonEditableQue  == true){
                vm.saveText = $filter('translate')('QUESTFORDOCTOR.BUTTON4');
                vm.nonEditableQue = false;
                return;
              }
                 AddMedications.updateQuestions(queObj.question_text,vm.questionText,vm.ansOfQues);
                 $state.go('myQuestions',{camefrom:"showQueSave"});
            }
           
		}
				
})();
(function() {
	'use strict';
	
	 angular
      .module('app.controllers')
      .controller('successAsk', successAsk);
	   successAsk.$inject = ['$scope', '$state','$stateParams'];
	   /* =================Succsess and redirect to Digital Coach====================== */
	   function successAsk($scope, $state) {
              var vm = this;
            vm.backToDigital = function(){
                $state.go('tab.digitalCoach');
            }
            vm.goToQuestion = function(){
            	 $state.go('myQuestions',{camefrom:"successAsk"});
            }
		}
				
})();
(function () {
    'use strict';
	  angular
      .module('app.controllers')
      .controller('tab', tab);
	   tab.$inject = ['$scope', '$state','$ionicModal','$ionicPlatform','$timeout','SendEHSPin','$cordovaNetwork','$cordovaDialogs','$filter','$ionicLoading','$ionicScrollDelegate'];
	   
	   function tab($scope, $state,$ionicModal,$ionicPlatform,$timeout,SendEHSPin,$cordovaNetwork,$cordovaDialogs,$filter,$ionicLoading,$ionicScrollDelegate) {
          var vm = this;
          vm.isModalShown;
          
          $ionicModal.fromTemplateUrl('templates/verifyPin.html', {
                scope: $scope,
                animation: 'slide-in-up'
            }).then(function(modal) {
                $scope.verifyPin = modal;
                 if(window.localStorage.getItem("pinValues") != null){
                         $scope.verifyPin.show();
                         vm.isModalShown=true;
                     }

                  SendEHSPin.verifyApp(window.localStorage.getItem("ehsInstDate"));
           });
        $ionicPlatform.ready(function() {
                document.addEventListener("pause", function() {
                    if(window.localStorage.getItem("pinValues") != null){
                    	    vm.showVerifyPin = true;
						   	vm.showSendMail = false;
						   	vm.wrongPin = false;
						   	vm.mailSent = false;
							vm.pins = [0,1,2,3];
							vm.verifyPassword ='';
							vm.verifyPinDotVisible = {};
							vm.storedPIN = JSON.parse(localStorage.getItem('pinValues'));
                            $scope.verifyPin.show();
                            $ionicScrollDelegate.scrollTop();
                            vm.isModalShown=true;
                    }
                     SendEHSPin.verifyApp(window.localStorage.getItem("ehsInstDate"));
                }, false);

                $ionicPlatform.registerBackButtonAction(function () {
			        console.log("$state.current.name",$state.current.name);
			      if (vm.isModalShown) {       
			        return;
			      } else {
			        window.history.back();
			      }
			      }, 1000);
               
        });
        $scope.$on('$ionicView.beforeEnter', function (event, viewData) {
        	 $ionicLoading.hide().then(function(){
                             console.log("The loading indicator is now hidden");
                         });
             
		    vm.showVerifyPin = true;
		   	vm.showSendMail = false;
		   	vm.wrongPin = false;
		   	vm.mailSent = false;
			vm.pins = [0,1,2,3];
			vm.verifyPassword ='';
			vm.verifyPinDotVisible = {};
			vm.storedPIN = JSON.parse(localStorage.getItem('pinValues'));
			
		});

        

        vm.keyboardSettings = {
		showLetters: true,
		//theme: 'dark',
		
		action: function(number) {
			if (vm.verifyPassword.length < 4)
			{
				vm.verifyPassword += number;
				vm.verifyPinDotVisible[vm.verifyPassword.length] = true;
				vm.wrongPin = null;
			}
			$timeout(function(){
			if(vm.verifyPassword.length == 4)
			{
				console.log("lenth 4");
					if(vm.verifyPassword == vm.storedPIN)
					{
						console.log("lenth hide"+vm.storedPIN);
						$scope.verifyPin.hide();
						vm.isModalShown=false;
					}
					else
					{
						console.log("lenth hide");
						vm.wrongPin = true;
						vm.verifyPassword = '';
						vm.verifyPinDotVisible = {};
					}
			}
			},500);
		},
		//no button
		leftButton: {
			html: '',
			action: function() {},
			style: {
				color: '#fff',
				bgColor: '#bbb',
				activeBgColor: 'rgba(0, 0, 0, 0.50)',
				borderColor: 'transparent'
			}
		},

		// Backspace key
		rightButton: {
			html: '<i class="icon ion-backspace"></i>',
			action: function() 
			{
					vm.verifyPassword = '';
					vm.verifyPinDotVisible = {};
			},
			style: 
			{
				color: '#555',
				bgColor: '#bbb',
				activeBgColor: 'rgba(0, 0, 0, 0.50)',
				borderColor: 'transparent'
			}
		}
	}

	   		vm.forgetPin = function(){
	   			vm.verifyPassword = '';
				vm.verifyPinDotVisible = {};
	   			vm.showSendMail = true;
	   			vm.showVerifyPin = false;
	   			vm.wrongPin = false;
	   		}

			vm.sendMail = function(){
				if($cordovaNetwork.isOnline()){
					vm.storedPIN = JSON.parse(localStorage.getItem('pinValues'));
                	console.log(vm.storedPIN);
					var userData = {
            			pin:vm.storedPIN,
            			email:window.localStorage.getItem('userMail')
          			}
          			SendEHSPin.sendPin(userData).then(function(res){
            			console.log(res);
          			},function(err){
            			console.log(err);
          			});
          			vm.showSendMail = false; 
          			vm.showVerifyPin = false;
          			vm.mailSent = true;
				}
				else {
				 $cordovaDialogs.alert($filter('translate')('VERIFYPIN.NETWORK_MSG'), $filter('translate')('VERIFYPIN.NETWORK_ERROR'), $filter('translate')('QUESTFORDOCTOR.BUTTON1'))
                .then(function() {
                        console.log("network error");
                        return;
                });
					return;
				}				
			}
	     }	   
})();
(function () {
    'use strict';
	  angular
      .module('app.controllers')
      .controller('tAndC', tAndC);
	   tAndC.$inject = ['$scope', '$state','$stateParams','$ionicPlatform','$timeout'];
	   
	   function tAndC($scope, $state,$stateParams,$ionicPlatform,$timeout) {
           $scope.$emit('pageChange', {
            title: 'Terms & Privacy'
        })
         var vm = this;
         $scope.$on('$ionicView.beforeEnter', function (event, viewData) {
           $ionicPlatform.ready(function() {
                   screen.lockOrientation('portrait')
                }); 
        });
        
         vm.termsSelected = true;
         vm.showFooter = true;
         if($stateParams.cameFrom!="home"){
             vm.showFooter = false;
         }
         vm.goToTerms = function() {
             vm.termsSelected = true;
             $timeout(function() {
              var slideHeight = document.getElementById('div_1').offsetHeight;
              document.getElementById('div_2').style.height = slideHeight;
             }, 10);
         }
          vm.goToPrivacy = function(){
             vm.termsSelected = false;
             $timeout(function() {
              var slideHeight = document.getElementById('div_2').offsetHeight;
              document.getElementById('div_1').style.height = slideHeight;
             }, 10);
         }
        vm.goToDigitalcoach = function(){
            $state.go('tab.digitalCoach')
        }
        vm.goBack =  function(){
            window.history.back();
        }
	   }
})();
(function () {
    'use strict';
	  angular
      .module('app.controllers')
      .controller('timeline', timeline);
	   timeline.$inject = ['$scope', '$state','$ionicSlideBoxDelegate','Timeline','$timeout','SendEHSPin','$stateParams','$ionicScrollDelegate','$ionicLoading','Graph','$ionicTabsDelegate','$q','$filter','$ionicPlatform','$ionicPosition'];
	   
	   function timeline($scope, $state, $ionicSlideBoxDelegate,Timeline,$timeout,SendEHSPin,$stateParams,$ionicScrollDelegate,$ionicLoading,Graph,$ionicTabsDelegate,$q,$filter,$ionicPlatform,$ionicPosition) {
        var vm=this; 
        vm.monthlyTimeline = [{}];
        vm.subHeader="";
        vm.newUser = true;
        vm.dayAndGrade={};
        var panelIsShown = false;
        vm.today_date = moment().format("dddd, MMMM Do");
        var current_slide_index =0;
        vm.todayDayTime = true;
        vm.landscape = false;
        var loadData = true;
        vm.oprational_gDate = "";
        var isSmoking = false;
        var isAlchoholic = false;
       
        var mql = window.matchMedia("(orientation: portrait)");
        mql.addListener(function(m) {
           if(panelIsShown == true){
             vm.selectedGraph = 0;
              if(m.matches) { //portrait
                       
                        vm.landscape = false;
                        $ionicScrollDelegate.resize();
                        $timeout(function(){
                          vm.landscape = false;
                          $ionicTabsDelegate.showBar(true);
                           StatusBar.show();
                       },1);
              }
              else { //landscape
                       vm.landscape = true;
                      
                       $ionicScrollDelegate.resize();
                       $timeout(function(){
                          vm.landscape = true;
                          $ionicTabsDelegate.showBar(false);
                          vm.changeSelection(0,'div');
                           StatusBar.hide();
                       },1);
              }
              $ionicScrollDelegate.resize();
            }
         });
      

           


        var setDataInitially=function(){Timeline.getMonthYear().then(
            function(result){ 
                   vm.newUser = false;
                   vm.monthlyTimeline = Timeline.getAllMonthsTillNow(result[0]);//getting all months till now  
                   console.log(result[0]);                
                   for(var i=0;i<vm.monthlyTimeline.length;i++){ //adding data parameter to object
                    vm.monthlyTimeline[i].data = [];
                    vm.monthlyTimeline[i].loaded = false;
                   }
                   $timeout(function(){
                       $ionicSlideBoxDelegate.slide(vm.monthlyTimeline.length-1,1);//go to latest slide
                       vm.lastSlide = true;
                       if(vm.monthlyTimeline.length-1==0){
                          vm.firstSlide = true; 
                       }
                        setDataForMonth();
                    },1);
            },
            function(err){  
                vm.newUser = true;
                vm.monthlyTimeline = [{}];
                 $ionicLoading.hide().then(function(){                           
                            });
                console.log(err);  
        });}
       
          // $timeout(function(){
          //        $ionicLoading.show({
          //         template: 'Loading...',
          //         duration: 2000
          //          }).then(function(){
          //        console.log("The loading indicator is now displayed");
          //       });
          //       setDataInitially();      
          //   },1000);
         
		    $scope.$on('$ionicView.afterEnter', function (event, viewData) {
            if(moment(Timeline.getTimelineParams())._isValid){
                $ionicLoading.show({
                  template: 'Loading...',
                  duration: 2000
                   }).then(function(){
                 console.log("The loading indicator is now displayed");
                });
                   $timeout(function(){
                      setDataInitially();   
                      loadData = false;   
                  },1);
            }
            if(loadData == true){
              $ionicLoading.show({
                  template: 'Loading...',
                  duration: 2000
                   }).then(function(){
                 console.log("The loading indicator is now displayed");
                });
              $timeout(function(){
                      setDataInitially();   
                      loadData = false;   
                  },1000);
              }
              if(vm.landscape == true || panelIsShown == true){
                   $ionicPlatform.ready(function() {
                   //screen.unlockOrientation();
                });
              }
               if(window.localStorage.getItem('isSmoking') == 'No'){
                    isSmoking = true;
                }
              if(window.localStorage.getItem('isAlchoholic') == 'No'){
                  isAlchoholic = true;
                }
              
            
        });
         if(window.localStorage.getItem('isSmoking') == 'No'){
                    isSmoking = true;
                }
              if(window.localStorage.getItem('isAlchoholic') == 'No'){
                  isAlchoholic = true;
                }
        $scope.$on('$ionicView.beforeLeave', function (event, viewData) {
           // $ionicPlatform.ready(function() {
           //         screen.lockOrientation('portrait')
           //      }); 
        });

       var setDataForMonth = function(){
            vm.subHeader=vm.monthlyTimeline[$ionicSlideBoxDelegate.currentIndex()].id.split("_")[0];
            current_slide_index = $ionicSlideBoxDelegate.currentIndex();
             
            Timeline.getRecordsByMonth(vm.monthlyTimeline[current_slide_index].id).then(function(res){
                 vm.monthlyTimeline=Timeline.setAllDataEntry(res,vm.monthlyTimeline[current_slide_index].id,vm.monthlyTimeline,current_slide_index);           
                  $ionicLoading.hide().then(function(){
                            console.log("The loading indicator is now hidden");
                            });     
                }, function (err) {
                    var res=[];
                    res[0] = {};
                    res[0].date="1994-12-12";
                    vm.monthlyTimeline=Timeline.setAllDataEntry(res,vm.monthlyTimeline[current_slide_index].id,vm.monthlyTimeline,current_slide_index);
                        $ionicLoading.hide().then(function(){
                         
                            console.log("The loading indicator is now hidden");
                            });
                    console.error(err);
                    }); 
                 
       }   
       vm.timelineChange = function(current_slide_index){
             //$ionicSlideBoxDelegate.update();
             vm.newUser = false;
           vm.subHeader=vm.monthlyTimeline[current_slide_index].id.split("_")[0];
           $ionicScrollDelegate.scrollTop();
            //document.getElementById('timelineSlide').style.height = "10px";
      
           if(current_slide_index == vm.monthlyTimeline.length-1){
               vm.todayDayTime = true;
               vm.lastSlide=true;
           }
           else{
             vm.todayDayTime = false;
             vm.lastSlide=false;
           }
           if(current_slide_index == 0){
               vm.firstSlide = true;
           }
           else{
                vm.firstSlide = false;
           }
           Timeline.setCurrentSlideIndex(current_slide_index);
           
           $timeout( function() {
              $ionicSlideBoxDelegate.update();
               $ionicScrollDelegate.resize();
              // console.log(document.getElementById('month-' + current_slide_index));
             //  var slideHeight = document.getElementById('month-' + current_slide_index).clientHeight;
              //  document.getElementById('timelineSlide').style.height = slideHeight+'px'; 
              // var slideHeight= window.getComputedStyle(document.getElementById('month-' + current_slide_index), null).getPropertyValue("height");
              //  console.log(slideHeight);
              // setHeight(slideHeight);
              // console.log(slideHeight);
            }, 100);
        }     
        var setHeight = function(slideHeight){
         $timeout(function() {
           console.log(slideHeight);
             document.getElementById('activeSlide').style.height = slideHeight; 
           }, 200);
       
        } 
       vm.lockSlide = function(){
          $ionicSlideBoxDelegate.enableSlide(false);
       }   
       var editRecordsInTimeline = function(date){
             Timeline.getRecordsByDate(date).then(
            function(res){          
                 var bufferArray = [];         
                for(var i=0; i<res.length;i++){ 
                  bufferArray.push(res[i]);
                }
                console.log(this);
                 $state.go('addRecords',{record_by_date:JSON.stringify(bufferArray)});
            },function(err){
              console.log(err);  
            });     
       }
             
       
         
       
        vm.togglePanel = function(index,data){
         
           var actualOffsetTop = 0;
          // var totalScreenHeight = window.innerHeight;
          // var sliderHeight =totalScreenHeight-43-43-49;
          //onsole.log($ionicPosition.position(angular.element(document.getElementById(data.date))));
          $timeout(function() {
             
             // console.log(angular.element(document.getElementById(moment(data.date).subtract(1, 'days').format("YYYY-MM-DD"))).prop('offsetTop'));
             // console.log(actualOffsetTop);
             // console.log(totalScreenHeight);
             // console.log(sliderHeight);
             // console.log(actualOffsetTop%totalScreenHeight);

             if(true){
              
              //$ionicScrollDelegate.scrollBy(0,80,true);
             }
          }, 10);
         
          if(data.avg_grade==0){
           
              $state.go('addRecords',{record_date:data.date})
              console.log(data.date);//u are getting date here and start your work here
              return;
          }
          if(!(data.exercise || data.smoke  || data.drinks || data.medication_value || data.weight || data.stress_value)){
              editRecordsInTimeline(data.date);
              return;
          }
          if (vm.isPanelShown(index)) {
                vm.shownPanel = null;
                panelIsShown = false;
                actualOffsetTop=angular.element(document.getElementById(data.date)).prop('offsetTop');
                $ionicScrollDelegate.scrollTo(0,actualOffsetTop,true);

                $ionicPlatform.ready(function() {
                   screen.lockOrientation('portrait')
                });

              } else {
                  panelIsShown = true;
                  $timeout(function() {
                    actualOffsetTop=angular.element(document.getElementById(data.date)).prop('offsetTop');
                    $ionicScrollDelegate.scrollTo(0,actualOffsetTop,true);
                  }, 10);
                  $ionicPlatform.ready(function() {
                  //s screen.unlockOrientation();
                }); 
                  vm.oprational_gDate = data.date;
                  vm.shownPanel = index;    
                   
              }  
        }
        vm.isPanelShown = function(index) {
              return vm.shownPanel == index;
            };
        vm.addRecords = function(){
              $state.go('addRecords');
         }
         vm.prevMonth = function(){
              $ionicSlideBoxDelegate.previous();
              setDataForMonth();
         }
         vm.nextMonth = function(){
            $ionicSlideBoxDelegate.next();
            //$ionicScrollDelegate.scrollTop();
         }

         vm.doRefresh = function() {
             current_slide_index = $ionicSlideBoxDelegate.currentIndex();
             if(current_slide_index ==vm.monthlyTimeline.length-1){
                $timeout( function() {
                vm.today_date = moment().format("dddd, MMMM Do");
                setDataInitially();
                 $scope.$broadcast('scroll.refreshComplete');
                }, 1000);
             }
             else{               
                 $scope.$broadcast('scroll.refreshComplete');
             }
         }
         vm.editRecord = function(date){
             editRecordsInTimeline(date);
        }
        vm.goTotAndC = function(){
			      $state.go('tAndC',{cameFrom:"timeline"});
		}
       
        var upperGradeGraphData = function(){
           Graph.setGradeGraphDataUpper(gradeGraphData);
        }

        vm.goToHowTo = function(){
          $state.go('tlHowTo');
        }
  
      vm.graphs=[{class:"graph0"},{class:"graph1"},{class:"graph2",isHide:isSmoking},{class:"graph3",isHide:isAlchoholic},{class:"graph4"},{class:"graph5"},{class:"graph6"}];
      vm.selectedGraph = 0;

      $ionicTabsDelegate.showBar(true);
      var ctx = document.getElementById("ehs-graph").getContext("2d");




      console.log(ctx);
      vm.graphData = {};
      var graphDataGrade = {
              backgroundColor : "rgba(0, 100, 144, 1)", // default is white
              labelY : ["Grade 1", "Grade 2", "Grade 3", "Grade 4"],
              padding : [7,4,30,15], //[top,right,bottom,left] 
              verticalGrid : 0,
              horizontalGrid : 3,
              gridColor : "#C5EFF7",
              plotColor : "rgba(197, 197, 197, 1)",
              boundary : {minX:0,minY:1, maxX:8,maxY:4},
      };
      var graphDataExercise = {
              backgroundColor : "rgba(53, 168, 222, 1)", // default is white
              labelY : ["0", "10", "20", "30", "40", "50","60+"],
              padding : [7,5,20,10], //[top,right,bottom,left] 
              verticalGrid : 0,
              horizontalGrid : 6,
              gridColor : "#C5EFF7",
              plotColor : "rgba(255, 253, 89, 1)",
              boundary : {minX:0,minY:0, maxX:8,maxY:60}
      };
      var graphDataSmoke = {
              backgroundColor : "rgba(221, 48, 223, 1)", // default is white
              labelY : ["0", "1-3", "4+"],
              padding : [7,5,20,10], //[top,right,bottom,left] 
              verticalGrid : 0,
              horizontalGrid : 2,
              gridColor : "#C5EFF7",
              plotColor : "rgba(71, 254, 237, 1)",
              boundary : {minX:0,minY:0, maxX:8,maxY:2}
      };
      var graphDataDrinks = {
              backgroundColor : "rgba(227, 199, 67, 1)", // default is white
              labelY : ["0", "1-2", "3+"],
              padding : [7,5,20,10], //[top,right,bottom,left] 
              verticalGrid : 0,
              horizontalGrid : 2,
              gridColor : "#C5EFF7",
              plotColor : "rgba(208, 78, 116, 1)",
              boundary : {minX:0,minY:0, maxX:8,maxY:2}
      };
      var graphDataWeight = {
            backgroundColor : "rgba(45, 190, 176, 1)", // default is white
            labelY : ["0", "40 kg", "80 kg", "120 kg", "160 kg", "200 kg"],
            padding : [7,5,20,10], //[top,right,bottom,left] 
            verticalGrid : 0,
            horizontalGrid : 5,
            gridColor : "#C5EFF7",
            plotColor : "rgba(246, 153, 247, 1)",
            boundary : {minX:0,minY:0, maxX:8,maxY:200}
      };
      var graphDataStress = {
            backgroundColor : "rgba(208, 78, 116, 1)", // default is white
            labelY : ["Low", "Medium", "HIGH"],
            padding : [7,5,20,10], //[top,right,bottom,left] 
            verticalGrid : 0,
            horizontalGrid : 2,
            gridColor : "#C5EFF7",
            plotColor : "rgba(167, 227, 255, 1)",
            boundary : {minX:0,minY:0, maxX:8,maxY:2}
      };
      var graphDataMeds = {
            backgroundColor : "rgba(87, 208, 78, 1)", // default is white
            labelY : ["0", "2", "4", "6", "8", "10+"],
            padding : [7,5,20,10], //[top,right,bottom,left] 
            verticalGrid : 0,
            horizontalGrid : 5,
            gridColor : "#C5EFF7",
            plotColor : "rgba(227, 199, 67, 1)",
            boundary : {minX:0,minY:0, maxX:8,maxY:10}     
      };
      vm.graphHeading = "";
      vm.currentValue = 0;
      vm.averageValue = 0;
      vm.showBlankGraph = false;
      vm.showFooter = true;
      vm.showLeftGraphPoints = false;
      vm.showRightGraphPoints =  false;
      var allGradeData = [];
      var allExerciseData = [];
      var allStressData = [];
      var allMedicationData = [];
      var allSmokeData = [];
      var allDrinksData = [];
      var allWeightData = [];
      var shownGradeGraphData = [];
      var shownExerciseGraphData = [];
      var shownSmokeGraphData = [];
      var shownMedsGraphData = [];
      var shownDrinksGraphData = [];
      var shownStressGraphData = [];
      var shownWeightGraphData = [];
      vm.noGraphMsg = [
         $filter('translate')('TIMELINE.TEXT11'),
         $filter('translate')('TIMELINE.TEXT12'),
         $filter('translate')('TIMELINE.TEXT13'),
         $filter('translate')('TIMELINE.TEXT14'),
         $filter('translate')('TIMELINE.TEXT15'),
         $filter('translate')('TIMELINE.TEXT16'),
         $filter('translate')('TIMELINE.TEXT17')
      ]
      var queHeader = [
        $filter('translate')('TIMELINE.TEXT22'),
         $filter('translate')('TIMELINE.TEXT23'),
         $filter('translate')('TIMELINE.TEXT24'),
         $filter('translate')('TIMELINE.TEXT25'),
         $filter('translate')('TIMELINE.TEXT26'),
         $filter('translate')('TIMELINE.TEXT27'),
         $filter('translate')('TIMELINE.TEXT28')
      ]
      

      var refreshCanvas = function(graph1){
        var canvasAtr = angular.element( document.querySelector( '#ehs-graph' ) );
        canvasAtr.attr('width',Math.round(window.innerWidth));
        canvasAtr.attr('height',Math.round(window.innerHeight*0.45));
        ctx.imageSmoothingEnabled = false;
         ctx.imageSmoothingQuality = "high";
        graph1.refresh()
        graph1.draw();
      }
        var drawGraph = function(oprational_gDate){
           var tempDataHolder = [];
          return $q(function(resolve, reject) {
            var gradeGraphData =[];
             Graph.setInitialGraph().then(function(res){
                 allGradeData = Graph.openGradeJason(res);
                 vm.currentValue = allGradeData[allGradeData.length-1].grade;
                 vm.averageValue = Graph.getCommonFieldsAvg(allGradeData,'grade').toFixed(2);
                 tempDataHolder = Graph.getSevenExerciseData(allGradeData,oprational_gDate);
                 shownGradeGraphData = tempDataHolder[0];
                 vm.showRightArrow = tempDataHolder[1];
                 vm.showLeftArrow = tempDataHolder[2];
                 gradeGraphData = Graph.getGradeDataForGraph(shownGradeGraphData);
                  //upperGradeGraphData();
                   resolve(gradeGraphData);
             },
             function(err){
                 resolve(gradeGraphData);
             });
          });
        }
      var getPlotdataNonGrade = function(field,oprational_Date){
        var tempDataHolder = [];
        if(field == "Exercise" || field == "Stress" || field == "Medication"){ 
            return $q(function(resolve, reject) {
            var exerciseGraphData =[];
            Graph.getPlotdataNonGarde(field).then(function(res){
            
               if(field == "Exercise"){
                  allExerciseData = res;
                   vm.currentValue = res[res.length-1].exercise+' mins';
                  vm.averageValue = Graph.getCommonFieldsAvg(res,'exercise').toFixed(0)+' mins';
                   tempDataHolder = Graph.getSevenExerciseData(allExerciseData,oprational_Date);
                  shownExerciseGraphData = tempDataHolder[0];
                  vm.showRightArrow = tempDataHolder[1];
                  vm.showLeftArrow = tempDataHolder[2];
                  exerciseGraphData =Graph.getExerciseDataForGraph(shownExerciseGraphData);
                  //exerciseGraphData = getDataPointsDetails[0];
                //   console.log(exerciseGraphData);
                //   vm.showRightGraphPoints =  getDataPointsDetails[1];
              }
              else if(field == "Stress"){
                  allStressData = res;
                  vm.currentValue = Graph.getStressText(res[res.length-1].stress);
                  vm.averageValue = Graph.getStressAvg(res,'stress');
                  shownStressGraphData = Graph.getSevenExerciseData(allStressData,oprational_Date);
                  tempDataHolder = Graph.getSevenExerciseData(allStressData,oprational_Date);
                  shownStressGraphData = tempDataHolder[0];
                  vm.showRightArrow = tempDataHolder[1];
                  vm.showLeftArrow = tempDataHolder[2];
                  exerciseGraphData = Graph.getStressDataForGraph(shownStressGraphData);
                 //vm.showRightGraphPoints =  getDataPointsDetails[1];
              }
              else if(field == "Medication"){
                  allMedicationData = res;                  
                  vm.currentValue = JSON.parse(res[res.length-1].medication).length+' Meds';
                  vm.averageValue = Graph.getMedsAvg(res).toFixed(0)+' Meds';
                  shownMedsGraphData = Graph.getSevenExerciseData(allMedicationData,oprational_Date);
                  tempDataHolder = Graph.getSevenExerciseData(allMedicationData,oprational_Date);
                  shownMedsGraphData = tempDataHolder[0];
                  vm.showRightArrow = tempDataHolder[1];
                  vm.showLeftArrow = tempDataHolder[2];
                  exerciseGraphData = Graph.getMedicationDataForGraph(shownMedsGraphData);
                 //vm.showRightGraphPoints =  getDataPointsDetails[1];
              } 
                  resolve(exerciseGraphData);
             },
             function(err){
                  resolve(exerciseGraphData);
             });
          });
        }
        else if(field == "Smoke" || field == "Drinks" || field == "Weight"){
           var tempDataHolder = [];
           return $q(function(resolve, reject) {
            var smokeGraphData =[];
            Graph.getPlotdataNonGardeSmoke(field,oprational_Date).then(function(res){
              if(field == "Smoke"){
                  allSmokeData = res;
                  vm.currentValue = res[res.length-1].smoke;
                  vm.averageValue = Graph.getAvgSmoke(res);
                  tempDataHolder = Graph.getSevenExerciseData(allSmokeData,oprational_Date);
                  shownSmokeGraphData = tempDataHolder[0];
                  vm.showRightArrow = tempDataHolder[1];
                  vm.showLeftArrow = tempDataHolder[2];
                  smokeGraphData =Graph.getSmokeDataForGraph(shownSmokeGraphData);
              }
              else if(field == "Drinks"){
                   allDrinksData = res;
                   vm.currentValue = res[res.length-1].drinks;
                    vm.averageValue = Graph.getAvgDrink(res);
                   tempDataHolder = Graph.getSevenExerciseData(allDrinksData,oprational_Date);
                  shownDrinksGraphData = tempDataHolder[0];
                  vm.showRightArrow = tempDataHolder[1];
                  vm.showLeftArrow = tempDataHolder[2];
                   smokeGraphData =Graph.getDrinksDataForGraph(shownDrinksGraphData);
              } 
              else if(field == "Weight"){
                  allWeightData = res;
                  vm.currentValue = res[res.length-1].weight+' kg';
                  vm.averageValue = Graph.getCommonFieldsAvg(res,'weight').toFixed(0)+' kg';
                  tempDataHolder = Graph.getSevenExerciseData(allWeightData,oprational_Date);
                  shownWeightGraphData = tempDataHolder[0];
                  vm.showRightArrow = tempDataHolder[1];
                  vm.showLeftArrow = tempDataHolder[2];
                 smokeGraphData = Graph.getWeightDataForGraph(shownWeightGraphData);
              } 
              resolve(smokeGraphData);
             },
             function(err){
                   resolve(smokeGraphData);
             });
          });
        }
      }
     var drawGraphWithPlotData = function(myplotdata){
        if(myplotdata=="")
          {
              vm.showBlankGraph = true;
              vm.showFooter = false;
              vm.graphData.padding = [10,5,15,10];
              vm.currentValue = "-";
              vm.averageValue = "-";
          }
        else
          {
              vm.showBlankGraph = false;
              vm.showFooter = true;
          }
          var graph = new LineGraph(ctx,vm.graphData);
          graph.setDimension(Math.round(window.innerWidth),Math.round(window.innerHeight*0.45));
          ctx.setTransform(4, 0, 0, 4, 0, 0);
          graph.setData(myplotdata);
          graph.draw();

          refreshCanvas(graph);
          window.addEventListener("resize", refreshCanvas(graph));
     }
 
      var exercisePrevGraphData = []; 
      vm.changeSelection = function(idx,side){
        vm.selectedGraph = idx;
        var myplotdata = [];
         switch(idx)
         {
          case 0:
          console.log(side);
                  if(side == 'div'){
                      vm.graphHeading = "Grade";
                      drawGraph(vm.oprational_gDate).then(function(data){
                      myplotdata = data;
                       vm.graphData = graphDataGrade;
                       drawGraphWithPlotData(myplotdata);
                       });
                   }
                   else{
                       if(side == 'left'){
                         myplotdata = Graph.getLeftPlotData(allGradeData,shownGradeGraphData);
                         console.log(myplotdata);
                         shownGradeGraphData = myplotdata[0];
                         vm.showLeftArrow = myplotdata[2];
                         vm.showRightArrow = myplotdata[1];
                       } 
                       else{
                         myplotdata = Graph.getRightPlotData(allGradeData,shownGradeGraphData);
                         shownGradeGraphData = myplotdata[0];
                         vm.showLeftArrow = myplotdata[2];
                         vm.showRightArrow = myplotdata[1];
                       } 
                        myplotdata = Graph.getGradeDataForGraph(shownGradeGraphData);
                        vm.graphData = graphDataGrade;
                        drawGraphWithPlotData(myplotdata);
                   }
                   break;
          case 1:
                if(side == 'div'){
                      vm.graphHeading = "Exercise";
                      getPlotdataNonGrade("Exercise",vm.oprational_gDate).then(function(data){
                      myplotdata = data;
                      exercisePrevGraphData = data;
                      vm.graphData = graphDataExercise;
                      drawGraphWithPlotData(myplotdata);
                    });
                  break; 
                  }
                   else{
                       if(side == 'left'){
                         myplotdata = Graph.getLeftPlotData(allExerciseData,shownExerciseGraphData);
                         shownExerciseGraphData = myplotdata[0];
                         vm.showLeftArrow = myplotdata[2];
                         vm.showRightArrow = myplotdata[1];
                       } 
                       else{
                         myplotdata = Graph.getRightPlotData(allExerciseData,shownExerciseGraphData);
                         shownExerciseGraphData = myplotdata[0];
                         vm.showLeftArrow = myplotdata[2];
                         vm.showRightArrow = myplotdata[1];
                       } 
                        myplotdata = Graph.getExerciseDataForGraph(shownExerciseGraphData);
                        vm.graphData = graphDataExercise;
                        drawGraphWithPlotData(myplotdata);
                   }
                   break;
          case 2: 
                  if(side == 'div'){
                        vm.graphHeading = "Smokes";
                        getPlotdataNonGrade("Smoke",vm.oprational_gDate).then(function(data){
                          myplotdata = data;
                          vm.graphData = graphDataSmoke;
                          drawGraphWithPlotData(myplotdata);
                        });
                  break;
                  }
                   else{
                       if(side == 'left'){
                         myplotdata = Graph.getLeftPlotData(allSmokeData,shownSmokeGraphData);
                         shownSmokeGraphData = myplotdata[0];
                         vm.showLeftArrow = myplotdata[2];
                         vm.showRightArrow = myplotdata[1];
                       } 
                       else{
                         myplotdata = Graph.getRightPlotData(allSmokeData,shownSmokeGraphData);
                         shownSmokeGraphData = myplotdata[0];
                         vm.showLeftArrow = myplotdata[2];
                         vm.showRightArrow = myplotdata[1];
                       } 
                        myplotdata = Graph.getSmokeDataForGraph(shownSmokeGraphData);
                        vm.graphData = graphDataSmoke;
                        drawGraphWithPlotData(myplotdata);
                   }
                   break;
          case 3:
                  if(side == 'div'){
                      vm.graphHeading = "Drinks";
                      getPlotdataNonGrade("Drinks",vm.oprational_gDate).then(function(data){
                        myplotdata = data;
                        vm.graphData = graphDataDrinks;
                        drawGraphWithPlotData(myplotdata);
                      });
                  break; 
                  }
                   else{
                       if(side == 'left'){
                         myplotdata = Graph.getLeftPlotData(allDrinksData,shownDrinksGraphData);
                         shownDrinksGraphData = myplotdata[0];
                         vm.showLeftArrow = myplotdata[2];
                         vm.showRightArrow = myplotdata[1];
                       } 
                       else{
                         myplotdata = Graph.getRightPlotData(allDrinksData,shownDrinksGraphData);
                         shownDrinksGraphData = myplotdata[0];
                         vm.showLeftArrow = myplotdata[2];
                         vm.showRightArrow = myplotdata[1];
                       } 
                        myplotdata = Graph.getDrinksDataForGraph(shownDrinksGraphData);
                        vm.graphData = graphDataDrinks;
                        drawGraphWithPlotData(myplotdata);
                   }
                   break;  
          case 4:
                  if(side == 'div'){
                  vm.graphHeading = "Weight";
                  getPlotdataNonGrade("Weight",vm.oprational_gDate).then(function(data){
                    myplotdata = data;
                    vm.graphData = graphDataWeight;
                    drawGraphWithPlotData(myplotdata);
                  });
                  break;
                  }
                   else{
                       if(side == 'left'){
                         myplotdata = Graph.getLeftPlotData(allWeightData,shownWeightGraphData);
                         shownWeightGraphData = myplotdata[0];
                         vm.showLeftArrow = myplotdata[2];
                         vm.showRightArrow = myplotdata[1];
                       } 
                       else{
                         myplotdata = Graph.getRightPlotData(allWeightData,shownWeightGraphData);
                         shownWeightGraphData = myplotdata[0];
                         vm.showLeftArrow = myplotdata[2];
                         vm.showRightArrow = myplotdata[1];
                       } 
                        myplotdata = Graph.getWeightDataForGraph(shownWeightGraphData);
                        vm.graphData = graphDataWeight;
                        drawGraphWithPlotData(myplotdata);
                   }
                   break;

          case 5:
                if(side == 'div'){
                      vm.graphHeading = "Stress";
                      getPlotdataNonGrade("Stress",vm.oprational_gDate).then(function(data){
                        myplotdata = data;
                        vm.graphData = graphDataStress;
                        drawGraphWithPlotData(myplotdata);
                      });
                  break;
                  }
                   else{
                       if(side == 'left'){
                         myplotdata = Graph.getLeftPlotData(allStressData,shownStressGraphData);
                         shownStressGraphData = myplotdata[0];
                         vm.showLeftArrow = myplotdata[2];
                         vm.showRightArrow = myplotdata[1];
                       } 
                       else{
                         myplotdata = Graph.getRightPlotData(allStressData,shownStressGraphData);
                         shownStressGraphData = myplotdata[0];
                         vm.showLeftArrow = myplotdata[2];
                         vm.showRightArrow = myplotdata[1];
                       } 
                        myplotdata = Graph.getStressDataForGraph(shownStressGraphData);
                        vm.graphData = graphDataStress;
                        drawGraphWithPlotData(myplotdata);
                   }
                   break;

          case 6:
          if(side == 'div'){
                  vm.graphHeading = "Medication";
                  getPlotdataNonGrade("Medication",vm.oprational_gDate).then(function(data){
                    myplotdata = data;
                    vm.graphData = graphDataMeds;
                    drawGraphWithPlotData(myplotdata);
                  });
                  break;
                  }
                   else{
                       if(side == 'left'){
                         myplotdata = Graph.getLeftPlotData(allMedicationData,shownMedsGraphData);
                         shownMedsGraphData = myplotdata[0];
                         vm.showLeftArrow = myplotdata[2];
                         vm.showRightArrow = myplotdata[1];
                       } 
                       else{
                         myplotdata = Graph.getRightPlotData(allMedicationData,shownMedsGraphData);
                         shownMedsGraphData = myplotdata[0];
                         vm.showLeftArrow = myplotdata[2];
                         vm.showRightArrow = myplotdata[1];
                       } 
                        myplotdata = Graph.getMedicationDataForGraph(shownMedsGraphData);
                        vm.graphData = graphDataMeds;
                        drawGraphWithPlotData(myplotdata);
                   }
                   break;

          default:
                  vm.graphHeading = "Grade";
                  myplotdata = [];
                  vm.graphData = graphDataGrade;
        }
       }
       vm.getRightDatePoints = function(selectedGraph){
           vm.changeSelection(selectedGraph,"right");
       }
       vm.getLeftDatePoints = function(selectedGraph){
           vm.changeSelection(selectedGraph,"left");
       }
       vm.goToAskQue = function(selectedGraph){
            var objToSend = [];
            var ans = queHeader[selectedGraph]+'<br>'+$filter('translate')('TIMELINE.TEXT20')+vm.currentValue
            +'<br>'+$filter('translate')('TIMELINE.TEXT21')+vm.averageValue;
            objToSend.selectedGraph = selectedGraph;
            objToSend.ans = ans;
            console.log(objToSend);
            $state.go('askQuestion',{ans:objToSend});
       }
	   }
})();
(function() {
	'use strict';
	
	 angular
      .module('app.controllers')
      .controller('verifyPin', verifyPin);

	   verifyPin.$inject = ['$scope', '$state', '$window','$timeout'];
	   
	   function verifyPin($scope, $state, $window, $timeout) {
	   	var vm = this;
	   	$scope.$on('$ionicView.beforeEnter', function (event, viewData) {
        vm.showVerifyPin = true;
	   	vm.showSendMail = false;
	   	vm.wrongPin = false;
	   	vm.mailSent = false;
	   	vm.pinVal = [];
		vm.pins = [0,1,2,3];
	   	vm.focused = 0; 

	   });
	   	vm.changeFocusC = function(focus,e){
		    console.log(e)
			if(e == 8){
				vm.focused--;
				return;
			}
			if(!(e>=48 && e <= 57)){
				vm.pinVal[focus] ='';
				return;
			} 
			if(vm.pinVal[focus].toString().length>1){
				vm.pinVal[focus] = vm.pinVal[focus].toString().charAt(1);
				return;
	   		}
				
	   		if(vm.pinVal[focus].toString().length == 1){
				vm.focused = focus;
				vm.focused++;
				if(vm.focused == 4){
					//Compare Pin
					var storedPIN = JSON.parse(localStorage.getItem('pinValues'));
					vm.arraysEqual(storedPIN, vm.pinVal);
				}
	   		}
	   			
	   			console.log(vm.pinVal);
	   		}

	   		vm.goBack =  function(){
	   			for(var i=0;i<4;i++)
					vm.pinVal[i] = '';
           		window.history.back();
       		}
       		vm.goToDashboard = function(){
       			vm.wrongPin = false;
       			for(var i=0;i<4;i++)
					vm.pinVal[i] = '';
       			$state.go('tab.timeline');
       		}

       		vm.arraysEqual = function(arr1, arr2) {
			    if(arr1.length !== arr2.length)
			        return false;
			    for(var i = arr1.length; i--;) {
			        if(arr1[i] !== arr2[i])
			            {
			            	vm.wrongPin = true;
			            	for(var i=0; i<4; i++)
								vm.pinVal[i] = '';
							vm.focused = 0;
			            	return false;
			            }
			    }
			    vm.goToDashboard();
			    return true;
			}
	   }	   
	}
)();