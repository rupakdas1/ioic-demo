(function() {
	'use strict';
	
	 angular
      .module('app.controllers')
      .controller('settings', settings);
	   settings.$inject = ['$scope', '$state','$ionicPlatform'];
	   
	   function settings($scope, $state,$ionicPlatform) {
	   	var vm = this;  
	   	$scope.$on('$ionicView.beforeEnter', function (event, viewData) {
           $ionicPlatform.ready(function() {
                   screen.lockOrientation('portrait')
                }); 
        });
	   	
		vm.goToAppHowTo = function(){
			$state.go("appHowTo");
		}
		vm.goToEnterPin = function(){
			$state.go("enterPin");
		}		
		vm.goTotAndC= function(){
			$state.go('tAndC');
		}
	   }
	   
	}
)();