(function() {
	'use strict';
	
	 angular
      .module('app.controllers')
      .controller('myReminders', myReminders);
      

	   myReminders.$inject = ['$scope', '$state', '$window','AddReminders','$ionicModal','$cordovaDialogs','$filter','$ionicHistory','$ionicListDelegate'];
	   
	   function myReminders($scope, $state, $window,AddReminders,$ionicModal,$cordovaDialogs,$filter,$ionicHistory,$ionicListDelegate) {
	   	var vm = this;
           vm.showlist=true;
             vm.Reminders=[];
     $scope.$on('$ionicView.beforeEnter', function (event, viewData) {
            $ionicListDelegate.closeOptionButtons();
            AddReminders.getReminders().then(
                    function(res){
                          if(viewData.stateParams.cameFrom=="editReminder"){
                          vm.Reminders = AddReminders.getItemsFromService();
                          vm.Reminders = res;
                          AddReminders.storeItemsInService(vm.Reminders);
                          }
                          else{
                            console.log("else",AddReminders.getItemsFromService());
                            for(var i = 0;i<res.length;i++){
                              vm.Reminders[i] =res[i];
                            }
                            AddReminders.storeItemsInService(vm.Reminders);
                            console.log(vm.Reminders);
                           }
                          vm.showlist=true;                         
                          },
                        function(err){
                            vm.showlist=false;
                             $state.go('tab.profileMain');
                             vm.Reminders = [];
                        });
        
        });
	   
		  vm.onItemDelete = function(item) {
        console.log("item",item)
                 $cordovaDialogs.confirm($filter('translate')('SETREMINDER.DIALOGTEXT'), $filter('translate')('SETREMINDER.DIALOGTITLE'), [$filter('translate')('QUESTFORDOCTOR.BUTTON'),$filter('translate')('QUESTFORDOCTOR.BUTTON2')])
                .then(function(buttonIndex) {
                // no button = 0, 'OK' = 1, 'Cancel' = 2
                        if(buttonIndex==1){
                            AddReminders.deleteReminder(item.reminder_name,item.recorded_date).then(
                                    function(res){                  
                                    },
                                    function(err){
                                      console.log(err);  
							});
                            vm.Reminders.splice(vm.Reminders.indexOf(item), 1);
                            console.log(vm.Reminders.length);
                            if(vm.Reminders.length==0){
                              vm.showlist=false;
                               $state.go('tab.profileMain');
                               vm.Reminders = [];
                            }
                        }
                });
  		};
      vm.gotToEditReminder=function(item){
        $state.go('editReminder',{items:JSON.stringify(item)});
        vm.Reminders = [];

      }
      vm.goToSetReminder=function(){
     
          $state.go('setReminder');
          vm.Reminders = [];
      }
  				
	   	vm.goBack =  function(){
             $state.go('tab.profileMain');
             vm.Reminders = [];
        }
            
	   }
	   
	}
)();