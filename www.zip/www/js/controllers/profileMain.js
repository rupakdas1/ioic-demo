(function() {
	'use strict';
	
	 angular
      .module('app.controllers')
      .controller('profileMain', profileMain);
	   profileMain.$inject = ['$scope', '$state','AddReminders','$filter','$ionicPlatform','$cordovaDialogs','Timeline','$ionicLoading'];
	   
	   function profileMain($scope, $state,AddReminders, $filter,$ionicPlatform,$cordovaDialogs,Timeline,$ionicLoading) {
	   	var vm = this;
		vm.upcommingEvents=[];
		vm.upcommingAppointments=[];
	   	vm.selectedTab = "Event";
		vm.showEvent = true;
   
     $ionicPlatform.ready(function() {
                document.addEventListener("resume", function() {
                   setUpcomingText();
                })
              });
     var setUpcomingText = function(){
       AddReminders.getEvents().then(
                    function(res){
                         
                          for(var i = 0;i<res.length;i++){
                             res[i].recorded_date=moment(res[i].recorded_date).toISOString();
                          }
                           res = $filter('orderBy')(res,'recorded_date',false);
                            // finalArray=sortedArray;
                           var currentEvent=0;
                           for(var i = 0;i<res.length;i++){
                            var currentTime=new Date().toISOString();
                             if(moment(res[i].recorded_date).isBefore(moment(currentTime))){
                               console.log("in");
                                 currentEvent=i+1;
                             }
                             res[i].recorded_date=moment(res[i].recorded_date).format("dddd, MMMM Do hh:mm a");
                          }
                          //Current Event
                          console.log('currentTime',currentTime);
                          console.log(res);  
                            vm.upcommingEvents=res[currentEvent];
                            
                            console.log('upcommingEvents',vm.upcommingEvents);
                       //    vm.upcommingEvents =$filter('translate')('PROFILE.EVENTS_SUCCESS')+"<br>"+res[0].event_name +"<br>"+ res[0].recorded_date;
                          },
                        function(err){
                            vm.upcommingEvents=undefined;
                          // vm.upcommingEvents = $filter('translate')('PROFILE.NO_PLANS_TEXT1')+"<br>"+$filter('translate')('PROFILE.NO_PLANS_TEXT2');
                          //  console.log(err); 
                        });

             AddReminders.getAppointments().then(
                    function(res){
                           for(var i = 0;i<res.length;i++){
                             res[i].recorded_date=moment(res[i].recorded_date).toISOString();
                          }
                           res = $filter('orderBy')(res,'recorded_date',false);
                            // finalArray=sortedArray;
                              var currentEvent=0;
                           for(var i = 0;i<res.length;i++){
                             var currentTime=new Date().toISOString();
                             if(moment(res[i].recorded_date).isBefore(moment(currentTime))){
                               console.log("in");
                                 currentEvent=i+1;
                             }
                             res[i].recorded_date=moment(res[i].recorded_date).format("dddd, MMMM Do hh:mm a")
                          }
                           vm.upcommingAppointments=res[currentEvent];
                          //  vm.upcommingAppointments =$filter('translate')('PROFILE.APPOINTMENTS_SUCCESS')+"<br>"+res[0].appointment_name +"<br>"+ res[0].recorded_date;
                          //  console.log(res[0]);                       
                          },
                        function(err){
                            vm.upcommingAppointments=undefined;
                          // vm.upcommingAppointments = $filter('translate')('PROFILE.NO_APP_PLANS_TEXT1')+"<br>"+$filter('translate')('PROFILE.NO_APP_PLANS_TEXT2');
                          //  console.log(err); 
                        });
     }

	$scope.$on('$ionicView.beforeEnter', function (event, viewData) {
              setUpcomingText();
               $ionicPlatform.ready(function() {
                   screen.lockOrientation('portrait')
                }); 
      });
	   	vm.goTotAndC = function(){
			      $state.go('tAndC',{cameFrom:"profileMain"});
		}
		vm.goToHowTo = function(){
			      $state.go('profileHowTo');
		}
		vm.isSelected = function(selectedTab){
			vm.selectedTab = selectedTab;
			vm.showEvent = selectedTab;
		}
		vm.goToMyMeds = function(){
			$state.go('myMeds');
		}
		vm.goToEHS = function(){
					$state.go('erectionHS');
		}
		vm.goToMyQuestions = function(){
					 $state.go('myQuestions',{camefrom:"profileMain"});
		}

		vm.goToVerifyPin = function(){
       Timeline.hasMasterData().then(
                    function(res){
                          $state.go('sendEmail');
                          $ionicLoading.show({
                            template: 'Loading...',
                            duration: 3000
                             }).then(function(){
                           console.log("The loading indicator is now displayed");
                          });
                    },
                      function(err){
                       $cordovaDialogs.alert($filter('translate')('EXPORTDATA.ERROR'),[$filter('translate')('QUESTFORDOCTOR.BUTTON1')])
                     .then(function(buttonIndex) {
                       
                    });   
                    });
			
		}
       
	      vm.goToSetReminder = function(){
           AddReminders.getLengthOfRemindres().then(
                    function(res){
                        	$state.go('myReminders');
                    },
                      function(err){
						            console.log(err)
                         $state.go('setReminder');
                    });
		}
		vm.goToCreateEvent = function(){
				  AddReminders.getLengthOfEvents().then(
                    function(res){
                        	$state.go('myEvents');
                    },
                      function(err){
						             $state.go('createEvent');
                    });
		}
		 vm.goToCreateAppointment = function(){
				   AddReminders.getLengthOfAppointments().then(
                    function(res){
                        	$state.go('myAppointments');
                    },
                      function(err){
                          $state.go('createAppointment');
                    });
		}
	   }
	   
	}
)();