(function() {
	'use strict';
	
	 angular
      .module('app.controllers')
      .controller('myMeds', myMeds);
	   myMeds.$inject = ['$scope', '$state', '$window','AddMedications','$ionicModal','$cordovaDialogs','$filter','$ionicScrollDelegate','$ionicListDelegate'];
	   
	   function myMeds($scope, $state, $window,AddMedications,$ionicModal,$cordovaDialogs,$filter,$ionicScrollDelegate,$ionicListDelegate) {
	   	var vm = this;
        vm.showlist = true;
        vm.Medicines = [];
        
        var savedOldMedName = "";
        vm.hideSave = true;
        vm.saveText = $filter('translate')('QUESTFORDOCTOR.BUTTON3');
        vm.onItemDelete = function(item) {
                 $cordovaDialogs.confirm($filter('translate')('MYMEDS.DIALOGTEXT'), $filter('translate')('MYMEDS.DIALOGTITLE'), [$filter('translate')('QUESTFORDOCTOR.BUTTON1'),$filter('translate')('QUESTFORDOCTOR.BUTTON2')])
                .then(function(buttonIndex) {
                // no button = 0, 'OK' = 1, 'Cancel' = 2
                        if(buttonIndex == 1){
                            AddMedications.deleteMedicine(item.medication_name).then(
                                function(res){                  
                                },
                                function(err){
                                    console.log(err);  
                                });
                            vm.Medicines.splice(vm.Medicines.indexOf(item), 1);
                            if(vm.Medicines.length == 0){
                               vm.showlist=false;
                            }
                        }
                });
  		};
  		var getMedicine = function(){ 
            $ionicScrollDelegate.scrollTop();
            AddMedications.getMedications().then(
            function(res){
                 for(var i = 0;i<res.length;i++){               
                    vm.Medicines[i] = res[i]
                    }
                vm.showlist = true;                   
            },
            function(err){
                vm.showlist = false;
                console.log(err);  
            });
		  }
        $scope.$on('$ionicView.beforeEnter', function (event, viewData) {
              //$state.go($state.current, {}, {reload: true}); 
                $ionicListDelegate.closeOptionButtons();
		        getMedicine();

        });
	   	vm.goBack =  function(){
            window.history.back();
            vm.Medicines = []; 
        }
         /* =================Close Medication Modal====================== */ 
		vm.closeModal = function(modalType){
                  $scope.addMedication.hide();
                  $scope.editMedication.hide();
                  vm.hideSave = true;
                  vm.saveText = $filter('translate')('QUESTFORDOCTOR.BUTTON3');
                     vm.medication_err = 0;
                    vm.medication_input = '';
            }   
            /* =================Open Medication Modal====================== */
		 $ionicModal.fromTemplateUrl('templates/addMedication.html', {
                scope: $scope,
                animation: 'slide-in-up'
            }).then(function(modal) {
                $scope.addMedication = modal;
            });
             $ionicModal.fromTemplateUrl('templates/editMedication.html', {
                scope: $scope,
                animation: 'slide-in-up'
            }).then(function(modal) {
                $scope.editMedication = modal;
            });	
        vm.addMed = function(){
			vm.medication_input = '';
              $scope.addMedication.show();
		}

        vm.getDateFormatted = function(date){
			return moment(date).format("M/DD/YYYY");
		}
        
		 vm.textUpdate = function(){
               vm.medication_err = false;
         }      
            vm.saveMedication = function(){
              
              if(vm.medication_input != ""){
                var medicationData = vm.medication_input;
                 AddMedications.setMedications(medicationData).then(function(res){
                        $scope.addMedication.hide();
                        
                 },function(err){
                        vm.medication_err = 1;
                    }); 
				   getMedicine();
                }
            }
            vm.editMedication = function(){
                if(vm.hideSave){
                    vm.saveText = $filter('translate')('QUESTFORDOCTOR.BUTTON4');
                    vm.hideSave = false;
                    return
                }
                     AddMedications.updateMedications(vm.medication_input,savedOldMedName).then(function(){
                        $scope.editMedication.hide();
                        
                    },function(err){
                            vm.medication_err = 1;
                        }); 
                    getMedicine();
                  vm.hideSave = true;
                  vm.saveText = $filter('translate')('QUESTFORDOCTOR.BUTTON3');
            }
        vm.itemClicked = function(medObj){
             vm.medication_input = medObj.medication_name;
             savedOldMedName = vm.medication_input; 
             $scope.editMedication.show();
        }
        vm.deleteMedication = function(){
             $cordovaDialogs.confirm($filter('translate')('MYMEDS.DIALOGTEXT'), $filter('translate')('MYMEDS.DIALOGTITLE'), [$filter('translate')('QUESTFORDOCTOR.BUTTON1'),$filter('translate')('QUESTFORDOCTOR.BUTTON2')])
                .then(function(buttonIndex) {
                // no button = 0, 'OK' = 1, 'Cancel' = 2
                        if(buttonIndex == 1){
                            AddMedications.deleteMedicine(savedOldMedName).then(
                                function(res){    
                                     $scope.editMedication.hide();
                                     vm.Medicines = []; 
                                      getMedicine();           
                                },
                                function(err){
                                    console.log(err);  
                                });
                        }
                vm.hideSave = true;
                vm.saveText = $filter('translate')('QUESTFORDOCTOR.BUTTON3');
                    
                });
        }

	   }
	   
	}
)();