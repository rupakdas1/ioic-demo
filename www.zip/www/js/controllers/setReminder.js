(function() {
	'use strict';
	
	 angular
      .module('app.controllers')
      .controller('setReminder', setReminder);
	   setReminder.$inject = ['$scope', '$state','$stateParams','ionicTimePicker','ionicDatePicker','$location','AddReminders','$cordovaDialogs','$filter'];
	   
	   function setReminder($scope, $state,$stateParams,ionicTimePicker,ionicDatePicker,$location,AddReminders,$cordovaDialogs,$filter) {
              
             var vm=this; 
             var reminderObj = {};
             vm.oldReminderText=null;
             vm.oldRecordedDate=null;
              vm.oldDate=null;
              vm.oldTime=null;
             var path = $location.path();
              console.log("path",path);
             if(path=='/editReminder'){
              vm.editScreen=true;
              $scope.$on('$ionicView.beforeEnter', function (event, viewData) {
                
                 reminderObj = {};
                 reminderObj = JSON.parse(viewData.stateParams.items);
                 console.log("reminder",reminderObj);
                vm.oldReminderText=vm.reminderText=reminderObj.reminder_name;
                vm.oldRecordedDate=reminderObj.recorded_date;
                vm.oldDate = vm.set_date_edit=moment(reminderObj.recorded_date).format("dddd, MMMM Do");
              vm.oldTime = vm.record_time_edit=moment(reminderObj.recorded_date).format("hh:mm A");
          
            });
             } else{
              console.log("insetReminder");
              vm.reminderText="";
               vm.set_date_edit="";
               vm.record_time_edit="";
              vm.editScreen=false;
             }
		     $scope.$emit('pageChange', {
              title: 'Set Reminder',
              leftButton:'Cancel',
              rightButton:'Save'
            })
       
            vm.saveReminder = function(){
               if(vm.reminderText != "" && vm.set_date_edit !="" && vm.record_time_edit !=""){
                var reminderData = vm.reminderText;
                var reminderDate= vm.set_date_edit;
                var reminderTime = vm.record_time_edit;
                var reminderDate=moment(vm.set_date_edit+' '+vm.record_time_edit,"dddd, MMMM Do hh:mm a").toISOString();
               
                 AddReminders.setReminders(reminderData,reminderDate).then(
                    function(res){
                        console.log(res);
                        vm.reminderText=null;
                         vm.set_date_edit=null;
                         vm.record_time_edit=null;
                        $state.go("myReminders");            
                    },
                    function(err){
                 $cordovaDialogs.alert($filter('translate')('SETREMINDER.ERRORTEXT'),[$filter('translate')('QUESTFORDOCTOR.BUTTON1')])
                 .then(function(buttonIndex) {
                       
                    });                 
                    });
                }              
            }
            vm.updateReminder = function(){
             var reminderData = vm.reminderText;
             var reminderDate=moment(vm.set_date_edit+' '+vm.record_time_edit,"dddd, MMMM Do hh:mm a").toISOString();
                console.log("oldReminderText",vm.oldReminderText,"oldRecordedDate",vm.oldRecordedDate);
               AddReminders.updateReminders(vm.oldReminderText,vm.oldRecordedDate,reminderData,reminderDate).then(
                    function(res){
                        console.log(res); 
                        // $state.go("myReminders");
                         $state.go('myReminders', {cameFrom:"editReminder"});       
                    },
                    function(err){

                        console.log(err);  
                    });
            }
            vm.goToReminders = function(){
                vm.reminderText=null;
                vm.set_date_edit=null;
                vm.record_time_edit=null;
              $state.go('tab.profileMain');
               }
            vm.goBack = function(){
                vm.reminderText=null;
                vm.set_date_edit=null;
                vm.record_time_edit=null;
               $state.go('myReminders', {cameFrom:"editReminder"});   
            }
          
            vm.deleteReminder=function(){
                 $cordovaDialogs.confirm($filter('translate')('SETREMINDER.DIALOGTEXT'), $filter('translate')('SETREMINDER.DIALOGTITLE'), [$filter('translate')('QUESTFORDOCTOR.BUTTON'),$filter('translate')('QUESTFORDOCTOR.BUTTON2')])
                .then(function(buttonIndex) {
                // no button = 0, 'OK' = 1, 'Cancel' = 2
                        if(buttonIndex==1){
                            AddReminders.deleteReminder(vm.oldReminderText,vm.oldRecordedDate).then(
                                    function(res){    
                                    $state.go('myReminders', {cameFrom:"editReminder"});                 
                                    },
                                    function(err){
                                      console.log(err);  
                          });
                            // vm.Reminders.splice(vm.Reminders.indexOf(item), 1);
                            // console.log(vm.Reminders.length);
                            // if(vm.Reminders.length==0){
                            //    vm.showlist=false;
                            // }
                        }
                });

            }
            vm.dateCheck=function(date){
                  var date = new Date(date);
                  var  year = date.getFullYear();
                  var  month = date.getMonth()+1;
                  var  dt = date.getDate();

                    if (dt < 10) {
                    dt = '0' + dt;
                    }
                    if (month < 10) {
                    month = '0' + month;
                    }
                    return year+'-' + month + '-'+dt;        
            }
             vm.TimeCheck=function(time){
                 var selectedTime = new Date(time * 1000);
                // console.log('Selected epoch is : ', val, 'and the time is ', selectedTime.getUTCHours(), 'H :', selectedTime.getUTCMinutes(), 'M');
                  var ampm = selectedTime.getUTCHours() >= 12 ? 'PM' : 'AM';
                 var hours = selectedTime.getUTCHours() % 12;
                             hours = hours ? hours : 12;
                 var minutes = selectedTime.getUTCMinutes();
                    if (minutes< 10) {
                          minutes = "0" + minutes;
                        }     
                return hours+ ':'+minutes+' '+ ampm;
            }

            vm.selectDate =function(){
             var ipObj1 = {
              callback: function (val) {  //Mandatory
                console.log('Return value from the datepicker popup is : ' + val);              
                vm.set_date_edit=moment(val).format("dddd, MMMM Do");
                if(vm.record_time_edit){
                    var datechek=vm.dateCheck(new Date(val).toISOString());
                      var d = new Date().toISOString();
                      var currentDate=vm.dateCheck(d);
                      if(datechek==currentDate){
                       var display_time = (((new Date()).getHours() * 60 * 60) + ((new Date()).getMinutes() * 60));  
                        var checkTime=vm.TimeCheck(display_time);
                        console.log("checkTime",checkTime);
                        var beginningTime = moment(vm.record_time_edit ,'h:mma');
                         var endTime = moment(checkTime, 'h:mma');
                         console.log("beginningTime",beginningTime);
                         console.log("endTime",endTime); 
                         if(beginningTime.isBefore(endTime)){
                         vm.set_date_edit='';
                        //  vm.record_time_edit='';
                         $cordovaDialogs.alert($filter('translate')('EVENT.PAST_TIME'),[$filter('translate')('QUESTFORDOCTOR.BUTTON1')])
                         .then(function(buttonIndex) {
                                        
                         });

                         }    
                      }
                }
              },
              from: new Date(), //Optional
            //  to: new Date(2016, 10, 30), //Optional
              inputDate: new Date(),      //Optional
              mondayFirst: true,          //Optional
              closeOnSelect: false,       //Optional
              templateType: 'popup',      //Optional
              dateFormat: 'dd MMMM yyyy',
            };
              ionicDatePicker.openDatePicker(ipObj1);
            }
           vm.openTimer= function(isEdit,time_edit){
        
               if(vm.set_date_edit){
                   var a=moment(vm.set_date_edit,"dddd, MMMM Do").toISOString();
                   var d = new Date().toISOString();
                var selected_date = vm.dateCheck(a);
                var current_Date = vm.dateCheck(d); 
                console.log("selected_date",selected_date);
                console.log("current_Date",current_Date);
                if(selected_date==current_Date){
                  vm.avoidPastTime=true;
                }else{
                     vm.avoidPastTime=false;
                }
            
               }
              if(time_edit){
                var momentObj = moment(time_edit, ["h:mm A"]).format("HH:mm");
                var display_time = moment.duration(momentObj).asSeconds()
              }else{
                var display_time = (((new Date()).getHours() * 60 * 60) + ((new Date()).getMinutes() * 60));
              }

              console.log("open Timmer")
            var ipObj = {
                            callback: function (val) {  //Mandatory
                             
                            if (typeof (val) === 'undefined') {
                                 console.log('Time not selected');
                            } else {
                            var selectedTime = new Date(val * 1000);
                               // console.log('Selected epoch is : ', val, 'and the time is ', selectedTime.getUTCHours(), 'H :', selectedTime.getUTCMinutes(), 'M');
                                var ampm = selectedTime.getUTCHours() >= 12 ? 'PM' : 'AM';
                                var hours = selectedTime.getUTCHours() % 12;
                                    hours = hours ? hours : 12;
                                var minutes = selectedTime.getUTCMinutes();
                                if (minutes< 10) {
                                    minutes = "0" + minutes;
                                }    
                     
                                if(isEdit){
                                    vm.record_time_edit = hours+ ':'+minutes+' '+ ampm;
                                    console.log('vm.record_time_edit',vm.record_time_edit);
                                    if( vm.avoidPastTime==true){
                                       var display_time = (((new Date()).getHours() * 60 * 60) + ((new Date()).getMinutes() * 60));  
                                       var checkTime=vm.TimeCheck(display_time);
                                       console.log("checkTime",checkTime);
                                       var beginningTime = moment(vm.record_time_edit ,'h:mma');
                                        var endTime = moment(checkTime, 'h:mma');
                                        console.log("beginningTime",beginningTime);
                                           console.log("endTime",endTime);
                                       
                                        if(beginningTime.isBefore(endTime)){
                                          vm.record_time_edit='';
                                          $cordovaDialogs.alert($filter('translate')('EVENT.PAST_TIME'),[$filter('translate')('QUESTFORDOCTOR.BUTTON1')])
                                          .then(function(buttonIndex) {
                                        
                                           });

                                        }
                                    }
                                }else{
                                      
                                    vm.record_time = hours+ ':'+minutes+' '+ ampm;
                                }
                         vm.chooseTime = true;
                            }
                            },
                            inputTime: display_time, 
                            format: 12,        
                            step: 1,          
                            setLabel: 'Set'
                  };

                ionicTimePicker.openTimePicker(ipObj);
            }
		}
				
})();