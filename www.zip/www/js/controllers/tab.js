(function () {
    'use strict';
	  angular
      .module('app.controllers')
      .controller('tab', tab);
	   tab.$inject = ['$scope', '$state','$ionicModal','$ionicPlatform','$timeout','SendEHSPin','$cordovaNetwork','$cordovaDialogs','$filter','$ionicLoading','$ionicScrollDelegate'];
	   
	   function tab($scope, $state,$ionicModal,$ionicPlatform,$timeout,SendEHSPin,$cordovaNetwork,$cordovaDialogs,$filter,$ionicLoading,$ionicScrollDelegate) {
          var vm = this;
          vm.isModalShown;
          
          $ionicModal.fromTemplateUrl('templates/verifyPin.html', {
                scope: $scope,
                animation: 'slide-in-up'
            }).then(function(modal) {
                $scope.verifyPin = modal;
                 if(window.localStorage.getItem("pinValues") != null){
                         $scope.verifyPin.show();
                         vm.isModalShown=true;
                     }

                  SendEHSPin.verifyApp(window.localStorage.getItem("ehsInstDate"));
           });
        $ionicPlatform.ready(function() {
                document.addEventListener("resume", function() {
                    if(window.localStorage.getItem("pinValues") != null){
                    	    vm.showVerifyPin = true;
						   	vm.showSendMail = false;
						   	vm.wrongPin = false;
						   	vm.mailSent = false;
							vm.pins = [0,1,2,3];
							vm.verifyPassword ='';
							vm.verifyPinDotVisible = {};
							vm.storedPIN = JSON.parse(localStorage.getItem('pinValues'));
                            $scope.verifyPin.show();
                            $ionicScrollDelegate.scrollTop();
                            vm.isModalShown=true;
                    }
                     SendEHSPin.verifyApp(window.localStorage.getItem("ehsInstDate"));
                }, false);

                $ionicPlatform.registerBackButtonAction(function () {
			        console.log("$state.current.name",$state.current.name);
			      if (vm.isModalShown) {       
			        return;
			      } else {
			        window.history.back();
			      }
			      }, 1000);
               
        });
        $scope.$on('$ionicView.beforeEnter', function (event, viewData) {
        	 $ionicLoading.hide().then(function(){
                             console.log("The loading indicator is now hidden");
                         });
             
		    vm.showVerifyPin = true;
		   	vm.showSendMail = false;
		   	vm.wrongPin = false;
		   	vm.mailSent = false;
			vm.pins = [0,1,2,3];
			vm.verifyPassword ='';
			vm.verifyPinDotVisible = {};
			vm.storedPIN = JSON.parse(localStorage.getItem('pinValues'));
			
		});

        

        vm.keyboardSettings = {
		showLetters: true,
		//theme: 'dark',
		
		action: function(number) {
			if (vm.verifyPassword.length < 4)
			{
				vm.verifyPassword += number;
				vm.verifyPinDotVisible[vm.verifyPassword.length] = true;
				vm.wrongPin = null;
			}
			$timeout(function(){
			if(vm.verifyPassword.length == 4)
			{
				console.log("lenth 4");
					if(vm.verifyPassword == vm.storedPIN)
					{
						console.log("lenth hide"+vm.storedPIN);
						$scope.verifyPin.hide();
						vm.isModalShown=false;
					}
					else
					{
						console.log("lenth hide");
						vm.wrongPin = true;
						vm.verifyPassword = '';
						vm.verifyPinDotVisible = {};
					}
			}
			},500);
		},
		//no button
		leftButton: {
			html: '',
			action: function() {},
			style: {
				color: '#fff',
				bgColor: '#bbb',
				activeBgColor: 'rgba(0, 0, 0, 0.50)',
				borderColor: 'transparent'
			}
		},

		// Backspace key
		rightButton: {
			html: '<i class="icon ion-backspace"></i>',
			action: function() 
			{
					vm.verifyPassword = '';
					vm.verifyPinDotVisible = {};
			},
			style: 
			{
				color: '#555',
				bgColor: '#bbb',
				activeBgColor: 'rgba(0, 0, 0, 0.50)',
				borderColor: 'transparent'
			}
		}
	}

	   		vm.forgetPin = function(){
	   			vm.verifyPassword = '';
				vm.verifyPinDotVisible = {};
	   			vm.showSendMail = true;
	   			vm.showVerifyPin = false;
	   			vm.wrongPin = false;
	   		}

			vm.sendMail = function(){
				if($cordovaNetwork.isOnline()){
					vm.storedPIN = JSON.parse(localStorage.getItem('pinValues'));
                	console.log(vm.storedPIN);
					var userData = {
            			pin:vm.storedPIN,
            			email:window.localStorage.getItem('userMail')
          			}
          			SendEHSPin.sendPin(userData).then(function(res){
            			console.log(res);
          			},function(err){
            			console.log(err);
          			});
          			vm.showSendMail = false; 
          			vm.showVerifyPin = false;
          			vm.mailSent = true;
				}
				else {
				 $cordovaDialogs.alert($filter('translate')('VERIFYPIN.NETWORK_MSG'), $filter('translate')('VERIFYPIN.NETWORK_ERROR'), $filter('translate')('QUESTFORDOCTOR.BUTTON1'))
                .then(function() {
                        console.log("network error");
                        return;
                });
					return;
				}				
			}
	     }	   
})();