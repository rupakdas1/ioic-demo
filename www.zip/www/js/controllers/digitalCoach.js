(function() {
	'use strict';
	
	 angular
      .module('app.controllers')
      .controller('digitalCoach', digitalCoach);
	   digitalCoach.$inject = ['$scope', '$state','Chats','$ionicScrollDelegate','$filter','$ionicTabsDelegate','$timeout','$cordovaKeyboard','focus','$ionicPlatform','AddReminders'];
	   
	   function digitalCoach($scope, $state, Chats,$ionicScrollDelegate,$filter,$ionicTabsDelegate,$timeout,$cordovaKeyboard,focus,$ionicPlatform,AddReminders) {
       
	   $ionicTabsDelegate.showBar(false);
	    $scope.$on('$ionicView.beforeEnter', function (event, viewData) {
				if(window.localStorage.getItem("returnUser")!="Y"){
					 vm.msgName=false;
                     vm.showInput = false;
				}
				 $ionicPlatform.ready(function() {
                  // screen.lockOrientation('portrait')
                }); 

			});
		 var vm = this;
		 
		 vm.outsideTab=true;
         vm.chats=Chats.all();
         vm.messages=[];
		 vm.namePara="";
		 vm.greeting = "";
		 vm.isSmoking=window.localStorage.getItem("isSmoking");
		 vm.isAlchoholic=window.localStorage.getItem("isAlchoholic");
		 $ionicScrollDelegate.resize();
		 /* =================Get name from localStorage====================== */ 
		 if(window.localStorage.getItem("person_name") != null){
            vm.namePara=window.localStorage.getItem("person_name").split(' ')[0];
		 }
		 /* =================Setting up a greeting text randomly====================== */ 
		 var random = Math.floor(Math.random() * 3) + 1;
		  switch (random) {
					case 1:
						  vm.greeting = $filter('translate')('DIGITALCOACH.GREETING5') + vm.namePara;
						break;
					case 2:
						  vm.greeting = $filter('translate')('DIGITALCOACH.GREETING6.OPT1') + vm.namePara+$filter('translate')('DIGITALCOACH.GREETING6.OPT2');
						break;
					case 3:
					      vm.greeting = $filter('translate')('DIGITALCOACH.GREETING7.OPT1') + vm.namePara+$filter('translate')('DIGITALCOACH.GREETING7.OPT2')
		  }
           if(window.localStorage.getItem("returnUser")=="Y"){
						$ionicTabsDelegate.showBar(true);
						vm.outsideTab=false;
						 AddReminders.getLengthOfAppointments().then(
							function(res){
								if(window.localStorage.getItem('isEDMedTaken')!='Y'){
									vm.currentQues=vm.chats[38].Ques;
									vm.questionToAsk=Chats.getQuestion(38);
									vm.messages.push(vm.questionToAsk.Answer);
								}
								else{
									vm.currentQues=vm.chats[40].Ques;
									vm.questionToAsk=Chats.getQuestion(40);
									vm.messages.push(vm.questionToAsk.Answer);
								}
							},
							function(err){
								vm.currentQues=vm.chats[50].Ques;
								vm.questionToAsk=Chats.getQuestion(50);
								vm.messages.push(vm.questionToAsk.Answer);
						     });
						vm.returnUser=true;
			}
			else {
						vm.currentQues=vm.chats[0].Ques;
						vm.returnUser=false;
			}
		
		  var scrollUp = function(){
			  $timeout(function(){
			   var clientHeight = document.getElementById('bottomQues').clientHeight;
               document.getElementById('dummyDiv').style.height = clientHeight + "px";
			   $ionicScrollDelegate.resize();
			   $ionicScrollDelegate.scrollBottom(true);
		   },100);
		 }
		vm.getQuestion = function(data){
			vm.questionToAsk=Chats.getQuestion(data.no);
			switchCalled(data)
			vm.messages.push(data); //pusshing that question to be asked in array
			vm.messages.push(vm.questionToAsk.Answer);//pushing answer also
			vm.currentQues=vm.questionToAsk.Ques;// assgining further question to ask
			scrollUp();
        }
		  /* =================Switch Digital coach====================== */ 
        var switchCalled = function(data){
			 switch (data.no) {
					case '46':
						  vm.isSmoking=data.Answer1;//data to be saved
						  window.localStorage.setItem("isSmoking",vm.isSmoking);
						break;
					case '100':
						 vm.isAlchoholic=data.Answer1; //data to be saved
						 console.log(vm.isAlchoholic)
							if(vm.isSmoking == "No" && vm.isAlchoholic == "No"){
								data.no=47;
								vm.questionToAsk=Chats.getQuestion(data.no);
								window.localStorage.setItem("isAlchoholic",vm.isAlchoholic);
							}
							else{
								data.no=48;
								vm.questionToAsk=Chats.getQuestion(data.no);
							}
						break;
					case '20':
						if(vm.isSmoking == "No" && vm.isAlchoholic == "No"){
							data.no=49;
							vm.questionToAsk=Chats.getQuestion(data.no);
						}
						break;
					case '23':
					    if(vm.isSmoking == "No" && vm.isAlchoholic == "No"){
						 vm.questionToAsk.Answer.Answer1=[$filter('translate')('DIGITALCOACH.ANSWER23.OPT1')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER23.OPT2')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER23.OPT31')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER23.OPT4')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER23.OPT5')];
						}
						 else if(vm.isSmoking == "No" && (vm.isAlchoholic == "Yes" || vm.isAlchoholic == "Skip for now")){
						 vm.questionToAsk.Answer.Answer1=[$filter('translate')('DIGITALCOACH.ANSWER23.OPT1')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER23.OPT2')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER23.OPT32')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER23.OPT4')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER23.OPT5')];
						}
						 else if((vm.isSmoking == "Yes" || vm.isSmoking == "Skip for now")  && vm.isAlchoholic == "No"){
						 vm.questionToAsk.Answer.Answer1=[$filter('translate')('DIGITALCOACH.ANSWER23.OPT1')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER23.OPT2')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER23.OPT33')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER23.OPT4')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER23.OPT5')];
						}
						 else {
						 vm.questionToAsk.Answer.Answer1=[$filter('translate')('DIGITALCOACH.ANSWER23.OPT1')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER23.OPT2')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER23.OPT34')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER23.OPT4')+"<br>"+$filter('translate')('DIGITALCOACH.ANSWER23.OPT5')];
						}
						break;
					case '27':
					    if(vm.isAlchoholic == "No"){
						   if(vm.questionToAsk.Ques.length>2){
							  vm.questionToAsk.Ques.splice(1, 1);
							}
						}
						break;
					case '28':
					    if(vm.isAlchoholic == "No"){
							if(vm.questionToAsk.Ques.length>2){
							  vm.questionToAsk.Ques.splice(0, 1);
							}
					    }
						break;
					case '30':
					    if(vm.isAlchoholic == "No"){
							if(vm.questionToAsk.Ques.length>2){
							  vm.questionToAsk.Ques.splice(1, 1);
							}
					    }
					   break;
					case '40':
					      window.localStorage.setItem('isEDMedTaken','Y');
						  break; 
					case '7':
					   if(window.localStorage.getItem("isSmoking") == "Yes" || window.localStorage.getItem("isSmoking") == "No")
					   {
						   if(window.localStorage.getItem("isSmoking") == "Yes" || window.localStorage.getItem("isSmoking") == "No")
						   {
							   console.log("i came")
							   data.no = '100';
							   switchCalled(data);
						   }
						   else{
							   data.no = '46';
							   vm.questionToAsk=Chats.getQuestion(data.no);
							   switchCalled(data);
						   }
						       
					   }
				}
		}
		 /* ================= Digital coach form changed====================== */ 
		vm.formChanged = function(){
					if(vm.user_name != ""){
						return true;
					}
			 	$ionicScrollDelegate.resize();
				return false;				
		}
		vm.msgName=false;
		
		  /* =================Set Name for user====================== */ 
		vm.setName = function(){
				window.localStorage.setItem("returnUser","Y");
				vm.namePara = vm.user_name;
				vm.namePara=vm.namePara.split(' ')[0];//setting only first name
				window.localStorage.setItem("person_name",vm.namePara)
				vm.messages.push(vm.chats[0].Answer);
				vm.msgName=true;
				vm.showInput = false;
				vm.skipName=false;
				$cordovaKeyboard.close();
				 $timeout(function(){
				 	$cordovaKeyboard.close();
				    document.getElementById('dummyDiv').style.height= 38 + "vh";
					$ionicScrollDelegate.resize();
					$ionicScrollDelegate.scrollBottom(true);
				 },10);

				return true;
				}
		vm.goToDigitalCoachTab = function(){
				$ionicTabsDelegate.showBar(true);
				vm.outsideTab=false;
				$ionicScrollDelegate.resize();	  
			   }
		vm.showInput=false;
		$timeout(function() {
          console.log('mandatory');
		}, 10);
		vm.openInput = function(){
				   $timeout(function(){
                       console.log('showKeyboard');
                      vm.showInput = true;
                      vm.msgName=true;
				   },1);
				   if(ionic.Platform.isAndroid()){
			         vm.showInput = true;
				   }
				   	$ionicScrollDelegate.resize();
			   }			    
		vm.openQues = function(){
			        window.localStorage.setItem("returnUser","Y");
					vm.msgName=true;
				    vm.showInput = false;
					vm.skipName=true;
				    vm.messages.push(vm.chats[0].Answer);
					 $timeout(function(){
					    document.getElementById('dummyDiv').style.height= 38 + "vh";
						$ionicScrollDelegate.scrollBottom(true);
						$ionicScrollDelegate.resize();
					 },5);
							    
			   }
		vm.gotQuestion =function(ans){
                   $state.go('askQuestion',{ans:ans});
			   }
		vm.goTotAndC = function(){
			      $state.go('tAndC',{cameFrom:"digitalCoach"});
		}
		vm.goToHowTo = function(){
			      $state.go('dcHowTo');
		} 
		}
				
})();