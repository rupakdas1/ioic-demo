(function() {
	'use strict';
	
	 angular
      .module('app.controllers')
      .controller('myAppointments', myAppointments);
	   myAppointments.$inject = ['$scope', '$state', '$window','$ionicModal','$cordovaDialogs','$filter','AddReminders','$ionicListDelegate'];
	   
	   function myAppointments($scope, $state, $window,$ionicModal,$cordovaDialogs,$filter,AddReminders,$ionicListDelegate) {
	   	var vm = this;
           vm.showlist=true;
           vm.Appointments=[];
            $scope.$on('$ionicView.beforeEnter', function (event, viewData) {
            $ionicListDelegate.closeOptionButtons();
            AddReminders.getAppointments().then(
                    function(res){
                          if(viewData.stateParams.cameFrom=="editAppointment"){
                          vm.Appointments = AddReminders.getAppointmentsFromService();
                          vm.Appointments = res;
                          AddReminders.storeAppointmentsInService(vm.Appointments);
                          }
                          else{
                            console.log("else",AddReminders.getAppointmentsFromService());
                              for(var i = 0;i < res.length;i++){
                              vm.Appointments[i] =res[i];
                            }
                            AddReminders.storeAppointmentsInService(vm.Appointments);
                            console.log(vm.Appointments);
                           }
                          vm.showlist=true;                         
                          },
                        function(err){
                            vm.showlist=false;
                           $state.go('tab.profileMain');
                             vm.Appointments = [];
                        });
        
        });
	   	
		  vm.onItemDelete = function(item) {
        console.log("item",item)
                 $cordovaDialogs.confirm($filter('translate')('APPOINTMENT.DIALOGTEXT'), $filter('translate')('APPOINTMENT.DIALOGTITLE'), [$filter('translate')('QUESTFORDOCTOR.BUTTON'),$filter('translate')('QUESTFORDOCTOR.BUTTON2')])
                .then(function(buttonIndex) {
                // no button = 0, 'OK' = 1, 'Cancel' = 2
                        if(buttonIndex==1){
                            AddReminders.deleteAppointment(item.appointment_name).then(
                                    function(res){                  
                                    },
                                    function(err){
                                      console.log(err);  
              });
                            vm.Appointments.splice(vm.Appointments.indexOf(item), 1);
                            console.log(vm.Appointments.length);
                            if(vm.Appointments.length==0){
                               vm.showlist=false;
                                $state.go('tab.profileMain');
                                  vm.Appointments = [];
                            }
                        }
                });
      };
      vm.goToEditAppointments = function(item){

      $state.go('editAppointment',{items:JSON.stringify(item)});
      vm.Appointments = [];
      }
      vm.goCreateAppointment=function(){
       
        $state.go('createAppointment');
          vm.Appointments = [];
      }
	   	vm.goBack =  function(){
           $state.go('tab.profileMain');
             vm.Appointments = [];
        }
		}
	   
	}
)();