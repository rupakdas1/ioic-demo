(function() {
	'use strict';
	
	 angular
      .module('app.controllers')
      .controller('enterPin', enterPin);

	   enterPin.$inject = ['$scope', '$state', '$window', '$timeout','$cordovaKeyboard'];
	   
	   function enterPin($scope, $state, $window, $timeout,$cordovaKeyboard) {
	   	var vm = this;
			
		vm.enterEmail = false;
		vm.userEmail = '';  
		$scope.$on('$ionicView.beforeEnter', function (event, viewData) {
			vm.userEmail = null;  
	   	vm.enterEmail = false;
	   	vm.reEnterPin = false;
	   	vm.wrongPin = false;
	   	vm.pinSaved = true;
	   	vm.pins = [0,1,2,3];
	   	vm.finalPin = '';
	   	vm.password = '';
		vm.pinDotVisible = {};
		vm.validate_email = false;
		});
	 
	   	var getData="", storedData="";

		vm.keyboardSettings = {
		showLetters: true,
		//theme: 'dark',
		
		action: function(number) {
			if (vm.password.length < 4)
			{
				vm.password += number;
				vm.pinDotVisible[vm.password.length] = true;
				vm.wrongPin = null;
			}
			$timeout(function(){
			if(vm.password.length == 4)
			{
				if(!(vm.reEnterPin || vm.enterEmail))
				{
					
						vm.reEnterPin =true;

					vm.finalPin = vm.password;
					vm.password = '';
					vm.pinDotVisible = {};
					console.log(vm.finalPin);
				}
				else if(vm.reEnterPin && vm.pinSaved)
				{
					if(vm.password == vm.finalPin)
					{
						vm.enterEmail = true;
						vm.reEnterPin =false;
					}
					else
					{
						vm.wrongPin = true;
						vm.password = '';
						vm.pinDotVisible = {};
					}
				}
			}},500);
		},
		//no button
		leftButton: {
			html: '',
			action: function() {},
			style: {
				color: '#fff',
				bgColor: '#ddd',
				activeBgColor: 'rgba(0, 0, 0, 0.50)',
				borderColor: 'transparent'
			}
		},

		// Backspace key
		rightButton: {
			html: '<i class="icon ion-backspace"></i>',
			action: function() 
			{
					vm.password = '';
					vm.pinDotVisible = {};
			},
			style: 
			{
				color: '#555',
				bgColor: '#ddd',
				activeBgColor: 'rgba(0, 0, 0, 0.50)',
				borderColor: 'transparent'
			}
		}
	}


	   
	   
	  

	   	vm.goBack =  function(){
      	   $state.go('tab.settings');
        } 
        vm.validateEmail = function(emailForm){
			 vm.validate_email = emailForm.userEmail.$error.email;
		}
	
        vm.continue = function(emailForm,user) { 
			vm.validate_email = emailForm.userEmail.$error.email;
			if(vm.validate_email){
			  validate_email = false;
			}
			if(user == undefined){
				user = "";
			}
        	
		    localStorage.setItem("userMail", user);
			vm.pinSaved = false;
			       					
			localStorage.setItem("pinValues", JSON.stringify(vm.finalPin));
			getData = localStorage.getItem('pinValues');
			storedData = JSON.parse(getData);
			console.log(storedData);
			$cordovaKeyboard.close();
		};

		vm.goToSettings = function(){
				vm.enterEmail = true;
	   			vm.reEnterPin = false;
	   			vm.wrongPin = false;
	   			vm.pinSaved = true;
	   			vm.password = '';
	   			vm.finalPin = '';
	   			vm.pinDotVisible = {};
				$state.go('tab.settings');
		}
	   	   
	}
}
)();