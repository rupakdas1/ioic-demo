(function() {
  'use strict';
   angular
      .module('app.controllers')
      .controller('addRecords', addRecords);
     addRecords.$inject = ['$scope', '$state','$ionicScrollDelegate','AddRecords','Timeline','AddMedications', 'ionicTimePicker', '$stateParams','$ionicModal','$window','$ionicPopup','$cordovaDialogs','$filter','$ionicLoading','$ionicPlatform'];
     function addRecords($scope, $state,$ionicScrollDelegate,AddRecords,Timeline,AddMedications,ionicTimePicker,$stateParams,$ionicModal, $window,$ionicPopup,$cordovaDialogs,$filter,$ionicLoading,$ionicPlatform) {
           $scope.$on('$ionicView.beforeEnter', function (event, viewData) {
              
                AddMedications.getMedications().then(
                    function(res){
                     
                    vm.medication_names =[];
                    for(var i=0;i<res.length;i++){         
               vm.medication_names.push(res[i].medication_name);
                      }
            },
                    function(err){
                        console.log(err);  
                    });
                    vm.saveGradeChange = false;
                $ionicPlatform.ready(function() {
                   //screen.lockOrientation('portrait');
				   
				     
                }); 
				
				
                
            }); 

 			 $ionicPlatform.registerBackButtonAction(function () {
			        //console.log("$state.current.name",$state.current.name);

                    ionicTimePicker.openTimePicker();
			     
                }, 1000);
                

      var vm = this;
            vm.page_title = 1
            vm.active = null;
            vm.cur_date  =  new Date();
            vm.display_date = new Date();
            vm.waking_active = null;
            vm.last_long = {'level' : 0,'level_edit': 0};
            vm.exercise = {'level' : 0};
            vm.drink_active = "";
            vm.smoke_active  = "";
            vm.partner_active  = "";            
            vm.checkMedication = {};
            vm.showSmoke = true;
            vm.showDrink = true;
            vm.stress_active = '';
            vm.chooseTime = '';
            vm.saveGradeChange = false;
            vm.grade  = '';
            var grade,grade_date, is_wakeup, last_long_level, record_time;
            var exercise = "";
            var drink = "";
            var weight = "";
            var stress = "";
            var smoke = "";
            var medication = [];
            var lucky = "";
            var month_year = "";
            var dateData = "";
            var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
            // Last long slider on grade data
            vm.range_last_long = {  
                value:vm.last_long.level,           
                options: {
                floor: 0,
                ceil: 60,
                showSelectionBar: true
            }
            };
            // Last long slider on edit grade data
            vm.range_last_long_edit = {  
                value:vm.last_long.level_edit,           
                options: {
                floor: 0,
                ceil: 60,
                showSelectionBar: true
            }
            };
       // Exercise slider on non grade data
            vm.range_exercise = {  
                value:vm.exercise.level,           
                options: {
                floor: 0,
                ceil: 60,
                showSelectionBar: true
            }
            };
           /* =================Wieight scale  section===================== */
            vm.weightArr = [];      
            if(window.localStorage.getItem("isSmoking") == "No")
                vm.showSmoke = false;
             if(window.localStorage.getItem("isAlchoholic") == "No")
                vm.showDrink = false;
            for(var i = 0; i <= 215; i =i+5){
                vm.weightArr.push(i);
            }
            vm.weight_selected="";
            var multiplier=50;
            vm.clickItem = function(idx){
                var left = idx*multiplier-multiplier*4.5;
                var left1 = idx*multiplier-multiplier*3;
                $ionicScrollDelegate.$getByHandle('mainScroll').scrollTo(left1, 0, true);
            }
            vm.onScrollWeight = function(){
                //console.log($ionicScrollDelegate.$getByHandle('mainScroll').getScrollPosition());
                var left = $ionicScrollDelegate.$getByHandle('mainScroll').getScrollPosition().left;     
                vm.weight_selected = Math.round((((left+multiplier*5)/10)-10))
                $scope.$apply();
            }                
        /* =================Delete a record confirmation===================== */
            vm.showConfirm = function() {
                 $cordovaDialogs.confirm($filter('translate')('ADD_RECORD.LINE16'), $filter('translate')('ADD_RECORD.LINE17'), [$filter('translate')('QUESTFORDOCTOR.BUTTON1'),$filter('translate')('QUESTFORDOCTOR.BUTTON2')])
                .then(function(buttonIndex) {
                        if(buttonIndex==1){
                          console.log("asf")
                            AddRecords.deleteRecord(vm.display_date).then(function(res){
                            if(res == 1){
                                console.log(vm.display_date);
                                 $ionicLoading.show({
                                    template: 'Loading...',
                                    duration: 3000
                                    }).then(function(){
                                    console.log("The loading indicator is now displayed");
                                    });
                                     Timeline.setTimelineParams(vm.display_date);
                                $state.go('tab.timeline');    
                            }
                          });
                        }
                });
            };
             /* =================Grade related Data====================== */
             vm.gradeData = {
                grades:{
                    items: [{
                            text: '1',
                            clickText: $filter('translate')('ADD_RECORD.GRADES.clickText1')
                        },{
                            text: '2',
                            clickText:  $filter('translate')('ADD_RECORD.GRADES.clickText2')
                        },{
                            text: '3',
                            clickText:  $filter('translate')('ADD_RECORD.GRADES.clickText3')
                        },
                        {
                            text: '4',
                            clickText:  $filter('translate')('ADD_RECORD.GRADES.clickText4')
                        }
                    ]
                },                
                lucky:{
                    items: [{
                            class: 'icon-spouse',                             
                            text:  $filter('translate')('ADD_RECORD.LUCKY.text1')  
                        },{
                            class: 'icon-partner',

                            text:  $filter('translate')('ADD_RECORD.LUCKY.text2')   
                        },{
                            class: 'icon-solo',
                            text:  $filter('translate')('ADD_RECORD.LUCKY.text3')   
                        }
                    ]
                },   
                waking:{
                    items : [{

                        text:  $filter('translate')('ADD_RECORD.WALKING.text1')    
                    },{

                         text:  $filter('translate')('ADD_RECORD.WALKING.text2')
                    }]
                }
            }
             /* =================Non Grade related Data====================== */
            vm.nonGradeData = {
                smokes:{
                        items: [{
                            class: '',
                            text:  $filter('translate')('ADD_RECORD.SMOKES.no_smoke')                  
                        },{
                            class: 'icon-smoke-less',
                            text:  $filter('translate')('ADD_RECORD.SMOKES.smoke_less')               
                        },{
                            class: 'icon-smoke-plus',
                            text:  $filter('translate')('ADD_RECORD.SMOKES.smoke_plus')
                        }
                        ]
                    },
                drinks : {
                    items: [{
                        text:  $filter('translate')('ADD_RECORD.DRINKS.text1')    
                    },{
                        text:  $filter('translate')('ADD_RECORD.DRINKS.text2')
                    },{
                        text:  $filter('translate')('ADD_RECORD.DRINKS.text3')
                    }
                    ]
                },
                partners : {
                    items: [{
                       text:  $filter('translate')('ADD_RECORD.STRESS.text1')   
                    },{
                       text:  $filter('translate')('ADD_RECORD.STRESS.text2')               
                    },{
                       text:  $filter('translate')('ADD_RECORD.STRESS.text3')
                    }
                    ]
                }
            }
       //Stress click
            vm.stressClick = function(index) {              
                vm.stress_active = index;  
            };
             //Smoke click
            vm.smokeClick = function(index) {               
                vm.smoke_active = index;
                smoke = vm.nonGradeData.smokes.items[index].text;
            }; 
            /* =================Record by date====================== */
            if($stateParams.record_by_date){
                var c = JSON.parse($stateParams.record_by_date);
                vm.display_date = c[0].date;
                vm.prev_grade = [];
                for(var i = 0; i< c.length; i++){
                     // Grade data
                    if(c[i].grade_first != null && c[i].grade_first != 'undefined')                      
                        vm.prev_grade.push(JSON.parse(c[i].grade_first));
                    if(c[i].grade_second != null && c[i].grade_second != 'undefined')              
                         vm.prev_grade.push(JSON.parse(c[i].grade_second));                 
                    if(c[i].grade_third != null &&  c[i].grade_third != 'undefined')                         
                       vm.prev_grade.push(JSON.parse(c[i].grade_third));
                         // Non Grade data                       
                        vm.drink_active = c[i].drinks;

                      //  vm.smoke_active = c[i].smoke;
                        if(c[i].smoke == 0){
                            vm.smokeClick(0)
                        }else if(c[i].smoke == '<1'){
                             vm.smokeClick(1)
                        }else{
                             vm.smokeClick(2)
                        }

            vm.stressClick(parseInt(c[i].stress));
                        vm.range_exercise.value = c[i].exercise;
                        vm.date_of_record = c[i].date;
                        vm.weight_selected = c[i].weight;
                         if(c[i].medication.length > 0){
                            var madication_for_date = JSON.parse(c[i].medication);          
                            angular.forEach(madication_for_date, function(value, key) {
                            vm.checkMedication[value] = true
                            });
                        }    
                        vm.page_title = 2;
                        vm.showSave = true
                }
                console.log(vm.prev_grade)
            }
            /* Prev date entry */
             if($stateParams.record_date){
                 vm.display_date = $stateParams.record_date;
             }
             /* =================Edit Grade Modal====================== */
            $ionicModal.fromTemplateUrl('templates/editGradeModal.html', {
                scope: $scope,
                animation: 'slide-in-up'
            }).then(function(modal) {
                $scope.editGrademodal = modal;
            });           
            vm.getRowId = 0;
               var gradeSl;
            vm.editGrade = function(grade_date,grade_sl){   
                gradeSl = grade_sl;                
                AddRecords.getGradeData(grade_date,grade_sl).then(
                     function(res){                                 
                            var gd_data = JSON.parse(res)
                            vm.grade_edit = gd_data.grade;
                            vm.gradeTxt_edit = vm.gradeData.grades.items[gd_data.grade-1].clickText;
                            vm.waking_active_edit = gd_data.is_wakeup;
                            vm.record_time_edit = gd_data.record_time;
                            vm.range_last_long_edit.value = gd_data.last_long_level;
                            lucky = gd_data.luckyData;
                            is_wakeup = gd_data.is_wakeup;                   
                            switch(gd_data.luckyData){
                                case 'Spouse':
                                    vm.lucky_active_edit = 0;
                                    break;
                                case 'New Partner':
                                    vm.lucky_active_edit = 1;
                                    break;
                                case 'Solo':
                                    vm.lucky_active_edit = 2;
                                    break;
                            }
                           $scope.editGrademodal.show();
                    },
                    function(err){
                        console.log(err);  
                    });
            }
        /* =================Close Modal Popup====================== */
            vm.closeModal = function(modalType){
                if(modalType == 'editGrade'){
                    vm.active_edit = '';
                    vm.grade_edit = '';
                    vm.saveGradeChange = false;              
                  $scope.editGrademodal.hide();
                }
                else if(modalType == 'medicate'){
                    vm.medication_input = '';
                    vm.medication_err = false;         
                     $scope.addMedication.hide();
                }
            }                
          vm.gradeClick = function(index,isEdit) {
      vm.showSave = false;
      vm.grade_l = true;
            if(isEdit){
                vm.active_edit = index;
                vm.grade_edit = index+1;
                vm.gradeTxt_edit = vm.gradeData.grades.items[index].clickText;
            }else{
                vm.active = index;
                vm.gradeTxt = vm.gradeData.grades.items[index].clickText;
                 vm.grade = index+1; 
            } 
            var gradeDate = "";
            if($stateParams.record_by_date){
                    var recordData = JSON.parse($stateParams.record_by_date);
                    gradeDate = recordData[0].date;
            }else if($stateParams.record_date){
                    gradeDate = $stateParams.record_date;
            }else{
                var dateData = new Date();
                gradeDate = dateData.toISOString().split("T")[0];
            }
            grade_date = gradeDate; 
          }
           vm.wakingClick = function(index,isEdit) {
      vm.walking = true
               if(isEdit){
                   vm.waking_active_edit =  index;
                   is_wakeup = index; 
               }else{
                vm.waking_active = index;      
                is_wakeup = index;      
               }                           
          }
           vm.luckyClick = function(index,isEdit){
        vm.lucky = true
               if(isEdit){
                    vm.lucky_active_edit = index;
                    lucky = vm.gradeData.lucky.items[index].text;
               }else{
                    vm.lucky_active = index;
                    lucky = vm.gradeData.lucky.items[index].text;                   
               }
          }
      vm.drinkClick = function(index) {
            vm.drink_active = index;
            drink = vm.nonGradeData.drinks.items[index].text;
          };
                
          vm.goBack = function(){
              console.log('vm.saveGradeChange ' +vm.saveGradeChange);
              if(vm.saveGradeChange){
                 Timeline.setTimelineParams(vm.display_date);
                  $state.go('tab.timeline');
              }
              else{
                   Timeline.setTimelineParams('cancel');
                   $state.go('tab.timeline');
                
              }
                
          }
          /* =================Save Medication ====================== */            
           vm.saveMedication = function(){
              if(vm.medication_input != ""){
                var medicationData = vm.medication_input;       
                 AddMedications.setMedications(medicationData).then(function(res){
                            AddMedications.getMedications().then(
                            function(res){
                                vm.medication_names =[];
                             for(var i=0;i<res.length;i++){        
                                    vm.medication_names.push(res[i].medication_name);
                                }                                                                                     
                            },
                            function(err){
                                console.log(err);
                            });       
                            $scope.addMedication.hide();
                        },function(err){
                            vm.medication_err = 1;
                        });
                }              
            }
             $ionicModal.fromTemplateUrl('templates/addMedication.html', {
                scope: $scope,
                animation: 'slide-in-up'
            }).then(function(modal) {
                $scope.addMedication = modal;
            }); 
          vm.navigateToMedication = function(){
                vm.medication_input = '';
                $scope.addMedication.show();
          }  
      vm.textUpdate = function(){
         vm.medication_err = false;             
      }       
     /* =================Time Picker====================== */
        vm.openTimer= function(isEdit, time_edit){
      if(time_edit){
        var momentObj = moment(time_edit, ["h:mm A"]).format("HH:mm");
        var display_time = moment.duration(momentObj).asSeconds()
      }else{
        var display_time = (((new Date()).getHours() * 60 * 60) + ((new Date()).getMinutes() * 60))
      }
            var ipObj = {
            callback: function (val) {//Mandatory
            if (typeof (val) === 'undefined') {
                 console.log('Time not selected');
            } else {
            var selectedTime = new Date(val * 1000);
               // console.log('Selected epoch is : ', val, 'and the time is ', selectedTime.getUTCHours(), 'H :', selectedTime.getUTCMinutes(), 'M');
                var ampm = selectedTime.getUTCHours() >= 12 ? 'PM' : 'AM';
                var hours = selectedTime.getUTCHours() % 12;
                    hours = hours ? hours : 12;
                var minutes = selectedTime.getUTCMinutes();
                if (minutes< 10) {
                    minutes = "0" + minutes;
                }    
     
                if(isEdit){
                    vm.record_time_edit = hours+ ':'+minutes+' '+ ampm;
                }else{
                    vm.record_time = hours+ ':'+minutes+' '+ ampm;
                }
         vm.chooseTime = true;
            }
            },
            inputTime: display_time, 
            format: 12,        
            step: 5,          
            setLabel: 'Set'
            };
            ionicTimePicker.openTimePicker(ipObj);
        }
        /* =================save a record====================== */
          vm.saveRecord = function(){
          // vm.grade_l &&  vm.chooseTime
            if(vm.grade != '' && vm.chooseTime == '' ){
                  $cordovaDialogs.alert($filter('translate')('ADD_RECORD.ALERT_TEXT'), $filter('translate')('ADD_RECORD.ALERT'),[$filter('translate')('QUESTFORDOCTOR.BUTTON1')])
                     .then(function(buttonIndex) {
                     
                    });   
                      return;
            }
        
              var monthYear = "";
               medication = [];
               if(Object.keys(vm.checkMedication).length > 0){
                    for(var i in vm.checkMedication) {
                        if(vm.checkMedication[i] == true) {
                        medication.push(i);
                        }
                    }
               }             
               var presentDate = new Date();
                dateData = new Date();
                 if($stateParams.record_by_date){
                   var recordData = JSON.parse($stateParams.record_by_date);
                   dateData = recordData[0].date;
                   var monthIndex = dateData[5] + dateData[6];
                   monthYear = months[(monthIndex-'0')-1] + '_'+dateData.split("-")[0] ;
                   console.log(monthYear);
                }else if( $stateParams.record_date){
                    dateData = $stateParams.record_date;
                    var monthIndex = dateData[5] + dateData[6];
                   monthYear = months[(monthIndex-'0')-1] + '_'+dateData.split("-")[0] ;
                }
                else{                   
                    dateData = new Date();
                    monthYear = months[dateData.getMonth()] + '_' + dateData.getFullYear();
                    dateData = dateData.toISOString().split("T")[0];                                                      
                }
                var recordData = {
                    date: dateData,
                    month_year : monthYear, 
                    gradeValueData:{
                        grade : vm.grade,
                        record_time: vm.record_time ? vm.record_time: AddRecords.currentTime(presentDate),
                        date : grade_date,
                        luckyData:lucky,
                        is_wakeup: is_wakeup,
                        last_long_level: vm.range_last_long.value
                    },
                    exerciseData:vm.range_exercise.value,
                    drinkData:(drink)?drink:vm.drink_active,
                    smokeData :(smoke)?smoke:vm.smoke_active,
                    weightData:vm.weight_selected,
                    stressData:vm.stress_active,
                    medicationData:medication                    
                }
           if(localStorage.getItem(dateData) >= 0 && localStorage.getItem(dateData) != null){
               //console.log("currentRowId");
            AddRecords.setRecords(recordData,1, vm.prev_grade);
             Timeline.setTimelineParams(vm.display_date);
            $state.go('tab.timeline');   
           }
           else{
            AddRecords.setRecords(recordData,1, vm.prev_grade); 
             Timeline.setTimelineParams(vm.display_date);
            $state.go('tab.timeline');    
           }
          }
         AddRecords.getRecords();      
         /* =================Edit a saved Grade====================== */ 
          vm.editSaveGrade=function(){  
                vm.gradeEditedData = {
                        grade : vm.grade_edit,
                        record_time: vm.record_time_edit ? vm.record_time_edit: AddRecords.currentTime(new Date()),
                        date : vm.prev_grade[gradeSl].date,
                        luckyData:lucky,
                        is_wakeup: is_wakeup,
                        last_long_level: vm.range_last_long_edit.value
                    };           
                     AddRecords.updateRecord(vm.gradeEditedData,gradeSl).then(function(restxt){
                         if(restxt == 1){
                        Timeline.getRecordsByDate(vm.gradeEditedData.date).then(
                            function(res){           
                                var bufferArray = [];                            
                                for(var i=0; i<res.length;i++){                             
                                bufferArray.push(res[i]);                            
                                }                           
                                vm.prev_grade = [];
                                for(var i = 0; i< bufferArray.length; i++){
                                     // Grade data 
                                    if(bufferArray[i].grade_first != null)              
                                         vm.prev_grade.push(JSON.parse(bufferArray[i].grade_first));                                 
                                    if(bufferArray[i].grade_second != null && bufferArray[i].grade_second != 'undefined')                           
                                        vm.prev_grade.push(JSON.parse(bufferArray[i].grade_second));          
                                    if(bufferArray[i].grade_third != null && bufferArray[i].grade_third != 'undefined')                              
                                        vm.prev_grade.push(JSON.parse(bufferArray[i].grade_third));                                                                  
                                }                    
                                vm.active_edit = "";
                                vm.grade_edit = "";
                                vm.showSave = true;
                                vm.saveGradeChange = true;
                               $scope.editGrademodal.hide();
                             
                            },function(err){
                                console.log(err);  
                            });  
                         }
                    },function(err){
                        console.log(err);
                    });                
            }
    }     
})();