(function() {
	'use strict';
	
	 angular
      .module('app.controllers')
      .controller('sendEmail', sendEmail);
	   sendEmail.$inject = ['$scope', '$state'];	   
	   function sendEmail($scope, $state) {
	   	var vm = this;
	   	vm.goBack =  function(){
            window.history.back();
        }						
	   }	   
	}
)();