(function() {
	'use strict';
	
	 angular
      .module('app.controllers')
      .controller('appHowTo', appHowTo);
	   appHowTo.$inject = ['$scope', '$state'];	   
	   function appHowTo($scope, $state) {
	   	var vm = this;
	   	vm.goBack =  function(){
            window.history.back();
        }	
		vm.goToTimeline = function(){
			$state.go('tlHowTo');
		}	
		vm.goToDigitalCoach = function(){
			$state.go('dcHowTo');
		}
		vm.goToProfileHowTo = function(){
			$state.go('profileHowTo');
		}
	   }	   
	}
)();