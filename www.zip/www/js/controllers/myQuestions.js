(function() {
	'use strict';
	
	 angular
      .module('app.controllers')
      .controller('myQuestions', myQuestions);
	   myQuestions.$inject = ['$scope', '$state', '$window','AddMedications','$filter','$cordovaDialogs','$ionicLoading','$timeout','$ionicHistory','$stateParams','$ionicScrollDelegate','$ionicListDelegate'];
	   
	   function myQuestions($scope, $state, $window, AddMedications, $filter, $cordovaDialogs, $ionicLoading, $timeout,$ionicHistory,$stateParams,$ionicScrollDelegate,$ionicListDelegate) {
			var vm = this;
			vm.showlist = false;
			vm.items = [];
			var  temp = [];
			var camefrom = "";			
	   	$scope.$on('$ionicView.beforeEnter', function (event, viewData) {
			   $ionicListDelegate.closeOptionButtons();
			     $ionicLoading.show({
						template: 'Loading...',
						duration: 2000
						}).then(function(){
						console.log("The loading indicator is now displayed");
						});
				
               AddMedications.getQuestions().then(
                    function(res){
						$ionicScrollDelegate.scrollTop();
						vm.showlist = true;  
						console.log(viewData.stateParams.camefrom);
						if(viewData.stateParams.camefrom=="showQueCancel"){
							vm.items = AddMedications.getItemsFromService();
							vm.items =res;
							AddMedications.storeItemsInService(vm.items);
					   }
					   else if(viewData.stateParams.camefrom=="showQueSave"){
					   	    for(var i = 0;i<res.length;i++){
								vm.items[i] =res[i];
							}
							AddMedications.storeItemsInService(vm.items);
					   }
					   else{
						   for(var i = 0;i<res.length;i++){
								vm.items[i] =res[i];
							}
							AddMedications.storeItemsInService(vm.items);
							 if(viewData.stateParams.camefrom == "profileMain"){
								AddMedications.setCamefrom("profileMain");
							} 
							else{
								AddMedications.setCamefrom("successAsk");
							}							
					   }
						 $ionicLoading.hide().then(function(){
                           
                            });                     
                    },
                    function(err){
						 $ionicLoading.hide().then(function(){
                            });   
						 if(viewData.stateParams.camefrom == "profileMain"){
								AddMedications.setCamefrom("profileMain");
							} 
							else{
								AddMedications.setCamefrom("successAsk");
							}
                        console.log(err); 
						vm.showlist=false; 
                    });               
        });
		/* ================= Delete Question event===================== */
  		 vm.onItemDelete = function(item) {				
				 $cordovaDialogs.confirm($filter('translate')('QUESTFORDOCTOR.DIALOGTEXT'), $filter('translate')('QUESTFORDOCTOR.DIALOGTITLE'), [$filter('translate')('QUESTFORDOCTOR.BUTTON1'),$filter('translate')('QUESTFORDOCTOR.BUTTON2')])
                .then(function(buttonIndex) {
                // no button = 0, 'OK' = 1, 'Cancel' = 2
                        if(buttonIndex == 1){
                            AddMedications.deleteQuestion(item.question_text,item.faq_answer).then(
						    function(res){                  
							},
							function(err){
								console.log(err);  
							});
                            vm.items.splice(vm.items.indexOf(item), 1);
							  if(vm.items.length == 0){
							  	$timeout(function() {
							  		vm.showlist = false;
							  	}, 100);
                               
                            }
                        }
                });
  		};
        vm.itemClicked = function(item,index){
			vm.items =[];
			if(item.faq_answer == null){
				item.faq_answer = "";
			}
			$state.go('showQuestion',{items:JSON.stringify(item)});
		}  	
	   	vm.goBack =  function(){
			   if($stateParams.camefrom == "profileMain" || $stateParams.camefrom == "successAsk"){
                   window.history.back();
                   vm.items = [];
			   }
			   else{				  
				   if(AddMedications.getCamefrom() == "profileMain"){
					   $state.go('tab.profileMain');
					   vm.items = [];
				   } 
				   else{
					   $state.go('successAsk');
					    vm.items = [];
				   }
			   }           
        }
		vm.addQue = function(){
			$state.go('askQuestion');
			vm.items =[];
		}
		vm.getDateFormatted = function(date){
			return moment(date).format("M/DD/YYYY");
		}		 
	   }	   
	}
)();