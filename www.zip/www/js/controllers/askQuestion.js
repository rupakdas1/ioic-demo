(function() {
	'use strict';
	
	 angular
      .module('app.controllers')
      .controller('askQuestion', askQuestion);
	   askQuestion.$inject = ['$scope', '$state','$stateParams','AddMedications','$ionicPlatform','$ionicScrollDelegate'];
	   
	   function askQuestion($scope, $state,$stateParams,AddMedications,$ionicPlatform,$ionicScrollDelegate) {
             var vm=this; 
             vm.graphQue = false; 
             vm.ansOfQues = "";
             vm.imageIndex = 8;
             vm.imgsrc = [
               "img/graph/grade_btn@2x.png",
               "img/graph/exercise_btn@2x.png",
               "img/graph/smoke_btn@2x.png",
               "img/graph/drink_btn@2x.png",
               "img/graph/weight_btn@2x.png",
               "img/graph/stress_btn@2x.png",
               "img/graph/meds_btn@2x.png"
             ]
		     $scope.$emit('pageChange', {
              title: 'Ask a Question',
              leftButton:'Cancel',
              rightButton:'Save'
            })
        $scope.$on('$ionicView.afterEnter', function (event, viewData) {
          vm.ansOfQues= viewData.stateParams.ans;
          if(typeof vm.ansOfQues == 'object' && vm.ansOfQues != null){
             vm.graphQue = true; 
             vm.imageIndex = parseInt(vm.ansOfQues.selectedGraph);
             vm.ansOfQues=vm.ansOfQues.ans;
             $ionicPlatform.ready(function() {
                   screen.lockOrientation('landscape')
                }); 
          }
          else{
            vm.graphQue = false;  
          }
          $ionicScrollDelegate.scrollTop();
        });
        // $scope.$on('$ionicView.beforeLeave', function (event, viewData) {
        //    $ionicPlatform.ready(function() {
        //            screen.lockOrientation('portrait')
        //         }); 
        // });
            vm.saveQuestion = function(){
               AddMedications.setQuestions(vm.questionText,vm.ansOfQues,vm.imageIndex);
               vm.questionText="";
               if(vm.ansOfQues=="" || vm.ansOfQues==null){
                $state.go('myQuestions',{camefrom:"showQueSave"});
               }
               else if(vm.graphQue == true){
                 $state.go('tab.timeline');
               }
               else{
                 $state.go('successAsk');
               }
            }
             vm.goBack = function(){
              vm.questionText="";
              window.history.back();    
            }           
		}
				
})();