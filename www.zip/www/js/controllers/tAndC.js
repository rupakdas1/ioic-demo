(function () {
    'use strict';
	  angular
      .module('app.controllers')
      .controller('tAndC', tAndC);
	   tAndC.$inject = ['$scope', '$state','$stateParams','$ionicPlatform','$timeout','$ionicScrollDelegate'];
	   
	   function tAndC($scope, $state,$stateParams,$ionicPlatform,$timeout,$ionicScrollDelegate) {
           $scope.$emit('pageChange', {
            title: 'Terms & Privacy'
        })
         var vm = this;
         $scope.$on('$ionicView.beforeEnter', function (event, viewData) {
           $ionicPlatform.ready(function() {
                   screen.lockOrientation('portrait')
                }); 
        });
        
         vm.termsSelected = true;
         vm.showFooter = true;
         if($stateParams.cameFrom!="home"){
             vm.showFooter = false;
         }
         vm.goToTerms = function() {
             vm.termsSelected = true;
             $timeout(function() {
               $ionicScrollDelegate.resize();
             }, 10);
         }
          vm.goToPrivacy = function(){
             vm.termsSelected = false;
             $timeout(function() {
               $ionicScrollDelegate.resize();
             }, 10);
         }
        vm.goToDigitalcoach = function(){
            $state.go('tab.digitalCoach')
        }
        vm.goBack =  function(){
            window.history.back();
        }
	   }
})();