(function() {
	'use strict';
	
	 angular
      .module('app.controllers')
      .controller('verifyPin', verifyPin);

	   verifyPin.$inject = ['$scope', '$state', '$window','$timeout'];
	   
	   function verifyPin($scope, $state, $window, $timeout) {
	   	var vm = this;
	   	$scope.$on('$ionicView.beforeEnter', function (event, viewData) {
        vm.showVerifyPin = true;
	   	vm.showSendMail = false;
	   	vm.wrongPin = false;
	   	vm.mailSent = false;
	   	vm.pinVal = [];
		vm.pins = [0,1,2,3];
	   	vm.focused = 0; 

	   });
	   	vm.changeFocusC = function(focus,e){
		    console.log(e)
			if(e == 8){
				vm.focused--;
				return;
			}
			if(!(e>=48 && e <= 57)){
				vm.pinVal[focus] ='';
				return;
			} 
			if(vm.pinVal[focus].toString().length>1){
				vm.pinVal[focus] = vm.pinVal[focus].toString().charAt(1);
				return;
	   		}
				
	   		if(vm.pinVal[focus].toString().length == 1){
				vm.focused = focus;
				vm.focused++;
				if(vm.focused == 4){
					//Compare Pin
					var storedPIN = JSON.parse(localStorage.getItem('pinValues'));
					vm.arraysEqual(storedPIN, vm.pinVal);
				}
	   		}
	   			
	   			console.log(vm.pinVal);
	   		}

	   		vm.goBack =  function(){
	   			for(var i=0;i<4;i++)
					vm.pinVal[i] = '';
           		window.history.back();
       		}
       		vm.goToDashboard = function(){
       			vm.wrongPin = false;
       			for(var i=0;i<4;i++)
					vm.pinVal[i] = '';
       			$state.go('tab.timeline');
       		}

       		vm.arraysEqual = function(arr1, arr2) {
			    if(arr1.length !== arr2.length)
			        return false;
			    for(var i = arr1.length; i--;) {
			        if(arr1[i] !== arr2[i])
			            {
			            	vm.wrongPin = true;
			            	for(var i=0; i<4; i++)
								vm.pinVal[i] = '';
							vm.focused = 0;
			            	return false;
			            }
			    }
			    vm.goToDashboard();
			    return true;
			}
	   }	   
	}
)();