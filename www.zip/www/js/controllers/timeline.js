(function () {
  'use strict';
  angular
    .module('app.controllers')
    .controller('timeline', timeline);
  timeline.$inject = ['$scope', '$state', '$ionicSlideBoxDelegate', 'Timeline', '$timeout', 'SendEHSPin', '$stateParams', '$ionicScrollDelegate', '$ionicLoading', 'Graph', '$ionicTabsDelegate', '$q', '$filter', '$ionicPlatform', '$ionicPosition'];
  function timeline($scope, $state, $ionicSlideBoxDelegate, Timeline, $timeout, SendEHSPin, $stateParams, $ionicScrollDelegate, $ionicLoading, Graph, $ionicTabsDelegate, $q, $filter, $ionicPlatform, $ionicPosition) {
    var vm = this;
    vm.monthlyTimeline = [{}];
    vm.subHeader = "";
    vm.newUser = true;
    vm.dayAndGrade = {};
    var panelIsShown = false;
    vm.today_date = moment().format("dddd, MMMM Do");
    var current_slide_index = 0;
    vm.todayDayTime = true;
    vm.landscape = false;
    var loadData = true;
    vm.oprational_gDate = "";
    var isSmoking = false;
    var isAlchoholic = false;
    console.log(ionic.Platform)

    var mql = window.matchMedia("(orientation: portrait)");
    mql.addListener(function (m) {
      if (panelIsShown == true) {
        vm.selectedGraph = 0;
        if (m.matches) { //portrait

          vm.landscape = false;
          $ionicScrollDelegate.resize();
          $timeout(function () {
            vm.landscape = false;
            $ionicTabsDelegate.showBar(true);
              Fullscreen.off();
          }, 1);
        }
        else { //landscape
          vm.landscape = true;

          $ionicScrollDelegate.resize();
          $timeout(function () {
            vm.landscape = true;
            $ionicTabsDelegate.showBar(false);
            vm.changeSelection(0, 'div');
           Fullscreen.on();
          }, 1);
        }
        $ionicScrollDelegate.resize();
      }
    });





    var setDataInitially = function () {
      Timeline.getMonthYear().then(
        function (result) {
          vm.newUser = false;
          vm.monthlyTimeline = Timeline.getAllMonthsTillNow(result[0]);//getting all months till now  
          console.log(result[0]);
          for (var i = 0; i < vm.monthlyTimeline.length; i++) { //adding data parameter to object
            vm.monthlyTimeline[i].data = [];
            vm.monthlyTimeline[i].loaded = false;
          }
          $timeout(function () {
            $ionicSlideBoxDelegate.slide(vm.monthlyTimeline.length - 1, 1);//go to latest slide
            vm.lastSlide = true;
            if (vm.monthlyTimeline.length - 1 == 0) {
              vm.firstSlide = true;
            }
      setDataForMonth();
          }, 1);
        },
        function (err) {
          vm.newUser = true;
          vm.monthlyTimeline = [{}];
          $ionicLoading.hide().then(function () {
          });
          console.log(err);
        });
    }

    // $timeout(function(){
    //        $ionicLoading.show({
    //         template: 'Loading...',
    //         duration: 2000
    //          }).then(function(){
    //        console.log("The loading indicator is now displayed");
    //       });
    //       setDataInitially();      
    //   },1000);

    $scope.$on('$ionicView.afterEnter', function (event, viewData) {
      if (moment(Timeline.getTimelineParams())._isValid) {
        $ionicLoading.show({
          template: 'Loading...',
          duration: 2000
        }).then(function () {
          console.log("The loading indicator is now displayed");
        });
        $timeout(function () {
          setDataInitially();
          loadData = false;
        }, 1);
      }
      if (loadData == true) {
        $ionicLoading.show({
          template: 'Loading...',
          duration: 2000
        }).then(function () {
          console.log("The loading indicator is now displayed");
        });
        $timeout(function () {
          setDataInitially();
          loadData = false;
        }, 1000);
      }
      if (vm.landscape == true || panelIsShown == true) {
        $ionicPlatform.ready(function () {
          screen.unlockOrientation();
        });
      }
      if (window.localStorage.getItem('isSmoking') == 'No') {
        isSmoking = true;
      }
      if (window.localStorage.getItem('isAlchoholic') == 'No') {
        isAlchoholic = true;
      }

    });
    if (window.localStorage.getItem('isSmoking') == 'No') {
      isSmoking = true;
    }
    if (window.localStorage.getItem('isAlchoholic') == 'No') {
      isAlchoholic = true;
    }
    $scope.$on('$ionicView.beforeLeave', function (event, viewData) {
      //  $ionicPlatform.ready(function() {
      //          screen.lockOrientation('portrait')
      //       }); 
    });

    var setDataForMonth = function () {
      vm.subHeader = vm.monthlyTimeline[$ionicSlideBoxDelegate.currentIndex()].id.split("_")[0];
      current_slide_index = $ionicSlideBoxDelegate.currentIndex();

      Timeline.getRecordsByMonth(vm.monthlyTimeline[current_slide_index].id).then(function (res) {
        vm.monthlyTimeline = Timeline.setAllDataEntry(res, vm.monthlyTimeline[current_slide_index].id, vm.monthlyTimeline, current_slide_index);
        $ionicLoading.hide().then(function () {
          console.log("The loading indicator is now hidden");
          $ionicScrollDelegate.resize();
        });
      }, function (err) {
        var res = [];
        res[0] = {};
        res[0].date = "1994-12-12";
        vm.monthlyTimeline = Timeline.setAllDataEntry(res, vm.monthlyTimeline[current_slide_index].id, vm.monthlyTimeline, current_slide_index);
        $ionicLoading.hide().then(function () {

          console.log("The loading indicator is now hidden");
        });
        console.error(err);
      });

    }
    vm.timelineChange = function (current_slide_index) {
      $ionicSlideBoxDelegate.update();
      vm.newUser = false;
      vm.subHeader = vm.monthlyTimeline[current_slide_index].id.split("_")[0];
      $ionicScrollDelegate.scrollTop();
      //document.getElementById('timelineSlide').style.height = "10px";

      if (current_slide_index == vm.monthlyTimeline.length - 1) {
        vm.todayDayTime = true;
        vm.lastSlide = true;
      }
      else {
        vm.todayDayTime = false;
        vm.lastSlide = false;
      }
      if (current_slide_index == 0) {
        vm.firstSlide = true;
      }
      else {
        vm.firstSlide = false;
      }
      Timeline.setCurrentSlideIndex(current_slide_index);

      $timeout(function () {
        //$ionicSlideBoxDelegate.update();
        //$ionicScrollDelegate.resize();
        // console.log(document.getElementById('month-' + current_slide_index));
        //  var slideHeight = document.getElementById('month-' + current_slide_index).clientHeight;
        //  document.getElementById('timelineSlide').style.height = slideHeight+'px'; 
         var slideHeight= window.getComputedStyle(document.getElementById('month-' + current_slide_index), null).getPropertyValue("height");
         console.log(slideHeight);
        // $scope.$apply();
         setHeight(slideHeight,current_slide_index);
        // console.log(slideHeight);
      }, 200);
    }
    var setHeight = function (slideHeight,current_slide_index) {
      $timeout(function () {
        //$ionicScrollDelegate.resize();
        document.getElementById('month-0').style.height = slideHeight;
        //$scope.$apply();
        // $ionicScrollDelegate.resize();
      }, 200);

    }
    vm.lockSlide = function () {
      $ionicSlideBoxDelegate.enableSlide(false);
    }
    var editRecordsInTimeline = function (date) {
      Timeline.getRecordsByDate(date).then(
        function (res) {
          var bufferArray = [];
          for (var i = 0; i < res.length; i++) {
            bufferArray.push(res[i]);
          }
          console.log(this);
          $state.go('addRecords', { record_by_date: JSON.stringify(bufferArray) });
        }, function (err) {
          console.log(err);
        });
    }




    vm.togglePanel = function (index, data) {

      var actualOffsetTop = 0;
      if (data.avg_grade == 0) {

        $state.go('addRecords', { record_date: data.date })
        console.log(data.date);//u are getting date here and start your work here
        return;
      }
      if (!(data.exercise || data.smoke || data.drinks || data.medication_value || data.weight || data.stress_value)) {
        editRecordsInTimeline(data.date);
        return;
      }
      if (vm.isPanelShown(index)) {
        vm.shownPanel = null;
        panelIsShown = false;
        actualOffsetTop = angular.element(document.getElementById(data.date)).prop('offsetTop');
        $ionicScrollDelegate.scrollTo(0, actualOffsetTop, true);

        $ionicPlatform.ready(function () {
          screen.lockOrientation('portrait')
        });

      } else {
        panelIsShown = true;
        $timeout(function () {
          actualOffsetTop = angular.element(document.getElementById(data.date)).prop('offsetTop');
          $ionicScrollDelegate.scrollTo(0, actualOffsetTop, true);
        }, 10);
        $ionicPlatform.ready(function () {
          screen.unlockOrientation();
        });
        vm.oprational_gDate = data.date;
        vm.shownPanel = index;

      }
    }
    vm.isPanelShown = function (index) {
      return vm.shownPanel == index;
    };
    vm.addRecords = function () {
      $state.go('addRecords');
    }
    vm.prevMonth = function () {
      $ionicSlideBoxDelegate.previous();
      setDataForMonth();
    }
    vm.nextMonth = function () {
      $ionicSlideBoxDelegate.next();
      //$ionicScrollDelegate.scrollTop();
    }

    vm.doRefresh = function () {
      current_slide_index = $ionicSlideBoxDelegate.currentIndex();
      if (current_slide_index == vm.monthlyTimeline.length - 1) {
        $timeout(function () {
          vm.today_date = moment().format("dddd, MMMM Do");
          setDataInitially();
          $scope.$broadcast('scroll.refreshComplete');
           $ionicScrollDelegate.resize();
        }, 1000);
      }
      else {
        $scope.$broadcast('scroll.refreshComplete');
         $ionicScrollDelegate.resize();
      }
    }
    vm.editRecord = function (date) {
      editRecordsInTimeline(date);
    }
    vm.goTotAndC = function () {
      $state.go('tAndC', { cameFrom: "timeline" });
    }

    var upperGradeGraphData = function () {
      Graph.setGradeGraphDataUpper(gradeGraphData);
    }

    vm.goToHowTo = function () {
      $state.go('tlHowTo');
    }

    vm.graphs = [{ class: "graph0" }, { class: "graph1" }, { class: "graph2", isHide: isSmoking }, { class: "graph3", isHide: isAlchoholic }, { class: "graph4" }, { class: "graph5" }, { class: "graph6" }];
    vm.selectedGraph = 0;

    $ionicTabsDelegate.showBar(true);
    var ctx = document.getElementById("ehs-graph").getContext("2d");




    console.log(ctx);
    vm.graphData = {};
    var graphDataGrade = {
      backgroundColor: "rgba(0, 100, 144, 1)", // default is white
      labelY: ["Grade 1", "Grade 2", "Grade 3", "Grade 4"],
      padding: [7, 4, 30, 15], //[top,right,bottom,left] 
      verticalGrid: 0,
      horizontalGrid: 3,
      gridColor: "#C5EFF7",
      plotColor: "rgba(197, 197, 197, 1)",
      boundary: { minX: 0, minY: 1, maxX: 8, maxY: 4 },
    };
    var graphDataExercise = {
      backgroundColor: "rgba(53, 168, 222, 1)", // default is white
      labelY: ["0", "10", "20", "30", "40", "50", "60+"],
      padding: [7, 5, 20, 10], //[top,right,bottom,left] 
      verticalGrid: 0,
      horizontalGrid: 6,
      gridColor: "#C5EFF7",
      plotColor: "rgba(255, 253, 89, 1)",
      boundary: { minX: 0, minY: 0, maxX: 8, maxY: 60 }
    };
    var graphDataSmoke = {
      backgroundColor: "rgba(221, 48, 223, 1)", // default is white
      labelY: ["0", "<1", "1+"],
      padding: [7, 5, 20, 10], //[top,right,bottom,left] 
      verticalGrid: 0,
      horizontalGrid: 2,
      gridColor: "#C5EFF7",
      plotColor: "rgba(71, 254, 237, 1)",
      boundary: { minX: 0, minY: 0, maxX: 8, maxY: 2 }
    };
    var graphDataDrinks = {
      backgroundColor: "rgba(227, 199, 67, 1)", // default is white
      labelY: ["0", "1-2", "3+"],
      padding: [7, 5, 20, 10], //[top,right,bottom,left] 
      verticalGrid: 0,
      horizontalGrid: 2,
      gridColor: "#C5EFF7",
      plotColor: "rgba(208, 78, 116, 1)",
      boundary: { minX: 0, minY: 0, maxX: 8, maxY: 2 }
    };
    var graphDataWeight = {
      backgroundColor: "rgba(45, 190, 176, 1)", // default is white
      labelY: ["0", "40 kg", "80 kg", "120 kg", "160 kg", "200 kg"],
      padding: [7, 5, 20, 10], //[top,right,bottom,left] 
      verticalGrid: 0,
      horizontalGrid: 5,
      gridColor: "#C5EFF7",
      plotColor: "rgba(246, 153, 247, 1)",
      boundary: { minX: 0, minY: 0, maxX: 8, maxY: 200 }
    };
    var graphDataStress = {
      backgroundColor: "rgba(208, 78, 116, 1)", // default is white
      labelY: ["Low", "Medium", "HIGH"],
      padding: [7, 5, 20, 10], //[top,right,bottom,left] 
      verticalGrid: 0,
      horizontalGrid: 2,
      gridColor: "#C5EFF7",
      plotColor: "rgba(167, 227, 255, 1)",
      boundary: { minX: 0, minY: 0, maxX: 8, maxY: 2 }
    };
    var graphDataMeds = {
      backgroundColor: "rgba(87, 208, 78, 1)", // default is white
      labelY: ["0", "2", "4", "6", "8", "10+"],
      padding: [7, 5, 20, 10], //[top,right,bottom,left] 
      verticalGrid: 0,
      horizontalGrid: 5,
      gridColor: "#C5EFF7",
      plotColor: "rgba(227, 199, 67, 1)",
      boundary: { minX: 0, minY: 0, maxX: 8, maxY: 10 }
    };
    vm.graphHeading = "";
    vm.currentValue = 0;
    vm.averageValue = 0;
    vm.showBlankGraph = false;
    vm.showFooter = true;
    vm.showLeftGraphPoints = false;
    vm.showRightGraphPoints = false;
    var allGradeData = [];
    var allExerciseData = [];
    var allStressData = [];
    var allMedicationData = [];
    var allSmokeData = [];
    var allDrinksData = [];
    var allWeightData = [];
    var shownGradeGraphData = [];
    var shownExerciseGraphData = [];
    var shownSmokeGraphData = [];
    var shownMedsGraphData = [];
    var shownDrinksGraphData = [];
    var shownStressGraphData = [];
    var shownWeightGraphData = [];
    vm.noGraphMsg = [
      $filter('translate')('TIMELINE.TEXT11'),
      $filter('translate')('TIMELINE.TEXT12'),
      $filter('translate')('TIMELINE.TEXT13'),
      $filter('translate')('TIMELINE.TEXT14'),
      $filter('translate')('TIMELINE.TEXT15'),
      $filter('translate')('TIMELINE.TEXT16'),
      $filter('translate')('TIMELINE.TEXT17')
    ]
    var queHeader = [
      $filter('translate')('TIMELINE.TEXT22'),
      $filter('translate')('TIMELINE.TEXT23'),
      $filter('translate')('TIMELINE.TEXT24'),
      $filter('translate')('TIMELINE.TEXT25'),
      $filter('translate')('TIMELINE.TEXT26'),
      $filter('translate')('TIMELINE.TEXT27'),
      $filter('translate')('TIMELINE.TEXT28')
    ]


    var refreshCanvas = function (graph1) {
      var canvasAtr = angular.element(document.querySelector('#ehs-graph'));
      canvasAtr.attr('width', Math.round(window.innerWidth));
      canvasAtr.attr('height', Math.round(window.innerHeight * 0.45));
      ctx.imageSmoothingEnabled = false;
      ctx.imageSmoothingQuality = "high";
      graph1.refresh()
      graph1.draw();
    }
    var drawGraph = function (oprational_gDate) {
      var tempDataHolder = [];
      return $q(function (resolve, reject) {
        var gradeGraphData = [];
        Graph.setInitialGraph().then(function (res) {
          allGradeData = Graph.openGradeJason(res);
          vm.currentValue = "Grade "+ allGradeData[allGradeData.length - 1].grade;
          vm.averageValue = "Grade "+Graph.getCommonFieldsAvg(allGradeData, 'grade').toFixed(2);
          tempDataHolder = Graph.getSevenExerciseData(allGradeData, oprational_gDate);
          shownGradeGraphData = tempDataHolder[0];
          vm.showRightArrow = tempDataHolder[1];
          vm.showLeftArrow = tempDataHolder[2];
          gradeGraphData = Graph.getGradeDataForGraph(shownGradeGraphData);
          //upperGradeGraphData();
          resolve(gradeGraphData);
        },
          function (err) {
            resolve(gradeGraphData);
          });
      });
    }
    var getPlotdataNonGrade = function (field, oprational_Date) {
      var tempDataHolder = [];
      if (field == "Exercise" || field == "Stress" || field == "Medication") {
        return $q(function (resolve, reject) {
          var exerciseGraphData = [];
          Graph.getPlotdataNonGarde(field).then(function (res) {

            if (field == "Exercise") {
              allExerciseData = res;
              vm.currentValue = res[res.length - 1].exercise + ' mins';
              vm.averageValue = Graph.getCommonFieldsAvg(res, 'exercise').toFixed(0) + ' mins';
              tempDataHolder = Graph.getSevenExerciseData(allExerciseData, oprational_Date);
              shownExerciseGraphData = tempDataHolder[0];
              vm.showRightArrow = tempDataHolder[1];
              vm.showLeftArrow = tempDataHolder[2];
              exerciseGraphData = Graph.getExerciseDataForGraph(shownExerciseGraphData);
              //exerciseGraphData = getDataPointsDetails[0];
              //   console.log(exerciseGraphData);
              //   vm.showRightGraphPoints =  getDataPointsDetails[1];
            }
            else if (field == "Stress") {
              allStressData = res;
              vm.currentValue = "Grade "+Graph.getStressText(res[res.length - 1].stress);
              vm.averageValue = "Grade "+Graph.getStressAvg(res, 'stress');
              shownStressGraphData = Graph.getSevenExerciseData(allStressData, oprational_Date);
              tempDataHolder = Graph.getSevenExerciseData(allStressData, oprational_Date);
              shownStressGraphData = tempDataHolder[0];
              vm.showRightArrow = tempDataHolder[1];
              vm.showLeftArrow = tempDataHolder[2];
              exerciseGraphData = Graph.getStressDataForGraph(shownStressGraphData);
              //vm.showRightGraphPoints =  getDataPointsDetails[1];
            }
            else if (field == "Medication") {
              allMedicationData = res;
              vm.currentValue = JSON.parse(res[res.length - 1].medication).length + ' Meds';
              vm.averageValue = Graph.getMedsAvg(res).toFixed(0) + ' Meds';
              shownMedsGraphData = Graph.getSevenExerciseData(allMedicationData, oprational_Date);
              tempDataHolder = Graph.getSevenExerciseData(allMedicationData, oprational_Date);
              shownMedsGraphData = tempDataHolder[0];
              vm.showRightArrow = tempDataHolder[1];
              vm.showLeftArrow = tempDataHolder[2];
              exerciseGraphData = Graph.getMedicationDataForGraph(shownMedsGraphData);
              //vm.showRightGraphPoints =  getDataPointsDetails[1];
            }
            resolve(exerciseGraphData);
          },
            function (err) {
              resolve(exerciseGraphData);
            });
        });
      }
      else if (field == "Smoke" || field == "Drinks" || field == "Weight") {
        var tempDataHolder = [];
        return $q(function (resolve, reject) {
          var smokeGraphData = [];
          Graph.getPlotdataNonGardeSmoke(field, oprational_Date).then(function (res) {
            if (field == "Smoke") {
              allSmokeData = res;
              vm.currentValue = res[res.length - 1].smoke+" Pack";
              vm.averageValue = Graph.getAvgSmoke(res)+" Pack";
              tempDataHolder = Graph.getSevenExerciseData(allSmokeData, oprational_Date);
              shownSmokeGraphData = tempDataHolder[0];
              vm.showRightArrow = tempDataHolder[1];
              vm.showLeftArrow = tempDataHolder[2];
              smokeGraphData = Graph.getSmokeDataForGraph(shownSmokeGraphData);
            }
            else if (field == "Drinks") {
              allDrinksData = res;
              vm.currentValue = res[res.length - 1].drinks+" Drinks";
              vm.averageValue = Graph.getAvgDrink(res)+" Drinks";
              tempDataHolder = Graph.getSevenExerciseData(allDrinksData, oprational_Date);
              shownDrinksGraphData = tempDataHolder[0];
              vm.showRightArrow = tempDataHolder[1];
              vm.showLeftArrow = tempDataHolder[2];
              smokeGraphData = Graph.getDrinksDataForGraph(shownDrinksGraphData);
            }
            else if (field == "Weight") {
              allWeightData = res;
              vm.currentValue = res[res.length - 1].weight + ' kg';
              vm.averageValue = Graph.getCommonFieldsAvg(res, 'weight').toFixed(0) + ' kg';
              tempDataHolder = Graph.getSevenExerciseData(allWeightData, oprational_Date);
              shownWeightGraphData = tempDataHolder[0];
              vm.showRightArrow = tempDataHolder[1];
              vm.showLeftArrow = tempDataHolder[2];
              smokeGraphData = Graph.getWeightDataForGraph(shownWeightGraphData);
            }
            resolve(smokeGraphData);
          },
            function (err) {
              resolve(smokeGraphData);
            });
        });
      }
    }
    var drawGraphWithPlotData = function (myplotdata) {
      if (myplotdata == "") {
        vm.showBlankGraph = true;
        vm.showFooter = false;
        vm.graphData.padding = [10, 5, 15, 10];
        vm.currentValue = "-";
        vm.averageValue = "-";
      }
      else {
        vm.showBlankGraph = false;
        vm.showFooter = true;
      }
      var graph = new LineGraph(ctx, vm.graphData);
      graph.setDimension(Math.round(window.innerWidth), Math.round(window.innerHeight * 0.45));
      ctx.setTransform(4, 0, 0, 4, 0, 0);
      graph.setData(myplotdata);
      graph.draw();

      refreshCanvas(graph);
      window.addEventListener("resize", refreshCanvas(graph));
    }

    var exercisePrevGraphData = [];
    vm.changeSelection = function (idx, side) {
      vm.selectedGraph = idx;
      var myplotdata = [];
      switch (idx) {
        case 0:
          console.log(side);
          if (side == 'div') {
            vm.graphHeading = "Grade";
            drawGraph(vm.oprational_gDate).then(function (data) {
              myplotdata = data;
              vm.graphData = graphDataGrade;
              drawGraphWithPlotData(myplotdata);
            });
          }
          else {
            if (side == 'left') {
              myplotdata = Graph.getLeftPlotData(allGradeData, shownGradeGraphData);
              console.log(myplotdata);
              shownGradeGraphData = myplotdata[0];
              vm.showLeftArrow = myplotdata[2];
              vm.showRightArrow = myplotdata[1];
            }
            else {
              myplotdata = Graph.getRightPlotData(allGradeData, shownGradeGraphData);
              shownGradeGraphData = myplotdata[0];
              vm.showLeftArrow = myplotdata[2];
              vm.showRightArrow = myplotdata[1];
            }
            myplotdata = Graph.getGradeDataForGraph(shownGradeGraphData);
            vm.graphData = graphDataGrade;
            drawGraphWithPlotData(myplotdata);
          }
          break;
        case 1:
          if (side == 'div') {
            vm.graphHeading = "Exercise";
            getPlotdataNonGrade("Exercise", vm.oprational_gDate).then(function (data) {
              myplotdata = data;
              exercisePrevGraphData = data;
              vm.graphData = graphDataExercise;
              drawGraphWithPlotData(myplotdata);
            });
            break;
          }
          else {
            if (side == 'left') {
              myplotdata = Graph.getLeftPlotData(allExerciseData, shownExerciseGraphData);
              shownExerciseGraphData = myplotdata[0];
              vm.showLeftArrow = myplotdata[2];
              vm.showRightArrow = myplotdata[1];
            }
            else {
              myplotdata = Graph.getRightPlotData(allExerciseData, shownExerciseGraphData);
              shownExerciseGraphData = myplotdata[0];
              vm.showLeftArrow = myplotdata[2];
              vm.showRightArrow = myplotdata[1];
            }
            myplotdata = Graph.getExerciseDataForGraph(shownExerciseGraphData);
            vm.graphData = graphDataExercise;
            drawGraphWithPlotData(myplotdata);
          }
          break;
        case 2:
          if (side == 'div') {
            vm.graphHeading = "Smokes";
            getPlotdataNonGrade("Smoke", vm.oprational_gDate).then(function (data) {
              myplotdata = data;
              vm.graphData = graphDataSmoke;
              drawGraphWithPlotData(myplotdata);
            });
            break;
          }
          else {
            if (side == 'left') {
              myplotdata = Graph.getLeftPlotData(allSmokeData, shownSmokeGraphData);
              shownSmokeGraphData = myplotdata[0];
              vm.showLeftArrow = myplotdata[2];
              vm.showRightArrow = myplotdata[1];
            }
            else {
              myplotdata = Graph.getRightPlotData(allSmokeData, shownSmokeGraphData);
              shownSmokeGraphData = myplotdata[0];
              vm.showLeftArrow = myplotdata[2];
              vm.showRightArrow = myplotdata[1];
            }
            myplotdata = Graph.getSmokeDataForGraph(shownSmokeGraphData);
            vm.graphData = graphDataSmoke;
            drawGraphWithPlotData(myplotdata);
          }
          break;
        case 3:
          if (side == 'div') {
            vm.graphHeading = "Drinks";
            getPlotdataNonGrade("Drinks", vm.oprational_gDate).then(function (data) {
              myplotdata = data;
              vm.graphData = graphDataDrinks;
              drawGraphWithPlotData(myplotdata);
            });
            break;
          }
          else {
            if (side == 'left') {
              myplotdata = Graph.getLeftPlotData(allDrinksData, shownDrinksGraphData);
              shownDrinksGraphData = myplotdata[0];
              vm.showLeftArrow = myplotdata[2];
              vm.showRightArrow = myplotdata[1];
            }
            else {
              myplotdata = Graph.getRightPlotData(allDrinksData, shownDrinksGraphData);
              shownDrinksGraphData = myplotdata[0];
              vm.showLeftArrow = myplotdata[2];
              vm.showRightArrow = myplotdata[1];
            }
            myplotdata = Graph.getDrinksDataForGraph(shownDrinksGraphData);
            vm.graphData = graphDataDrinks;
            drawGraphWithPlotData(myplotdata);
          }
          break;
        case 4:
          if (side == 'div') {
            vm.graphHeading = "Weight";
            getPlotdataNonGrade("Weight", vm.oprational_gDate).then(function (data) {
              myplotdata = data;
              vm.graphData = graphDataWeight;
              drawGraphWithPlotData(myplotdata);
            });
            break;
          }
          else {
            if (side == 'left') {
              myplotdata = Graph.getLeftPlotData(allWeightData, shownWeightGraphData);
              shownWeightGraphData = myplotdata[0];
              vm.showLeftArrow = myplotdata[2];
              vm.showRightArrow = myplotdata[1];
            }
            else {
              myplotdata = Graph.getRightPlotData(allWeightData, shownWeightGraphData);
              shownWeightGraphData = myplotdata[0];
              vm.showLeftArrow = myplotdata[2];
              vm.showRightArrow = myplotdata[1];
            }
            myplotdata = Graph.getWeightDataForGraph(shownWeightGraphData);
            vm.graphData = graphDataWeight;
            drawGraphWithPlotData(myplotdata);
          }
          break;

        case 5:
          if (side == 'div') {
            vm.graphHeading = "Stress";
            getPlotdataNonGrade("Stress", vm.oprational_gDate).then(function (data) {
              myplotdata = data;
              vm.graphData = graphDataStress;
              drawGraphWithPlotData(myplotdata);
            });
            break;
          }
          else {
            if (side == 'left') {
              myplotdata = Graph.getLeftPlotData(allStressData, shownStressGraphData);
              shownStressGraphData = myplotdata[0];
              vm.showLeftArrow = myplotdata[2];
              vm.showRightArrow = myplotdata[1];
            }
            else {
              myplotdata = Graph.getRightPlotData(allStressData, shownStressGraphData);
              shownStressGraphData = myplotdata[0];
              vm.showLeftArrow = myplotdata[2];
              vm.showRightArrow = myplotdata[1];
            }
            myplotdata = Graph.getStressDataForGraph(shownStressGraphData);
            vm.graphData = graphDataStress;
            drawGraphWithPlotData(myplotdata);
          }
          break;

        case 6:
          if (side == 'div') {
            vm.graphHeading = "Medication";
            getPlotdataNonGrade("Medication", vm.oprational_gDate).then(function (data) {
              myplotdata = data;
              vm.graphData = graphDataMeds;
              drawGraphWithPlotData(myplotdata);
            });
            break;
          }
          else {
            if (side == 'left') {
              myplotdata = Graph.getLeftPlotData(allMedicationData, shownMedsGraphData);
              shownMedsGraphData = myplotdata[0];
              vm.showLeftArrow = myplotdata[2];
              vm.showRightArrow = myplotdata[1];
            }
            else {
              myplotdata = Graph.getRightPlotData(allMedicationData, shownMedsGraphData);
              shownMedsGraphData = myplotdata[0];
              vm.showLeftArrow = myplotdata[2];
              vm.showRightArrow = myplotdata[1];
            }
            myplotdata = Graph.getMedicationDataForGraph(shownMedsGraphData);
            vm.graphData = graphDataMeds;
            drawGraphWithPlotData(myplotdata);
          }
          break;

        default:
          vm.graphHeading = "Grade";
          myplotdata = [];
          vm.graphData = graphDataGrade;
      }
    }
    vm.getRightDatePoints = function (selectedGraph) {
      vm.changeSelection(selectedGraph, "right");
    }
    vm.getLeftDatePoints = function (selectedGraph) {
      vm.changeSelection(selectedGraph, "left");
    }
    vm.goToAskQue = function (selectedGraph) {
      console.log(selectedGraph);
      var objToSend = [];
      var ans = queHeader[selectedGraph] + '<br>' + $filter('translate')('TIMELINE.TEXT20') + vm.currentValue
        + '<br>' + $filter('translate')('TIMELINE.TEXT21') + vm.averageValue;
      objToSend.selectedGraph = selectedGraph;
      objToSend.ans = ans;
      console.log(objToSend);
      $state.go('askQuestion', { ans: objToSend });
    }
  }
})();