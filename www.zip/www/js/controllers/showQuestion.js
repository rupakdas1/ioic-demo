(function() {
	'use strict';
	
	 angular
      .module('app.controllers')
      .controller('showQuestion', showQuestion);
	   showQuestion.$inject = ['$scope', '$state','$stateParams','AddMedications','$filter','$cordovaDialogs'];
	   
	   function showQuestion($scope, $state,$stateParams,AddMedications,$filter,$cordovaDialogs) {
              
             var vm=this;
             vm.saveText = $filter('translate')('QUESTFORDOCTOR.BUTTON3');
             vm.imgsrc = [
               "img/graph/grade_btn@2x.png",
               "img/graph/exercise_btn@2x.png",
               "img/graph/smoke_btn@2x.png",
               "img/graph/drink_btn@2x.png",
               "img/graph/weight_btn@2x.png",
               "img/graph/stress_btn@2x.png",
               "img/graph/meds_btn@2x.png"
             ]
            var queObj = {};
             	$scope.$on('$ionicView.beforeEnter', function (event, viewData) {
                queObj = {};
                queObj = JSON.parse(viewData.stateParams.items);
                vm.nonEditableQue=true; 
                vm.que_index =queObj.index;
                vm.ansOfQues=queObj.faq_answer;
                vm.questionText = queObj.question_text;
                vm.imageIndex = queObj.graphIndex;
                if(vm.imageIndex<8){
                    vm.graphQue=true;
                }
                else
                  vm.graphQue=false;
            });
           vm.editQuestion = function(){
               vm.nonEditableQue = false;
           }
             vm.goBack = function(){
              $state.go('myQuestions',{camefrom:"showQueCancel"});
            }
            vm.saveQuestion = function(){
              if(vm.nonEditableQue  == true){
                vm.saveText = $filter('translate')('QUESTFORDOCTOR.BUTTON4');
                vm.nonEditableQue = false;
                return;
              }
                 AddMedications.updateQuestions(queObj.question_text,vm.questionText,vm.ansOfQues);
                 $state.go('myQuestions',{camefrom:"showQueSave"});
            }

            vm.deleteQuestion = function(item) {				
              $cordovaDialogs.confirm($filter('translate')('QUESTFORDOCTOR.DIALOGTEXT'), $filter('translate')('QUESTFORDOCTOR.DIALOGTITLE'), [$filter('translate')('QUESTFORDOCTOR.BUTTON1'),$filter('translate')('QUESTFORDOCTOR.BUTTON2')])
                    .then(function(buttonIndex) {
                    // no button = 0, 'OK' = 1, 'Cancel' = 2
                            if(buttonIndex == 1){
                                AddMedications.deleteQuestion(queObj.question_text,vm.ansOfQues).then(
                                    function(res){   
                                      $state.go('myQuestions',{camefrom:"showQueSave"});               
                                    },
                                    function(err){
                                    console.log(err);  
                                    });
                                }
                    });
  		     };
           
		}
				
})();