(function() {
	'use strict';
	
	 angular
      .module('app.controllers')
      .controller('successAsk', successAsk);
	   successAsk.$inject = ['$scope', '$state','$stateParams'];
	   /* =================Succsess and redirect to Digital Coach====================== */
	   function successAsk($scope, $state) {
              var vm = this;
            vm.backToDigital = function(){
                $state.go('tab.digitalCoach');
            }
            vm.goToQuestion = function(){
            	 $state.go('myQuestions',{camefrom:"successAsk"});
            }
		}
				
})();