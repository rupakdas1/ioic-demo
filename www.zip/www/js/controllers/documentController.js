

(function() {
	'use strict';
	 angular
      .module('app.controllers')
      .controller('documentController', documentController);
	   documentController.$inject = ['$scope', '$state','$ionicScrollDelegate','$stateParams','$ionicModal','$window','$ionicPopup','$cordovaDialogs','$filter','$ionicLoading','$ionicPlatform','InvoiceService','$cordovaEmailComposer','Timeline','$q','Graph','$timeout'];
	   function documentController($scope, $state,$ionicScrollDelegate,$stateParams,$ionicModal, $window,$ionicPopup,$cordovaDialogs,$filter,$ionicLoading,$ionicPlatform,InvoiceService,$cordovaEmailComposer,Timeline,$q,Graph,$timeout) {
    //   $ionicPlatform.ready(function() {
    //    //screen.lockOrientation('portrait')
    //    }); 
         var vm = this;       
         var pdfData = [];
         var canvasData=[];
     setDefaultsForPdfViewer($scope);
  $scope.$on('$ionicView.beforeEnter', function (event, viewData) {

     Timeline.getLastSevenData().then(
            function(result){ 
                 pdfData = Timeline.setDataToPdf(result);
            },
            function(err){  
                  
             });
  
                for(var i=0;i<7;i++){
                   vm.changeSelection(i);
                }
               
                $timeout(function() {
                   // var obj = JSON.stringify(dataURLObj)
                   // localStorage.setItem("IMAGE_URL",obj);
                   canvasData = [];
                   canvasData=Timeline.getItemsFromService();
                   console.log('canvasData',canvasData);
                  vm.createInvoice();
                }, 2000);
             vm.emailTo = " ";
               vm.emailCc= "";
                
                vm.emailSubject="";
                 vm.emailbodyText="";
               
             



  });

    // Initialize the modal view.
    $ionicModal.fromTemplateUrl('pdf-viewer.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function (modal) {
        vm.modal = modal;
    });       
      //Create PDF after the platform is ready

    ionic.Platform.ready(function() {       
   
    console.log("Platform Ready.");
   vm.goBack=function(){
     $state.go('tab.profileMain');
   }
   
    vm.createInvoice = function () {

        var invoice = pdfData;
          console.log("invoice",invoice);
        InvoiceService.createPdf(invoice,canvasData)
                        .then(function(pdf) {
                            var blob = new Blob([pdf], {type: 'application/pdf'});
                            $scope.pdfUrl = URL.createObjectURL(blob);

                            if (ionic.Platform.isAndroid()) {

                                console.log(blob);
                                var fileName = "Report.pdf";
                                fileName = fileName.trim();
                        window.resolveLocalFileSystemURL(cordova.file.externalRootDirectory, function (fileSystem) {
                                    fileSystem.getDirectory("EssarData", {
                                        create : true,
                                        exclusive : false
                                    }, function (dir) {
                                        var PdfFilePath = dir.toURL();
                                        console.log(dir);
                                        console.log("PdfFilePath: " + PdfFilePath);
                                        console.log("tmpPath:  " + PdfFilePath);

                                        var finalPATH = PdfFilePath + fileName;
                                        var openPdfPath = (PdfFilePath) + fileName;
                                        //console.log("openPdfPath: "+openPdfPath);
                                        var getPDFfile = "EssarData/" + fileName;

                                        fileSystem.getFile(getPDFfile, {
                                            create : true
                                        }, function (entry) {
                                            var fileEntry = entry;
                                            console.log(cordova.file.externalRootDirectory);
                                            entry.createWriter(function (writer) {
                                                writer.onwrite = function (evt) {
                                                    console.log("write success");

                                                    console.log(finalPATH);
                                                    //save the finalpath in localStorage
                                                    localStorage.setItem("FILE_PATH_ANDROID",finalPATH);
                                                    
                                                        $ionicLoading.hide().then(function(){
                                console.log("The loading indicator is now hidden");
                                });  
                                                        //install cordova fileopener plugin for android 
                                                    // window.cordova.plugins.FileOpener.openFile(finalPATH, function (data) {

                                                    //     console.log(finalPATH);

                                                    // }, function onError(error) {
                                                    //     alert('message: ' + error.message);
                                                    // });
                                                };
                                
                                    var data = blob;
                                    var buffer = new ArrayBuffer(data.length);
                                    var array = new Uint8Array(buffer);
                                    for (var i = 0; i < data.length; i++) {
                                        array[i] = data.charCodeAt(i);
                                    }
                                    writer.write(blob);                           
                            }, function (error) {
                                console.log("ERROR: " + error);
                            });

                            }, function (error) {
                        console.log("error: " + error);
                        });
                                        
                  }, function (error) {});
              }, function (event) {
                        console.log("event: " + evt.target.error.code);
            });
        } else {
                    var fileNameIos ="Report.pdf";
                    fileNameIos = fileNameIos.trim();
                    window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, function (fileSystem) {

                        fileSystem.root.getDirectory("EssarData", {
                            create : true,
                            exclusive : false
                        }, function (dir) {
                            var PdfFilePathIos = dir.toURL();
                            var finalPATHIos = PdfFilePathIos + fileNameIos;
                            var openPdfPath = (PdfFilePathIos) + fileNameIos;
                            var getPDFfile = "EssarData/" + fileNameIos;

                            fileSystem.root.getFile(getPDFfile, {
                                create : true
                            }, function (entry) {
                                var fileEntry = entry;
                                console.log(entry);
                                entry.createWriter(function (writer) {
                                    writer.onwrite = function (evt) {
                                        console.log("write success");

                                        console.log(finalPATHIos)
                                        localStorage.setItem("FILE_PATH_IOS",finalPATHIos);
                                        // install cordova Fileopener2 plugin for ios
                                        cordova.plugins.fileOpener2.open(
                                            finalPATHIos, // You can also use a Cordova-style file uri: cdvfile://localhost/persistent/Download/starwars.pdf
                                            'application/pdf', {
                                            error : function (e) {
                                                 $ionicLoading.hide().then(function(){
                                console.log("The loading indicator is now hidden");
                                });  
                                                console.log('Error status: ' + e.status + ' - Error message: ' + e.message);
                                            },
                                            success : function () {
                                                   $ionicLoading.hide().then(function(){
                                console.log("The loading indicator is now hidden");
                                });  
                                            }
                                        });
                                    };

                                    writer.write(blob);

                                }, function (error) {
                                    console.log("error: " + error);
                                });

                            }, function (error) {
                                console.log("ERROR: " + error);
                            });
                        }, function (error) {});

                    }, function (event) {
                        console.log("event: " + evt.target.error.code);
                    });
                }

                

            }, false);

                // Display the modal view
                 
        }
                            

}, false);

    // Clean up the modal view.
 

vm.getData=function(){  
    
      
      
}

    // Send Email
    vm.sendEmail = function(){
        console.log("send mail");
        Timeline.flushServiceData();
        if (ionic.Platform.isAndroid()){
        var filepath = localStorage.getItem("FILE_PATH_ANDROID");  
        }
        else{
        var filepath = localStorage.getItem("FILE_PATH_IOS");
    }
        console.log(filepath);  
 var email = {
                to: vm.emailTo,
                cc: vm.emailCc,
                bcc: ['', ''],
                attachments: [
                  //'finalPATH'
                  //'res://icon.png',
                  //'base64:icon.png//iVBORw0KGgoAAAANSUhEUg...',
                  filepath
                 ],
                subject: vm.emailSubject,
                body: vm.emailbodyText,
                isHtml: true

                // to: 'sudatta.desai@tcs.com',
                // cc: 'sudatta.desai@tcs.com',
                // bcc: ['', ''],
                // attachments: [
                //   //'finalPATH'
                //   //'res://icon.png',
                //   //'base64:icon.png//iVBORw0KGgoAAAANSUhEUg...',
                //   filepath
                //  ],
                // subject: vm.emailSubject,
                // body: vm.emailbodyText,
                // isHtml: true
              }; 
              console.log("email var created");
                    
                    $cordovaEmailComposer.isAvailable().then(function() {
                        // is available
                        console.log("Is available");
                      }, function () {
                        // not available
                        console.log("not available");
                      });


                      $cordovaEmailComposer.open(email).then(null, function () {
                       // user cancelled email
                       console.log("user cancelled email");
                      });
        }       

//Draw Canvas 

        vm.graphData = {};
        var dataURLObj = [];
      var graphDataGrade = {
              backgroundColor : "rgba(0, 100, 144, 1)", // default is white
              labelY : ["Grade 1", "Grade 2", "Grade 3", "Grade 4"],
              padding : [7,4,30,15], //[top,right,bottom,left] 
              verticalGrid : 0,
              horizontalGrid : 3,
              gridColor : "#C5EFF7",
              plotColor : "rgba(197, 197, 197, 1)",
              boundary : {minX:0,minY:1, maxX:8,maxY:4},
      };
      var graphDataExercise = {
              backgroundColor : "rgba(53, 168, 222, 1)", // default is white
              labelY : ["0", "10", "20", "30", "40", "50","60+"],
              padding : [7,5,20,10], //[top,right,bottom,left] 
              verticalGrid : 0,
              horizontalGrid : 6,
              gridColor : "#C5EFF7",
              plotColor : "rgba(255, 253, 89, 1)",
              boundary : {minX:0,minY:0, maxX:8,maxY:60}
      };
      var graphDataSmoke = {
              backgroundColor : "rgba(221, 48, 223, 1)", // default is white
              labelY : ["0", "1-3", "4+"],
              padding : [7,5,20,10], //[top,right,bottom,left] 
              verticalGrid : 0,
              horizontalGrid : 2,
              gridColor : "#C5EFF7",
              plotColor : "rgba(71, 254, 237, 1)",
              boundary : {minX:0,minY:0, maxX:8,maxY:2}
      };
      var graphDataDrinks = {
              backgroundColor : "rgba(227, 199, 67, 1)", // default is white
              labelY : ["0", "1-2", "3+"],
              padding : [7,5,20,10], //[top,right,bottom,left] 
              verticalGrid : 0,
              horizontalGrid : 2,
              gridColor : "#C5EFF7",
              plotColor : "rgba(208, 78, 116, 1)",
              boundary : {minX:0,minY:0, maxX:8,maxY:2}
      };
      var graphDataWeight = {
            backgroundColor : "rgba(45, 190, 176, 1)", // default is white
            labelY : ["0", "40 kg", "80 kg", "120 kg", "160 kg", "200 kg"],
            padding : [7,5,20,10], //[top,right,bottom,left] 
            verticalGrid : 0,
            horizontalGrid : 5,
            gridColor : "#C5EFF7",
            plotColor : "rgba(246, 153, 247, 1)",
            boundary : {minX:0,minY:0, maxX:8,maxY:200}
      };
      var graphDataStress = {
            backgroundColor : "rgba(208, 78, 116, 1)", // default is white
            labelY : ["Low", "Medium", "HIGH"],
            padding : [7,5,20,10], //[top,right,bottom,left] 
            verticalGrid : 0,
            horizontalGrid : 2,
            gridColor : "#C5EFF7",
            plotColor : "rgba(167, 227, 255, 1)",
            boundary : {minX:0,minY:0, maxX:8,maxY:2}
      };
      var graphDataMeds = {
            backgroundColor : "rgba(87, 208, 78, 1)", // default is white
            labelY : ["0", "2", "4", "6", "8", "10+"],
            padding : [7,5,20,10], //[top,right,bottom,left] 
            verticalGrid : 0,
            horizontalGrid : 5,
            gridColor : "#C5EFF7",
            plotColor : "rgba(227, 199, 67, 1)",
            boundary : {minX:0,minY:0, maxX:8,maxY:10}     
      };
          
          
      

               vm.graphData = [];
      var canvas = document.getElementById('tutorial');
          var ctx = canvas.getContext('2d');

        vm.changeSelection = function(idx){
        vm.selectedGraph = idx;
        var myplotdata = [];
         switch(idx)
         {
          case 0:
                      drawGraph(vm.oprational_gDate).then(function(data){
                      myplotdata = data;
                       vm.graphData = graphDataGrade;
                       drawGraphWithPlotData(myplotdata);
                      
                       });
                   
                   break;
          case 1:
                      getPlotdataNonGrade("Exercise").then(function(data){
                        console.log(data);
                      myplotdata = data;
                       vm.graphData = graphDataExercise
                      drawGraphWithPlotData(myplotdata);
                      
                    });
                  break; 
                 
          case 2: 
                        getPlotdataNonGrade("Smoke").then(function(data){
                          myplotdata = data;
                          vm.graphData = graphDataSmoke;
                          drawGraphWithPlotData(myplotdata);
                         
                        });
                  break;
                 
          case 3:
                      getPlotdataNonGrade("Drinks").then(function(data){
                        myplotdata = data;
                        vm.graphData = graphDataDrinks;
                        drawGraphWithPlotData(myplotdata);
                      
                      });
                  break; 
                  
          case 4:
                  getPlotdataNonGrade("Weight").then(function(data){
                    myplotdata = data;
                    vm.graphData = graphDataWeight;
                    drawGraphWithPlotData(myplotdata);
                  
                  });
                  break;
                  

          case 5:
                      getPlotdataNonGrade("Stress").then(function(data){
                        myplotdata = data;
                        vm.graphData = graphDataStress;
                        drawGraphWithPlotData(myplotdata);
                     
                      });
                  break;
                 

          case 6:
                  getPlotdataNonGrade("Medication").then(function(data){
                    myplotdata = data;
                    vm.graphData = graphDataMeds;
                    drawGraphWithPlotData(myplotdata);
                  
                  });
                  break;
                  

          default:
                  vm.graphHeading = "Grade";
                  myplotdata = [];
                  vm.graphData = graphDataGrade;
        }
       }
       
       var drawGraph = function(oprational_gDate){
           var tempDataHolder = [];
          return $q(function(resolve, reject) {
            var gradeGraphData =[];
             Graph.setInitialPdf().then(function(res){
                 tempDataHolder = Graph.openGradeJason(res);
                 vm.currentValue = tempDataHolder[tempDataHolder.length-1].grade;
                 vm.averageValue = Graph.getCommonFieldsAvg(tempDataHolder,'grade').toFixed(2);
                 tempDataHolder = Graph.getSevenExerciseData(tempDataHolder,moment());
                 gradeGraphData = Graph.getGradeDataForGraph(tempDataHolder[0]);
                  //upperGradeGraphData();
                  console.log(gradeGraphData);
                  gradeGraphData.graphHeader = "Current: Grade " + vm.currentValue +" |  Average: Grade "+ vm.averageValue;
                   resolve(gradeGraphData);
             },
             function(err){
                   console.log(gradeGraphData);
                 resolve(gradeGraphData);
             });
          });
        }


       var getPlotdataNonGrade = function(field){
        var tempDataHolder = [];
        if(field == "Exercise" || field == "Stress" || field == "Medication"){ 
            return $q(function(resolve, reject) {
            var exerciseGraphData =[];
            Graph.getPdfExercise(field).then(function(res){
               if(field == "Exercise"){
                   vm.currentValue = res[res.length-1].exercise+' mins';
                  vm.averageValue = Graph.getCommonFieldsAvg(res,'exercise').toFixed(0)+' mins';
                  exerciseGraphData = Graph.getExerciseDataForGraph(res);
                  exerciseGraphData.graphHeader = "Current: " + vm.currentValue +" mins |  Average: "+ vm.averageValue+" mins";
               
              }
              else if(field == "Stress"){
                  vm.currentValue = Graph.getStressText(res[res.length-1].stress);
                  vm.averageValue = Graph.getStressAvg(res,'stress');
                  exerciseGraphData = Graph.getStressDataForGraph(res);
                  exerciseGraphData.graphHeader = "Current: " + vm.currentValue +" Pack |  Average: "+ vm.averageValue+" Pack";
                 //vm.showRightGraphPoints =  getDataPointsDetails[1];
              }
              else if(field == "Medication"){
                  vm.currentValue = JSON.parse(res[res.length-1].medication).length+' Meds';
                  vm.averageValue = Graph.getMedsAvg(res).toFixed(0)+' Meds';
                  exerciseGraphData = Graph.getMedicationDataForGraph(res);
                  exerciseGraphData.graphHeader = "Current: " + vm.currentValue +" Meds |  Average: "+ vm.averageValue+" Meds";
                 //vm.showRightGraphPoints =  getDataPointsDetails[1];
              } 
                  resolve(exerciseGraphData);
             },
             function(err){
                  resolve(exerciseGraphData);
             });
          });
        }
        else if(field == "Smoke" || field == "Drinks" || field == "Weight"){
           var tempDataHolder = [];
           return $q(function(resolve, reject) {
            var smokeGraphData =[];
            Graph.getPdfSmoke(field).then(function(res){
              if(field == "Smoke"){
                  vm.currentValue = res[res.length-1].smoke;
                  vm.averageValue = Graph.getAvgSmoke(res);
                  smokeGraphData =Graph.getSmokeDataForGraph(res);
                  smokeGraphData.graphHeader = "Current: " + vm.currentValue +" Pack |  Average: "+ vm.averageValue+" Pack";
              }
              else if(field == "Drinks"){
                   vm.currentValue = res[res.length-1].drinks;
                    vm.averageValue = Graph.getAvgDrink(res);
                   smokeGraphData =Graph.getDrinksDataForGraph(res);
                   smokeGraphData.graphHeader = "Current: " + vm.currentValue +" Drinks |  Average: "+ vm.averageValue+" Drinks";
              } 
              else if(field == "Weight"){
                  vm.currentValue = res[res.length-1].weight+' kg';
                  vm.averageValue = Graph.getCommonFieldsAvg(res,'weight').toFixed(0)+' kg';
                  smokeGraphData = Graph.getWeightDataForGraph(res);
                  smokeGraphData.graphHeader = "Current: " + vm.currentValue +" kg |  Average: "+ vm.averageValue+" kg";
              } 
              resolve(smokeGraphData);
             },
             function(err){
                   resolve(smokeGraphData);
             });
          });
        }
      }


       var drawGraphWithPlotData = function(myplotdata){
        console.log(myplotdata);

        if(myplotdata=="")
          {
             
          }
        else
          {
              
          }
        
         
          var graph = new LineGraph(ctx,vm.graphData);
          graph.setDimension(Math.round(600),Math.round(200));
          ctx.setTransform(1, 0, 0, 1, 0, 0);
          graph.setData(myplotdata);
          graph.draw();
          var dataURL = canvas.toDataURL();
          Timeline.storeItemsInService(dataURL,myplotdata.graphHeader);
           document.getElementById('canvasImg').src = dataURL;
          refreshCanvas(graph);
          window.addEventListener("resize", refreshCanvas(graph));
     
    }
     var refreshCanvas = function(graph1){
        var canvasAtr = angular.element( document.querySelector( '#ehs-graph' ) );
        canvasAtr.attr('width',Math.round(window.innerWidth));
        canvasAtr.attr('height',Math.round(window.innerHeight*0.45));
        ctx.imageSmoothingEnabled = false;
         ctx.imageSmoothingQuality = "high";
        graph1.refresh()
        graph1.draw();
      }
   
       vm.drawImage = function(){
                             // save canvas image as data url (png format by default)
      var dataURL = canvas.toDataURL();
      console.log(dataURL);
      localStorage.setItem("IMAGE_URL",dataURL);
      // set canvasImg image src to dataURL
      // so it can be saved as an image
      document.getElementById('canvasImg').src = dataURL;
  }        
 
    return vm;
          
       }
}
)();



function setDefaultsForPdfViewer($scope) {  
    $scope.scroll = 0;
    $scope.loading = 'loading';

    $scope.onError = function (error) {
        console.error(error);
    };

    $scope.onLoad = function () {
        $scope.loading = '';
    };

    $scope.onProgress = function (progress) {
        console.log(progress);
    };
}


