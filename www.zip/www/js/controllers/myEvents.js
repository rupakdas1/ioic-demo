(function() {
	'use strict';
	
	 angular
      .module('app.controllers')
      .controller('myEvents', myEvents);
	   myEvents.$inject = ['$scope', '$state', '$window','AddReminders','$ionicModal','$cordovaDialogs','$filter','$ionicListDelegate'];
	   
	   function myEvents($scope, $state, $window,AddReminders,$ionicModal,$cordovaDialogs,$filter,$ionicListDelegate) {
	     var vm = this;
           vm.showlist=true;
             vm.Events=[];
     $scope.$on('$ionicView.beforeEnter', function (event, viewData) {
            $ionicListDelegate.closeOptionButtons();
            AddReminders.getEvents().then(
                    function(res){
                          if(viewData.stateParams.cameFrom=="editEvent"){
                          vm.Events = AddReminders.getEventsFromService();
                          vm.Events = res;
                          AddReminders.storeEventsInService(vm.Events);
                          }
                          else{
                            console.log("else",AddReminders.getEventsFromService());
                             for(var i=0;i<res.length;i++){
                              vm.Events[i] =res[i];
                            }
                            AddReminders.storeEventsInService(vm.Events);
                            console.log(vm.Events);
                           }
                          vm.showlist=true;                         
                          },
                        function(err){
                            vm.showlist=false;
                             $state.go('tab.profileMain');
                             vm.Events = [];
                        });
        
        });
	   	
		  vm.onItemDelete = function(item) {
        console.log("item",item)
                 $cordovaDialogs.confirm($filter('translate')('EVENT.DIALOGTEXT'), $filter('translate')('EVENT.DIALOGTITLE'), [$filter('translate')('QUESTFORDOCTOR.BUTTON'),$filter('translate')('QUESTFORDOCTOR.BUTTON2')])
                .then(function(buttonIndex) {
                // no button = 0, 'OK' = 1, 'Cancel' = 2
                        if(buttonIndex==1){
                            AddReminders.deleteEvent(item.event_name).then(
                                    function(res){                  
                                    },
                                    function(err){
                                      console.log(err);  
              });
                            vm.Events.splice(vm.Events.indexOf(item), 1);
                            console.log(vm.Events.length);
                            if(vm.Events.length==0){
                               vm.showlist=false;
                                $state.go('tab.profileMain');
                                vm.Events = [];
                            }
                        }
                });
      };
      vm.goToEditEvent = function(item){

         $state.go('editEvent',{items:JSON.stringify(item)});
         vm.Events = [];
      }
      vm.goToCreateEvent = function(){
         $state.go('createEvent');
         vm.Events = [];
      }	
	   	vm.goBack =  function(){
            $state.go('tab.profileMain');
            vm.Events = [];
        }
	   }
	   
	}
)();