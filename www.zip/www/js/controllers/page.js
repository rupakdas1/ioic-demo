(function () {
    'use strict';

    angular
      .module('app.controllers')
      .controller('PageCtrl', PageCtrl);

    PageCtrl.$inject = ['$scope', '$state','$ionicHistory'];

    /* @ngInject */
    function PageCtrl($scope, $state, $ionicHistory) {
        var vm = this;
        vm.title = 'PageCtrl';
        vm.pageTitle = "";
        vm.isAskOuestion="false";
        vm.isTAndC="false";

        function activate() {
            
        }

        vm.goHome = function() {
            console.log("xdvc")
            window.history.back();
        }

        vm.goComparision = function() {
            $state.go('comparision');
        }

        $scope.$on('pageChange', function(e, data) {
            vm.pageTitle = data.title;
            vm.leftButton = data.leftButton;
            vm.rightButton= data.rightButton;
        })
    }

})();

