(function() {
	'use strict';
	
	 angular
      .module('app.controllers')
      .controller('dcHowTo', dcHowTo);
	   dcHowTo.$inject = ['$scope', '$state','$stateParams','$ionicSlideBoxDelegate','$ionicScrollDelegate'];
	   
	   function dcHowTo($scope, $state,$stateParams,$ionicSlideBoxDelegate,$ionicScrollDelegate) {
              
             $scope.$on('$ionicView.beforeEnter', function (event, viewData) {
                 $ionicSlideBoxDelegate.slide(0);
            });   
             var vm=this; 

             vm.timelineData = [
                 {
                         avg_grade:3,
                         date:"2016-06-16",
                         today:true
                     
                 },
                     {
                         avg_grade:2,
                         date:"2016-06-15",
                         today:false
                     },
                      {
                         avg_grade:2,
                         date:"2016-06-14",
                         today:false
                     }
                 
             ];
             vm.today_date = moment("2016-06-16").format("dddd, MMMM Do");

             console.log(vm.timelineData);
             vm.lockSlide = function(){
                    $ionicSlideBoxDelegate.enableSlide(false);
             }
            
             vm.goBack = function(){
                 window.history.back();
             }
             vm.goNext = function(){
                 $ionicScrollDelegate.scrollTop();
                 $ionicSlideBoxDelegate.next();
             } 
		    
		}
				
})();