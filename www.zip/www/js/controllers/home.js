(function () {
    'use strict';
	  angular
      .module('app.controllers')
      .controller('home', home);
	   home.$inject = ['$scope', '$state'];
	   
	   function home($scope, $state) {
			var vm=this;
			vm.coverShow = false;
			vm.goTotAndC = function(){
				$state.go('tAndC',{"cameFrom":"home"});
			}
		 /* =================Slide  Changed ====================== */ 
		vm.slideHasChanged = function($index){
			if($index > 0)
				vm.coverShow = true;
			else
				vm.coverShow = false;
		}
	   }
})();