(function() {
	'use strict';
	
	 angular
      .module('app.controllers')
      .controller('erectionHS', erectionHS);
	   erectionHS.$inject = ['$scope', '$state', '$window'];
	   
	   function erectionHS($scope, $state, $window) {
	   	var vm = this;

	   	vm.goBack =  function(){
            window.history.back();
        }
	   }
	   
	}
)();