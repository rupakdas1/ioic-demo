// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
// 'starter.services' is found in services.js
// 'starter.controllers' is found in controllers.js
var db = null;
angular.module('app', ['ionic', 'app.controllers', 'app.services', 'app.directives','pascalprecht.translate','ngCordova','ionic-timepicker','ngAnimate','ionic-datepicker','ion-digit-keyboard', 'rzModule','pdf']) 
.run(function($ionicPlatform, $cordovaSQLite,$timeout, $rootScope, $location, $state, $translate) {
  $ionicPlatform.ready(function() {
   
        $translate('ANALYTICS').then(function(translation){
      function _waitForAnalytics(){
      if (typeof analytics !== 'undefined'){
          window.ga.startTrackerWithId(translation);
          window.ga.trackView('Home');
          window.ga.trackEvent('event', 'Event', 'Application Launched');
          window.ga.setAppVersion('0.0.8');
        } else {
         // console.log('analytics not ready');
          setTimeout(function() {
              _waitForAnalytics();
          }, 1000);
      }
      
      };
     _waitForAnalytics();
    })
 

    //screen.lockOrientation('portrait');


    $rootScope.statesArr = [];
    $rootScope.onBack = false;
    $rootScope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState) {
      window.ga && window.ga.trackView($location.path())
      if(!fromState.abstract && !$rootScope.onBack) {
        $rootScope.statesArr.push(fromState);
      }
      $rootScope.onBack = false;
    });
    
    if (window.cordova && window.cordova.plugins && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
      cordova.plugins.Keyboard.disableScroll(true);
    }
    if (window.StatusBar) {
      // org.apache.cordova.statusbar required
      StatusBar.styleDefault();
    }
    if(navigator && navigator.splashscreen) {
      $timeout(function() {
        navigator.splashscreen.hide();
        }, 100);
      }
      /*
         *Encrypting Database with sqlcipher adapter
         *Encrypted by secure key store
      */

    // var dbSecurePass = new Date().toString();
    // cordova.plugins.SecureKeyStore.set(function (secure_key) {
    //   //console.log(res); // res - string securely stored
    //   db = $cordovaSQLite.openDB({ name: "ehs.db", key: secure_key,  location: 'default' });
    //   $cordovaSQLite.execute(db, "CREATE TABLE IF NOT EXISTS tbl_master (id INTEGER, date DATETIME PRIMARY KEY, month_year text, grade_first text, grade_second text, grade_third text, exercise integer, drinks text, smoke text, weight integer, stress text, medication text)"); 
    //   $cordovaSQLite.execute(db, "CREATE TABLE IF NOT EXISTS tbl_medications (medication_name text PRIMARY KEY,recorded_date DATETIME)"); 
    //   $cordovaSQLite.execute(db, "CREATE TABLE IF NOT EXISTS tbl_queForDoctor (question_text text,recorded_date DATETIME,faq_answer text,graphIndex INTEGER)");     
    //   $cordovaSQLite.execute(db, "CREATE TABLE IF NOT EXISTS tbl_reminders (reminder_name text,recorded_date DATETIME,PRIMARY KEY (reminder_name, recorded_date))"); 
    //   $cordovaSQLite.execute(db, "CREATE TABLE IF NOT EXISTS tbl_events (event_name text,recorded_date DATETIME,location_text text,PRIMARY KEY (event_name, recorded_date))");
    //   $cordovaSQLite.execute(db, "CREATE TABLE IF NOT EXISTS tbl_appointments (appointment_name text,recorded_date DATETIME,location_text text,PRIMARY KEY (appointment_name, recorded_date))");
    // }, function (error) {
    //   console.log(error);
    // }, "dbKey", dbSecurePass);

	 

	    /* Dev test */
      db = window.openDatabase("my.db", "1.0", "Cordova Demo", 200000);
      //db = $cordovaSQLite.openDB({ name: "ehs.db", location: 1 });
     $cordovaSQLite.execute(db, "CREATE TABLE IF NOT EXISTS tbl_master (id INTEGER, date DATETIME PRIMARY KEY, month_year text, grade_first text, grade_second text, grade_third text, exercise integer, drinks text, smoke text, weight integer, stress text, medication text)"); 
      $cordovaSQLite.execute(db, "CREATE TABLE IF NOT EXISTS tbl_medications (medication_name text PRIMARY KEY,recorded_date DATETIME)"); 
      $cordovaSQLite.execute(db, "CREATE TABLE IF NOT EXISTS tbl_queForDoctor (question_text text,recorded_date DATETIME,faq_answer text,graphIndex INTEGER)");     
      $cordovaSQLite.execute(db, "CREATE TABLE IF NOT EXISTS tbl_reminders (reminder_name text,recorded_date DATETIME,PRIMARY KEY (reminder_name, recorded_date))"); 
      $cordovaSQLite.execute(db, "CREATE TABLE IF NOT EXISTS tbl_events (event_name text,recorded_date DATETIME,location_text text,PRIMARY KEY (event_name, recorded_date))");
      $cordovaSQLite.execute(db, "CREATE TABLE IF NOT EXISTS tbl_appointments (appointment_name text,recorded_date DATETIME,location_text text,PRIMARY KEY (appointment_name, recorded_date))");

  });
})
.config(function($stateProvider, $urlRouterProvider, $translateProvider,$ionicConfigProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
  .state('home', {
    url: '/home',
    templateUrl: 'templates/home.html',
    controller: 'home as vm'
  })
  .state('page', {
      abstract: true,
      controller: 'PageCtrl as page',
      templateUrl: 'templates/page.html'
    })
 
  .state('tAndC', {
    url: '/tAndC/:cameFrom',
    templateUrl: 'templates/terms/tAndC.html',
    controller: 'tAndC as vm'
  })
  .state('askQuestion', {
    url: '/askQuestion',
     params: {ans: null},
    templateUrl: 'templates/askQuestion.html',
    controller: 'askQuestion as vm'
  })
  .state('successAsk', {
    url: '/successAsk',
    templateUrl: 'templates/successAsk.html',
    controller: 'successAsk as vm'
  })
  .state('addRecords', {
    url: '/addRecords',
	  params : { record_by_date: null ,record_date:null},
    templateUrl: 'templates/dash-board/addRecords.html',
    controller: 'addRecords as vm'
  })
  .state('dcHowTo', {
    url: '/dcHowTo',
    templateUrl: 'templates/dcHowTo.html',
    controller: 'dcHowTo as vm'
  })
   .state('tlHowTo', {
    url: '/tlHowTo',
    templateUrl: 'templates/settings/tlHowTo.html',
    controller: 'dcHowTo as vm'
  })
  .state('myMeds', {
    url: '/myMeds',
    templateUrl: 'templates/profile/myMeds.html',
    controller: 'myMeds as vm'
  })
  .state('erectionHS', {
    url: '/erectionHS',
    templateUrl: 'templates/profile/erectionHS.html',
    controller: 'erectionHS as vm'
  })
  .state('myQuestions', {
    url: '/myQuestions/:camefrom',
    templateUrl: 'templates/profile/myQuestions.html',
    controller: 'myQuestions as vm'
  })
  .state('showQuestion', {
    url: '/showQuestion',
    params: {items: null},
    templateUrl: 'templates/profile/showQuestion.html',
    controller: 'showQuestion as vm'
  })
  .state('appHowTo', {
    url: '/appHowTo',
    templateUrl: 'templates/settings/appHowTo.html',
    controller: 'appHowTo as vm'
  })
	.state('profileHowTo', {
		url: '/profileHowTo',
		templateUrl: 'templates/profileHowTo.html',
		controller: 'dcHowTo as vm'
	})
  .state('enterPin', {
    url: '/enterPin',
    templateUrl: 'templates/settings/enterPin.html',
    controller: 'enterPin as vm'
  })
     .state('setReminder', {
    url: '/setReminder',
    templateUrl: 'templates/profile/setReminder.html',
    controller: 'setReminder as vm'
  })
   .state('editReminder', {
    url: '/editReminder',
    params: {items: null},
    templateUrl: 'templates/profile/setReminder.html',
    controller: 'setReminder as vm'
  })
    .state('myReminders', {
    url: '/myReminders/:cameFrom',
    templateUrl: 'templates/profile/myReminders.html',
    controller: 'myReminders as vm'
  })
    .state('createEvent', {
    url: '/createEvent',
    templateUrl: 'templates/profile/createEvent.html',
    controller: 'createEvent as vm'
  })
    .state('editEvent', {
    url: '/editEvent',
     params: {items: null},
    templateUrl: 'templates/profile/createEvent.html',
    controller: 'createEvent as vm'
  })
    .state('myEvents', {
    url: '/myEvents/:cameFrom',
    templateUrl: 'templates/profile/myEvents.html',
    controller: 'myEvents as vm'
  })
    .state('createAppointment', {
    url: '/createAppointment',
    templateUrl: 'templates/profile/createAppointment.html',
    controller: 'createAppointment as vm'
  })
    .state('editAppointment', {
    url: '/editAppointment',
     params: {items: null},
    templateUrl: 'templates/profile/createAppointment.html',
    controller: 'createAppointment as vm'
  })
     .state('myAppointments', {
    url: '/myAppointments/:cameFrom',
    templateUrl: 'templates/profile/myAppointments.html',
    controller: 'myAppointments as vm'
  })
  .state('sendEmail', {
    url: '/sendEmail/:cameFrom',
    templateUrl: 'templates/profile/sendEmail.html',
    controller: 'documentController as vm'
  })
	.state('tab', {
	url: '/tab',
	abstract: true,
	templateUrl: 'templates/tab.html',
	controller : 'tab as vm'
	})
  .state('tab.timeline', {
    url: '/timeline',
    views: {
      'tab-dash': {
        templateUrl: 'templates/timeline.html',
        controller: 'timeline as vm'
      }
    }
  })
  .state('tab.digitalCoach', {
    url: '/digitalCoach',
    views: {
      'tab-digital': {
        templateUrl: 'templates/digitalCoach.html',
        controller: 'digitalCoach as vm'
      }
    }
  })
  .state('tab.profileMain', {
    url: '/profile/profileMain',
    views: {
      'tab-profile': {
        templateUrl: 'templates/profile/profileMain.html',
        controller: 'profileMain as vm'
      }
    }
  })
   .state('tab.settings', {
    url: '/settings/settings',
    views: {
      'tab-settings': {
        templateUrl: 'templates/settings/settings.html',
        controller: 'settings as vm'
      }
    }
  });
  if(window.localStorage.getItem("ehsInstDate") == null){
        window.localStorage.setItem("ehsInstDate",moment());  
  }
  if(window.localStorage.getItem("returnUser") == "Y"){
    $urlRouterProvider.otherwise('/tab/timeline');
  }
  else {
    $urlRouterProvider.otherwise('/home');
  }
	$translateProvider.translations('en', lang);
	$translateProvider.preferredLanguage("en");
	$translateProvider.fallbackLanguage("en");
  $ionicConfigProvider.tabs.position('bottom');
  $ionicConfigProvider.views.swipeBackEnabled(false);
});
