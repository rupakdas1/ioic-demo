/**
  * <unordered-list /> directive for showing text in multiple li items
  * like questions discussions, ...
  **/
(function () {
    'use strict';

    angular
      .module('app.directives')
      .directive('unorderedList', unorderedList);

    unorderedList.$inject = ['$translate'];

    /* @ngInject */
    function unorderedList($translate) {
      return {
        restrict: 'E',
        templateUrl: 'templates/directives/unorderedList.html',
        replace: true,
        scope: {
          data: '=data'
        },
        controller: function($scope) {
          $scope.isObject = angular.isObject;
        }
      }
    }

})();
