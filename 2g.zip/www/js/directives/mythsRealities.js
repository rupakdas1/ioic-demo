/**
  * <myths-realities /> directive for showing text in multiple paras
  * like closer look, talking to partner, ...
  **/
(function () {
    'use strict';

    angular
      .module('app.directives')
      .directive('mythsRealities', mythsRealities);

    mythsRealities.$inject = ['$translate'];

    /* @ngInject */
    function mythsRealities($translate) {
      return {
        restrict: 'E',
        templateUrl: 'templates/directives/mythsRealities.html',
        replace: true,
        scope: {
          data: '=data',
          active: '=active'
        },
        controller: function($scope) {
          var vm = this;
          vm.showDesc = function(index) {
              $scope.active = index;
          }
        },
        controllerAs: 'vm'
      }
    }

})();
