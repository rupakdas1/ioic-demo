/**
  * <benefits-risks /> directive for showing text in multiple paras
  * like closer look, talking to partner, ...
  **/
(function () {
    'use strict';

    angular
      .module('app.directives')
      .directive('benefitsRisks', benefitsRisks);

    benefitsRisks.$inject = ['$translate'];

    /* @ngInject */
    function benefitsRisks($translate) {
      return {
        restrict: 'E',
        templateUrl: 'templates/directives/benefitsRisks.html',
        replace: true,
        scope: {
          data: '=data',
          active: '=active'
        },
        controller: function($scope) {
          var vm = this;
          vm.benefitsRisksActiveTab = null;
          vm.benefitsRisksTabs = [{
              title: 'TABS.POTENTIAL_NONC_BENEFITS',
              class: 'potential-nonc-benefits'
              }, {
              title: 'TABS.RISKS',
              class: 'risks-img'
              }, {
              title: 'TABS.CONTRAINDICATIONS',
              class: 'contraindications'
              }, {
              title: 'TABS.POSSIBLE_SIDE_EFFECTS',
              class: 'possible-side-effects'
          }];

          vm.changeBenefitsRisksTab = function(index) {
              $scope.active = index;
          }
        },
        controllerAs: 'vm'
      }
    }

})();
