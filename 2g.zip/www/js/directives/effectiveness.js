/**
  * <effectiveness /> directive for showing text in multiple paras
  * like closer look, talking to partner, ...
  **/
(function () {
    'use strict';

    angular
      .module('app.directives')
      .directive('effectiveness', effectiveness);

    effectiveness.$inject = ['$translate'];

    /* @ngInject */
    function effectiveness($translate) {
      return {
        restrict: 'E',
        templateUrl: 'templates/directives/effectiveness.html',
        replace: true,
        scope: {
          data: '=data'
        },
        controller: function($scope) {
          var vm = this;
          vm.isLower = function(header) {
            return /HAVE|NEVER_HAVE/.test(header);
          }
        },
        controllerAs: 'vm'
      }
    }

})();
