/**
  * <para-list /> directive for showing text in multiple paras
  * like closer look, talking to partner, ...
  **/
(function () {
    'use strict';

    angular
      .module('app.directives')
      .directive('paraList', paraList);

    paraList.$inject = ['$translate'];

    /* @ngInject */
    function paraList($translate) {
      return {
        restrict: 'E',
        templateUrl: 'templates/directives/paraList.html',
        replace: true,
        scope: {
          data: '=data'
        }
      }
    }

})();
