angular.module('app', ['ionic', 'app.controllers', 'app.services', 'app.directives', 'pascalprecht.translate'])

.run(function($ionicPlatform, $rootScope, $location, $translate,$state ) {
  $ionicPlatform.ready(function() {
    $translate('ANALYTICS').then(function(translation){
      localStorage.getItem('analytics') === 'HOME.SETTINGS.ANALYTICS.ON' && window.ga && window.ga.startTrackerWithId(translation);
    })
    
    if (window.cordova && window.cordova.plugins && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
      cordova.plugins.Keyboard.disableScroll(true);

    }
    if (window.StatusBar) {
      StatusBar.styleDefault();
    }

    $translate('ACCESS.CODE').then(function(translation) {
      localStorage.setItem('accessKey', translation);
    });
    $rootScope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState) {
      localStorage.getItem('analytics') === 'HOME.SETTINGS.ANALYTICS.ON' && window.ga && window.ga.trackView($location.path())
      if(!fromState.abstract && !$rootScope.onBack) {
        $rootScope.statesArr.push(fromState);
      }
      $rootScope.onBack = false;

    });

    $ionicPlatform.registerBackButtonAction(function () {
      if($state.current.name=="home" || $state.current.name=="access"){
        navigator.app.exitApp(); //<-- remove this line to disable the exit
      }else{
        $rootScope.goBack();
      }
    }, 100);
  });

  $rootScope.statesArr = [];
  $rootScope.onBack = false;
  
  $rootScope.$on('$stateChangeStart', function(evt, to, params) {
      if (to.redirectTo) {
        evt.preventDefault();
        $state.go(to.redirectTo, params, {location: 'replace'})
      }
    });
})

.config(function($stateProvider, $urlRouterProvider, $translateProvider) {
  $stateProvider
  // Main states for app
    .state('app', {
      abstract: true,
      controller: 'AppCtrl as app',
      templateUrl: 'templates/app.html'
    })
    .state('access', {
      parent: 'app',
      url: '/access',
      controller: 'AccessCtrl as app',
      templateUrl: 'templates/access.html'
    })
    .state('core_ui', {
      abstract: true,
      parent: 'app',
      controller: 'CoreCtrl as core',
      templateUrl: 'templates/core.html'
    })
    // Home state
    .state('home', {
      parent: 'core_ui',
      url: '/home',
      controller: "HomeCtrl as vm",
      templateUrl: 'templates/home.html'
    })
    .state('page', {
      abstract: true,
      parent: 'core_ui',
      controller: 'PageCtrl as page',
      templateUrl: 'templates/page.html'
    })
    // comparision state
    .state('comparision', {
      parent: 'page',
      url: '/comparision',
      controller: 'ComparisionCtrl as vm',
      templateUrl: 'templates/comparision.html'
    })
    // conversation state
    .state('conversation', {
      parent: 'page',
      url: '/conversation',
      controller: 'ConversationCtrl as vm',
      templateUrl: 'templates/conversation.html'
    })
    // Condoms state
    .state('condoms', {
      parent: 'page',
      url: '/condoms',
      controller: 'CondomsCtrl as vm',
      templateUrl: 'templates/with_every_intercourse_act/condoms.html'
    })
    // Diaphragm state
    .state('diaphragm', {
      parent: 'page',
      url: '/diaphragm',
      controller: 'DiaphragmCtrl as vm',
      templateUrl: 'templates/with_every_intercourse_act/diaphragm.html'
    })
    // Sponge state
    .state('sponge', {
      parent: 'page',
      url: '/sponge',
      controller: 'SpongeCtrl as vm',
      templateUrl: 'templates/with_every_intercourse_act/sponge.html'
    })
    // Copper iud state
    .state('e_copper_iud', {
      parent: 'page',
      url: '/e_copper_iud',
      controller: 'ECopperIUDCtrl as vm',
      templateUrl: 'templates/emergency/e_copper_iud.html'
    })
    // emergency pills state
    .state('e_pills', {
      parent: 'page',
      url: '/e_pills',
      controller: 'EPillsCtrl as vm',
      templateUrl: 'templates/emergency/e_pills.html'
    })
    // daily pills state
    .state('pill', {
      parent: 'page',
      url: '/pill',
      controller: 'PillCtrl as vm',
      templateUrl: 'templates/daily/pill.html'
    })
    // vaginal ring state
    .state('vaginal_ring', {
      parent: 'page',
      url: '/vaginal_ring',
      controller: 'VaginalRingCtrl as vm',
      templateUrl: 'templates/monthly/vaginal_ring.html'
    })
    // patch state
    .state('patch', {
      parent: 'page',
      url: '/patch',
      controller: 'PatchCtrl as vm',
      templateUrl: 'templates/monthly/patch.html'
    })
    // injection state
    .state('injection', {
      parent: 'page',
      url: '/injection',
      controller: 'InjectionCtrl as vm',
      templateUrl: 'templates/2_3_months/injection.html'
    })
    // iud state
    .state('iud', {
      parent: 'page',
      url: '/iud',
      controller: 'IUDCtrl as vm',
      templateUrl: 'templates/longer_reversible/iud.html'
    })
    // implant state
    .state('implant', {
      parent: 'page',
      url: '/implant',
      controller: 'ImplantCtrl as vm',
      templateUrl: 'templates/longer_reversible/implant.html'
    })
    // vasectomy state
    .state('vasectomy', {
      parent: 'page',
      url: '/vasectomy',
      controller: 'VasectomyCtrl as vm',
      templateUrl: 'templates/permanent/vasectomy.html'
    })
    // female sterilization tubal ligation state
    .state('female_sterilization_tubal_ligation', {
      parent: 'page',
      url: '/female_sterilization_tubal_ligation',
      controller: 'FemaleSterilizationTubalLigationCtrl as vm',
      templateUrl: 'templates/permanent/female_sterilization_tubal_ligation.html'
    })
    // female sterilization tubal occulusion state
    .state('female_sterilization_tubal_occulusion', {
      parent: 'page',
      url: '/female_sterilization_tubal_occulusion',
      controller: 'FemaleSterilizationTubalOcculusionCtrl as vm',
      templateUrl: 'templates/permanent/female_sterilization_tubal_occulusion.html'
    })

  $urlRouterProvider.otherwise('/access');

  $translateProvider.translations('en', lang);

  $translateProvider.preferredLanguage("en");
});
