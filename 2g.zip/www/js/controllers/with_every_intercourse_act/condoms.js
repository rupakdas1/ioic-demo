(function () {
    'use strict';

    angular
      .module('app.controllers')
      .controller('CondomsCtrl', CondomsCtrl);

    CondomsCtrl.$inject = ['$scope', '$state'];

    /* @ngInject */
    function CondomsCtrl($scope, $state) {
        var vm = this;
        vm.title = 'CondomsCtrl';

        $scope.$emit('pageChange', {
            title: 'CONDOMS.PAGE_TITLE'
        })

        vm.activeTab = 0;
        vm.tabs = ['TABS.EFFECTIVENESS', 'TABS.BENEFITS_RISKS', 'TABS.MYTHS_REALITIES'];

        vm.changeTab = function(index) {
            vm.activeTab = index;
            vm.benefitsRisksActive = null;
            vm.mythsRealitiesActive = null;
        }

        vm.benefitsRisksActive = null;
        vm.mythsRealitiesActive = null;

        vm.effectiveness = {
            notes: {
                items: ["CONDOMS.EFFECTIVENESS.LINE_1", "CONDOMS.EFFECTIVENESS.LINE_2"],
                type: 'para'
            },
            estimates: {
                headers: ["CONDOMS.EFFECTIVENESS.FEMALE_CONDOM", "CONDOMS.EFFECTIVENESS.MALE_CONDOM"],
                rows: [
                    [{
                        when: "TABS.PERFECT_USE",
                        no: 5
                    }, {
                        when: "TABS.PERFECT_USE",
                        no: 2
                    }],
                    [{
                        when: "TABS.TYPICAL_USE",
                        no: 20
                    }, {
                        when: "TABS.TYPICAL_USE",
                        no: 18
                    }]
                ]
            },
            comment: "CONDOMS.EFFECTIVENESS.COMMENT"
        }

        vm.benefitsRisks = {
            potentialNoncBenefits: {
                items: ["CONDOMS.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_1", "CONDOMS.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_2",
                "CONDOMS.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_3"],
                type: 'list'
            },
            risks: {
                _header: "CONDOMS.BENEFITS_RISKS.RISKS.HEADER",
                items: ["CONDOMS.BENEFITS_RISKS.RISKS.LINE_1", "CONDOMS.BENEFITS_RISKS.RISKS.LINE_2", "CONDOMS.BENEFITS_RISKS.RISKS.LINE_3","CONDOMS.BENEFITS_RISKS.RISKS.LINE_4","CONDOMS.BENEFITS_RISKS.RISKS.LINE_5"],
                type: 'list'
            },
            contraindications: {
                items: ["CONDOMS.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_1"],
                type: 'list'
            },
            possibleSideEffects: {
                items: []
            }
        }

        vm.mythsRealities = {
            items: [{
                text: 'CONDOMS.MYTHS_REALITIES.LINE_1',
                clickText: 'CONDOMS.MYTHS_REALITIES.LINE_CLICK_1'
            },{
                text: 'CONDOMS.MYTHS_REALITIES.LINE_2',
                clickText: 'CONDOMS.MYTHS_REALITIES.LINE_CLICK_2'
            },{
                text: 'CONDOMS.MYTHS_REALITIES.LINE_3',
                clickText: 'CONDOMS.MYTHS_REALITIES.LINE_CLICK_3'
            },{
                text: 'CONDOMS.MYTHS_REALITIES.LINE_4',
                clickText: 'CONDOMS.MYTHS_REALITIES.LINE_CLICK_4'
            },{
                text: 'CONDOMS.MYTHS_REALITIES.LINE_5',
                clickText: 'CONDOMS.MYTHS_REALITIES.LINE_CLICK_5'
            }]
        }

    }

})();

