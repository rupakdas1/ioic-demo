(function () {
    'use strict';

    angular
      .module('app.controllers')
      .controller('SpongeCtrl', SpongeCtrl);

    SpongeCtrl.$inject = ['$scope', '$state'];

    /* @ngInject */
    function SpongeCtrl($scope, $state) {
        var vm = this;
        vm.title = 'SpongeCtrl';

        $scope.$emit('pageChange', {
            title: 'SPONGE.PAGE_TITLE'
        })

        vm.activeTab = 0;
        vm.tabs = ['TABS.EFFECTIVENESS', 'TABS.BENEFITS_RISKS'];

        vm.changeTab = function(index) {
            vm.activeTab = index;
            vm.benefitsRisksActive = null;
            vm.mythsRealitiesActive = null;
        }

        vm.benefitsRisksActive = null;
        vm.mythsRealitiesActive = null;

        vm.effectiveness = {
            notes: {
                items: ["SPONGE.EFFECTIVENESS.LINE_1", "SPONGE.EFFECTIVENESS.LINE_2", "SPONGE.EFFECTIVENESS.LINE_3", "SPONGE.EFFECTIVENESS.LINE_4"],
                type: 'list'
            },
            estimates: {
                headers: ["SPONGE.EFFECTIVENESS.HAVE", "SPONGE.EFFECTIVENESS.NEVER_HAVE"],
                rows: [
                    [{
                        when: "TABS.PERFECT_USE",
                        no: 20
                    }, {
                        when: "TABS.PERFECT_USE",
                        no: 9
                    }],
                    [{
                        when: "TABS.TYPICAL_USE",
                        no: 24
                    }, {
                        when: "TABS.TYPICAL_USE",
                        no: 12
                    }]
                ]
            },
            comment: "SPONGE.EFFECTIVENESS.COMMENT"
        }

        vm.benefitsRisks = {
            potentialNoncBenefits: {
                items: ["SPONGE.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_1", "SPONGE.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_2",
                "SPONGE.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_3", "SPONGE.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_4"],
                type: 'list'
            },
            risks: {
                items: ["SPONGE.BENEFITS_RISKS.RISKS.LINE_1", "SPONGE.BENEFITS_RISKS.RISKS.LINE_2", "SPONGE.BENEFITS_RISKS.RISKS.LINE_3"],
                type: 'list'
            },
            contraindications: {
                items: ["SPONGE.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_1"],
                type: 'para'
            },
            possibleSideEffects: {
                items: ["SPONGE.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_1"],
                type: 'para'
            } 
        }

    }

})();

