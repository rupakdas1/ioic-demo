(function () {
    'use strict';

    angular
      .module('app.controllers')
      .controller('DiaphragmCtrl', DiaphragmCtrl);

    DiaphragmCtrl.$inject = ['$scope', '$state'];

    /* @ngInject */
    function DiaphragmCtrl($scope, $state) {
        var vm = this;
        vm.title = 'DiaphragmCtrl';

        $scope.$emit('pageChange', {
            title: 'DIAPHRAGM.PAGE_TITLE'
        })


        vm.activeTab = 0;
        vm.tabs = ['TABS.EFFECTIVENESS', 'TABS.BENEFITS_RISKS', 'TABS.MYTHS_REALITIES'];

        vm.changeTab = function(index) {
            vm.activeTab = index;
            vm.benefitsRisksActive = null;
            vm.mythsRealitiesActive = null;
        }

        vm.benefitsRisksActive = null;
        vm.mythsRealitiesActive = null;

        vm.effectiveness = {
            notes: {
                items: ["DIAPHRAGM.EFFECTIVENESS.LINE_1", "DIAPHRAGM.EFFECTIVENESS.LINE_2"],
                type: 'para'
            },
            estimates: {
                headers: ["DIAPHRAGM.TITLE"],
                rows: [
                    [{
                        when: "TABS.PERFECT_USE",
                        no: 6
                    }],
                    [{
                        when: "TABS.TYPICAL_USE",
                        no: 12
                    }]
                ]
            },
            comment: "DIAPHRAGM.EFFECTIVENESS.COMMENT"
        }

        vm.benefitsRisks = {
            potentialNoncBenefits: {
                items: ["DIAPHRAGM.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_1", "DIAPHRAGM.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_2",
                "DIAPHRAGM.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_3", "DIAPHRAGM.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_4"],
                type: 'list'
            },
            risks: {
                items: ["DIAPHRAGM.BENEFITS_RISKS.RISKS.LINE_1", "DIAPHRAGM.BENEFITS_RISKS.RISKS.LINE_2"],
                type: 'list'
            },
            contraindications: {
                header: "DIAPHRAGM.BENEFITS_RISKS.CONTRAINDICATIONS.HEADER",
                items: ["DIAPHRAGM.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_1", "DIAPHRAGM.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_2",
                    "DIAPHRAGM.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_3", { 
                        text: "DIAPHRAGM.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_4", sub: ["DIAPHRAGM.BENEFITS_RISKS.CONTRAINDICATIONS.SUB_1"]
                    }],
                type: 'list'
            },
            possibleSideEffects: {
                items: ["DIAPHRAGM.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_1"],
                type: 'para'
            } 
        }

        vm.mythsRealities = {
            items: [{
                text: 'DIAPHRAGM.MYTHS_REALITIES.LINE_1',
                clickText: 'DIAPHRAGM.MYTHS_REALITIES.LINE_CLICK_1'
            },{
                text: 'DIAPHRAGM.MYTHS_REALITIES.LINE_2',
                clickText: 'DIAPHRAGM.MYTHS_REALITIES.LINE_CLICK_2'
            },{
                text: 'DIAPHRAGM.MYTHS_REALITIES.LINE_3',
                clickText: 'DIAPHRAGM.MYTHS_REALITIES.LINE_CLICK_3'
            },{
                text: 'DIAPHRAGM.MYTHS_REALITIES.LINE_4',
                clickText: 'DIAPHRAGM.MYTHS_REALITIES.LINE_CLICK_4'
            }]
        }
    }

})();

