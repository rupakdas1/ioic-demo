(function () {
    'use strict';

    angular
      .module('app.controllers')
      .controller('ComparisionCtrl', ComparisionCtrl);

    ComparisionCtrl.$inject = ['$scope', '$state'];

    /* @ngInject */
    function ComparisionCtrl($scope, $state) {
        var vm = this;
        vm.title = 'ComparisionCtrl';

        $scope.$emit('pageChange', {
            title: 'HOME.COMPARISION'
        })
    }

})();

