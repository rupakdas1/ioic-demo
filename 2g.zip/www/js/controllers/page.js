(function () {
    'use strict';

    angular
      .module('app.controllers')
      .controller('PageCtrl', PageCtrl);

    PageCtrl.$inject = ['$scope', '$state'];

    /* @ngInject */
    function PageCtrl($scope, $state) {
        var vm = this;
        vm.title = 'PageCtrl';
        vm.pageTitle = "";

        ////////////////

        function activate() {
            
        }

        vm.goHome = function() {
            $state.go('home');
        }

        vm.goComparision = function() {
            $state.go('comparision');
        }

        $scope.$on('pageChange', function(e, data) {
            vm.pageTitle = data.title;
        })
    }

})();

