(function () {
    'use strict';

    angular
      .module('app.controllers')
      .controller('PillCtrl', PillCtrl);

    PillCtrl.$inject = ['$scope', '$state'];

    /* @ngInject */
    function PillCtrl($scope, $state) {
        var vm = this;
        vm.title = 'PillCtrl';

        $scope.$emit('pageChange', {
            title: 'PILL.PAGE_TITLE'
        })

        vm.activeTab = 0;
        vm.tabs = ['TABS.EFFECTIVENESS', 'TABS.BENEFITS_RISKS', 'TABS.MYTHS_REALITIES', 'TABS.REGIMENS', 'TABS.NO_OF_PILLS', 'TABS.TYPE_OF_PILLS'];

        vm.changeTab = function(index) {
            vm.activeTab = index;
            vm.benefitsRisksActive = null;
            vm.mythsRealitiesActive = null;
            vm.activePills = null;
        }

        vm.benefitsRisksActive = null;
        vm.mythsRealitiesActive = null;
        vm.activePills = null;

        vm.effectiveness = {
            notes: {
                subheader: "PILL.EFFECTIVENESS.SUBHEADER",
                items: ["PILL.EFFECTIVENESS.LINE_1", "PILL.EFFECTIVENESS.LINE_2"],
                type: 'list'
            },
            estimates: {
                headers: ["PILL.EFFECTIVENESS.THE_PILL"],
                rows: [
                    [{
                        when: "TABS.PERFECT_USE",
                        no: 0.3
                    }],
                    [{
                        when: "TABS.TYPICAL_USE",
                        no: 9
                    }]
                ]
            },
            comment: "PILL.EFFECTIVENESS.COMMENT"
        }

        vm.benefitsRisks = {
            potentialNoncBenefits: {
                col1: {
                    header: "PILL.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.HEADER",
                    items: ["PILL.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_1", "PILL.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_2",
                    "PILL.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_3","PILL.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_4","PILL.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_5"
                    ,"PILL.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_6"],
                    type: 'list'   
                },
                col2: {
                    header: "PILL.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.HEADER_1",
                    items: ["PILL.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_7", "PILL.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_8"],                    
                    type: 'list' 
                }
                
            },
            risks: {
                items: [{text: "PILL.BENEFITS_RISKS.RISKS.LINE_1", sub: ["PILL.BENEFITS_RISKS.RISKS.SUB_1"]}, "PILL.BENEFITS_RISKS.RISKS.LINE_2"],
                type: 'list'
            },
            contraindications: {
                header: "PILL.BENEFITS_RISKS.CONTRAINDICATIONS.HEADER",
                items: ["PILL.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_1", "PILL.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_2",
                "PILL.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_3", "PILL.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_4",
                "PILL.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_5", "PILL.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_6",
                "PILL.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_7", "PILL.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_8",
                "PILL.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_9", "PILL.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_10",
                "PILL.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_11", "PILL.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_12",
                "PILL.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_13", "PILL.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_14",
                "PILL.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_15", "PILL.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_16"],
                footer: "PILL.BENEFITS_RISKS.CONTRAINDICATIONS.FOOTER",
                type: 'list'
            },
            possibleSideEffects: {
                items: ["PILL.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_1", "PILL.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_2"],
                 footer: "PILL.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.FOOTER",
                 type: 'list'
            }
        }

        vm.mythsRealities = {
            items: [{
                text: 'PILL.MYTHS_REALITIES.LINE_1',
                clickText: 'PILL.MYTHS_REALITIES.LINE_CLICK_1'
            },{
                text: 'PILL.MYTHS_REALITIES.LINE_2',
                clickText: 'PILL.MYTHS_REALITIES.LINE_CLICK_2'
            },{
                text: 'PILL.MYTHS_REALITIES.LINE_3',
                clickText: 'PILL.MYTHS_REALITIES.LINE_CLICK_3'
            },{
                text: 'PILL.MYTHS_REALITIES.LINE_4',
                clickText: 'PILL.MYTHS_REALITIES.LINE_CLICK_4'
            },{
                text: 'PILL.MYTHS_REALITIES.LINE_5',
                clickText: 'PILL.MYTHS_REALITIES.LINE_CLICK_5'
            },{
                text: 'PILL.MYTHS_REALITIES.LINE_6',
                clickText: 'PILL.MYTHS_REALITIES.LINE_CLICK_6'
            }]
        }

        vm.typeOfPillsTabs = [{
              title: 'TABS.AMOUNT_OF_ESTROGEN',
              class: 'pills-ee'
              }, {
              title: 'TABS.TYPE_OF_PROGESTIN',
              class: 'pills-p4'
              }, {
              title: 'TABS.MONO_MULTI_PHASES',
              class: 'pills-mm'
              }];

        vm.changeTypeOfPillsTab = function(index) {
            vm.activePills = index;
        }

        vm.typeOfPillsMM = {
                header: "PILL.TYPE_OF_PILLS.MM.HEADER",
                items: ["PILL.TYPE_OF_PILLS.MM.LINE_1", "PILL.TYPE_OF_PILLS.MM.LINE_2"]
            }

    }

})();

