(function () {
    'use strict';

    angular
      .module('app.controllers')
      .controller('PatchCtrl', PatchCtrl);

    PatchCtrl.$inject = ['$scope', '$state'];

    /* @ngInject */
    function PatchCtrl($scope, $state) {
        var vm = this;
        vm.title = 'PatchCtrl';

        $scope.$emit('pageChange', {
            title: 'PATCH.PAGE_TITLE'
        })

        vm.activeTab = 0;
        vm.tabs = ['TABS.EFFECTIVENESS', 'TABS.BENEFITS_RISKS', 'TABS.MYTHS_REALITIES'];

        vm.changeTab = function(index) {
            vm.activeTab = index;
            vm.benefitsRisksActive = null;
            vm.mythsRealitiesActive = null;
        }

        vm.benefitsRisksActive = null;
        vm.mythsRealitiesActive = null;

        vm.effectiveness = {
            notes: {
                items: ["PATCH.EFFECTIVENESS.LINE_1", "PATCH.EFFECTIVENESS.LINE_2", "PATCH.EFFECTIVENESS.LINE_3", "PATCH.EFFECTIVENESS.LINE_4",
                "PATCH.EFFECTIVENESS.LINE_5"],
                type: 'list'
            },
            estimates: {
                headers: ["PATCH.TITLE"],
                rows: [
                    [{
                        when: "TABS.PERFECT_USE",
                        no: 0.3
                    }],
                    [{
                        when: "TABS.TYPICAL_USE",
                        no: 9
                    }]
                ]
            },
            comment: "PATCH.EFFECTIVENESS.COMMENT"
        }

        vm.benefitsRisks = {
            potentialNoncBenefits: {
                items: ["PATCH.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_1", "PATCH.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_2",
                "PATCH.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_3"],
                type: 'list'
            },
            risks: {
                items: [{ text: "PATCH.BENEFITS_RISKS.RISKS.LINE_1", sub: ["PATCH.BENEFITS_RISKS.RISKS.SUB_1", "PATCH.BENEFITS_RISKS.RISKS.SUB_2", "PATCH.BENEFITS_RISKS.RISKS.SUB_3"]}],
                type: 'list'
            },
            contraindications: {
                header: "PATCH.BENEFITS_RISKS.CONTRAINDICATIONS.HEADER",
                items: ["PATCH.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_1", "PATCH.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_2",
                "PATCH.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_3", "PATCH.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_4",
                "PATCH.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_5", "PATCH.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_6",
                "PATCH.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_7", "PATCH.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_8",
                "PATCH.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_9", "PATCH.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_10",
                "PATCH.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_11", "PATCH.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_12",
                "PATCH.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_13", "PATCH.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_14",
                "PATCH.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_15", "PATCH.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_16"],
                footer: "PATCH.BENEFITS_RISKS.CONTRAINDICATIONS.FOOTER",
                type: 'list'
            },
            possibleSideEffects: {
                items: ["PATCH.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_1", "PATCH.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_2",
                 "PATCH.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_3"],
                 footer: "PATCH.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.FOOTER",
                 type: 'list'
            }
        }

        vm.mythsRealities = {
            items: [{
                text: 'PATCH.MYTHS_REALITIES.LINE_1',
                clickText: 'PATCH.MYTHS_REALITIES.LINE_CLICK_1'
            },{
                text: 'PATCH.MYTHS_REALITIES.LINE_2',
                clickText: 'PATCH.MYTHS_REALITIES.LINE_CLICK_2'
            },{
                text: 'PATCH.MYTHS_REALITIES.LINE_3',
                clickText: 'PATCH.MYTHS_REALITIES.LINE_CLICK_3'
            }]
        }

    }

})();

