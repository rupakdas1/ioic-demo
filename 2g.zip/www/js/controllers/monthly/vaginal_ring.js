(function () {
    'use strict';

    angular
      .module('app.controllers')
      .controller('VaginalRingCtrl', VaginalRingCtrl);

    VaginalRingCtrl.$inject = ['$scope', '$state'];

    /* @ngInject */
    function VaginalRingCtrl($scope, $state) {
        var vm = this;
        vm.title = 'VaginalRingCtrl';

        $scope.$emit('pageChange', {
            title: 'VAGINAL_RING.PAGE_TITLE'
        })

        vm.activeTab = 0;
        vm.tabs = ['TABS.EFFECTIVENESS', 'TABS.BENEFITS_RISKS', 'TABS.MYTHS_REALITIES'];

        vm.changeTab = function(index) {
            vm.activeTab = index;
            vm.benefitsRisksActive = null;
            vm.mythsRealitiesActive = null;
        }

        vm.benefitsRisksActive = null;
        vm.mythsRealitiesActive = null;

        vm.effectiveness = {
            notes: {
                subheader: "VAGINAL_RING.EFFECTIVENESS.SUBHEADER",
                items: ["VAGINAL_RING.EFFECTIVENESS.LINE_1", "VAGINAL_RING.EFFECTIVENESS.LINE_2", "VAGINAL_RING.EFFECTIVENESS.LINE_3", "VAGINAL_RING.EFFECTIVENESS.LINE_4",
                "VAGINAL_RING.EFFECTIVENESS.LINE_5"],
                type: 'list'
            },
            estimates: {
                headers: ["VAGINAL_RING.TITLE"],
                rows: [
                    [{
                        when: "TABS.PERFECT_USE",
                        no: 0.3
                    }],
                    [{
                        when: "TABS.TYPICAL_USE",
                        no: 9
                    }]
                ]
            },
            comment: "VAGINAL_RING.EFFECTIVENESS.COMMENT"
        }

        vm.benefitsRisks = {
            potentialNoncBenefits: {
                items: ["VAGINAL_RING.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_1"],
                type: 'para'
            },
            risks: {
                items: [{ text: "VAGINAL_RING.BENEFITS_RISKS.RISKS.LINE_1", sub: ["VAGINAL_RING.BENEFITS_RISKS.RISKS.SUB_1"]}],
                type: 'list'
            },
            contraindications: {
                header: "VAGINAL_RING.BENEFITS_RISKS.CONTRAINDICATIONS.HEADER",
                items: ["VAGINAL_RING.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_1", "VAGINAL_RING.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_2",
                "VAGINAL_RING.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_3", "VAGINAL_RING.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_4",
                "VAGINAL_RING.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_5", "VAGINAL_RING.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_6",
                "VAGINAL_RING.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_7", "VAGINAL_RING.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_8",
                "VAGINAL_RING.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_9", "VAGINAL_RING.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_10",
                "VAGINAL_RING.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_11", "VAGINAL_RING.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_12",
                "VAGINAL_RING.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_13", "VAGINAL_RING.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_14",
                "VAGINAL_RING.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_15", "VAGINAL_RING.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_16"],
                footer: "VAGINAL_RING.BENEFITS_RISKS.CONTRAINDICATIONS.FOOTER",
                type: 'list'
            },
            possibleSideEffects: {
                items: ["VAGINAL_RING.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_1", "VAGINAL_RING.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_2",
                 "VAGINAL_RING.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_3", "VAGINAL_RING.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_4",
                 "VAGINAL_RING.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_5"],
                 footer: "VAGINAL_RING.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.FOOTER",
                 type: 'list'
            }
        }

        vm.mythsRealities = {
            items: [{
                text: 'VAGINAL_RING.MYTHS_REALITIES.LINE_1',
                clickText: 'VAGINAL_RING.MYTHS_REALITIES.LINE_CLICK_1'
            },{
                text: 'VAGINAL_RING.MYTHS_REALITIES.LINE_2',
                clickText: 'VAGINAL_RING.MYTHS_REALITIES.LINE_CLICK_2'
            },{
                text: 'VAGINAL_RING.MYTHS_REALITIES.LINE_3',
                clickText: 'VAGINAL_RING.MYTHS_REALITIES.LINE_CLICK_3'
            },{
                text: 'VAGINAL_RING.MYTHS_REALITIES.LINE_4',
                clickText: 'VAGINAL_RING.MYTHS_REALITIES.LINE_CLICK_4'
            }]
        }

    }

})();

