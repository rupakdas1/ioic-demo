(function () {
    'use strict';

    angular
      .module('app.controllers')
      .controller('VasectomyCtrl', VasectomyCtrl);

    VasectomyCtrl.$inject = ['$scope', '$state'];

    /* @ngInject */
    function VasectomyCtrl($scope, $state) {
        var vm = this;
        vm.title = 'VasectomyCtrl';

        $scope.$emit('pageChange', {
            title: 'VASECTOMY.PAGE_TITLE'
        })

        vm.activeTab = 0;
        vm.tabs = ['TABS.EFFECTIVENESS', 'TABS.BENEFITS_RISKS', 'TABS.MYTHS_REALITIES'];

        vm.changeTab = function(index) {
            vm.activeTab = index;
            vm.benefitsRisksActive = null;
            vm.mythsRealitiesActive = null;
        }

        vm.benefitsRisksActive = null;
        vm.mythsRealitiesActive = null;

        vm.effectiveness = {
            notes: {
                items: ["VASECTOMY.EFFECTIVENESS.LINE_1", "VASECTOMY.EFFECTIVENESS.LINE_2"],
                type: 'para'
            },
            estimates: {
                headers: ["VASECTOMY.TITLE"],
                rows: [
                    [{
                        when: "VASECTOMY.EFFECTIVENESS.AFTER_VASECTOMY",
                        no: "0.10 - 0.15"
                    }]
                ]
            },
            is_permanent: true
        }

        vm.benefitsRisks = {
            potentialNoncBenefits: {
                items: ["VASECTOMY.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_1", "VASECTOMY.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_2",
                "VASECTOMY.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_3", "VASECTOMY.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_4",
                "VASECTOMY.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_5"],
                type: 'list'
            },
            risks: {
                items: ["VASECTOMY.BENEFITS_RISKS.RISKS.LINE_1", "VASECTOMY.BENEFITS_RISKS.RISKS.LINE_2"],
                type: 'list'
            },
            contraindications: {
                header: "VASECTOMY.BENEFITS_RISKS.CONTRAINDICATIONS.HEADER",
                items: ["VASECTOMY.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_1", "VASECTOMY.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_2",
                "VASECTOMY.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_3", "VASECTOMY.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_4",
                "VASECTOMY.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_5", "VASECTOMY.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_6",
                "VASECTOMY.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_7", "VASECTOMY.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_8"],
                type: 'list'
            },
            possibleSideEffects: {
                items: ["VASECTOMY.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_1", "VASECTOMY.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_2"],
                type: 'list'
            }
        }

        vm.mythsRealities = {
            items: [{
                text: 'VASECTOMY.MYTHS_REALITIES.LINE_1',
                clickText: 'VASECTOMY.MYTHS_REALITIES.LINE_CLICK_1'
            },{
                text: 'VASECTOMY.MYTHS_REALITIES.LINE_2',
                clickText: 'VASECTOMY.MYTHS_REALITIES.LINE_CLICK_2'
            },{
                text: 'VASECTOMY.MYTHS_REALITIES.LINE_3',
                clickText: 'VASECTOMY.MYTHS_REALITIES.LINE_CLICK_3'
            }]
        }

    }

})();

