(function () {
    'use strict';

    angular
      .module('app.controllers')
      .controller('FemaleSterilizationTubalOcculusionCtrl', FemaleSterilizationTubalOcculusionCtrl);

    FemaleSterilizationTubalOcculusionCtrl.$inject = ['$scope', '$state'];

    /* @ngInject */
    function FemaleSterilizationTubalOcculusionCtrl($scope, $state) {
        var vm = this;
        vm.title = 'FemaleSterilizationTubalOcculusionCtrl';

        $scope.$emit('pageChange', {
            title: 'TUBAL_OCCLUSION.PAGE_TITLE'
        })

        vm.activeTab = 0;
        vm.tabs = ['TABS.EFFECTIVENESS', 'TABS.BENEFITS_RISKS', 'TABS.MYTHS_REALITIES'];

        vm.changeTab = function(index) {
            vm.activeTab = index;
            vm.benefitsRisksActive = null;
            vm.mythsRealitiesActive = null;
        }

        vm.benefitsRisksActive = null;
        vm.mythsRealitiesActive = null;

        vm.effectiveness = {
            notes: {
                items: ["TUBAL_OCCLUSION.EFFECTIVENESS.LINE_1", "TUBAL_OCCLUSION.EFFECTIVENESS.LINE_2"],
                type: 'list'
            },
            estimates: {
                headers: ["TUBAL_OCCLUSION.EFFECTIVENESS.TABLE_HEADER"],
                rows: [
                    [{
                        when: "TUBAL_OCCLUSION.EFFECTIVENESS.AFTER_TUBAL_OCCLUSION",
                        no: 0.5
                    }]
                ]
            },
			is_permanent: true
        }

        vm.benefitsRisks = {
            potentialNoncBenefits: {
                items: ["TUBAL_OCCLUSION.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_1", "TUBAL_OCCLUSION.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_2",
                "TUBAL_OCCLUSION.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_3"],
                type: 'list'
            },
            risks: {
                items: ["TUBAL_OCCLUSION.BENEFITS_RISKS.RISKS.LINE_1", "TUBAL_OCCLUSION.BENEFITS_RISKS.RISKS.LINE_2"],
                type: 'list'
            },
            contraindications: {
                items: ["TUBAL_OCCLUSION.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_1", "TUBAL_OCCLUSION.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_2",
                "TUBAL_OCCLUSION.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_3", "TUBAL_OCCLUSION.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_4",
                "TUBAL_OCCLUSION.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_5", "TUBAL_OCCLUSION.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_6",
                "TUBAL_OCCLUSION.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_7", "TUBAL_OCCLUSION.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_8",
                "TUBAL_OCCLUSION.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_9", "TUBAL_OCCLUSION.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_10"],
                type: 'list'
            },
            possibleSideEffects: {
                items: ["TUBAL_OCCLUSION.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_1"],
                type: 'para'
            }
        }

        vm.mythsRealities = {
            items: [{
                text: 'TUBAL_OCCLUSION.MYTHS_REALITIES.LINE_1',
                clickText: 'TUBAL_OCCLUSION.MYTHS_REALITIES.LINE_CLICK_1'
            },{
                text: 'TUBAL_OCCLUSION.MYTHS_REALITIES.LINE_2',
                clickText: 'TUBAL_OCCLUSION.MYTHS_REALITIES.LINE_CLICK_2'
            },{
                text: 'TUBAL_OCCLUSION.MYTHS_REALITIES.LINE_3',
                clickText: 'TUBAL_OCCLUSION.MYTHS_REALITIES.LINE_CLICK_3'
            },{
                text: 'TUBAL_OCCLUSION.MYTHS_REALITIES.LINE_4',
                clickText: 'TUBAL_OCCLUSION.MYTHS_REALITIES.LINE_CLICK_4'
            }]
        }

    }

})();

