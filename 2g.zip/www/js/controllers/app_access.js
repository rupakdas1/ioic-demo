(function () {
    'use strict';

    angular
      .module('app.controllers')
      .controller('AccessCtrl', AccessCtrl);

    AccessCtrl.$inject = ['$state'];

    /* @ngInject */
    function AccessCtrl($state) {
        var vm = this;
        vm.title = 'AccessCtrl';
        vm.accessKey = "";
        vm.validate = false;
        vm.validationMessage = "";

        activate();

        var bcrypt = dcodeIO.bcrypt;

        vm.access = function() {
            if(bcrypt.compareSync(vm.accessKey+'', localStorage.getItem('accessKey'))) {
                localStorage.setItem('fromAccess', true)
                localStorage.setItem('allowed', true)
                $state.go('home')
            } else {
                vm.validate = true;
                vm.validationMessage = "ACCESS.VALIDATION_MESSAGE";
            }
        }

        if(JSON.parse(localStorage.getItem('allowed'))) {
            $state.go('home');
        } else {
            $state.go('access');
        }

        ////////////////

        function activate() {
            
        }
    }

})();

