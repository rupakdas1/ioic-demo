(function () {
    'use strict';

    angular
      .module('app.controllers')
      .controller('EPillsCtrl', EPillsCtrl);

    EPillsCtrl.$inject = ['$scope', '$state'];

    /* @ngInject */
    function EPillsCtrl($scope, $state) {
        var vm = this;
        vm.title = 'EPillsCtrl';

        $scope.$emit('pageChange', {
            title: 'EMERGENCY_PILLS.PAGE_TITLE'
        })

        vm.activeTab = 0;
        vm.tabs = ['TABS.EFFECTIVENESS', 'TABS.BENEFITS_RISKS', 'TABS.MYTHS_REALITIES'];

        vm.changeTab = function(index) {
            vm.activeTab = index;
            vm.benefitsRisksActive = null;
            vm.mythsRealitiesActive = null;
        }

        vm.benefitsRisksActive = null;
        vm.mythsRealitiesActive = null;

        vm.effectiveness = {
            notes: {
                subheader: "EMERGENCY_PILLS.EFFECTIVENESS.SUBHEADER",
                items: [{
                    text: "EMERGENCY_PILLS.EFFECTIVENESS.LINE_1", sub: ["EMERGENCY_PILLS.EFFECTIVENESS.SUB_1", "EMERGENCY_PILLS.EFFECTIVENESS.SUB_2",
                    "EMERGENCY_PILLS.EFFECTIVENESS.SUB_3"]
                }, "EMERGENCY_PILLS.EFFECTIVENESS.LINE_2", "EMERGENCY_PILLS.EFFECTIVENESS.LINE_3"],
                type: 'list'
            },
            estimates: {
                headers: ["EMERGENCY_PILLS.TITLE"],
                rows: [
                    [{
                        when: "EMERGENCY_PILLS.EFFECTIVENESS.AFTER_PILL_USE",
                        no: "0.6 - 3.5"
                    }]
                ]
            },
            comment: "EMERGENCY_PILLS.EFFECTIVENESS.COMMENT"
        }

        vm.benefitsRisks = {
            potentialNoncBenefits: {
                items: ["EMERGENCY_PILLS.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_1"],
                type: 'list'
            },
            risks: {
                items: ["EMERGENCY_PILLS.BENEFITS_RISKS.RISKS.LINE_1"],
                type: 'para'
            },
            contraindications: {
                header: "EMERGENCY_PILLS.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_1",
				items: ["EMERGENCY_PILLS.BENEFITS_RISKS.CONTRAINDICATIONS.SUB_1"],
                type: 'list'
            },
            possibleSideEffects: {
                items: ["EMERGENCY_PILLS.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_1", "EMERGENCY_PILLS.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_2",
                 "EMERGENCY_PILLS.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_3"],
                 type: 'list'
            }
        }

        vm.mythsRealities = {
            items: [{
                text: 'EMERGENCY_PILLS.MYTHS_REALITIES.LINE_1',
                clickText: 'EMERGENCY_PILLS.MYTHS_REALITIES.LINE_CLICK_1'
            },{
                text: 'EMERGENCY_PILLS.MYTHS_REALITIES.LINE_2',
                clickText: 'EMERGENCY_PILLS.MYTHS_REALITIES.LINE_CLICK_2'
            },{
                text: 'EMERGENCY_PILLS.MYTHS_REALITIES.LINE_3',
                clickText: 'EMERGENCY_PILLS.MYTHS_REALITIES.LINE_CLICK_3'
            },{
                text: 'EMERGENCY_PILLS.MYTHS_REALITIES.LINE_4',
                clickText: 'EMERGENCY_PILLS.MYTHS_REALITIES.LINE_CLICK_4'
            }]
        }

    }

})();

