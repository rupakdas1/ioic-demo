(function () {
    'use strict';

    angular
      .module('app.controllers')
      .controller('ECopperIUDCtrl', ECopperIUDCtrl);

    ECopperIUDCtrl.$inject = ['$scope', '$state'];

    /* @ngInject */
    function ECopperIUDCtrl($scope, $state) {
        var vm = this;
        vm.title = 'ECopperIUDCtrl';

        $scope.$emit('pageChange', {
            title: 'E_COPPER_IUD.PAGE_TITLE'
        })

        vm.activeTab = 0;
        vm.tabs = ['TABS.EFFECTIVENESS', 'TABS.BENEFITS_RISKS', 'TABS.MYTHS_REALITIES'];

        vm.changeTab = function(index) {
            vm.activeTab = index;
            vm.benefitsRisksActive = null;
            vm.mythsRealitiesActive = null;
        }

        vm.benefitsRisksActive = null;
        vm.mythsRealitiesActive = null;

        vm.effectiveness = {
            notes: {
                subheader: "E_COPPER_IUD.EFFECTIVENESS.SUBHEADER",
                items: ["E_COPPER_IUD.EFFECTIVENESS.LINE_1", "E_COPPER_IUD.EFFECTIVENESS.LINE_2"],
                type: 'list'
            },
            estimates: {
                headers: ["E_COPPER_IUD.TITLE"],
                rows: [
                    [{
                        when: "E_COPPER_IUD.EFFECTIVENESS.AFTER_IUD",
                        no: "<0.1"
                    }]
                ]
            }
        }

        vm.benefitsRisks = {
            potentialNoncBenefits: {
                items: ["E_COPPER_IUD.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_1", "E_COPPER_IUD.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_2"],
                type: 'list'
            },
            risks: {
                items: ["E_COPPER_IUD.BENEFITS_RISKS.RISKS.LINE_1"],
                type: 'para'
            },
            contraindications: {
                items: ["E_COPPER_IUD.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_1", "E_COPPER_IUD.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_2"],
                type: 'list'
            },
            possibleSideEffects: {
                items: ["E_COPPER_IUD.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_1", "E_COPPER_IUD.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_2",
                "E_COPPER_IUD.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_3"],
                type: 'list'
            }
        }

        vm.mythsRealities = {
            items: [{
                text: 'E_COPPER_IUD.MYTHS_REALITIES.LINE_1',
                clickText: 'E_COPPER_IUD.MYTHS_REALITIES.LINE_CLICK_1'
            },{
                text: 'E_COPPER_IUD.MYTHS_REALITIES.LINE_2',
                clickText: 'E_COPPER_IUD.MYTHS_REALITIES.LINE_CLICK_2'
            }]
        }

    }

})();

