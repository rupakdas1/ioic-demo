(function () {
    'use strict';

    angular
      .module('app.controllers')
      .controller('IUDCtrl', IUDCtrl);

    IUDCtrl.$inject = ['$scope', '$state'];

    /* @ngInject */
    function IUDCtrl($scope, $state) {
        var vm = this;
        vm.title = 'IUDCtrl';

        $scope.$emit('pageChange', {
            title: 'IUD.PAGE_TITLE'
        })

        vm.activeTab = 0;
        vm.tabs = ['TABS.EFFECTIVENESS', 'TABS.BENEFITS_RISKS', 'TABS.MYTHS_REALITIES'];

        vm.changeTab = function(index) {
            vm.activeTab = index;
            vm.benefitsRisksActive = null;
            vm.mythsRealitiesActive = null;
        }

        vm.benefitsRisksActive = null;
        vm.mythsRealitiesActive = null;

        vm.effectiveness = {
            notes: {
                subheader: "IUD.EFFECTIVENESS.SUBHEADER",
                items: ["IUD.EFFECTIVENESS.LINE_1", "IUD.EFFECTIVENESS.LINE_2", "IUD.EFFECTIVENESS.LINE_3", "IUD.EFFECTIVENESS.LINE_4",
                "IUD.EFFECTIVENESS.LINE_5"],
                type: 'list'
            },
            estimates: {
                headers: ["IUD.TITLE"],
                rows: [
                    [{
                        when: "IUD.EFFECTIVENESS.TYPICAL_HORMONAL",
                        no: 0.2
                    }],
                    [{
                        when: "IUD.EFFECTIVENESS.TYPICAL_COPPER",
                        no: 0.8
                    }]
                ]
            }
        }

        vm.benefitsRisks = {
            potentialNoncBenefits: {
                items: ["IUD.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_1", "IUD.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_2",
                "IUD.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_3", "IUD.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_4",
                "IUD.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_5"],
                type: 'list'
            },
            risks: {
                items: ["IUD.BENEFITS_RISKS.RISKS.LINE_1", "IUD.BENEFITS_RISKS.RISKS.LINE_2", "IUD.BENEFITS_RISKS.RISKS.LINE_3"],
                type: 'list'
            },
            contraindications: {
                header: "IUD.BENEFITS_RISKS.CONTRAINDICATIONS.HEADER",
                items: ["IUD.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_1", "IUD.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_2",
                "IUD.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_3", "IUD.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_4",
                "IUD.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_5", "IUD.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_6",
                "IUD.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_7", "IUD.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_8",
                "IUD.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_9", "IUD.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_10",
                "IUD.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_11"],
                type: 'list'
            },
            possibleSideEffects: {
                items: ["IUD.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_1", "IUD.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_2",
                 "IUD.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_3", "IUD.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_4"],
                 type: 'list'
            }
        }

        vm.mythsRealities = {
            items: [{
                text: 'IUD.MYTHS_REALITIES.LINE_1',
                clickText: 'IUD.MYTHS_REALITIES.LINE_CLICK_1'
            },{
                text: 'IUD.MYTHS_REALITIES.LINE_2',
                clickText: 'IUD.MYTHS_REALITIES.LINE_CLICK_2'
            },{
                text: 'IUD.MYTHS_REALITIES.LINE_3',
                clickText: 'IUD.MYTHS_REALITIES.LINE_CLICK_3'
            },{
                text: 'IUD.MYTHS_REALITIES.LINE_4',
                clickText: 'IUD.MYTHS_REALITIES.LINE_CLICK_4'
            },{
                text: 'IUD.MYTHS_REALITIES.LINE_5',
                clickText: 'IUD.MYTHS_REALITIES.LINE_CLICK_5'
            }]
        }

    }

})();

