(function () {
    'use strict';

    angular
      .module('app.controllers')
      .controller('ImplantCtrl', ImplantCtrl);

    ImplantCtrl.$inject = ['$scope', '$state'];

    /* @ngInject */
    function ImplantCtrl($scope, $state) {
        var vm = this;
        vm.title = 'ImplantCtrl';

        $scope.$emit('pageChange', {
            title: 'IMPLANT.PAGE_TITLE'
        })

        vm.activeTab = 0;
        vm.tabs = ['TABS.EFFECTIVENESS', 'TABS.BENEFITS_RISKS', 'TABS.MYTHS_REALITIES'];

        vm.changeTab = function(index) {
            vm.activeTab = index;
            vm.benefitsRisksActive = null;
            vm.mythsRealitiesActive = null;
        }

        vm.benefitsRisksActive = null;
        vm.mythsRealitiesActive = null;

        vm.effectiveness = {
            notes: {
                items: ["IMPLANT.EFFECTIVENESS.LINE_1", "IMPLANT.EFFECTIVENESS.LINE_2", "IMPLANT.EFFECTIVENESS.LINE_3", "IMPLANT.EFFECTIVENESS.LINE_4"],
                type: 'list'
            },
            estimates: {
                headers: ["IMPLANT.TITLE"],
                rows: [
                    [{
                        when: "IMPLANT.EFFECTIVENESS.PERFECT_TYPICAL_USE",
                        no: 0.05
                    }]
                ]
            },
            comment: "IMPLANT.EFFECTIVENESS.COMMENT"
        }

        vm.benefitsRisks = {
            potentialNoncBenefits: {
                items: ["IMPLANT.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_1", "IMPLANT.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_2",
                "IMPLANT.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_3", "IMPLANT.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_4"],
                type: 'list'
            },
            risks: {
                items: ["IMPLANT.BENEFITS_RISKS.RISKS.LINE_1", "IMPLANT.BENEFITS_RISKS.RISKS.LINE_2"],
                type: 'list'
            },
            contraindications: {
                items: ["IMPLANT.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_1", "IMPLANT.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_2"],
                type: 'list'
            },
            possibleSideEffects: {
                col1: {
                    items: ["IMPLANT.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_1", "IMPLANT.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_2",
                     "IMPLANT.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_3", "IMPLANT.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_4"],
                     type: 'list'
                },
                col2: {
                    items: ["IMPLANT.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_5", "IMPLANT.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_6",
                     "IMPLANT.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_7", "IMPLANT.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_8", "IMPLANT.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_9"],
                     type: 'list'  
                }
            }
        }

        vm.mythsRealities = {
            items: [{
                text: 'IMPLANT.MYTHS_REALITIES.LINE_1',
                clickText: 'IMPLANT.MYTHS_REALITIES.LINE_CLICK_1'
            },{
                text: 'IMPLANT.MYTHS_REALITIES.LINE_2',
                clickText: 'IMPLANT.MYTHS_REALITIES.LINE_CLICK_2'
            }]
        }

    }

})();

