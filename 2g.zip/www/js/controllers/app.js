angular.module('app.controllers', []);

(function () {
    'use strict';

    angular
      .module('app.controllers')
      .controller('AppCtrl', AppCtrl);

    AppCtrl.$inject = ['$state'];

    /* @ngInject */
    function AppCtrl($state) {
        var vm = this;
        vm.title = 'AppCtrl';

        activate();

        if(JSON.parse(localStorage.getItem('allowed'))) {
            $state.go('home');
        } else {
            $state.go('access');
        }

        ////////////////

        function activate() {
            
        }
    }

})();

