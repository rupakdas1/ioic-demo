(function () {
  'use strict';

  angular
    .module('app.controllers')
    .controller('CoreCtrl', CoreCtrl);

  CoreCtrl.$inject = ['$state', '$rootScope', '$timeout'];

  /* @ngInject */
  function CoreCtrl($state, $rootScope, $timeout) {
    var vm = this;
    vm.title = 'CoreCtrl';
    vm.state = $state;
    activate();

    vm.referencesView = false;
    vm.settingsView = false;
    vm.licenseView = false;
    vm.validate = false;
    vm.validationMessage = "";

    ////////////////

    function activate() {

    }

    $rootScope.goBack = vm.goBack = function() {
      if($rootScope.statesArr.length > 0) {
        var poppedState = $rootScope.statesArr.pop()
        $rootScope.onBack = true;
        $state.go(poppedState.name || 'home');
      }
    }

    vm.openLink = function(e) {
      cordova.InAppBrowser.open(e, '_blank', 'location=yes');
      return false;
    }

    vm.showReferences = function() {
      vm.referencesView = true;
      document.getElementById('references-content-hldr').style.webkitOverflowScrolling = 'touch';
        document.getElementById('settingsContent').style.display = 'none';
        document.getElementById('license-content-hldr').style.display = 'none';
    }
    vm.hideReferences = function() {
      vm.referencesView = false;
      $timeout(function() {
        document.getElementById('references-content-hldr').scrollTop = 0;
      }, 50);
        document.getElementById('settingsContent').style.display = 'block';
        document.getElementById('license-content-hldr').style.display = 'block';
    }
    vm.showSettings = function() {
      vm.settingsView = true;
    }
    vm.hideSettings = function() {
      if(!vm.isAgreed()){
        vm.settingsView = false;
        //$state.go('home'); // added here by bala on Jill's request
        vm.settings.currentTab = 'templates/settings/analytics.html'; 
      } else{
        vm.validate = true;
        vm.validationMessage = "Please accept the Terms of Use to start using the application.";
      }
    }

    vm.showLicense = function() {
      vm.licenseView = true;
    }
    vm.hideLicense = function() {
      vm.licenseView = false; 
      document.getElementById('license-content-hldr').scrollTop = 0;
    }

    vm.acceptedTerms = function() {
      localStorage.setItem('termsAccepted', true);
      vm.hideSettings();
    }

    vm.isAgreed = function() {
      return !JSON.parse(localStorage.getItem('termsAccepted'));
    }

    vm.settings = {};

    vm.settings.tabs = [{
          title: 'SETTINGS.TAB1',
          url: 'templates/settings/analytics.html'
      }, {
          title: 'SETTINGS.TAB2',
          url: 'templates/settings/terms_of_use.html'
      }, {
          title: 'SETTINGS.TAB3',
          url: 'templates/settings/privacy.html'
    }];

    vm.settings.currentTab = 'templates/settings/analytics.html';

    vm.settings.setCurrentTab = function (tab) {
      vm.settings.currentTab = tab.url;
      document.getElementById('settingsContent').childNodes[0].scrollTop = 0;
    }
    vm.settings.isActiveTab = function(tabUrl) {
      return tabUrl == vm.settings.currentTab;
    }
    vm.settings.analytics = {
      'SETTINGS.ANALYTICS.ON': 'green',
      'SETTINGS.ANALYTICS.OFF': 'red'
    }
    var analyticsState = localStorage.getItem('analytics'); 
    if(analyticsState) {
      vm.settings.analyticsToggle = analyticsState;
    } else {
      vm.settings.analyticsToggle = 'SETTINGS.ANALYTICS.ON';
    }

    vm.analyticsChange = function() {
      localStorage.setItem('analytics', vm.settings.analyticsToggle)
    }

  }

})();

