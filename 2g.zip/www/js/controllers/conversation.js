(function () {
    'use strict';

    angular
      .module('app.controllers')
      .controller('ConversationCtrl', ConversationCtrl);

    ConversationCtrl.$inject = ['$scope', '$state'];

    /* @ngInject */
    function ConversationCtrl($scope, $state) {
        var vm = this;
        vm.title = 'ConversationCtrl';

        $scope.$emit('pageChange', {
            title: 'HOME.CONVERSATION'
        })

        vm.conversationOptions = ["CONVERSATION.YES", "CONVERSATION.NO", "CONVERSATION.NO_PARTNER", "CONVERSATION.TIPS"];
        vm.activeOption = null;
        vm.changeTypeOfOption = function(index) {
            vm.activeOption = index;
        }

        vm.tips1 = {
            items: ["CONVERSATION.TIPS_OPTION_LINE_1", "CONVERSATION.TIPS_OPTION_LINE_2", "CONVERSATION.TIPS_OPTION_LINE_3"]
        }

        vm.tips2 = {
            items: ["CONVERSATION.TIPS_OPTION_LINE_4", "CONVERSATION.TIPS_OPTION_LINE_5"]
        }
    }

})();

