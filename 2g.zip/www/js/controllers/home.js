(function () {
    'use strict';

    angular
      .module('app.controllers')
      .controller('HomeCtrl', HomeCtrl);

    HomeCtrl.$inject = ['$scope', '$state'];

    /* @ngInject */
    function HomeCtrl($scope, $state) {
        var vm = this;
        vm.title = 'HomeCtrl';

        vm.reset = function(e, overlay) {
            if(e && e.target.tagName === 'IMG' && !overlay) {
                return;
            }
            vm.withEveryOverlay = false;
            vm.emergencyOverlay = false;
            vm.dailyOverlay = false;
            vm.weeklyOverlay = false;
            vm.monthsOverlay = false;
            vm.longOverlay = false;
            vm.permanentOverlay = false;
        }
        
        activate();

        if(JSON.parse(localStorage.getItem('fromAccess')) || !JSON.parse(localStorage.getItem('termsAccepted'))) {
            localStorage.setItem('fromAccess', false)
            $scope.$parent.core.showSettings();
            $scope.$parent.core.settings.currentTab = 'templates/settings/terms_of_use.html'
        } else if(!JSON.parse(localStorage.getItem('allowed'))) {
            $state.go('access');
        }

        vm.goComparision = function() {
            $state.go('comparision');
        }

        vm.goConversation = function() {
            $state.go('conversation');
        }
        
        vm.showOverlay = function(e, overlay) {
            vm.reset(e, true);
            switch(overlay) {
                case 'withEvery': vm.withEveryOverlay = true;
                                break;
                case 'emergency': vm.emergencyOverlay = true;
                                break;
                case 'daily': vm.dailyOverlay = true;
                                break;
                case 'weekly': vm.weeklyOverlay = true;
                                break;
                case 'months': vm.monthsOverlay = true;
                                break;
                case 'long': vm.longOverlay = true;
                                break;
                case 'permanent': vm.permanentOverlay = true;
                                break;
            }
        }

        vm.reset();

        ////////////////

        function activate() {
            
        }
    }

})();

