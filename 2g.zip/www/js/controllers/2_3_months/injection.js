(function () {
    'use strict';

    angular
      .module('app.controllers')
      .controller('InjectionCtrl', InjectionCtrl);

    InjectionCtrl.$inject = ['$scope', '$state'];

    /* @ngInject */
    function InjectionCtrl($scope, $state) {
        var vm = this;
        vm.title = 'InjectionCtrl';

        $scope.$emit('pageChange', {
            title: 'INJECTION.PAGE_TITLE'
        })

        vm.activeTab = 0;
        vm.tabs = ['TABS.EFFECTIVENESS', 'TABS.BENEFITS_RISKS', 'TABS.MYTHS_REALITIES'];

        vm.changeTab = function(index) {
            vm.activeTab = index;
            vm.benefitsRisksActive = null;
            vm.mythsRealitiesActive = null;
        }

        vm.benefitsRisksActive = null;
        vm.mythsRealitiesActive = null;

        vm.effectiveness = {
            notes: {
                items: ["INJECTION.EFFECTIVENESS.LINE_1", "INJECTION.EFFECTIVENESS.LINE_2", "INJECTION.EFFECTIVENESS.LINE_3", "INJECTION.EFFECTIVENESS.LINE_4"],
                type: 'list'
            },
            estimates: {
                headers: ["INJECTION.EFFECTIVENESS.WHEN"],
                rows: [
                    [{
                        when: "TABS.PERFECT_USE",
                        when_sub: "INJECTION.EFFECTIVENESS.WHEN_SUB",
                        no: 0.2
                    }],
                    [{
                        when: "TABS.TYPICAL_USE",
                        no: 6
                    }]
                ]
            }
        }

        vm.benefitsRisks = {
            potentialNoncBenefits: {
                items: ["INJECTION.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_1", "INJECTION.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_2",
                "INJECTION.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_3", "INJECTION.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_4",
                "INJECTION.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_5", "INJECTION.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_6",
                "INJECTION.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_7", "INJECTION.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_8"],
                type: 'list'
            },
            risks: {
                items: ["INJECTION.BENEFITS_RISKS.RISKS.LINE_1", "INJECTION.BENEFITS_RISKS.RISKS.LINE_2"],
                type: 'list'
            },
            contraindications: {
                col1: {
                    header: "INJECTION.BENEFITS_RISKS.CONTRAINDICATIONS.HEADER_1",
                    items: ["INJECTION.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_1", "INJECTION.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_2"],
                    type: 'list'
                },
                col2: {
                    header: "INJECTION.BENEFITS_RISKS.CONTRAINDICATIONS.HEADER_2",
                    items: ["INJECTION.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_3"],
                    type: 'list'
                }
            },
            possibleSideEffects: {
                items: ["INJECTION.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_1", "INJECTION.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_2",
                 "INJECTION.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_3"],
                 type: 'list'
            }
        }

        vm.mythsRealities = {
            items: [{
                text: 'INJECTION.MYTHS_REALITIES.LINE_1',
                clickText: 'INJECTION.MYTHS_REALITIES.LINE_CLICK_1'
            },{
                text: 'INJECTION.MYTHS_REALITIES.LINE_2',
                clickText: 'INJECTION.MYTHS_REALITIES.LINE_CLICK_2'
            },{
                text: 'INJECTION.MYTHS_REALITIES.LINE_3',
                clickText: 'INJECTION.MYTHS_REALITIES.LINE_CLICK_3'
            },{
                text: 'INJECTION.MYTHS_REALITIES.LINE_4',
                clickText: 'INJECTION.MYTHS_REALITIES.LINE_CLICK_4'
            }]
        }

    }

})();

