angular.module('app.controllers', []);

(function () {
    'use strict';

    angular
      .module('app.controllers')
      .controller('AppCtrl', AppCtrl);

    AppCtrl.$inject = ['$state'];

    /* @ngInject */
    function AppCtrl($state) {
        var vm = this;
        vm.title = 'AppCtrl';

        activate();

        if(JSON.parse(localStorage.getItem('allowed'))) {
            $state.go('home');
        } else {
            $state.go('access');
        }

        ////////////////

        function activate() {
            
        }
    }

})();


(function () {
    'use strict';

    angular
      .module('app.controllers')
      .controller('AccessCtrl', AccessCtrl);

    AccessCtrl.$inject = ['$state'];

    /* @ngInject */
    function AccessCtrl($state) {
        var vm = this;
        vm.title = 'AccessCtrl';
        vm.accessKey = "";
        vm.validate = false;
        vm.validationMessage = "";

        activate();

        var bcrypt = dcodeIO.bcrypt;

        vm.access = function() {
            if(bcrypt.compareSync(vm.accessKey+'', localStorage.getItem('accessKey'))) {
                localStorage.setItem('fromAccess', true)
                localStorage.setItem('allowed', true)
                $state.go('home')
            } else {
                vm.validate = true;
                vm.validationMessage = "ACCESS.VALIDATION_MESSAGE";
            }
        }

        if(JSON.parse(localStorage.getItem('allowed'))) {
            $state.go('home');
        } else {
            $state.go('access');
        }

        ////////////////

        function activate() {
            
        }
    }

})();


(function () {
    'use strict';

    angular
      .module('app.controllers')
      .controller('ComparisionCtrl', ComparisionCtrl);

    ComparisionCtrl.$inject = ['$scope', '$state'];

    /* @ngInject */
    function ComparisionCtrl($scope, $state) {
        var vm = this;
        vm.title = 'ComparisionCtrl';

        $scope.$emit('pageChange', {
            title: 'HOME.COMPARISION'
        })
    }

})();


(function () {
    'use strict';

    angular
      .module('app.controllers')
      .controller('ConversationCtrl', ConversationCtrl);

    ConversationCtrl.$inject = ['$scope', '$state'];

    /* @ngInject */
    function ConversationCtrl($scope, $state) {
        var vm = this;
        vm.title = 'ConversationCtrl';

        $scope.$emit('pageChange', {
            title: 'HOME.CONVERSATION'
        })

        vm.conversationOptions = ["CONVERSATION.YES", "CONVERSATION.NO", "CONVERSATION.NO_PARTNER", "CONVERSATION.TIPS"];
        vm.activeOption = null;
        vm.changeTypeOfOption = function(index) {
            vm.activeOption = index;
        }

        vm.tips1 = {
            items: ["CONVERSATION.TIPS_OPTION_LINE_1", "CONVERSATION.TIPS_OPTION_LINE_2", "CONVERSATION.TIPS_OPTION_LINE_3"]
        }

        vm.tips2 = {
            items: ["CONVERSATION.TIPS_OPTION_LINE_4", "CONVERSATION.TIPS_OPTION_LINE_5"]
        }
    }

})();


(function () {
  'use strict';

  angular
    .module('app.controllers')
    .controller('CoreCtrl', CoreCtrl);

  CoreCtrl.$inject = ['$state', '$rootScope', '$timeout'];

  /* @ngInject */
  function CoreCtrl($state, $rootScope, $timeout) {
    var vm = this;
    vm.title = 'CoreCtrl';
    vm.state = $state;
    activate();

    vm.referencesView = false;
    vm.settingsView = false;
    vm.licenseView = false;
    vm.validate = false;
    vm.validationMessage = "";

    ////////////////

    function activate() {

    }

    $rootScope.goBack = vm.goBack = function() {
      if($rootScope.statesArr.length > 0) {
        var poppedState = $rootScope.statesArr.pop()
        $rootScope.onBack = true;
        $state.go(poppedState.name || 'home');
      }
    }

    vm.openLink = function(e) {
      cordova.InAppBrowser.open(e, '_blank', 'location=yes');
      return false;
    }

    vm.showReferences = function() {
      vm.referencesView = true;
      document.getElementById('references-content-hldr').style.webkitOverflowScrolling = 'touch';
        document.getElementById('settingsContent').style.display = 'none';
        document.getElementById('license-content-hldr').style.display = 'none';
    }
    vm.hideReferences = function() {
      vm.referencesView = false;
      $timeout(function() {
        document.getElementById('references-content-hldr').scrollTop = 0;
      }, 50);
        document.getElementById('settingsContent').style.display = 'block';
        document.getElementById('license-content-hldr').style.display = 'block';
    }
    vm.showSettings = function() {
      vm.settingsView = true;
    }
    vm.hideSettings = function() {
      if(!vm.isAgreed()){
        vm.settingsView = false;
        //$state.go('home'); // added here by bala on Jill's request
        vm.settings.currentTab = 'templates/settings/analytics.html'; 
      } else{
        vm.validate = true;
        vm.validationMessage = "Please accept the Terms of Use to start using the application.";
      }
    }

    vm.showLicense = function() {
      vm.licenseView = true;
    }
    vm.hideLicense = function() {
      vm.licenseView = false; 
      document.getElementById('license-content-hldr').scrollTop = 0;
    }

    vm.acceptedTerms = function() {
      localStorage.setItem('termsAccepted', true);
      vm.hideSettings();
    }

    vm.isAgreed = function() {
      return !JSON.parse(localStorage.getItem('termsAccepted'));
    }

    vm.settings = {};

    vm.settings.tabs = [{
          title: 'SETTINGS.TAB1',
          url: 'templates/settings/analytics.html'
      }, {
          title: 'SETTINGS.TAB2',
          url: 'templates/settings/terms_of_use.html'
      }, {
          title: 'SETTINGS.TAB3',
          url: 'templates/settings/privacy.html'
    }];

    vm.settings.currentTab = 'templates/settings/analytics.html';

    vm.settings.setCurrentTab = function (tab) {
      vm.settings.currentTab = tab.url;
      document.getElementById('settingsContent').childNodes[0].scrollTop = 0;
    }
    vm.settings.isActiveTab = function(tabUrl) {
      return tabUrl == vm.settings.currentTab;
    }
    vm.settings.analytics = {
      'SETTINGS.ANALYTICS.ON': 'green',
      'SETTINGS.ANALYTICS.OFF': 'red'
    }
    var analyticsState = localStorage.getItem('analytics'); 
    if(analyticsState) {
      vm.settings.analyticsToggle = analyticsState;
    } else {
      vm.settings.analyticsToggle = 'SETTINGS.ANALYTICS.ON';
    }

    vm.analyticsChange = function() {
      localStorage.setItem('analytics', vm.settings.analyticsToggle)
    }

  }

})();


(function () {
    'use strict';

    angular
      .module('app.controllers')
      .controller('HomeCtrl', HomeCtrl);

    HomeCtrl.$inject = ['$scope', '$state'];

    /* @ngInject */
    function HomeCtrl($scope, $state) {
        var vm = this;
        vm.title = 'HomeCtrl';

        vm.reset = function(e, overlay) {
            if(e && e.target.tagName === 'IMG' && !overlay) {
                return;
            }
            vm.withEveryOverlay = false;
            vm.emergencyOverlay = false;
            vm.dailyOverlay = false;
            vm.weeklyOverlay = false;
            vm.monthsOverlay = false;
            vm.longOverlay = false;
            vm.permanentOverlay = false;
        }
        
        activate();

        if(JSON.parse(localStorage.getItem('fromAccess')) || !JSON.parse(localStorage.getItem('termsAccepted'))) {
            localStorage.setItem('fromAccess', false)
            $scope.$parent.core.showSettings();
            $scope.$parent.core.settings.currentTab = 'templates/settings/terms_of_use.html'
        } else if(!JSON.parse(localStorage.getItem('allowed'))) {
            $state.go('access');
        }

        vm.goComparision = function() {
            $state.go('comparision');
        }

        vm.goConversation = function() {
            $state.go('conversation');
        }
        
        vm.showOverlay = function(e, overlay) {
            vm.reset(e, true);
            switch(overlay) {
                case 'withEvery': vm.withEveryOverlay = true;
                                break;
                case 'emergency': vm.emergencyOverlay = true;
                                break;
                case 'daily': vm.dailyOverlay = true;
                                break;
                case 'weekly': vm.weeklyOverlay = true;
                                break;
                case 'months': vm.monthsOverlay = true;
                                break;
                case 'long': vm.longOverlay = true;
                                break;
                case 'permanent': vm.permanentOverlay = true;
                                break;
            }
        }

        vm.reset();

        ////////////////

        function activate() {
            
        }
    }

})();


(function () {
    'use strict';

    angular
      .module('app.controllers')
      .controller('PageCtrl', PageCtrl);

    PageCtrl.$inject = ['$scope', '$state'];

    /* @ngInject */
    function PageCtrl($scope, $state) {
        var vm = this;
        vm.title = 'PageCtrl';
        vm.pageTitle = "";

        ////////////////

        function activate() {
            
        }

        vm.goHome = function() {
            $state.go('home');
        }

        vm.goComparision = function() {
            $state.go('comparision');
        }

        $scope.$on('pageChange', function(e, data) {
            vm.pageTitle = data.title;
        })
    }

})();


(function () {
    'use strict';

    angular
      .module('app.controllers')
      .controller('InjectionCtrl', InjectionCtrl);

    InjectionCtrl.$inject = ['$scope', '$state'];

    /* @ngInject */
    function InjectionCtrl($scope, $state) {
        var vm = this;
        vm.title = 'InjectionCtrl';

        $scope.$emit('pageChange', {
            title: 'INJECTION.PAGE_TITLE'
        })

        vm.activeTab = 0;
        vm.tabs = ['TABS.EFFECTIVENESS', 'TABS.BENEFITS_RISKS', 'TABS.MYTHS_REALITIES'];

        vm.changeTab = function(index) {
            vm.activeTab = index;
            vm.benefitsRisksActive = null;
            vm.mythsRealitiesActive = null;
        }

        vm.benefitsRisksActive = null;
        vm.mythsRealitiesActive = null;

        vm.effectiveness = {
            notes: {
                items: ["INJECTION.EFFECTIVENESS.LINE_1", "INJECTION.EFFECTIVENESS.LINE_2", "INJECTION.EFFECTIVENESS.LINE_3", "INJECTION.EFFECTIVENESS.LINE_4"],
                type: 'list'
            },
            estimates: {
                headers: ["INJECTION.EFFECTIVENESS.WHEN"],
                rows: [
                    [{
                        when: "TABS.PERFECT_USE",
                        when_sub: "INJECTION.EFFECTIVENESS.WHEN_SUB",
                        no: 0.2
                    }],
                    [{
                        when: "TABS.TYPICAL_USE",
                        no: 6
                    }]
                ]
            }
        }

        vm.benefitsRisks = {
            potentialNoncBenefits: {
                items: ["INJECTION.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_1", "INJECTION.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_2",
                "INJECTION.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_3", "INJECTION.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_4",
                "INJECTION.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_5", "INJECTION.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_6",
                "INJECTION.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_7", "INJECTION.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_8"],
                type: 'list'
            },
            risks: {
                items: ["INJECTION.BENEFITS_RISKS.RISKS.LINE_1", "INJECTION.BENEFITS_RISKS.RISKS.LINE_2"],
                type: 'list'
            },
            contraindications: {
                col1: {
                    header: "INJECTION.BENEFITS_RISKS.CONTRAINDICATIONS.HEADER_1",
                    items: ["INJECTION.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_1", "INJECTION.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_2"],
                    type: 'list'
                },
                col2: {
                    header: "INJECTION.BENEFITS_RISKS.CONTRAINDICATIONS.HEADER_2",
                    items: ["INJECTION.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_3"],
                    type: 'list'
                }
            },
            possibleSideEffects: {
                items: ["INJECTION.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_1", "INJECTION.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_2",
                 "INJECTION.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_3"],
                 type: 'list'
            }
        }

        vm.mythsRealities = {
            items: [{
                text: 'INJECTION.MYTHS_REALITIES.LINE_1',
                clickText: 'INJECTION.MYTHS_REALITIES.LINE_CLICK_1'
            },{
                text: 'INJECTION.MYTHS_REALITIES.LINE_2',
                clickText: 'INJECTION.MYTHS_REALITIES.LINE_CLICK_2'
            },{
                text: 'INJECTION.MYTHS_REALITIES.LINE_3',
                clickText: 'INJECTION.MYTHS_REALITIES.LINE_CLICK_3'
            },{
                text: 'INJECTION.MYTHS_REALITIES.LINE_4',
                clickText: 'INJECTION.MYTHS_REALITIES.LINE_CLICK_4'
            }]
        }

    }

})();


(function () {
    'use strict';

    angular
      .module('app.controllers')
      .controller('PillCtrl', PillCtrl);

    PillCtrl.$inject = ['$scope', '$state'];

    /* @ngInject */
    function PillCtrl($scope, $state) {
        var vm = this;
        vm.title = 'PillCtrl';

        $scope.$emit('pageChange', {
            title: 'PILL.PAGE_TITLE'
        })

        vm.activeTab = 0;
        vm.tabs = ['TABS.EFFECTIVENESS', 'TABS.BENEFITS_RISKS', 'TABS.MYTHS_REALITIES', 'TABS.REGIMENS', 'TABS.NO_OF_PILLS', 'TABS.TYPE_OF_PILLS'];

        vm.changeTab = function(index) {
            vm.activeTab = index;
            vm.benefitsRisksActive = null;
            vm.mythsRealitiesActive = null;
            vm.activePills = null;
        }

        vm.benefitsRisksActive = null;
        vm.mythsRealitiesActive = null;
        vm.activePills = null;

        vm.effectiveness = {
            notes: {
                subheader: "PILL.EFFECTIVENESS.SUBHEADER",
                items: ["PILL.EFFECTIVENESS.LINE_1", "PILL.EFFECTIVENESS.LINE_2"],
                type: 'list'
            },
            estimates: {
                headers: ["PILL.EFFECTIVENESS.THE_PILL"],
                rows: [
                    [{
                        when: "TABS.PERFECT_USE",
                        no: 0.3
                    }],
                    [{
                        when: "TABS.TYPICAL_USE",
                        no: 9
                    }]
                ]
            },
            comment: "PILL.EFFECTIVENESS.COMMENT"
        }

        vm.benefitsRisks = {
            potentialNoncBenefits: {
                col1: {
                    header: "PILL.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.HEADER",
                    items: ["PILL.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_1", "PILL.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_2",
                    "PILL.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_3","PILL.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_4","PILL.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_5"
                    ,"PILL.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_6"],
                    type: 'list'   
                },
                col2: {
                    header: "PILL.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.HEADER_1",
                    items: ["PILL.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_7", "PILL.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_8"],                    
                    type: 'list' 
                }
                
            },
            risks: {
                items: [{text: "PILL.BENEFITS_RISKS.RISKS.LINE_1", sub: ["PILL.BENEFITS_RISKS.RISKS.SUB_1"]}, "PILL.BENEFITS_RISKS.RISKS.LINE_2"],
                type: 'list'
            },
            contraindications: {
                header: "PILL.BENEFITS_RISKS.CONTRAINDICATIONS.HEADER",
                items: ["PILL.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_1", "PILL.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_2",
                "PILL.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_3", "PILL.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_4",
                "PILL.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_5", "PILL.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_6",
                "PILL.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_7", "PILL.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_8",
                "PILL.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_9", "PILL.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_10",
                "PILL.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_11", "PILL.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_12",
                "PILL.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_13", "PILL.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_14",
                "PILL.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_15", "PILL.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_16"],
                footer: "PILL.BENEFITS_RISKS.CONTRAINDICATIONS.FOOTER",
                type: 'list'
            },
            possibleSideEffects: {
                items: ["PILL.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_1", "PILL.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_2"],
                 footer: "PILL.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.FOOTER",
                 type: 'list'
            }
        }

        vm.mythsRealities = {
            items: [{
                text: 'PILL.MYTHS_REALITIES.LINE_1',
                clickText: 'PILL.MYTHS_REALITIES.LINE_CLICK_1'
            },{
                text: 'PILL.MYTHS_REALITIES.LINE_2',
                clickText: 'PILL.MYTHS_REALITIES.LINE_CLICK_2'
            },{
                text: 'PILL.MYTHS_REALITIES.LINE_3',
                clickText: 'PILL.MYTHS_REALITIES.LINE_CLICK_3'
            },{
                text: 'PILL.MYTHS_REALITIES.LINE_4',
                clickText: 'PILL.MYTHS_REALITIES.LINE_CLICK_4'
            },{
                text: 'PILL.MYTHS_REALITIES.LINE_5',
                clickText: 'PILL.MYTHS_REALITIES.LINE_CLICK_5'
            },{
                text: 'PILL.MYTHS_REALITIES.LINE_6',
                clickText: 'PILL.MYTHS_REALITIES.LINE_CLICK_6'
            }]
        }

        vm.typeOfPillsTabs = [{
              title: 'TABS.AMOUNT_OF_ESTROGEN',
              class: 'pills-ee'
              }, {
              title: 'TABS.TYPE_OF_PROGESTIN',
              class: 'pills-p4'
              }, {
              title: 'TABS.MONO_MULTI_PHASES',
              class: 'pills-mm'
              }];

        vm.changeTypeOfPillsTab = function(index) {
            vm.activePills = index;
        }

        vm.typeOfPillsMM = {
                header: "PILL.TYPE_OF_PILLS.MM.HEADER",
                items: ["PILL.TYPE_OF_PILLS.MM.LINE_1", "PILL.TYPE_OF_PILLS.MM.LINE_2"]
            }

    }

})();


(function () {
    'use strict';

    angular
      .module('app.controllers')
      .controller('ImplantCtrl', ImplantCtrl);

    ImplantCtrl.$inject = ['$scope', '$state'];

    /* @ngInject */
    function ImplantCtrl($scope, $state) {
        var vm = this;
        vm.title = 'ImplantCtrl';

        $scope.$emit('pageChange', {
            title: 'IMPLANT.PAGE_TITLE'
        })

        vm.activeTab = 0;
        vm.tabs = ['TABS.EFFECTIVENESS', 'TABS.BENEFITS_RISKS', 'TABS.MYTHS_REALITIES'];

        vm.changeTab = function(index) {
            vm.activeTab = index;
            vm.benefitsRisksActive = null;
            vm.mythsRealitiesActive = null;
        }

        vm.benefitsRisksActive = null;
        vm.mythsRealitiesActive = null;

        vm.effectiveness = {
            notes: {
                items: ["IMPLANT.EFFECTIVENESS.LINE_1", "IMPLANT.EFFECTIVENESS.LINE_2", "IMPLANT.EFFECTIVENESS.LINE_3", "IMPLANT.EFFECTIVENESS.LINE_4"],
                type: 'list'
            },
            estimates: {
                headers: ["IMPLANT.TITLE"],
                rows: [
                    [{
                        when: "IMPLANT.EFFECTIVENESS.PERFECT_TYPICAL_USE",
                        no: 0.05
                    }]
                ]
            },
            comment: "IMPLANT.EFFECTIVENESS.COMMENT"
        }

        vm.benefitsRisks = {
            potentialNoncBenefits: {
                items: ["IMPLANT.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_1", "IMPLANT.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_2",
                "IMPLANT.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_3", "IMPLANT.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_4"],
                type: 'list'
            },
            risks: {
                items: ["IMPLANT.BENEFITS_RISKS.RISKS.LINE_1", "IMPLANT.BENEFITS_RISKS.RISKS.LINE_2"],
                type: 'list'
            },
            contraindications: {
                items: ["IMPLANT.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_1", "IMPLANT.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_2"],
                type: 'list'
            },
            possibleSideEffects: {
                col1: {
                    items: ["IMPLANT.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_1", "IMPLANT.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_2",
                     "IMPLANT.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_3", "IMPLANT.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_4"],
                     type: 'list'
                },
                col2: {
                    items: ["IMPLANT.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_5", "IMPLANT.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_6",
                     "IMPLANT.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_7", "IMPLANT.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_8", "IMPLANT.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_9"],
                     type: 'list'  
                }
            }
        }

        vm.mythsRealities = {
            items: [{
                text: 'IMPLANT.MYTHS_REALITIES.LINE_1',
                clickText: 'IMPLANT.MYTHS_REALITIES.LINE_CLICK_1'
            },{
                text: 'IMPLANT.MYTHS_REALITIES.LINE_2',
                clickText: 'IMPLANT.MYTHS_REALITIES.LINE_CLICK_2'
            }]
        }

    }

})();


(function () {
    'use strict';

    angular
      .module('app.controllers')
      .controller('IUDCtrl', IUDCtrl);

    IUDCtrl.$inject = ['$scope', '$state'];

    /* @ngInject */
    function IUDCtrl($scope, $state) {
        var vm = this;
        vm.title = 'IUDCtrl';

        $scope.$emit('pageChange', {
            title: 'IUD.PAGE_TITLE'
        })

        vm.activeTab = 0;
        vm.tabs = ['TABS.EFFECTIVENESS', 'TABS.BENEFITS_RISKS', 'TABS.MYTHS_REALITIES'];

        vm.changeTab = function(index) {
            vm.activeTab = index;
            vm.benefitsRisksActive = null;
            vm.mythsRealitiesActive = null;
        }

        vm.benefitsRisksActive = null;
        vm.mythsRealitiesActive = null;

        vm.effectiveness = {
            notes: {
                subheader: "IUD.EFFECTIVENESS.SUBHEADER",
                items: ["IUD.EFFECTIVENESS.LINE_1", "IUD.EFFECTIVENESS.LINE_2", "IUD.EFFECTIVENESS.LINE_3", "IUD.EFFECTIVENESS.LINE_4",
                "IUD.EFFECTIVENESS.LINE_5"],
                type: 'list'
            },
            estimates: {
                headers: ["IUD.TITLE"],
                rows: [
                    [{
                        when: "IUD.EFFECTIVENESS.TYPICAL_HORMONAL",
                        no: 0.2
                    }],
                    [{
                        when: "IUD.EFFECTIVENESS.TYPICAL_COPPER",
                        no: 0.8
                    }]
                ]
            }
        }

        vm.benefitsRisks = {
            potentialNoncBenefits: {
                items: ["IUD.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_1", "IUD.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_2",
                "IUD.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_3", "IUD.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_4",
                "IUD.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_5"],
                type: 'list'
            },
            risks: {
                items: ["IUD.BENEFITS_RISKS.RISKS.LINE_1", "IUD.BENEFITS_RISKS.RISKS.LINE_2", "IUD.BENEFITS_RISKS.RISKS.LINE_3"],
                type: 'list'
            },
            contraindications: {
                header: "IUD.BENEFITS_RISKS.CONTRAINDICATIONS.HEADER",
                items: ["IUD.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_1", "IUD.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_2",
                "IUD.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_3", "IUD.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_4",
                "IUD.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_5", "IUD.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_6",
                "IUD.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_7", "IUD.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_8",
                "IUD.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_9", "IUD.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_10",
                "IUD.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_11"],
                type: 'list'
            },
            possibleSideEffects: {
                items: ["IUD.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_1", "IUD.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_2",
                 "IUD.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_3", "IUD.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_4"],
                 type: 'list'
            }
        }

        vm.mythsRealities = {
            items: [{
                text: 'IUD.MYTHS_REALITIES.LINE_1',
                clickText: 'IUD.MYTHS_REALITIES.LINE_CLICK_1'
            },{
                text: 'IUD.MYTHS_REALITIES.LINE_2',
                clickText: 'IUD.MYTHS_REALITIES.LINE_CLICK_2'
            },{
                text: 'IUD.MYTHS_REALITIES.LINE_3',
                clickText: 'IUD.MYTHS_REALITIES.LINE_CLICK_3'
            },{
                text: 'IUD.MYTHS_REALITIES.LINE_4',
                clickText: 'IUD.MYTHS_REALITIES.LINE_CLICK_4'
            },{
                text: 'IUD.MYTHS_REALITIES.LINE_5',
                clickText: 'IUD.MYTHS_REALITIES.LINE_CLICK_5'
            }]
        }

    }

})();


(function () {
    'use strict';

    angular
      .module('app.controllers')
      .controller('PatchCtrl', PatchCtrl);

    PatchCtrl.$inject = ['$scope', '$state'];

    /* @ngInject */
    function PatchCtrl($scope, $state) {
        var vm = this;
        vm.title = 'PatchCtrl';

        $scope.$emit('pageChange', {
            title: 'PATCH.PAGE_TITLE'
        })

        vm.activeTab = 0;
        vm.tabs = ['TABS.EFFECTIVENESS', 'TABS.BENEFITS_RISKS', 'TABS.MYTHS_REALITIES'];

        vm.changeTab = function(index) {
            vm.activeTab = index;
            vm.benefitsRisksActive = null;
            vm.mythsRealitiesActive = null;
        }

        vm.benefitsRisksActive = null;
        vm.mythsRealitiesActive = null;

        vm.effectiveness = {
            notes: {
                items: ["PATCH.EFFECTIVENESS.LINE_1", "PATCH.EFFECTIVENESS.LINE_2", "PATCH.EFFECTIVENESS.LINE_3", "PATCH.EFFECTIVENESS.LINE_4",
                "PATCH.EFFECTIVENESS.LINE_5"],
                type: 'list'
            },
            estimates: {
                headers: ["PATCH.TITLE"],
                rows: [
                    [{
                        when: "TABS.PERFECT_USE",
                        no: 0.3
                    }],
                    [{
                        when: "TABS.TYPICAL_USE",
                        no: 9
                    }]
                ]
            },
            comment: "PATCH.EFFECTIVENESS.COMMENT"
        }

        vm.benefitsRisks = {
            potentialNoncBenefits: {
                items: ["PATCH.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_1", "PATCH.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_2",
                "PATCH.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_3"],
                type: 'list'
            },
            risks: {
                items: [{ text: "PATCH.BENEFITS_RISKS.RISKS.LINE_1", sub: ["PATCH.BENEFITS_RISKS.RISKS.SUB_1", "PATCH.BENEFITS_RISKS.RISKS.SUB_2", "PATCH.BENEFITS_RISKS.RISKS.SUB_3"]}],
                type: 'list'
            },
            contraindications: {
                header: "PATCH.BENEFITS_RISKS.CONTRAINDICATIONS.HEADER",
                items: ["PATCH.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_1", "PATCH.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_2",
                "PATCH.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_3", "PATCH.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_4",
                "PATCH.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_5", "PATCH.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_6",
                "PATCH.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_7", "PATCH.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_8",
                "PATCH.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_9", "PATCH.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_10",
                "PATCH.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_11", "PATCH.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_12",
                "PATCH.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_13", "PATCH.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_14",
                "PATCH.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_15", "PATCH.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_16"],
                footer: "PATCH.BENEFITS_RISKS.CONTRAINDICATIONS.FOOTER",
                type: 'list'
            },
            possibleSideEffects: {
                items: ["PATCH.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_1", "PATCH.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_2",
                 "PATCH.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_3"],
                 footer: "PATCH.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.FOOTER",
                 type: 'list'
            }
        }

        vm.mythsRealities = {
            items: [{
                text: 'PATCH.MYTHS_REALITIES.LINE_1',
                clickText: 'PATCH.MYTHS_REALITIES.LINE_CLICK_1'
            },{
                text: 'PATCH.MYTHS_REALITIES.LINE_2',
                clickText: 'PATCH.MYTHS_REALITIES.LINE_CLICK_2'
            },{
                text: 'PATCH.MYTHS_REALITIES.LINE_3',
                clickText: 'PATCH.MYTHS_REALITIES.LINE_CLICK_3'
            }]
        }

    }

})();


(function () {
    'use strict';

    angular
      .module('app.controllers')
      .controller('VaginalRingCtrl', VaginalRingCtrl);

    VaginalRingCtrl.$inject = ['$scope', '$state'];

    /* @ngInject */
    function VaginalRingCtrl($scope, $state) {
        var vm = this;
        vm.title = 'VaginalRingCtrl';

        $scope.$emit('pageChange', {
            title: 'VAGINAL_RING.PAGE_TITLE'
        })

        vm.activeTab = 0;
        vm.tabs = ['TABS.EFFECTIVENESS', 'TABS.BENEFITS_RISKS', 'TABS.MYTHS_REALITIES'];

        vm.changeTab = function(index) {
            vm.activeTab = index;
            vm.benefitsRisksActive = null;
            vm.mythsRealitiesActive = null;
        }

        vm.benefitsRisksActive = null;
        vm.mythsRealitiesActive = null;

        vm.effectiveness = {
            notes: {
                subheader: "VAGINAL_RING.EFFECTIVENESS.SUBHEADER",
                items: ["VAGINAL_RING.EFFECTIVENESS.LINE_1", "VAGINAL_RING.EFFECTIVENESS.LINE_2", "VAGINAL_RING.EFFECTIVENESS.LINE_3", "VAGINAL_RING.EFFECTIVENESS.LINE_4",
                "VAGINAL_RING.EFFECTIVENESS.LINE_5"],
                type: 'list'
            },
            estimates: {
                headers: ["VAGINAL_RING.TITLE"],
                rows: [
                    [{
                        when: "TABS.PERFECT_USE",
                        no: 0.3
                    }],
                    [{
                        when: "TABS.TYPICAL_USE",
                        no: 9
                    }]
                ]
            },
            comment: "VAGINAL_RING.EFFECTIVENESS.COMMENT"
        }

        vm.benefitsRisks = {
            potentialNoncBenefits: {
                items: ["VAGINAL_RING.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_1"],
                type: 'para'
            },
            risks: {
                items: [{ text: "VAGINAL_RING.BENEFITS_RISKS.RISKS.LINE_1", sub: ["VAGINAL_RING.BENEFITS_RISKS.RISKS.SUB_1"]}],
                type: 'list'
            },
            contraindications: {
                header: "VAGINAL_RING.BENEFITS_RISKS.CONTRAINDICATIONS.HEADER",
                items: ["VAGINAL_RING.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_1", "VAGINAL_RING.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_2",
                "VAGINAL_RING.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_3", "VAGINAL_RING.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_4",
                "VAGINAL_RING.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_5", "VAGINAL_RING.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_6",
                "VAGINAL_RING.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_7", "VAGINAL_RING.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_8",
                "VAGINAL_RING.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_9", "VAGINAL_RING.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_10",
                "VAGINAL_RING.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_11", "VAGINAL_RING.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_12",
                "VAGINAL_RING.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_13", "VAGINAL_RING.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_14",
                "VAGINAL_RING.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_15", "VAGINAL_RING.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_16"],
                footer: "VAGINAL_RING.BENEFITS_RISKS.CONTRAINDICATIONS.FOOTER",
                type: 'list'
            },
            possibleSideEffects: {
                items: ["VAGINAL_RING.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_1", "VAGINAL_RING.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_2",
                 "VAGINAL_RING.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_3", "VAGINAL_RING.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_4",
                 "VAGINAL_RING.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_5"],
                 footer: "VAGINAL_RING.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.FOOTER",
                 type: 'list'
            }
        }

        vm.mythsRealities = {
            items: [{
                text: 'VAGINAL_RING.MYTHS_REALITIES.LINE_1',
                clickText: 'VAGINAL_RING.MYTHS_REALITIES.LINE_CLICK_1'
            },{
                text: 'VAGINAL_RING.MYTHS_REALITIES.LINE_2',
                clickText: 'VAGINAL_RING.MYTHS_REALITIES.LINE_CLICK_2'
            },{
                text: 'VAGINAL_RING.MYTHS_REALITIES.LINE_3',
                clickText: 'VAGINAL_RING.MYTHS_REALITIES.LINE_CLICK_3'
            },{
                text: 'VAGINAL_RING.MYTHS_REALITIES.LINE_4',
                clickText: 'VAGINAL_RING.MYTHS_REALITIES.LINE_CLICK_4'
            }]
        }

    }

})();


(function () {
    'use strict';

    angular
      .module('app.controllers')
      .controller('ECopperIUDCtrl', ECopperIUDCtrl);

    ECopperIUDCtrl.$inject = ['$scope', '$state'];

    /* @ngInject */
    function ECopperIUDCtrl($scope, $state) {
        var vm = this;
        vm.title = 'ECopperIUDCtrl';

        $scope.$emit('pageChange', {
            title: 'E_COPPER_IUD.PAGE_TITLE'
        })

        vm.activeTab = 0;
        vm.tabs = ['TABS.EFFECTIVENESS', 'TABS.BENEFITS_RISKS', 'TABS.MYTHS_REALITIES'];

        vm.changeTab = function(index) {
            vm.activeTab = index;
            vm.benefitsRisksActive = null;
            vm.mythsRealitiesActive = null;
        }

        vm.benefitsRisksActive = null;
        vm.mythsRealitiesActive = null;

        vm.effectiveness = {
            notes: {
                subheader: "E_COPPER_IUD.EFFECTIVENESS.SUBHEADER",
                items: ["E_COPPER_IUD.EFFECTIVENESS.LINE_1", "E_COPPER_IUD.EFFECTIVENESS.LINE_2"],
                type: 'list'
            },
            estimates: {
                headers: ["E_COPPER_IUD.TITLE"],
                rows: [
                    [{
                        when: "E_COPPER_IUD.EFFECTIVENESS.AFTER_IUD",
                        no: "<0.1"
                    }]
                ]
            }
        }

        vm.benefitsRisks = {
            potentialNoncBenefits: {
                items: ["E_COPPER_IUD.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_1", "E_COPPER_IUD.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_2"],
                type: 'list'
            },
            risks: {
                items: ["E_COPPER_IUD.BENEFITS_RISKS.RISKS.LINE_1"],
                type: 'para'
            },
            contraindications: {
                items: ["E_COPPER_IUD.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_1", "E_COPPER_IUD.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_2"],
                type: 'list'
            },
            possibleSideEffects: {
                items: ["E_COPPER_IUD.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_1", "E_COPPER_IUD.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_2",
                "E_COPPER_IUD.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_3"],
                type: 'list'
            }
        }

        vm.mythsRealities = {
            items: [{
                text: 'E_COPPER_IUD.MYTHS_REALITIES.LINE_1',
                clickText: 'E_COPPER_IUD.MYTHS_REALITIES.LINE_CLICK_1'
            },{
                text: 'E_COPPER_IUD.MYTHS_REALITIES.LINE_2',
                clickText: 'E_COPPER_IUD.MYTHS_REALITIES.LINE_CLICK_2'
            }]
        }

    }

})();


(function () {
    'use strict';

    angular
      .module('app.controllers')
      .controller('EPillsCtrl', EPillsCtrl);

    EPillsCtrl.$inject = ['$scope', '$state'];

    /* @ngInject */
    function EPillsCtrl($scope, $state) {
        var vm = this;
        vm.title = 'EPillsCtrl';

        $scope.$emit('pageChange', {
            title: 'EMERGENCY_PILLS.PAGE_TITLE'
        })

        vm.activeTab = 0;
        vm.tabs = ['TABS.EFFECTIVENESS', 'TABS.BENEFITS_RISKS', 'TABS.MYTHS_REALITIES'];

        vm.changeTab = function(index) {
            vm.activeTab = index;
            vm.benefitsRisksActive = null;
            vm.mythsRealitiesActive = null;
        }

        vm.benefitsRisksActive = null;
        vm.mythsRealitiesActive = null;

        vm.effectiveness = {
            notes: {
                subheader: "EMERGENCY_PILLS.EFFECTIVENESS.SUBHEADER",
                items: [{
                    text: "EMERGENCY_PILLS.EFFECTIVENESS.LINE_1", sub: ["EMERGENCY_PILLS.EFFECTIVENESS.SUB_1", "EMERGENCY_PILLS.EFFECTIVENESS.SUB_2",
                    "EMERGENCY_PILLS.EFFECTIVENESS.SUB_3"]
                }, "EMERGENCY_PILLS.EFFECTIVENESS.LINE_2", "EMERGENCY_PILLS.EFFECTIVENESS.LINE_3"],
                type: 'list'
            },
            estimates: {
                headers: ["EMERGENCY_PILLS.TITLE"],
                rows: [
                    [{
                        when: "EMERGENCY_PILLS.EFFECTIVENESS.AFTER_PILL_USE",
                        no: "0.6 - 3.5"
                    }]
                ]
            },
            comment: "EMERGENCY_PILLS.EFFECTIVENESS.COMMENT"
        }

        vm.benefitsRisks = {
            potentialNoncBenefits: {
                items: ["EMERGENCY_PILLS.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_1"],
                type: 'list'
            },
            risks: {
                items: ["EMERGENCY_PILLS.BENEFITS_RISKS.RISKS.LINE_1"],
                type: 'para'
            },
            contraindications: {
                header: "EMERGENCY_PILLS.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_1",
				items: ["EMERGENCY_PILLS.BENEFITS_RISKS.CONTRAINDICATIONS.SUB_1"],
                type: 'list'
            },
            possibleSideEffects: {
                items: ["EMERGENCY_PILLS.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_1", "EMERGENCY_PILLS.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_2",
                 "EMERGENCY_PILLS.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_3"],
                 type: 'list'
            }
        }

        vm.mythsRealities = {
            items: [{
                text: 'EMERGENCY_PILLS.MYTHS_REALITIES.LINE_1',
                clickText: 'EMERGENCY_PILLS.MYTHS_REALITIES.LINE_CLICK_1'
            },{
                text: 'EMERGENCY_PILLS.MYTHS_REALITIES.LINE_2',
                clickText: 'EMERGENCY_PILLS.MYTHS_REALITIES.LINE_CLICK_2'
            },{
                text: 'EMERGENCY_PILLS.MYTHS_REALITIES.LINE_3',
                clickText: 'EMERGENCY_PILLS.MYTHS_REALITIES.LINE_CLICK_3'
            },{
                text: 'EMERGENCY_PILLS.MYTHS_REALITIES.LINE_4',
                clickText: 'EMERGENCY_PILLS.MYTHS_REALITIES.LINE_CLICK_4'
            }]
        }

    }

})();


(function () {
    'use strict';

    angular
      .module('app.controllers')
      .controller('CondomsCtrl', CondomsCtrl);

    CondomsCtrl.$inject = ['$scope', '$state'];

    /* @ngInject */
    function CondomsCtrl($scope, $state) {
        var vm = this;
        vm.title = 'CondomsCtrl';

        $scope.$emit('pageChange', {
            title: 'CONDOMS.PAGE_TITLE'
        })

        vm.activeTab = 0;
        vm.tabs = ['TABS.EFFECTIVENESS', 'TABS.BENEFITS_RISKS', 'TABS.MYTHS_REALITIES'];

        vm.changeTab = function(index) {
            vm.activeTab = index;
            vm.benefitsRisksActive = null;
            vm.mythsRealitiesActive = null;
        }

        vm.benefitsRisksActive = null;
        vm.mythsRealitiesActive = null;

        vm.effectiveness = {
            notes: {
                items: ["CONDOMS.EFFECTIVENESS.LINE_1", "CONDOMS.EFFECTIVENESS.LINE_2"],
                type: 'para'
            },
            estimates: {
                headers: ["CONDOMS.EFFECTIVENESS.FEMALE_CONDOM", "CONDOMS.EFFECTIVENESS.MALE_CONDOM"],
                rows: [
                    [{
                        when: "TABS.PERFECT_USE",
                        no: 5
                    }, {
                        when: "TABS.PERFECT_USE",
                        no: 2
                    }],
                    [{
                        when: "TABS.TYPICAL_USE",
                        no: 20
                    }, {
                        when: "TABS.TYPICAL_USE",
                        no: 18
                    }]
                ]
            },
            comment: "CONDOMS.EFFECTIVENESS.COMMENT"
        }

        vm.benefitsRisks = {
            potentialNoncBenefits: {
                items: ["CONDOMS.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_1", "CONDOMS.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_2",
                "CONDOMS.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_3"],
                type: 'list'
            },
            risks: {
                _header: "CONDOMS.BENEFITS_RISKS.RISKS.HEADER",
                items: ["CONDOMS.BENEFITS_RISKS.RISKS.LINE_1", "CONDOMS.BENEFITS_RISKS.RISKS.LINE_2", "CONDOMS.BENEFITS_RISKS.RISKS.LINE_3","CONDOMS.BENEFITS_RISKS.RISKS.LINE_4","CONDOMS.BENEFITS_RISKS.RISKS.LINE_5"],
                type: 'list'
            },
            contraindications: {
                items: ["CONDOMS.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_1"],
                type: 'list'
            },
            possibleSideEffects: {
                items: []
            }
        }

        vm.mythsRealities = {
            items: [{
                text: 'CONDOMS.MYTHS_REALITIES.LINE_1',
                clickText: 'CONDOMS.MYTHS_REALITIES.LINE_CLICK_1'
            },{
                text: 'CONDOMS.MYTHS_REALITIES.LINE_2',
                clickText: 'CONDOMS.MYTHS_REALITIES.LINE_CLICK_2'
            },{
                text: 'CONDOMS.MYTHS_REALITIES.LINE_3',
                clickText: 'CONDOMS.MYTHS_REALITIES.LINE_CLICK_3'
            },{
                text: 'CONDOMS.MYTHS_REALITIES.LINE_4',
                clickText: 'CONDOMS.MYTHS_REALITIES.LINE_CLICK_4'
            },{
                text: 'CONDOMS.MYTHS_REALITIES.LINE_5',
                clickText: 'CONDOMS.MYTHS_REALITIES.LINE_CLICK_5'
            }]
        }

    }

})();


(function () {
    'use strict';

    angular
      .module('app.controllers')
      .controller('DiaphragmCtrl', DiaphragmCtrl);

    DiaphragmCtrl.$inject = ['$scope', '$state'];

    /* @ngInject */
    function DiaphragmCtrl($scope, $state) {
        var vm = this;
        vm.title = 'DiaphragmCtrl';

        $scope.$emit('pageChange', {
            title: 'DIAPHRAGM.PAGE_TITLE'
        })


        vm.activeTab = 0;
        vm.tabs = ['TABS.EFFECTIVENESS', 'TABS.BENEFITS_RISKS', 'TABS.MYTHS_REALITIES'];

        vm.changeTab = function(index) {
            vm.activeTab = index;
            vm.benefitsRisksActive = null;
            vm.mythsRealitiesActive = null;
        }

        vm.benefitsRisksActive = null;
        vm.mythsRealitiesActive = null;

        vm.effectiveness = {
            notes: {
                items: ["DIAPHRAGM.EFFECTIVENESS.LINE_1", "DIAPHRAGM.EFFECTIVENESS.LINE_2"],
                type: 'para'
            },
            estimates: {
                headers: ["DIAPHRAGM.TITLE"],
                rows: [
                    [{
                        when: "TABS.PERFECT_USE",
                        no: 6
                    }],
                    [{
                        when: "TABS.TYPICAL_USE",
                        no: 12
                    }]
                ]
            },
            comment: "DIAPHRAGM.EFFECTIVENESS.COMMENT"
        }

        vm.benefitsRisks = {
            potentialNoncBenefits: {
                items: ["DIAPHRAGM.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_1", "DIAPHRAGM.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_2",
                "DIAPHRAGM.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_3", "DIAPHRAGM.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_4"],
                type: 'list'
            },
            risks: {
                items: ["DIAPHRAGM.BENEFITS_RISKS.RISKS.LINE_1", "DIAPHRAGM.BENEFITS_RISKS.RISKS.LINE_2"],
                type: 'list'
            },
            contraindications: {
                header: "DIAPHRAGM.BENEFITS_RISKS.CONTRAINDICATIONS.HEADER",
                items: ["DIAPHRAGM.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_1", "DIAPHRAGM.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_2",
                    "DIAPHRAGM.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_3", { 
                        text: "DIAPHRAGM.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_4", sub: ["DIAPHRAGM.BENEFITS_RISKS.CONTRAINDICATIONS.SUB_1"]
                    }],
                type: 'list'
            },
            possibleSideEffects: {
                items: ["DIAPHRAGM.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_1"],
                type: 'para'
            } 
        }

        vm.mythsRealities = {
            items: [{
                text: 'DIAPHRAGM.MYTHS_REALITIES.LINE_1',
                clickText: 'DIAPHRAGM.MYTHS_REALITIES.LINE_CLICK_1'
            },{
                text: 'DIAPHRAGM.MYTHS_REALITIES.LINE_2',
                clickText: 'DIAPHRAGM.MYTHS_REALITIES.LINE_CLICK_2'
            },{
                text: 'DIAPHRAGM.MYTHS_REALITIES.LINE_3',
                clickText: 'DIAPHRAGM.MYTHS_REALITIES.LINE_CLICK_3'
            },{
                text: 'DIAPHRAGM.MYTHS_REALITIES.LINE_4',
                clickText: 'DIAPHRAGM.MYTHS_REALITIES.LINE_CLICK_4'
            }]
        }
    }

})();


(function () {
    'use strict';

    angular
      .module('app.controllers')
      .controller('SpongeCtrl', SpongeCtrl);

    SpongeCtrl.$inject = ['$scope', '$state'];

    /* @ngInject */
    function SpongeCtrl($scope, $state) {
        var vm = this;
        vm.title = 'SpongeCtrl';

        $scope.$emit('pageChange', {
            title: 'SPONGE.PAGE_TITLE'
        })

        vm.activeTab = 0;
        vm.tabs = ['TABS.EFFECTIVENESS', 'TABS.BENEFITS_RISKS'];

        vm.changeTab = function(index) {
            vm.activeTab = index;
            vm.benefitsRisksActive = null;
            vm.mythsRealitiesActive = null;
        }

        vm.benefitsRisksActive = null;
        vm.mythsRealitiesActive = null;

        vm.effectiveness = {
            notes: {
                items: ["SPONGE.EFFECTIVENESS.LINE_1", "SPONGE.EFFECTIVENESS.LINE_2", "SPONGE.EFFECTIVENESS.LINE_3", "SPONGE.EFFECTIVENESS.LINE_4"],
                type: 'list'
            },
            estimates: {
                headers: ["SPONGE.EFFECTIVENESS.HAVE", "SPONGE.EFFECTIVENESS.NEVER_HAVE"],
                rows: [
                    [{
                        when: "TABS.PERFECT_USE",
                        no: 20
                    }, {
                        when: "TABS.PERFECT_USE",
                        no: 9
                    }],
                    [{
                        when: "TABS.TYPICAL_USE",
                        no: 24
                    }, {
                        when: "TABS.TYPICAL_USE",
                        no: 12
                    }]
                ]
            },
            comment: "SPONGE.EFFECTIVENESS.COMMENT"
        }

        vm.benefitsRisks = {
            potentialNoncBenefits: {
                items: ["SPONGE.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_1", "SPONGE.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_2",
                "SPONGE.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_3", "SPONGE.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_4"],
                type: 'list'
            },
            risks: {
                items: ["SPONGE.BENEFITS_RISKS.RISKS.LINE_1", "SPONGE.BENEFITS_RISKS.RISKS.LINE_2", "SPONGE.BENEFITS_RISKS.RISKS.LINE_3"],
                type: 'list'
            },
            contraindications: {
                items: ["SPONGE.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_1"],
                type: 'para'
            },
            possibleSideEffects: {
                items: ["SPONGE.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_1"],
                type: 'para'
            } 
        }

    }

})();


(function () {
    'use strict';

    angular
      .module('app.controllers')
      .controller('FemaleSterilizationTubalLigationCtrl', FemaleSterilizationTubalLigationCtrl);

    FemaleSterilizationTubalLigationCtrl.$inject = ['$scope', '$state'];

    /* @ngInject */
    function FemaleSterilizationTubalLigationCtrl($scope, $state) {
        var vm = this;
        vm.title = 'FemaleSterilizationTubalLigationCtrl';

        $scope.$emit('pageChange', {
            title: 'TUBAL_LIGATION.PAGE_TITLE'
        })

        vm.activeTab = 0;
        vm.tabs = ['TABS.EFFECTIVENESS', 'TABS.BENEFITS_RISKS', 'TABS.MYTHS_REALITIES'];

        vm.changeTab = function(index) {
            vm.activeTab = index;
            vm.benefitsRisksActive = null;
            vm.mythsRealitiesActive = null;
        }

        vm.benefitsRisksActive = null;
        vm.mythsRealitiesActive = null;

        vm.effectiveness = {
            notes: {
                items: ["TUBAL_LIGATION.EFFECTIVENESS.LINE_1", "TUBAL_LIGATION.EFFECTIVENESS.LINE_2", "TUBAL_LIGATION.EFFECTIVENESS.LINE_3"],
                type: 'list'
            },
            estimates: {
                headers: ["TUBAL_LIGATION.TITLE"],
                rows: [
                    [{
                        when: "TUBAL_LIGATION.EFFECTIVENESS.AFTER_TUBAL_LIGATION",
                        no: 0.5
                    }]
                ]
            },
			is_permanent: true
        }

        vm.benefitsRisks = {
            potentialNoncBenefits: {
                items: ["TUBAL_LIGATION.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_1", "TUBAL_LIGATION.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_2",
                "TUBAL_LIGATION.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_3", "TUBAL_LIGATION.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_4"],
                type: 'list'
            },
            risks: {
                items: ["TUBAL_LIGATION.BENEFITS_RISKS.RISKS.LINE_1", "TUBAL_LIGATION.BENEFITS_RISKS.RISKS.LINE_2"],
                type: 'list'
            },
            contraindications: {
                header: "TUBAL_LIGATION.BENEFITS_RISKS.CONTRAINDICATIONS.HEADER",
                items: ["TUBAL_LIGATION.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_1", "TUBAL_LIGATION.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_2",
                "TUBAL_LIGATION.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_3", "TUBAL_LIGATION.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_4",
                "TUBAL_LIGATION.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_5", "TUBAL_LIGATION.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_6",
                "TUBAL_LIGATION.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_7", "TUBAL_LIGATION.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_8",
                "TUBAL_LIGATION.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_9"],
                footer: "TUBAL_LIGATION.BENEFITS_RISKS.CONTRAINDICATIONS.FOOTER",
                type: 'list'
            },
            possibleSideEffects: {
                items: ["TUBAL_LIGATION.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_1"],
                type: 'para'
            }
        }

        vm.mythsRealities = {
            items: [{
                text: 'TUBAL_LIGATION.MYTHS_REALITIES.LINE_1',
                clickText: 'TUBAL_LIGATION.MYTHS_REALITIES.LINE_CLICK_1'
            },{
                text: 'TUBAL_LIGATION.MYTHS_REALITIES.LINE_2',
                clickText: 'TUBAL_LIGATION.MYTHS_REALITIES.LINE_CLICK_2'
            },{
                text: 'TUBAL_LIGATION.MYTHS_REALITIES.LINE_3',
                clickText: 'TUBAL_LIGATION.MYTHS_REALITIES.LINE_CLICK_3'
            },{
                text: 'TUBAL_LIGATION.MYTHS_REALITIES.LINE_4',
                clickText: 'TUBAL_LIGATION.MYTHS_REALITIES.LINE_CLICK_4'
            }]
        }

    }

})();


(function () {
    'use strict';

    angular
      .module('app.controllers')
      .controller('FemaleSterilizationTubalOcculusionCtrl', FemaleSterilizationTubalOcculusionCtrl);

    FemaleSterilizationTubalOcculusionCtrl.$inject = ['$scope', '$state'];

    /* @ngInject */
    function FemaleSterilizationTubalOcculusionCtrl($scope, $state) {
        var vm = this;
        vm.title = 'FemaleSterilizationTubalOcculusionCtrl';

        $scope.$emit('pageChange', {
            title: 'TUBAL_OCCLUSION.PAGE_TITLE'
        })

        vm.activeTab = 0;
        vm.tabs = ['TABS.EFFECTIVENESS', 'TABS.BENEFITS_RISKS', 'TABS.MYTHS_REALITIES'];

        vm.changeTab = function(index) {
            vm.activeTab = index;
            vm.benefitsRisksActive = null;
            vm.mythsRealitiesActive = null;
        }

        vm.benefitsRisksActive = null;
        vm.mythsRealitiesActive = null;

        vm.effectiveness = {
            notes: {
                items: ["TUBAL_OCCLUSION.EFFECTIVENESS.LINE_1", "TUBAL_OCCLUSION.EFFECTIVENESS.LINE_2"],
                type: 'list'
            },
            estimates: {
                headers: ["TUBAL_OCCLUSION.EFFECTIVENESS.TABLE_HEADER"],
                rows: [
                    [{
                        when: "TUBAL_OCCLUSION.EFFECTIVENESS.AFTER_TUBAL_OCCLUSION",
                        no: 0.5
                    }]
                ]
            },
			is_permanent: true
        }

        vm.benefitsRisks = {
            potentialNoncBenefits: {
                items: ["TUBAL_OCCLUSION.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_1", "TUBAL_OCCLUSION.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_2",
                "TUBAL_OCCLUSION.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_3"],
                type: 'list'
            },
            risks: {
                items: ["TUBAL_OCCLUSION.BENEFITS_RISKS.RISKS.LINE_1", "TUBAL_OCCLUSION.BENEFITS_RISKS.RISKS.LINE_2"],
                type: 'list'
            },
            contraindications: {
                items: ["TUBAL_OCCLUSION.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_1", "TUBAL_OCCLUSION.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_2",
                "TUBAL_OCCLUSION.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_3", "TUBAL_OCCLUSION.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_4",
                "TUBAL_OCCLUSION.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_5", "TUBAL_OCCLUSION.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_6",
                "TUBAL_OCCLUSION.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_7", "TUBAL_OCCLUSION.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_8",
                "TUBAL_OCCLUSION.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_9", "TUBAL_OCCLUSION.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_10"],
                type: 'list'
            },
            possibleSideEffects: {
                items: ["TUBAL_OCCLUSION.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_1"],
                type: 'para'
            }
        }

        vm.mythsRealities = {
            items: [{
                text: 'TUBAL_OCCLUSION.MYTHS_REALITIES.LINE_1',
                clickText: 'TUBAL_OCCLUSION.MYTHS_REALITIES.LINE_CLICK_1'
            },{
                text: 'TUBAL_OCCLUSION.MYTHS_REALITIES.LINE_2',
                clickText: 'TUBAL_OCCLUSION.MYTHS_REALITIES.LINE_CLICK_2'
            },{
                text: 'TUBAL_OCCLUSION.MYTHS_REALITIES.LINE_3',
                clickText: 'TUBAL_OCCLUSION.MYTHS_REALITIES.LINE_CLICK_3'
            },{
                text: 'TUBAL_OCCLUSION.MYTHS_REALITIES.LINE_4',
                clickText: 'TUBAL_OCCLUSION.MYTHS_REALITIES.LINE_CLICK_4'
            }]
        }

    }

})();


(function () {
    'use strict';

    angular
      .module('app.controllers')
      .controller('VasectomyCtrl', VasectomyCtrl);

    VasectomyCtrl.$inject = ['$scope', '$state'];

    /* @ngInject */
    function VasectomyCtrl($scope, $state) {
        var vm = this;
        vm.title = 'VasectomyCtrl';

        $scope.$emit('pageChange', {
            title: 'VASECTOMY.PAGE_TITLE'
        })

        vm.activeTab = 0;
        vm.tabs = ['TABS.EFFECTIVENESS', 'TABS.BENEFITS_RISKS', 'TABS.MYTHS_REALITIES'];

        vm.changeTab = function(index) {
            vm.activeTab = index;
            vm.benefitsRisksActive = null;
            vm.mythsRealitiesActive = null;
        }

        vm.benefitsRisksActive = null;
        vm.mythsRealitiesActive = null;

        vm.effectiveness = {
            notes: {
                items: ["VASECTOMY.EFFECTIVENESS.LINE_1", "VASECTOMY.EFFECTIVENESS.LINE_2"],
                type: 'para'
            },
            estimates: {
                headers: ["VASECTOMY.TITLE"],
                rows: [
                    [{
                        when: "VASECTOMY.EFFECTIVENESS.AFTER_VASECTOMY",
                        no: "0.10 - 0.15"
                    }]
                ]
            },
            is_permanent: true
        }

        vm.benefitsRisks = {
            potentialNoncBenefits: {
                items: ["VASECTOMY.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_1", "VASECTOMY.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_2",
                "VASECTOMY.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_3", "VASECTOMY.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_4",
                "VASECTOMY.BENEFITS_RISKS.POTENTIAL_NONC_BENEFITS.LINE_5"],
                type: 'list'
            },
            risks: {
                items: ["VASECTOMY.BENEFITS_RISKS.RISKS.LINE_1", "VASECTOMY.BENEFITS_RISKS.RISKS.LINE_2"],
                type: 'list'
            },
            contraindications: {
                header: "VASECTOMY.BENEFITS_RISKS.CONTRAINDICATIONS.HEADER",
                items: ["VASECTOMY.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_1", "VASECTOMY.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_2",
                "VASECTOMY.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_3", "VASECTOMY.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_4",
                "VASECTOMY.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_5", "VASECTOMY.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_6",
                "VASECTOMY.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_7", "VASECTOMY.BENEFITS_RISKS.CONTRAINDICATIONS.LINE_8"],
                type: 'list'
            },
            possibleSideEffects: {
                items: ["VASECTOMY.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_1", "VASECTOMY.BENEFITS_RISKS.POSSIBLE_SIDE_EFFECTS.LINE_2"],
                type: 'list'
            }
        }

        vm.mythsRealities = {
            items: [{
                text: 'VASECTOMY.MYTHS_REALITIES.LINE_1',
                clickText: 'VASECTOMY.MYTHS_REALITIES.LINE_CLICK_1'
            },{
                text: 'VASECTOMY.MYTHS_REALITIES.LINE_2',
                clickText: 'VASECTOMY.MYTHS_REALITIES.LINE_CLICK_2'
            },{
                text: 'VASECTOMY.MYTHS_REALITIES.LINE_3',
                clickText: 'VASECTOMY.MYTHS_REALITIES.LINE_CLICK_3'
            }]
        }

    }

})();

