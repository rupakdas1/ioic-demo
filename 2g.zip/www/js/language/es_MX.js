var lang = {
	HELLO: "Hola",
	WELCOME: "Bienvenida"
};
