var lang = {
    ACCESS: {
        VALIDATION_MESSAGE: 'Please enter valid access code.',
        CODE: '$2a$06$h4GDKlHtH4/yE4vMW4JsnuERDc2dmASRgwksD0g5WzK7lVAI8j1Ei',     
        WELCOME: 'Welcome to the ', 
        PARA0: "Let's Talk About Contraception App",
        PARA1: 'The content contained in this app is intended for healthcare practioners. You need to access code to be able to access the content of this app.',
        PARA2: 'If you are a healthcare practioner and do not have a access code, contact',
        PARA2_1: '{local market instructions}.',
        ENTER_ACCESS_CODE: 'Please enter your Access Code',
        INVALID_PASSCODE_MSG: 'Please enter valid access code.'
    },
    ANALYTICS: 'UA-84592740-1', //-1 is dev // 2 for prod
    CORE_BTN_TXT: 'References',
    SETTINGS: {
        TITLE: "Settings and Terms of Use",
        TAB1: "Analytics",
        TAB2: "Terms of Use",
        TAB3: "Privacy",
        ANALYTICS: {
            PARA1: "This application captures anonymous usage statistics, including aggregate location information. This data will be used to make the application better for you in the future.",
            PARA2: "If you do not wish to share this data you can select Off below.",
            OFF: "Off",
            ON: "On"
        }
    },
    HOME: {
    	TITLE: "Let's Talk About",
        TITLE_1: "Contraception",
    	SUB_TITLE: "What kind best suits you?",
    	HOME: "Home",
    	COMPARISION: "Comparison",
    	CONVERSATION: "Conversation",
    	WITH_EVERY_INTERCOURSE_ACT: "With Every Intercourse Act",
    	WITH_EVERY_INTERCOURSE_ACT_SUB: "Do you prefer to use contraception only at the time of intercourse?",
    	EMERGENCY: "Emergency",
    	EMERGENCY_SUB: "Are you worried because you had sex without using contraception or your birth control failed?",
    	DAILY: "Daily",
    	DAILY_SUB: "Can you remember to take medication every day?",
    	WEEKLY_MONTHLY: "Weekly/Monthly",
    	WEEKLY_MONTHLY_SUB: "Can you remember to change a patch every week or a ring every month?",
    	TWO_THREE_MONTHS: "2 or 3 Months",
    	TWO_THREE_MONTHS_SUB: "Are you okay remembering an injection every few months?",
    	LONGER_REVERSIBLE: "Longer-Acting Reversible",
    	LONGER_REVERSIBLE_SUB: "Do you prefer a more “forgettable” method of contraception?",
    	PERMANENT: "Permanent",
    	PERMANENT_SUB: "Are you finished having children?"
    },
    COMPARISION: {
    	MOST_EFFECTIVE: "MOST EFFECTIVE",
    	LEAST_EFFECTIVE: "LEAST EFFECTIVE",
    	LINE_1: "Less than 1 pregnancy<br>per 100 women in one year",
    	LINE_2: "6-12 pregnancy per<br>100 women in a year",
    	LINE_3: "18 or more pregnancies per<br>100 women in a year",
    	NOTE: "*The percentages indicate the number out of every hundred women who experienced an unintended pregnancy within the first year of typical use of each contraceptive method."
    },
    CONVERSATION: {
        QUESTION: "Have you and your partner discussed contraception?",
        YES: "YES",
        NO: "NO",
        NO_PARTNER: "NO PARTNER",
        TIPS: "TIPS",
        YES_OPTION: "What options did you discuss <br/> and which do you prefer?",
        NO_OPTION: "What is preventing the discussion?",
        NO_PARTNER_OPTION: "This might be a good time to <br/>consider options that might <br/> work well for you in the future.",
        TIPS_OPTION_LINE_1: "Have the discussion before you have sex.",
        TIPS_OPTION_LINE_2: "Talk about what's important to you when considering birth control.",
        TIPS_OPTION_LINE_3: "Remind him that most birth control does not protect against sexually transmitted infections (STIs). Only latex condoms help protect against STIs, including HIV.",
        TIPS_OPTION_LINE_4: "Tell him what birth control you're using or are considering using.",
        TIPS_OPTION_LINE_5: "Still uncomfortable opening the discussion? Consider writing a letter or sending an email."
    },
    TABS: {
    	EFFECTIVENESS: "Effectiveness",
    	BENEFITS_RISKS: "Benefits & Risks",
    	MYTHS_REALITIES: "Myths & Realities",
        REGIMENS: "Regimens",
        NO_OF_PILLS: "Number of Pills",
        TYPE_OF_PILLS: "Type of Pills",
    	POTENTIAL_NONC_BENEFITS: 'Potential Noncontraceptive Benefits',
    	RISKS: "Risks",
    	CONTRAINDICATIONS: "Contraindications",
    	POSSIBLE_SIDE_EFFECTS: "Possible side effects",
    	ESTIMATES_OVER_USE_OF_YEAR: "Estimates for use over one year",
        ESTIMATES_OVER_USE_OF_YEAR_PERMANENT: "Estimated pregnancies over one year",
    	PERFECT_USE: "Perfect use",
    	TYPICAL_USE: "Typical use",
    	WILL_GET_PREGNANT: "Will get pregnant",
    	NONE: "None",
        AMOUNT_OF_ESTROGEN: "Amount of Estrogen",
        TYPE_OF_PROGESTIN: "Type of Progestin",
        MONO_MULTI_PHASES: "Mono or Multi-phases"
    },
    CONDOMS: {
    	PAGE_TITLE: "With Every Intercourse Act - Condoms",
    	TITLE: "Condoms",
    	EFFECTIVENESS: {
    		LINE_1: "Male and female condoms are available, which are barrier methods of contraception.",
    		LINE_2: "No evidence that condoms lubricated with nonoxynol-9 (N-9) are more effective in preventing pregnancy or sexually transmitted infections than lubricated condoms that do not contain N-9.",
    		COMMENT: "Condoms can be effective if used consistently (every time intercourse occurs) and correctly.",
    		MALE_CONDOM: "Male condom",
    		FEMALE_CONDOM: "Female Condom"
    	},
    	BENEFITS_RISKS: {
    		POTENTIAL_NONC_BENEFITS: {
    			LINE_1: "Available over the counter (no prescription required)",
    			LINE_2: "Easily reversible",
    			LINE_3: "Reduces the risk of sexually transmitted infections, including HIV (male and female condom)"
    		},
    		RISKS: {
    			HEADER: "Practices that increse the risk that the condom will break and not provide a full barrier include:",
    			LINE_1: "Unrolling the condom first before putting it on",
    			LINE_2: "Using lubricants with an oil base",
    			LINE_3: "Using a condom that feels dried out or very sticky",
                LINE_4: "Reusing condoms",
                LINE_5: "Dry Sex"
    		},
    		CONTRAINDICATIONS: {
    			LINE_1: "Do not use latex male condom if either partner is allergic to latex"
    		}
    	},
    	MYTHS_REALITIES: {
    		LINE_1: "Condoms are full of holes.",
    		LINE_CLICK_1: "Manufacturers are required to carefully test each batch of condoms for leaks.",
    		LINE_2: "Condoms can get \"lost\" in vagina.",
    		LINE_CLICK_2: "Condoms rarely slip off during intercourse.<br>If it does, you or your partner can remove it from the vagina with relative ease.",
    		LINE_3: "Condoms can cause long-term health risks, like cancer.",
    		LINE_CLICK_3: "There are no short-or long-term risks with condoms.",
    		LINE_4: "Condoms can lead to premature ejaculation.",
    		LINE_CLICK_4: "Actually, condoms can help a man mantain an erection longer and prevent premature ejaculation.",
    		LINE_5: "I can't get a sexually transmitted infection (STI) if I use a condom.",
    		LINE_CLICK_5: "Consistent and correct use of condoms reduces the risks of transmission of many STIs and HIV, but it does not provide absolute protection."
    	}
    },
    DIAPHRAGM: {
    	PAGE_TITLE: "With Every Intercourse Act - Diaphragm",
    	TITLE: "Diaphragm",
    	EFFECTIVENESS: {
    		LINE_1: "Flexible latex or silicone dome-shaped device that is filled with spermicide and inserted high up into the vagina to cover the cervix.",
    		LINE_2: "Inserted up to 6 hours before sex and left for at least 6 hours after intercourse has occurred; it should not be left in for more than 24 hours.",
    		COMMENT: "How the diaphragm is used affects your risk of pregnancy."
    	},
    	BENEFITS_RISKS: {
    		POTENTIAL_NONC_BENEFITS: {
    			LINE_1: "Relatively discreet since it can be inserted ahead of time",
    			LINE_2: "Easily reversible",
    			LINE_3: "Relatively low ongoing cost for spermicide",
    			LINE_4: "Only needs to be replaced about every 2 years"
    		},
    		RISKS: {
    			LINE_1: "Urinary tract infections (UTIs), vaginal infections",
    			LINE_2: "Toxic shock syndrome has been reported (extremely rare)"
    		},
    		CONTRAINDICATIONS: {
    			HEADER: "Diaphragm should not be used in women who:",
    			LINE_1: "Have a high risk for HIV infection (due to the diaphragm’s use with nonoxynol-9 spermicidal gel)",
    			LINE_2: "Have severe or advanced HIV/AIDS",
    			LINE_3: "Have a history of toxic shock syndrome",
    			LINE_4: "Are allergic to latex (does not apply to silicone diaphragm) or spermicide",
    			SUB_1: "Diaphragm use may be discouraged for those allergic to silicone "
    		},
            POSSIBLE_SIDE_EFFECTS: {
                LINE_1: "Users may report irritation in or around vagina or penis"
            }
    	},
    	MYTHS_REALITIES: {
    		LINE_1: "The diaphragm is uncomfortable.",
    		LINE_CLICK_1: "The diaphragm is not uncomfortable if it is fitted properly.",
    		LINE_2: "My partner and I will feel it during sex.",
    		LINE_CLICK_2: "Generally, neither you nor your partner should be able to feel it during sex. ",
    		LINE_3: "I don’t need a spermicide with a diaphragm.",
    		LINE_CLICK_3: "While there is not enough evidence to know for sure, using a diaphragm without spermicide is NOT recommended.",
    		LINE_4: "The diaphragm protects against sexually transmitted infections (STIs) like HIV.",
    		LINE_CLICK_4: "Diaphragms do not offer any protection against STIs. The only contraceptive that protects against STIs is a condom (male or female)."
    	}
    },
    SPONGE: {
    	PAGE_TITLE: "With Every Intercourse Act - Sponge",
    	TITLE: "Sponge",
    	EFFECTIVENESS: {
    		LINE_1: "A barrier method used at the time of intercourse that is a small, circular, pillow-shaped, polyurethane sponge that contains spermicide",
    		LINE_2: "One-time use only",
    		LINE_3: "Effective up to 24 hours after insertion",
    		LINE_4: "Must remain in place for 6 hours after last intercourse has occurred",
    		COMMENT: "Pregnancy rates with the sponge are higher than with hormonal contraception.",
    		HAVE: "Women who HAVE had<br> a previous pregnancy",
    		NEVER_HAVE: "Women who HAVE NEVER<br> had a previous pregnancy"
    	},
        BENEFITS_RISKS: {
            POTENTIAL_NONC_BENEFITS: {
                LINE_1: "Can be inserted ahead of time",
                LINE_2: "Available over the counter (no prescription required)",
                LINE_3: "Easily reversible",
                LINE_4: "Does not contain hormones"
            },
            RISKS: {
                LINE_1: "Less effective in women who have been pregnant before",
                LINE_2: "Increased risk of toxic shock syndrome if left inserted more than 24-30 hours",
                LINE_3: "Although it is a barrier method, unlike condoms, it does not protect against sexually transmitted infections on its own"
            },
            CONTRAINDICATIONS: {
                LINE_1: "Should not use if allergic to spermicides"
            },
            POSSIBLE_SIDE_EFFECTS: {
                LINE_1: "Vaginal dryness in some women."             
            }
        }
    },
    E_COPPER_IUD: {
    	PAGE_TITLE: "Emergency Contraception - Copper IUD",
        HEADER_BUTTON_TXT: "Emergency Contraceptive Pills",
    	TITLE: "Emergency Copper IUD",
    	EFFECTIVENESS: {
            SUBHEADER: "Used to prevent pregnancy after unprotected or inadequately protected intercourse (eg, condom breakage or missed doses of oral contraceptives)",
    		LINE_1: "Works primarily by damaging sperm and egg before they can meet",
    		LINE_2: "Should be inserted as soon as possible up to 5 days after unprotected or inadequately protected intercourse to maximize effectiveness.",
            AFTER_IUD: "After Copper IUD insertion"
    	},
    	BENEFITS_RISKS: {
    		POTENTIAL_NONC_BENEFITS: {
    			LINE_1: "Hormone free",
    			LINE_2: "Lack of estrogen makes it an option for women who cannot or do not want to take estrogen, such as smokers over age 35 or nursing mothers "
    		
    		},
    		RISKS: {    			
    			LINE_1: "Uterine perforation is a rare but potentially serious complication of IUD insertion, which usually heals on its own. This risk is not specifically related to IUD insertion as emergency contraception"
    		},
    		CONTRAINDICATIONS: {
    			LINE_1: "Pregnancy ",
                LINE_2: "Evidence of current chlamydial infection or gonorrhea"
    		},
            POSSIBLE_SIDE_EFFECTS: {
                LINE_1: "Prolonged, heavy monthly bleeding",
                LINE_2: "Irregular bleeding",
                LINE_3: "More pain, cramping during monthly bleeding"
            }
    	},
    	MYTHS_REALITIES: {
    		LINE_1: "Use of a copper IUD for emergency contraception is abortion.",
    		LINE_CLICK_1: "Abortion is used to terminate an existing pregnancy, whereas emergency contraception is used only before a pregnancy is established.",
    		LINE_2: "Use of emergency contraception will harm the fetus if pregnancy occurs following insertion.",
    		LINE_CLICK_2: "The copper IUD does not cause birth defects. However, in the rare instance of pregnancy that occurs after copper IUD insertion, a woman should discuss having the device removed to help avoid miscarriage, preterm birth, or infection."
    	}
    },
    EMERGENCY_PILLS: {
    	PAGE_TITLE: "Emergency Contraception - Pills",
        HEADER_BUTTON_TXT: "Emergency Copper IUD",
    	TITLE: "Emergency Contraceptive Pills",
    	EFFECTIVENESS: {
            SUBHEADER: "Used to prevent pregnancy after unprotected or inadequately protected intercourse (eg, condom breakage or missed doses of oral contraceptives)",
    		LINE_1: "There are a number of pill options for emergency contraception, including:",
            SUB_1: "(1) special emergency contraceptive products (pills containing levonorgestrel only, estrogen and levonorgestrel combined, or ulipristal acetate)",
            SUB_2: "(2) contraceptive pills containing only progestin",
            SUB_3: "(3) combined contraceptive pills containing both progestin and estrogen",
    		LINE_2: "All work by preventing or delaying ovulation to decrease the chance of egg fertilization by sperm",
            LINE_3: "Should be taken as soon as possible up to 3 to 5 days after unprotected or inadequately protected intercourse to maximize effectiveness",
    		COMMENT: "Pregnancy rates vary depending on the type and timing of pill use. Pills containing ulipristal acetate are most effective, and combined oral contraceptive pills are least effective.",
            AFTER_PILL_USE: "After Pill Use"
    	},
    	BENEFITS_RISKS: {
    		POTENTIAL_NONC_BENEFITS: {
    			LINE_1: "Some types of pills may be available over the counter (no prescription required) depending on your location"    			
    		},
    		RISKS: {    			
    			LINE_1: "Women who use emergency contraceptive pills are at risk of becoming pregnant later in the same menstrual cycle from subsequent episodes of sexual intercourse, since the therapy delays ovulation. Women should use barrier contraceptives to prevent pregnancy (eg, condoms, diaphragms, and spermicides) immediately after using emergency contraceptive pills and should continue these barrier methods for at least 7 days until other regular methods of contraception such as pills, a vaginal ring, or injectables (if started) take effect."
    		},
    		CONTRAINDICATIONS: {
    			LINE_1: "None. All women can use emergency contraceptive pills, including breastfeeding women and women with previous ectopic pregnancy, cardiovascular disease, migraines, liver disease, or other conditions that prevent use of conventional oral contraceptives. Because of the short-term nature of their use, there are no medical conditions that make emergency contraceptive pills unsafe for any woman",
                SUB_1: "However, breastfeeding is not recommended for 1 week after taking ulipristal acetate since it is excreted in breast milk"
    		},
            POSSIBLE_SIDE_EFFECTS: {
                 LINE_1: "Nausea and headache (most common)",
                 LINE_2: "Irregular bleeding or spotting",
                 LINE_3: "Vomiting, breast tenderness, abdominal pain, dizziness, fatigue"   
            }
    	},
    	MYTHS_REALITIES: {
    		LINE_1: "Emergency contraception is only available through a doctor.",
    		LINE_CLICK_1: "Depending on where you live, some types of emergency contraceptive pills (eg, progestin-only pills) may be available over the counter and do not require a doctor’s prescription.",
    		LINE_2: "Emergency contraceptive pills cannot be used repeatedly.",
    		LINE_CLICK_2: "Emergency contraceptive pills may be used more than once, even within the same menstrual cycle. However, a woman who uses emergency contraceptive pills regularly for pregnancy prevention is more likely to have an unintended pregnancy than a woman who uses another contraceptive regularly.",
    		LINE_3: "Use of emergency contraception is abortion.",
    		LINE_CLICK_3: "Abortion is used to terminate an existing pregnancy, whereas emergency contraception is used only before a pregnancy is established. Emergency contraceptive pills do not work if a woman is already pregnant.",
    		LINE_4: "Use of emergency contraceptive pills will harm the fetus if pregnancy occurs.",
    		LINE_CLICK_4: "If you do get pregnant after using emergency contraceptive pills, there is no evidence that it causes any harm to the fetus."    		
    	}
    },
    PILL: {
    	PAGE_TITLE: "Daily - Pills",
    	TITLE: "Daily Pills",
    	SUB_TITLE: "(Estrogen/Progestin <br/>and Progestin-Only)",
    	EFFECTIVENESS: {
            SUBHEADER: "There are 2 types of oral contraceptives: pills with estrogen and progestin, called combination pills; and progestin-only pills:",
    		LINE_1: "Combination pills include an estrogen (often ethinyl estradiol) paired with one of several different types of progestins",
    		LINE_2: "Progestin-only pills do not contain any estrogen and can be used by women who have reasons not to use estrogen",
    		COMMENT: "The pill can be very effective. Actual effectiveness depends on whether it is used consistently and correctly.",
            THE_PILL: "The pill"
    	},
    	BENEFITS_RISKS: {
    		POTENTIAL_NONC_BENEFITS: {
                HEADER: "Combined oral contraceptives may:",
    			LINE_1: "Regulate and reduce bleeding, and reduce painful menstrual periods",
    			LINE_2: "Decrease acne",
    			LINE_3: "Help protect against ovarian cysts",
                LINE_4: "Help protect against iron-deficiency anemia",
                LINE_5: "Decrease hair on face or body",
                LINE_6: "Decrease risk of endometrial and ovarian cancer",
                HEADER_1: "Progestin-only oral contraceptives:",
                LINE_7: "Can be used by women of all ages, including those who are breastfeeding (starting 6 weeks after childbirth) and smokers",
                LINE_8: "May reduce length of menstruation and may lead to amenorrhea"
    		},
    		RISKS: {    			
    			LINE_1: "Increased risk of blood clots (also called venous thromboembolism, or VTE)",
    			SUB_1: "Overall risk of venous blood clots is small",
    			LINE_2: "Increased risk of stroke or heart attack (extremely rare)"
    		},
    		CONTRAINDICATIONS: {                
    			HEADER : "<p>Contraindications for specific products should be reviewed in the product labels.</p><br><br><p>According to the World Health Organization, combined hormonal contraceptives may NOT be used in the following circumstances:</p>",
                LINE_1: "Breastfeeding <6 weeks post-partum. Risks may also outweigh advantages if breastfeeding and <6 months postpartum",
                LINE_2: "<3 weeks postpartum and other known risk factors for VTE",
                LINE_3: "Smoker aged ≥35 years, particularly if she smokes 15 or more cigarettes a day",
                LINE_4: "Presence of multiple risk factors for cardiovascular disease (eg, older age, smoking, diabetes, hypertension, and known dyslipidemia)",
                LINE_5: "Hypertension with elevated blood pressure levels of SBP ≥160 or DBP ≥100 mmHg",
                LINE_6: "Elevated blood pressure levels and history of vascular disease [WHO 2015/pg116]",
                LINE_7: "History of blood clots, past or current",
                LINE_8: "Major surgery with prolonged immobilization",
                LINE_9: "Known thrombogenic mutations",
                LINE_10: "History of stroke, coronary artery disease, or complicated valvular heart disease",
                LINE_11: "Lupus with positive antiphospholipid antibodies",
                LINE_12: "Migraine with aura at any age",
                LINE_13: "Migraine without aura and age ≥35 years",
                LINE_14: "Current breast cancer; risk may also outweigh advantages if history of breast cancer in the past",
                LINE_15: "Diabetes with nephropathy/retinopathy/neuropathy, or diabetes of more than 20 years’ duration",
                LINE_16: "Liver problems: severe cirrhosis, acute or flare of viral hepatitis, hepatocellular adenoma, malignant hepatoma",
                FOOTER: "For those taking medications for seizures, or taking rifampicin or rifabutin for tuberculosis or other illnesses, the risks of using combined oral contraceptives may outweigh the benefits."
    		},
            POSSIBLE_SIDE_EFFECTS: {
                LINE_1: "Unscheduled bleeding or spotting",
                LINE_2: "Breast tenderness, nausea, or bloating",
                FOOTER: "NOTE: Side effects may disappear after the first few cycles of use."
            }
    	},
    	MYTHS_REALITIES: {
    		LINE_1: "The pill increases the risk of heart disease.",
    		LINE_CLICK_1: "Combined oral contraceptives do not increase the risk of heart disease for healthy non-smokers under the age of 35 with no other risk factors.",
    		LINE_2: "The pill increases the risk of breast cancer.",
    		LINE_CLICK_2: "Combined oral contraceptives do not increase the risk of breast cancer.",
    		LINE_3: "The pill causes weight gain.",
    		LINE_CLICK_3: "Most women do not gain or lose weight due to oral contraceptives.",
    		LINE_4: "The pill causes birth defects or abortion.",
    		LINE_CLICK_4: "If you do get pregnant while taking the pill, there is no evidence that it causes any harm to the fetus. Similarly, oral contraceptives do not cause abortion.",
    		LINE_5: "It takes a long time to get pregnant after stopping the pill.",
    		LINE_CLICK_5: "Evidence shows that 72% to 94% of women become pregnant within 12 months of stopping the pill. This is similar to other methods of birth control.",
            LINE_6: "Periodic breaks from the pill are needed.",
            LINE_CLICK_6: "Periodic breaks are not necessary and put you at risk for an unintended pregnancy. The pill can be continued until you wish to become pregnant."
    	},
        REGIMENS: {
            HEADER: "There are different regimens for combined oral contraceptives:"
        },
        NO_OF_PILLS: {
            LINE_1: "Most packs contain 28 pills (either 21 or 24 active-hormone pills with the remainder placebo or inactive pills). One pill is taken every day for 4 weeks straight and then a new pack is started.",
            LINE_2: "Some packs contain only 21 pills. With these packs, a woman generally takes 1 pill daily for 3 weeks, and then takes no pill for 7 days.",
            LINE_3: "Some pills are used for an extended period of time with less frequent hormone-free intervals or no hormone-free days at all.",
            SUB_1: "For example, a woman takes 84 days of active pills and 7 days of inactive pills, or takes a full year of active pills with no inactive pills."
        },
        TYPE_OF_PILLS: {
            EE: {
                LINE_1: "The dose of ethinyl estradiol (EE) in combination oral contraceptive pills ranges:<br/> 10 mcg, 20 mcg, 25 mcg, 30 mcg, 35 mcg, 50 mcg.",
                LINE_2: "Most of the currently available combination pills contain between 20 and 35 mcg of EE.",
                LINE_3: "Lower EE doses have been found to be equally effective in preventing pregnancy; may potentially cause fewer side effects, such as headache, breast tenderness, or nausea; and may potentially pose a lower risk of venous thrombosis.",
                LINE_4: "On the other hand, lower-dose pills may result in more breakthrough bleeding (bleeding or spotting between periods) than higher-dose pills.",
                SIDE_EFFECTS: "Side effects",
                HEADACHE: "Headache",
                NAUSEA: "Nausea",
                VENOUS: "Venous Thrombosis",
                BREAST: "Breast Tenderness",
                HYPERTENSION: "Hypertension"
            },
            P4: {
                LINE_1: "Most of the currently available COCs contain one of eight progestins. Examples of progestins include levonorgestrel, norethindrone, and drospirenone."
            },
            MM: {
                HEADER: "Combination oral pills can be categorized according to whether the dose of hormones stays the same or varies:",
                LINE_1: "Monophasic: each active pill contains the same amount of estrogen and progestin",
                LINE_2: "Multiphasic: the amounts of estrogen and progestin in active pills vary"
            }
        }
    },
    VAGINAL_RING: {
        TITLE: "Vaginal Ring",
        PAGE_TITLE: "Monthly - Vaginal Ring",
        EFFECTIVENESS: {
            SUBHEADER: "Provides effective contraception without having to take a pill every day",
            LINE_1: "A flexible, soft, transparent ring made of ethylene vinyl acetate copolymers and magnesium stearate",
            LINE_2: "Can be self-inserted into the vagina",
            LINE_3: "Continuously releases an estrogen and a progestin for 3 weeks",
            LINE_4: "Used continuously for 3 weeks followed by a 1-week, ring-free interval",
            LINE_5: "Can be stopped at any time; there is no delay in the return to fertility",
            COMMENT: "The effectiveness of the ring depends on whether it is used consistently and correctly."
        },
        BENEFITS_RISKS: {
            POTENTIAL_NONC_BENEFITS: {
                LINE_1: "Studies are limited, but researchers expect that health benefits will be similar to those of combined oral contraceptive pills."
            },
            RISKS: {
                LINE_1: "Increased risk of blood clots (also called venous thromboembolism, or VTE)",
                SUB_1 : "Overall risk of venous blood clots is small"
            },
            CONTRAINDICATIONS: {
                HEADER: "<p>Contraindications for specific products should be reviewed in the product labels.</p><br><p>According to the World Health Organization, the ring may NOT be used in the following circumstances:</p>",
                LINE_1: "Breastfeeding <6 weeks post-partum; risks may also outweigh advantages if breastfeeding and <6 months postpartum",
                LINE_2: "<3 weeks postpartum and known other risk factors for VTE",
                LINE_3: "By a smoker aged ≥35 years, particularly if she smokes 15 or more cigarettes a day",
                LINE_4: "Presence of multiple risk factors for cardiovascular disease (e.g. older age, smoking, diabetes, hypertension, and known dyslipidemia)",
                LINE_5: "Hypertension with blood pressure levels of SBP ≥160 or DBP ≥100 mmHg",
                LINE_6: "Elevated blood pressure levels and history of vascular disease",
                LINE_7: "History of blood clots",
                LINE_8: "Major surgery with prolonged immobilization",
                LINE_9: "Known thrombogenic mutations",
                LINE_10: "History of stroke, coronary artery disease, or complicated valvular heart disease",
                LINE_11: "Lupus with positive antiphospholipid antibodies",
                LINE_12: "Migraine with aura at any age",
                LINE_13: "Migraine without aura and age ≥35 years",
                LINE_14: "Current breast 	; risk may also outweigh advantages if 	 a history of breast cancer",
                LINE_15: "Diabetes with nephropathy/retinopathy/neuropathy, or diabetes of more than 20 years duration",
                LINE_16: "Liver problems: severe cirrhosis, acute or flare of viral hepatitis, hepatocellular adenoma, or malignant hepatoma",
                FOOTER: "For those taking medications for seizures, or taking rifampicin or rifabutin for tuberculosis or other illnesses, the risks of using the ring may outweigh the benefits."
            },
            POSSIBLE_SIDE_EFFECTS: {
                LINE_1: "Unscheduled bleeding or spotting ",
                LINE_2: "Breast tenderness, nausea, or bloating",
                LINE_3: "Headaches ",
                LINE_4: "Irritation, redness, or inflammation of the vagina (vaginitis)",
                LINE_5: "White vaginal discharge",
                FOOTER: "NOTE: Side effects may disappear after the first few cycles of use."
            }
        },
        MYTHS_REALITIES: {
            LINE_1: "The ring is not as effective as oral contraceptives.",
            LINE_CLICK_1: "Research on effectiveness is limited, but effectiveness rates in clinical trials of the vaginal ring suggest that it may be more effective than combined oral contraceptives, both as commonly used and with consistent and correct use.",
            LINE_2: "It will get \"lost\" in vagina.",
            LINE_CLICK_2: "There is no danger of the ring being pushed too far up in the vagina or getting lost.<br>It is normal for the ring to move around slightly within the vagina. Most women do not feel it when it is in place.",
            LINE_3: "My partner will feel it.",
            LINE_CLICK_3: "Two studies have reported that ~70%-90% of women and their partners never feel the ring during sexual intercourse. If you prefer, it can be removed during intercourse (for up to 3 hours) and reinserted afterward.",
            LINE_4: "I will not be able to use a tampon.",
            LINE_CLICK_4: "A tampon can be used as you would normally use it."
        }
    },
    PATCH: {
        TITLE: "Patch",
        PAGE_TITLE: "Weekly - Patch",
        EFFECTIVENESS: {
                LINE_1: "Provides effective contraception without having to take a pill every day",
                LINE_2: "A 2 x 2 cm adhesive transdermal patch that releases a continuous dose of estrogen and progesterone",
                LINE_3: "One new patch is applied every week for 3 weeks, followed by 1 week with no patch ",
                LINE_4: "The patch can be applied on the upper outer arm, back, stomach, abdomen, or buttocks, but not on the breasts ",
                LINE_5: "Can be stopped at any time; there is no delay in the return to fertility",
                COMMENT: "<p>The effectiveness of the patch depends on whether it is used consistently and correctly.</p><p>Pregnancy rates may be slightly higher among women weighing ≥90 kg (approximately 198 lbs) who use the patch compared to those who weigh less.</p>"
        },
        BENEFITS_RISKS: {
            POTENTIAL_NONC_BENEFITS: {
                LINE_1: "Regulates, and reduces bleeding, and reduces painful menstrual periods",
                LINE_2: "Decreases acne",
                LINE_3: "Studies are limited, but researchers expect that other health benefits will be similar to those of combined oral contraceptive pills"
            },
            RISKS: {
                LINE_1: "Increased risk of blood clots (also called venous thromboembolism, or VTE)",
                SUB_1: "Current evidence suggests that incidence is similar to that with pills, especially in women ≤39 years",
                SUB_2: "Overall risk of venous blood clots is small",
                SUB_3: "Risk of venous blood clot with patch is less than in pregnancy"
            },
            CONTRAINDICATIONS: {
                HEADER : "<p>Contraindications for specific products should be reviewed in the product labels.</p> <p>According to the World Health Organization, the patch may NOT be used in the following circumstances:</p>",
                LINE_1: "Breastfeeding <6 weeks post-partum; risks may also outweigh advantages if breastfeeding and <6 months postpartum",
                LINE_2: "<3 weeks postpartum and known other risk factors for VTE",
                LINE_3: "By a smoker aged ≥35 years, particularly if she smokes 15 or more cigarettes a day",
                LINE_4: "Presence of multiple risk factors for cardiovascular disease (e.g. older age, smoking, diabetes, hypertension, and known dyslipidemia)",
                LINE_5: "Hypertension with blood pressure levels of SBP ≥160 or DBP ≥100 mmHg",
                LINE_6: "Elevated blood pressure levels and history of vascular disease",
                LINE_7: "History of blood clots",
                LINE_8: "Major surgery with prolonged immobilization",
                LINE_9: "Known thrombogenic mutations",
                LINE_10: "History of stroke, coronary artery disease, or complicated valvular heart disease",
                LINE_11: "Lupus with positive antiphospholipid antibodies",
                LINE_12: "Migraine with aura at any age",
                LINE_13: "Migraine without aura and age ≥35 years",
                LINE_14: "Current breast cancer; risk may also outweigh advantages if history of breast cancer in the past",
                LINE_15: "Diabetes with nephropathy/retinopathy/neuropathy, or diabetes of more than 20 years’ duration",
                LINE_16: "Liver problems: severe cirrhosis, acute or flare of viral hepatitis, hepatocellular adenoma, malignant hepatoma",
                FOOTER: "For those taking medications for seizures, or taking rifampicin or rifabutin for tuberculosis or other illnesses, the risks of using the patch may outweigh the benefits."

            },
            POSSIBLE_SIDE_EFFECTS: {
                 LINE_1: "Unscheduled bleeding or spotting",                 
                 LINE_2: "Breast tenderness, nausea, or bloating",                 
                 LINE_3: "Local skin irritation",
                 FOOTER: "NOTE: Side effects may disappear after the first few cycles of use"                 
            }
        },
        MYTHS_REALITIES: {
            LINE_1: "The patch will make me gain weight.",
            LINE_CLICK_1: "A Cochran Collaboration® review of studies of pills and patches found no major effect on weight.",
            LINE_2: "I won’t be able to go swimming or take a bath.",
            LINE_CLICK_2: "The patch can be worn while swimming, bathing, and doing other activities.",
            LINE_3: "It doesn’t work as well as the pill.",
            LINE_CLICK_3: "The patch has comparable efficacy to pills."
        }
    },
    INJECTION: {
        TITLE: "Injectable Contraception",
        PAGE_TITLE: "Every 2 or 3 Months - Injection",
        EFFECTIVENESS: {
                LINE_1: "Provides effective, injectable, progestin-based contraception without having to take a pill every day",
                LINE_2: "Injection once every 2 or 3 months, depending on type of progestin",
                LINE_3: "Reversible",
                LINE_4: "Can be used by women of all ages and women who cannot use estrogen",
                WHEN: "Injection",
                WHEN_SUB: "(i.e. return every 3 months for the next injection)"
        },
        BENEFITS_RISKS: {
            POTENTIAL_NONC_BENEFITS: {
                LINE_1: "Convenient",
                LINE_2: "High rates of amenorrhea with resulting reduction in dysmenorrhea and anemia",
                LINE_3: "No estrogen; can be used by smokers older than 35, women who are breastfeeding, and other women who cannot use estrogen",
                LINE_4: "Reduces the risk of endometrial cancer, pelvic inflammatory disease, and fibroids",
                LINE_5: "May reduce symptoms associated with premenstrual syndrome and chronic pelvic pain",
                LINE_6: "May reduce sickle cell crises in women with the disease",
                LINE_7: "Reduces symptoms of endometriosis",
                LINE_8: "May reduce the frequency of seizures in people with the disorder"
            },
            RISKS: {
                LINE_1: "Decrease in bone mineral density; the effect seems to be reversible when DMPA is discontinued",
                LINE_2: "Delayed return to fertility; median time to conception is 10 months after last injection"
            },
            CONTRAINDICATIONS: {
                HEADER_1: "Do not use if you have:",
                LINE_1: "Current breast cancer",
                LINE_2: "Pregnancy (effects of DMPA on a fetus are unclear)",
                HEADER_2 : "Risk may outweigh benefit if:",
                LINE_3: "<6 weeks postpartum and breastfeeding"
            },
            POSSIBLE_SIDE_EFFECTS: {
                LINE_1: "Changes in menstrual cycle, including irregular bleeding, spotting, abnormally heavy or prolonged bleeding (particularly in the first few months), and amenorrhea as time goes on",
                LINE_2: "Weight gain may occur in some ",
                LINE_3: "Headache, decreased libido, dizziness, abdominal bloating and discomfort, mood changes, and breast tenderness"
            }
        },
        MYTHS_REALITIES: {
            LINE_1: "It’s not safe to skip periods.",
            LINE_CLICK_1: "Not having a monthly period is safe. There is no build-up of blood in the body.",
            LINE_2: "Injectable progestin is experimental.",
            LINE_CLICK_2: "All injectable contraception options have been approved by a government agency.",
            LINE_3: "It can’t be used if breastfeeding.",
            LINE_CLICK_3: "An injectable contraceptive can be used beginning 6 weeks postpartum.",
            LINE_4: "It will cause weight gain.",
            LINE_CLICK_4: "Some women who use injections may gain weight, and some women using injections may lose weight or experience no change. Some weight increase may be due to the natural weight gain that comes with aging."
        }
    },
    IUD: {
        TITLE: "IUD",
        PAGE_TITLE: "Long-Acting Reversible - IUD",
        EFFECTIVENESS: {
            TYPICAL_HORMONAL: "Typical use hormonal IUD",
            TYPICAL_COPPER: "Typical use copper IUD",
            SUBHEADER: "IUDs are one of the most effective and long-lasting methods of contraception.",
            LINE_1: "Long-acting, reversible contraception (LARC)",
            LINE_2: "Inserted in a physician’s office",
            LINE_3: "Small, T-shaped device placed inside your uterus",
            LINE_4: "Hormonal IUDs should generally be replaced after 5 years",
            LINE_5: "Copper IUDs don’t contain any hormones; a copper IUD may be effective for 10 years or more"
        },
        BENEFITS_RISKS: {
            POTENTIAL_NONC_BENEFITS: {
                LINE_1: "Hormone free option available ",
                LINE_2: "Lack of estrogen in hormonal and copper IUDs make them an option for women who cannot or do not want to take estrogen, such as smokers over age 35 or nursing mothers",
                LINE_3: "May help protect against endometrial cancer ",
                LINE_4: "Hormonal IUD may decrease menstrual bleeding",
                LINE_5: "Hormonal IUD may decrease symptoms of endometriosis and adenomyosis"
            },
                RISKS: {
                LINE_1: "Uterine perforations are rare but potentially serious complications of IUD insertion; a recent study demonstrated a similar rate between hormonal (1.4/1000 insertions) and copper (1.1/1000 insertions) IUDs",
                LINE_2: "Expulsion may occur in 2%-10% of users within the first year and may be more common in women who have not given birth",
                LINE_3: "Slight risk of infection during the first month due to insertion; no increased risk beyond"            
            },
            CONTRAINDICATIONS: {
                HEADER: "Contraindications to using copper or hormonal IUDs:",
                LINE_1: "Pregnancy",
                LINE_2: "Serious infection (sepsis) arising from the genital tract following childbirth or miscarriage",
                LINE_3: "Very recent post-septic abortion",
                LINE_4: "Unexplained vaginal bleeding",
                LINE_5: "Gestational C trophoblastic disease (a group of rare tumors developing from cells that normally develop into a placenta), either malignant or with persistently elevated β-hCG levels",
                LINE_6: "Cervical or endometrial cancer awaiting treatment ",
                LINE_7: "Current breast cancer (for hormonal IUD)",
                LINE_8: "Known distorted uterine cavity from fibroids or other causes",
                LINE_9: "Current pelvic inflammatory disease",
                LINE_10: "Current inflammation of the cervix with an unusual discharge, chlamydia, or gonorrhea infection",
                LINE_11: "Pelvic tuberculosis"
            },
            POSSIBLE_SIDE_EFFECTS: {
                LINE_1: "Irregular bleeding or changes in menstrual bleeding are common; the copper IUD may increase the amount of bleeding during periods, whereas the progestin-only IUD reduces the amount of bleeding",
                LINE_2: "Cramping at the time of insertion and in the first few months after insertion",
                LINE_3: "Hormonal IUD associated with a low incidence of hormonal side effects, such as depression, headache, acne, and breast tenderness",
                LINE_4: "Copper IUD may contribute to anemia in women with low iron"
            }
        },
        MYTHS_REALITIES: {
            LINE_1: "You can’t use an IUD if you’ve never had a baby.",
            LINE_CLICK_1: "The IUD can be used by women whether or not they have previously given birth.",
            LINE_2: "The IUD needs to be removed to treat a sexually transmitted infection.",
            LINE_CLICK_2: "The IUD can remain in place while you are treated.",
            LINE_3: "IUDs increase the risk of sexually transmitted infections and pelvic inflammatory disease (PID).",
            LINE_CLICK_3: "Although the IUD does not protect against sexually transmitted infections or PID, neither does it increase the risk after the first month.",
            LINE_4: "IUDs increase the risk of ectopic pregnancy.",
            LINE_CLICK_4: "Actually, an IUD greatly reduces the risk of ectopic pregnancy compared to the rate in women not using contraception. Ectopic pregnancy is rare in women who use IUDs.",
            LINE_5: "IUD increases the risk of infertility.",
            LINE_CLICK_5: "After an IUD is removed, IUD users can become pregnant just as quickly as women who have not been using an IUD."
        }
    },
    IMPLANT: {
        TITLE: "Implants",
        PAGE_TITLE: "Long-Acting Reversible - Implants",
        EFFECTIVENESS: {
            PERFECT_TYPICAL_USE: "Perfect and Typical use etonogestrel implant",
             LINE_1: "Long-acting, reversible, progestin-only contraceptive",
             LINE_2: "Small, flexible rod or capsule placed just under the skin of the upper arm",
             LINE_3: "Requires a trained provider to insert and remove",
             LINE_4: "Effective for 3-7 years, depending on type of implant",
             COMMENT: "Implants are very effective in reducing the risk of pregnancy."
        },
        BENEFITS_RISKS: {
            POTENTIAL_NONC_BENEFITS: {
             LINE_1: "May improve painful menstrual periods",
             LINE_2: "Can be used by women who cannot or do not want to use estrogen",
             LINE_3: "May help protect against iron-deficiency anemia",
             LINE_4: "Can be inserted anytime during the menstrual cycle if pregnancy has been excluded"
            },
            RISKS: {
             LINE_1: "Uncommon: Infection at insertion site, difficult removal (rare if properly inserted and a skilled provider removes it)",
             LINE_2: "Rare: Implant comes out"         
            },
            CONTRAINDICATIONS: {
             LINE_1: "Do not use if you have breast cancer",
             LINE_2: "Refer to product-specific labeling for other potential contraindications" 
            },
            POSSIBLE_SIDE_EFFECTS: {

             LINE_1: "Changes in bleeding patterns (no monthly bleeding, infrequent/frequent bleeding, or prolonged bleeding)",
             LINE_2: "Headaches",
             LINE_3: "Abdominal pain",
             LINE_4: "Acne (can improve or worsen)",
			 LINE_5: "Weight change",
             LINE_6: "Breast tenderness",
             LINE_7: "Dizziness",
             LINE_8: "Mood changes",
             LINE_9: "Nausea"
            }
        },
        MYTHS_REALITIES: {
            LINE_1: "It causes infertility.",
            LINE_CLICK_1: "The implant is completely reversible; once it is removed, fertility returns rapidly.",
            LINE_2: "It can’t be used while breastfeeding.",
            LINE_CLICK_2: "Breastfeeding women can start using implants as soon as 6 weeks after childbirth."
        }
    },
    VASECTOMY: {
        TITLE: "Vasectomy",
        PAGE_TITLE: "Permanent Contraception - Vasectomy",
        EFFECTIVENESS: {
            AFTER_VASECTOMY: "After vasectomy procedure",
            LINE_1: "Permanent option for men who do not want to father more children",
            LINE_2: "Vas deferens (tubes that carry sperm to the penis) are cut or blocked to prevent sperm from being released with semen"
        },
        BENEFITS_RISKS: {
            POTENTIAL_NONC_BENEFITS: {
             LINE_1: "Permanent",
             LINE_2: "Discreet",
             LINE_3: "Low risk of side effects",
             LINE_4: "No ongoing cost",
             LINE_5: "Quick recovery"
            },
            RISKS: {
             LINE_1: "Surgical complications include infection and hematoma (1%-2%)",
             LINE_2: "Rare feelings of regret"
            },
            CONTRAINDICATIONS: {
            HEADER: "Although there are no definite contraindications to male sterilization, some conditions require caution, delay of the procedure, or special arrangements, including:",
            LINE_1: "Severe or advanced HIV",
            LINE_2: "Local infection",
            LINE_3: "Coagulation disorders",
            LINE_4: "Systemic infection or gastroenteritis",
            LINE_5: "Filariasis, elephantiasis",
            LINE_6: "Intrascrotal mass",
            LINE_7: "Cryptorchidism",
            LINE_8: "Inguinal hernia"

            },
            POSSIBLE_SIDE_EFFECTS: {
            LINE_1: "Some short-term tenderness and bruising may occur",
            LINE_2: "The risk of chronic severe postoperative scrotal or testicular pain that interferes with quality of life is 1%-2%"
            }
        },
        MYTHS_REALITIES: {
            LINE_1: "A vasectomy affects sexual function.",
            LINE_CLICK_1: "Vasectomy has no impact on sex drive, the ability to get an erection, ejaculatory functioning, or masculinity.",
            LINE_2: "Vasectomies never fail.",
            LINE_CLICK_2: "Rarely, a vasectomy can fail. Additionally, it’s important to use another form of birth control for 3 months after the procedure; after 3 months, a man’s semen can be tested for sperm to see if the vasectomy has been successful.",
            LINE_3: "Vasectomy increases the risk of cancer or heart disease.",
            LINE_CLICK_3: "There is no evidence that vasectomy increases a man’s risk of cancer (including prostate cancer and testicular cancer) or heart disease."
        }
    },
    TUBAL_LIGATION: {
        TITLE: "Female Sterilization - Tubal Ligation",
        PAGE_TITLE: "Permanent Contraception - Female Sterilization - Tubal Ligation",
        HEADER_BUTTON_TXT: "Hysterioscopic Tubal Occlusion",
        EFFECTIVENESS: {
            AFTER_TUBAL_LIGATION: "After tubal ligation procedure",
            LINE_1: "Highly effective method for women who are certain they don’t want future pregnancy",
            LINE_2: "Surgical procedure in which a woman’s fallopian tubes are tied, blocked with clips or rings, or fused with an electrical current",
            LINE_3: "Often performed as an outpatient procedure"
        },
        BENEFITS_RISKS: {
            POTENTIAL_NONC_BENEFITS: {
            LINE_1: "Helps protect from pelvic inflammatory disease",
            LINE_2: "May decrease risk of ovarian cancer",
            LINE_3: "No ongoing cost",
            LINE_4: "No change to hormonal \“milieu\”"
            },
            RISKS: {
            LINE_1: "Procedure-related risks, but major complications are extremely rare",
            LINE_2: "Regret"
            },
            CONTRAINDICATIONS: {
                HEADER: "Although there are no absolute contraindications for tubal ligation, some conditions require caution, delay of the procedure, or special arrangements, including:",
                LINE_1: "Pregnancy",
                LINE_2: "Young age (up to 20% of women sterilized at a young age may regret the decision)",
                LINE_3: "Within 6 weeks of certain pregnancy-related complications, including infection, severe hemorrhage, or severe pre-eclampsia",
                LINE_4: "Complications related to an abortion",
                LINE_5: "Multiple risk factors for cardiovascular disease",
                LINE_6: "Vascular disease",
                LINE_7: "Hypertension with SBP ≥160 or DBP ≥100 mmHg",
                LINE_8: "Acute deep vein thrombosis or pulmonary embolism, or taking anticoagulants for either condition",
                LINE_9: "Severe or advanced HIV disease",
                FOOTER: "Please refer to the World Health Organization 2015 Medical Eligibility Criteria for a complete list."
            },
            POSSIBLE_SIDE_EFFECTS: {
                LINE_1: "After a laparoscopic permanent contraceptive procedure, women may experience shoulder pain, bloating, and lower abdominal pain or swelling."
            }
        },
        MYTHS_REALITIES: {
            LINE_1: "It ends periods.",
            LINE_CLICK_1: "Female sterilization has no effect on your periods.",
            LINE_2: "It affects libido.",
            LINE_CLICK_2: "Female sterilization will not impact your sexual drive or sexuality.",
            LINE_3: "It leads to weight gain.",
            LINE_CLICK_3: "Female sterilization has no effect on your weight.",
            LINE_4: "It’s reversible.",
            LINE_CLICK_4: "Female sterilization is meant to be permanent. Some women may be able to have it reversed, but reversible procedures may be costly and are not always successful."
        }
    },
    TUBAL_OCCLUSION: {
        TITLE: "Female Sterilization - Hysterioscopic <br>Tubal Occlusion",
        PAGE_TITLE: "Permanent Contraception - Hysterioscopic Tubal Occlusion",
         HEADER_BUTTON_TXT: " Tubal Ligation",
        EFFECTIVENESS: {
            AFTER_TUBAL_OCCLUSION: "After Hysterioscopic tubal occlusion",
            TABLE_HEADER: "Female Sterilization - Hysterioscopic Tubal Occlusion",
            LINE_1: "Highly effective method for women who are certain they don’t want future pregnancy",
            LINE_2: "Inserts placed in your fallopian tubes by a health care provider. Over 3-6 months, the inserts gradually result in blockage of the tubes. Alternative method of contraception must be used for at least 3 months post-procedure"            
        },
        BENEFITS_RISKS: {
            POTENTIAL_NONC_BENEFITS: {
                LINE_1: "No surgery required",
                LINE_2: "No ongoing cost",
                LINE_3: "No change to hormonal \“milieu\”"

            },
            RISKS: {
                LINE_1: "Procedure-related complications may include improper or unsuccessful placement of the insert and/or injury to the tubes or uterus",
                LINE_2: "If pregnancy occurs, ectopic pregnancy should be considered"
            },
            CONTRAINDICATIONS: {
                LINE_1: "Uncertainty about desire to end fertility",
                LINE_2: "Pregnancy or suspected pregnancy",
                LINE_3: "Taking immunosuppressive medication",
                LINE_4: "Previous delivery, miscarriage, or abortion within 6 weeks to 3 months, depending on the type of insert",
                LINE_5: "Current pelvic infection",
                LINE_6: "Inaccessible, technically difficult uterus and fallopian tubes",
                LINE_7: "Allergy to contrast medium",
                LINE_8: "Unwillingness to use another birth control method for the first 3 months",
                LINE_9: "Unwillingness to return 3 months later to check for tubal occlusion",
                LINE_10: "Previous tubal ligation"                
            },
            POSSIBLE_SIDE_EFFECTS: {
                LINE_1: "Cramping, pain, bleeding, and/or spotting are possible on the day of the procedure."
            }
        },
        MYTHS_REALITIES: {
            LINE_1: "It ends periods.",
            LINE_CLICK_1: "Female sterilization has no effect on your periods.",
            LINE_2: "It affects libido.",
            LINE_CLICK_2: "Female sterilization will not impact your sexual drive or sexuality.",
            LINE_3: "It leads to weight gain.",
            LINE_CLICK_3: "Female sterilization has no effect on your weight.",
            LINE_4: "It’s reversible.",
            LINE_CLICK_4: "Female sterilization is meant to be permanent. Some women may be able to have it reversed, but reversible procedures may be costly and are not always successful."
        }
    }
};