angular.module('app.services')
	.filter('replaceBR', function(){
		return function(text){
			return text.replace('<br/>','');
		}
	});